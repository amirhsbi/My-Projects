lockstat.o: lockstat.c /usr/include/stdc-predef.h types.h stat.h user.h \
 param.h
