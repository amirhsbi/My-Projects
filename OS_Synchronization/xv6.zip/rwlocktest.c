#include "types.h"
#include "stat.h"
#include "user.h"

static void
reader(int id)
{
  rw_read_lock();
  printf(1, "[R%d] pid=%d ENTER\n", id, getpid());
  sleep(50);
  printf(1, "[R%d] pid=%d EXIT\n", id, getpid());
  rw_read_unlock();
  exit();
}

static void
writer(int id)
{
  rw_write_lock();
  printf(1, "    [W%d] pid=%d ENTER (exclusive)\n", id, getpid());
  sleep(80);
  printf(1, "    [W%d] pid=%d EXIT\n", id, getpid());
  rw_write_unlock();
  exit();
}

int
main(void)
{
  for(int i = 0; i < 4; i++){
    int pid = fork();
    if(pid == 0) reader(i);
  }

  sleep(10);

  int pid = fork();
  if(pid == 0) writer(1);

  sleep(5);
  for(int i = 4; i < 7; i++){
    int pid2 = fork();
    if(pid2 == 0) reader(i);
  }

   for(int k = 0; k < 1 + 4 + 3; k++)
    wait();


   exit();
}
