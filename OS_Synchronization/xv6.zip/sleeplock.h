
#ifndef _SLEEPLOCK_H_
#define _SLEEPLOCK_H_

#include "types.h"
#include "spinlock.h"

struct proc;

struct sleeplock {
  uint locked;
  struct spinlock lk;
  char *name;

  // NEW: owner tracking
  struct proc *owner;
  int owner_pid;
};

void initsleeplock(struct sleeplock*, char*);
void acquiresleep(struct sleeplock*);
void releasesleep(struct sleeplock*);
int  holdingsleep(struct sleeplock*);

#endif
