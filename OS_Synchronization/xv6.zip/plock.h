#ifndef _PLOCK_H_
#define _PLOCK_H_

#include "types.h"
#include "spinlock.h"

struct proc;

struct plock_node {
  struct proc *p;
  int priority;
  struct plock_node *next;
};

struct plock {
  struct spinlock lk;
  int locked;
  struct proc *owner;
  struct plock_node *head;
};

void init_plock(struct plock *pl);
void plock_acquire(struct plock *pl, int priority);
void release_plock(struct plock *pl);

extern struct plock plock_global;

#endif
