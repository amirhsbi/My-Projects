#include "types.h"
#include "stat.h"
#include "user.h"
#include "param.h"

static void
print_scores(char *tag, uint64 *s, int cpus)
{
  printf(1, "%s\n", tag);
  for(int i = 0; i < cpus; i++){
    uint v = (uint)s[i]; 
    printf(1, "  cpu[%d] score=%d (ratio*2^20)\n", i, v);
  }
}

int
main(void)
{
  uint64 before[NCPU];
  uint64 after[NCPU];

  int cpus = 4;

  for(int i = 0; i < NCPU; i++){
    before[i] = 0;
    after[i] = 0;
  }

  if(getlockstat(before) < 0){
    printf(1, "getlockstat failed (before)\n");
    exit();
  }
  print_scores("Before load:", before, cpus);

  int kids = 16;
  for(int k = 0; k < kids; k++){
    int pid = fork();
    if(pid == 0){
      for(int i = 0; i < 10000; i++){
        uptime();
        if((i % 2000) == 0)
          sleep(1);
      }
      exit();
    }
  }
  for(int k = 0; k < kids; k++)
    wait();

  if(getlockstat(after) < 0){
    printf(1, "getlockstat failed (after)\n");
    exit();
  }
  print_scores("After load:", after, cpus);

  exit();
}
