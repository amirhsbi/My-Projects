rwlock.o: rwlock.c /usr/include/stdc-predef.h types.h defs.h param.h \
 memlayout.h mmu.h proc.h spinlock.h rwlock.h
