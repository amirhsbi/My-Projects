sleeplock.o: sleeplock.c /usr/include/stdc-predef.h types.h x86.h defs.h \
 param.h mmu.h spinlock.h proc.h sleeplock.h
