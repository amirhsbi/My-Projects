#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "plock.h"

struct plock plock_global;

void
init_plock(struct plock *pl)
{
  initlock(&pl->lk, "plock");
  pl->locked = 0;
  pl->owner = 0;
  pl->head = 0;
}

static struct plock_node*
node_alloc(struct proc *p, int prio)
{
  struct plock_node *n = (struct plock_node*)kalloc();
  if(n == 0)
    panic("plock: kalloc failed");
  memset(n, 0, sizeof(*n));
  n->p = p;
  n->priority = prio;
  n->next = 0;
  return n;
}

void
plock_acquire(struct plock *pl, int priority)
{
  acquire(&pl->lk);

  if(pl->locked == 0 && pl->head == 0){
    pl->locked = 1;
    pl->owner = myproc();
    release(&pl->lk);
    return;
  }

  struct plock_node *n = node_alloc(myproc(), priority);
  n->next = pl->head;
  pl->head = n;

  while(pl->owner != myproc()){
    sleep(myproc(), &pl->lk);
  }

  release(&pl->lk);
}

void
release_plock(struct plock *pl)
{
  acquire(&pl->lk);

  if(pl->owner != myproc())
    panic("release_plock: not owner");

  if(pl->head == 0){
    pl->locked = 0;
    pl->owner = 0;
    release(&pl->lk);
    return;
  }

  struct plock_node *prev = 0, *cur = pl->head;
  struct plock_node *maxprev = 0, *maxnode = cur;

  while(cur){
    if(cur->priority > maxnode->priority){
      maxnode = cur;
      maxprev = prev;
    }
    prev = cur;
    cur = cur->next;
  }

  if(maxprev) maxprev->next = maxnode->next;
  else pl->head = maxnode->next;

  pl->locked = 1;
  pl->owner = maxnode->p;
  wakeup(pl->owner);

  kfree((char*)maxnode);
  release(&pl->lk);
}
