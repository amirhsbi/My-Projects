#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "plock.h"
#include "rwlock.h"

static struct sleeplock test_slock;
extern struct spinlock tickslock;
static struct rwlock test_rw;

void
rwlocktestinit(void)
{
  rwlock_init(&test_rw, "test_rw");
}

int
sys_rw_read_lock(void)
{
  rwlock_acquire_read(&test_rw);
  return 0;
}

int
sys_rw_read_unlock(void)
{
  rwlock_release_read(&test_rw);
  return 0;
}

int
sys_rw_write_lock(void)
{
  rwlock_acquire_write(&test_rw);
  return 0;
}

int
sys_rw_write_unlock(void)
{
  rwlock_release_write(&test_rw);
  return 0;
}
static uint64
udiv64(uint64 n, uint64 d)
{
  if(d == 0)
    return ~0ULL;

  uint64 q = 0;
  uint64 r = 0;

  for(int i = 63; i >= 0; i--){
    r = (r << 1) | ((n >> i) & 1ULL);
    if(r >= d){
      r -= d;
      q |= (1ULL << i);
    }
  }
  return q;
}
int
sys_getlockstat(void)
{
  uint64 *score;
  if(argptr(0, (char**)&score, NCPU * sizeof(uint64)) < 0)
    return -1;

  acquire(&tickslock);
  for(int i = 0; i < NCPU; i++){
    uint64 acq = tickslock.count_acq[i];
    uint64 sp  = tickslock.total_spins[i];
    uint64 den = sp + 1ULL;

    uint64 num = (acq << 20);           
    uint64 q = udiv64(num, den);

    if(q > 0xffffffffULL) q = 0xffffffffULL;

    score[i] = q;
  }
  release(&tickslock);

  return 0;
}

// 2) plock syscalls
int
sys_acquire_plock_sys(void)
{
  int pr;
  if(argint(0, &pr) < 0)
    return -1;
  plock_acquire(&plock_global, pr);
  return 0;
}

int
sys_release_plock_sys(void)
{
  release_plock(&plock_global);
  return 0;
}
void
slocktestinit(void)
{
  initsleeplock(&test_slock, "test_slock");
}

int
sys_slock_acquire(void)
{
  acquiresleep(&test_slock);
  return 0;
}

int
sys_slock_release(void)
{
  releasesleep(&test_slock);
  return 0;
}

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
