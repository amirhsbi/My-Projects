#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  printf(1, "parent: acquiring sleeplock\n");
  slock_acquire();

  int pid = fork();
  if(pid == 0){
    printf(1, "child: trying to release sleeplock (should be blocked)\n");
    slock_release();
    printf(1, "child: returned from slock_release\n");
    exit();
  }

  wait();
  printf(1, "parent: releasing sleeplock (should succeed)\n");
  slock_release();
  exit();
}
