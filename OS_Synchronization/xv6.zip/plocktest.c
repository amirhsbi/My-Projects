#include "types.h"
#include "stat.h"
#include "user.h"

static void
child_waiter(int prio)
{
  acquire_plock_sys(prio);
  printf(1, "acquired: pid=%d prio=%d\n", getpid(), prio);
  sleep(20);
  release_plock_sys();
  exit();
}

int
main(void)
{
  int low = fork();
  if(low == 0){
    acquire_plock_sys(10);
    printf(1, "low acquired first: pid=%d prio=10\n", getpid());
    sleep(80);
    printf(1, "low releasing: pid=%d prio=10\n", getpid());
    release_plock_sys();
    exit();
  }

  sleep(10);

  int prios[4] = {50, 40, 30, 20};
  for(int i = 0; i < 4; i++){
    int pid = fork();
    if(pid == 0)
      child_waiter(prios[i]);
  }

  for(int i = 0; i < 5; i++)
    wait();

  exit();
}
