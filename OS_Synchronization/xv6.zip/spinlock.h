#ifndef _SPINLOCK_H_
#define _SPINLOCK_H_

#include "types.h"
#include "param.h"

struct cpu;

struct spinlock {
  uint locked;
  char *name;
  struct cpu *cpu;

  uint64 count_acq[NCPU];
  uint64 total_spins[NCPU];
};

void initlock(struct spinlock*, char*);
void acquire(struct spinlock*);
void release(struct spinlock*);
int holding(struct spinlock*);
void pushcli(void);
void popcli(void);

#endif
