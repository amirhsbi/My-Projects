#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "spinlock.h"
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
  initlock(&lk->lk, "sleeplock");
  lk->name = name;
  lk->locked = 0;
  lk->owner = 0;
  lk->owner_pid = -1;
}

void
acquiresleep(struct sleeplock *lk)
{
  acquire(&lk->lk);
  while(lk->locked)
    sleep(lk, &lk->lk);

  lk->locked = 1;

  // NEW: record owner
  lk->owner = myproc();
  lk->owner_pid = myproc()->pid;

  release(&lk->lk);
}

void
releasesleep(struct sleeplock *lk)
{
  acquire(&lk->lk);

  // NEW: only owner can release
  if(lk->owner != myproc()){
    cprintf("releasesleep blocked: pid %d tried to release '%s' owned by pid %d\n",
            myproc()->pid, lk->name, lk->owner_pid);
    release(&lk->lk);
    return;
  }

  lk->locked = 0;
  lk->owner = 0;
  lk->owner_pid = -1;
  wakeup(lk);
  release(&lk->lk);
}

int
holdingsleep(struct sleeplock *lk)
{
  int r;
  acquire(&lk->lk);
  r = lk->locked && (lk->owner == myproc());
  release(&lk->lk);
  return r;
}
