#include "types.h"
#include "stat.h"
#include "user.h"

void
busy(char c)
{
  int i, j;
  for(i = 0; i < 100; i++){
    for(j = 0; j < 10000000; j++){
    }
    printf(1, &c, 1);
  }
}

int
main(void)
{
  int pid1, pid2;

  pid1 = fork();
  if(pid1 == 0){
    set_priority_syscall(getpid(), 0);
    busy('A');
    exit();
  }

  pid2 = fork();
  if(pid2 == 0){
    set_priority_syscall(getpid(), 2);
    busy('B');
    exit();
  }

  wait();
  wait();
  write(1, "\n", 1);
  exit();
}