#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  if(argc != 3){
    printf(1, "usage: grep_test keyword filename\n");
    exit();
  }

  char buf[256];
  int ret = grep_syscall(argv[1], argv[2], buf, sizeof(buf));

  if(ret == 0)
    printf(1, "found: %s\n", buf);
  else if(ret == 1)
    printf(1, "no match\n");
  else
    printf(1, "error\n");

  exit();
}
