duplicate.o: duplicate.c /usr/include/stdc-predef.h types.h stat.h user.h
