#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  if(argc != 2){
    printf(2, "usage: dup file\n");
    exit();
  }

  int r = make_duplicate(argv[1]);

  if(r == 0)
    printf(1, "duplicate ok\n");
  else if(r == -1)
    printf(1, "source file not found\n");
  else
    printf(1, "duplicate failed\n");

  exit();
}
