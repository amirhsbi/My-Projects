#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int a = 5, b = 3;
  int r = simple_arithmetic_syscall(a, b);
  printf(1, "user: result = %d\n", r);
  exit();
}
