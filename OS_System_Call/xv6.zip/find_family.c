#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  if(argc != 2){
    printf(1, "usage: fam pid\n");
    exit();
  }
  int pid = atoi(argv[1]);
  int r = show_process_family(pid);
  printf(1, "ret = %d\n", r);
  exit();
}