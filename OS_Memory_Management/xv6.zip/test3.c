#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "paging.h"
#include "paging.c"

#define NUM_HOT_PAGES 3
#define NUM_COLD_PAGES 5
#define TOTAL_PAGES (NUM_HOT_PAGES + NUM_COLD_PAGES)
#define OUTER_RUNS 50 
#define INNER_ACCESSES 100 

void access_memory(char* base_addr, int page_index) {
    base_addr[page_index * 4096] = (char)(page_index + '0'); 
}

void
main(int argc, char *argv[])
{
    char *memory_block;
    memory_block = sbrk(TOTAL_PAGES * 4096);
    if (memory_block == (char *)0xffffffff) {
        printf(2, "sbrk failed to allocate memory.\n");
        exit();
    }
    memset(memory_block, 0, TOTAL_PAGES * 4096);
    uint startTime = rdtsc(); 
    int total_recorded_accesses = 0;
    for (int run = 1; run <= OUTER_RUNS; run++) {
      for (int i = 1; i <= INNER_ACCESSES; i++) {
            if (total_recorded_accesses < OUTER_RUNS * INNER_ACCESSES) {
                access_memory(memory_block, 0); total_recorded_accesses++;
            }
            if (total_recorded_accesses < OUTER_RUNS * INNER_ACCESSES) {
                access_memory(memory_block, 1); total_recorded_accesses++;
            }
            if (total_recorded_accesses < OUTER_RUNS * INNER_ACCESSES) {
                access_memory(memory_block, 2); total_recorded_accesses++;
            }

            for (int j = 0; j < NUM_COLD_PAGES; j++) {
                if (total_recorded_accesses < OUTER_RUNS * INNER_ACCESSES) {
                    access_memory(memory_block, NUM_HOT_PAGES + j); 
                    total_recorded_accesses++;
                } else {
                    break;
                }
            }
            
            if (total_recorded_accesses > (run * INNER_ACCESSES) && run < OUTER_RUNS) break;
        }
    }

    uint endTime = rdtsc();
    uint totalTime = endTime - startTime;
    getpagestats(); 
    exit();
    return 0;
}


