#include "types.h"
#include "defs.h"
#include "param.h"
#include "kalloc.c" 
#include "trap.c"
#include "paging.h"

#define ALGO_FIFO 1
#define ALGO_LRU  2
#define ALGO_LFU  3
#define ALGO_CLOCK 4

struct PageTableEntry frame_table[FRAME_TABLE_SIZE];

void frame_table_init(void) {
    initlock(&frame_table_lock, "frame_table");
    for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
        frame_table[i].valid = 0;
        frame_table[i].process_id = -1;
    }
}

void invalidate_process_pages(int pid) {
    acquire(&frame_table_lock);
    for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
        if (frame_table[i].process_id == pid && frame_table[i].valid == 1) {
            frame_table[i].valid = 0;
            frame_table[i].process_id = -1;
        }
    }
    release(&frame_table_lock);
}

struct PageTableEntry* get_or_load_page(uint va, int pid) {
    acquire(&frame_table_lock);
    
    uint vpn = va / PGSIZE;
    for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
        if (frame_table[i].valid == 1 && frame_table[i].process_id == pid && frame_table[i].virtual_page_num == vpn) {
            frame_table[i].access_time = ticks; 
            release(&frame_table_lock);
            return &frame_table[i];
        }
    }
    
    int target_frame = -1;
    for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
        if (frame_table[i].valid == 0) {
            target_frame = i; 
            break;
        }
    }
    if (target_frame == -1) {
        target_frame = select_victim_frame(); 
        if (target_frame == -1) {
             release(&frame_table_lock);
             return 0;
        }
    }
    
    struct PageTableEntry *pte = &frame_table[target_frame];
    
      if (pte->valid == 1 && pte->physical_addr) {
        kfree(pte->physical_addr);
    }
    
    pte->physical_addr = kalloc(); 
    if (pte->physical_addr == 0) {
        release(&frame_table_lock);
        return 0;
    }

    pte->valid = 1;
    pte->process_id = pid;
    pte->virtual_page_num = vpn;
    pte->load_time = ticks;
    pte->access_time = ticks;
    pte->usage_count = 1;

    release(&frame_table_lock);
    return pte;
}

extern int active_page_replacement_algo; 

int select_victim_frame() {
    int victim_idx = -1;
    acquire(&frame_table_lock);

    switch (active_page_replacement_algo) {
        case ALGO_FIFO:
            {
                uint oldest_time = (uint)-1;
                for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
                    if (frame_table[i].load_time < oldest_time) {
                        oldest_time = frame_table[i].load_time;
                        victim_idx = i;
                    }
                }
            }
            break;

        case ALGO_LRU:
            {
                uint latest_time = (uint)-1;
                for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
                    if (frame_table[i].access_time < latest_time) {
                        latest_time = frame_table[i].access_time;
                        victim_idx = i;
                    }
                }
            }
            break;

        case ALGO_LFU:
            {
                uint min_freq = (uint)-1;
                int best_victim = -1;
                
                for (int i = 0; i < FRAME_TABLE_SIZE; i++) {
                    if (frame_table[i].usage_count < min_freq) {
                        min_freq = frame_table[i].usage_count;
                        best_victim = i;
                    } else if (frame_table[i].usage_count == min_freq) {
                        if (frame_table[i].load_time < frame_table[best_victim].load_time) {
                            best_victim = i;
                        }
                    }
                }
                victim_idx = best_victim;
            }
            break;
            
        case ALGO_CLOCK:
            {
                static int clock_hand = 0; 
                int start_hand = clock_hand;
                
                do {
                    struct PageTableEntry *pte = &frame_table[clock_hand];
                                     
                    if (pte->access_time < ticks - 1) { 
                        victim_idx = clock_hand;
                        clock_hand = (clock_hand + 1) % FRAME_TABLE_SIZE;
                        release(&frame_table_lock);
                        return victim_idx;
                    }
                    
                    pte->access_time = ticks;
                    clock_hand = (clock_hand + 1) % FRAME_TABLE_SIZE;
                    
                } while (clock_hand != start_hand);
                
                victim_idx = start_hand; 
            }
            break;

        default:
            victim_idx = -1; 
            break;
    }
    
    release(&frame_table_lock);
    return victim_idx;
}

void update_page_stats(struct proc *p, int active_page_replacement_algo, int is_hit) {
    if (is_hit) {
        switch (active_page_replacement_algo) {
            case ALGO_FIFO: p->stats.fifo_stats.hit_count++; break;
            case ALGO_LRU: p->stats.lru_stats.hit_count++; break;
            case ALGO_LFU: p->stats.fifo_stats.hit_count++; break;
            case ALGO_CLOCK: p->stats.lru_stats.hit_count++; break;
        }
    }
    switch (active_page_replacement_algo) {
        case ALGO_FIFO: p->stats.fifo_stats.total_accesses++; break;
        case ALGO_LRU: p->stats.fifo_stats.total_accesses++; break;
        case ALGO_LFU: p->stats.fifo_stats.total_accesses++; break;
        case ALGO_CLOCK: p->stats.fifo_stats.total_accesses++; break;
    }
}
