#include "user.h"
#include "types.h"
#include "time.h"
#include "paging.h"
#include "paging.c"

#define LARGE_ARRAY_SIZE (4 * 1024 * 1024)
int *data = (int *) 0x10000000; 

void test_memory_access() {
    int i;
    int count = 0;
    int target_pages = 10;
      
    for (i = 0; i < LARGE_ARRAY_SIZE; i += 4096) {
        if (count >= target_pages) break;
        
        data[i / sizeof(int)] = i; 
        count++;
    }
}

int main(int argc, char *argv[]) {
    uint start_time = getticks();
    test_memory_access();
    uint end_time = getticks();
    printf(1, "Program finished. Execution Time: %u ticks\n", end_time - start_time);
    getpagestats(); 
    exit();
    return 0;
}
