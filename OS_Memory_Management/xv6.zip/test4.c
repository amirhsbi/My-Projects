#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "paging.h"
#include "paging.c"

#define NUM_PAGES 5
#define OUTER_RUNS 100

int
main() {
    int pages[NUM_PAGES];

    for (int i = 0; i < NUM_PAGES; i++) {
        pages[i] = i;
    }

    for (int run = 0; run < OUTER_RUNS; run++) {
        pages[0];
        pages[1];
        pages[2];
        pages[3];
        pages[0];
        pages[1];
        pages[4];
    }

    getpagestats(); 
    exit();
    return 0;
}
