#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "paging.h"
#include "paging.c"

#define NUM_PAGES 5
#define NUM_RUNS 4
#define PAGESIZE 4096


#define SYS_PAGETEST 300


void access_page(char* base_addr, int page_index) {
    base_addr[page_index * PAGESIZE] = (char)(page_index + '0');
}

void
main(int argc, char *argv[])
{
    char *memory_block;
    memory_block = sbrk(NUM_PAGES * PAGESIZE);
    if (memory_block == (char *)0xffffffff) {
        printf(2, "sbrk failed\n");
        exit();
    }
    
    memset(memory_block, 0, NUM_PAGES * PAGESIZE);
    for (int run = 0; run < NUM_RUNS; run++) {
      for (int access = 0; access < NUM_PAGES; access++) {
        int page_to_access = access % NUM_PAGES;
        access_page(memory_block, page_to_access);
      }
    }
    getpagestats(); 
    exit();
    return 0;
}
