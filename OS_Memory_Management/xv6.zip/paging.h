#ifndef PAGING_H
#define PAGING_H

#include "types.h"
#include "spinlock.h"

#define FRAME_TABLE_SIZE 4 

struct PageTableEntry {
    char *physical_addr;
    uint virtual_page_num;
    int process_id;
    uint valid;
    uint access_time; 
    uint load_time;   
    uint usage_count; 
};

extern struct PageTableEntry frame_table[FRAME_TABLE_SIZE];
extern struct spinlock frame_table_lock;

void frame_table_init(void);
void invalidate_process_pages(int pid);
struct PageTableEntry* get_or_load_page(uint va, int pid);

#endif
