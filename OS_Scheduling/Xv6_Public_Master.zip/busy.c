#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int n = 3;
  int i, j, pid;

  if(argc > 1)
    n = atoi(argv[1]);

  for(i = 0; i < n; i++){
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0){
      for(j = 0; j < 100000000; j++){
      }
      exit();
    }
  }

  for(i = 0; i < n; i++)
    wait();

  exit();
}
