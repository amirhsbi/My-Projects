#include "types.h"
#include "stat.h"
#include "user.h"

volatile int sink = 0;

void
busy_work(int k)
{
  int i, j;
  for(i = 0; i < k; i++){
    for(j = 0; j < 1000000; j++){
      sink += i + j;
    }
  }
}

int
main(int argc, char *argv[])
{
  int n = 20;
  int i, pid;

  if(argc > 1)
    n = atoi(argv[1]);

  printf(1, "schedtest: n=%d\n", n);

  th_start();

  for(i = 0; i < n; i++){
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0){
      busy_work(5 + (i % 3));
      exit();
    }
  }

  printf(1, "\n=== after fork ===\n");
  printinfo();

  busy_work(10);

  printf(1, "\n=== mid-run ===\n");
  printinfo();

  while(wait() > 0)
    ;

  th_stop();

  printf(1, "\n=== after wait ===\n");
  printinfo();

  exit();
}
