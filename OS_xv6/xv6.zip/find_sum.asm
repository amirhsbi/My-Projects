
_find_sum:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  return p;
}

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	81 ec 88 04 00 00    	sub    $0x488,%esp
  17:	8b 01                	mov    (%ecx),%eax
  19:	8b 51 04             	mov    0x4(%ecx),%edx
  char buf[1024]; int n=0;

  if(argc > 1){
  1c:	83 f8 01             	cmp    $0x1,%eax
  1f:	7e 45                	jle    66 <main+0x66>
  21:	8d 5a 04             	lea    0x4(%edx),%ebx
  24:	8d 34 82             	lea    (%edx,%eax,4),%esi
    int pos=0;
  27:	31 ff                	xor    %edi,%edi
  29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    for(int i=1;i<argc;i++){
      for(char *s=argv[i]; *s; s++) buf[pos++]=*s;
  30:	8b 0b                	mov    (%ebx),%ecx
  32:	89 f8                	mov    %edi,%eax
  34:	0f b6 11             	movzbl (%ecx),%edx
  37:	84 d2                	test   %dl,%dl
  39:	74 17                	je     52 <main+0x52>
  3b:	29 f9                	sub    %edi,%ecx
  3d:	8d 76 00             	lea    0x0(%esi),%esi
  40:	83 c0 01             	add    $0x1,%eax
  43:	88 94 05 e7 fb ff ff 	mov    %dl,-0x419(%ebp,%eax,1)
  4a:	0f b6 14 01          	movzbl (%ecx,%eax,1),%edx
  4e:	84 d2                	test   %dl,%dl
  50:	75 ee                	jne    40 <main+0x40>
      if(i+1<argc) buf[pos++]=' ';
  52:	83 c3 04             	add    $0x4,%ebx
  55:	39 f3                	cmp    %esi,%ebx
  57:	74 2f                	je     88 <main+0x88>
  59:	c6 84 05 e8 fb ff ff 	movb   $0x20,-0x418(%ebp,%eax,1)
  60:	20 
  61:	8d 78 01             	lea    0x1(%eax),%edi
    for(int i=1;i<argc;i++){
  64:	eb ca                	jmp    30 <main+0x30>
    }
    n = pos;
  } else {
    n = read(0, buf, sizeof(buf)-1);
  66:	8d 85 e8 fb ff ff    	lea    -0x418(%ebp),%eax
  6c:	53                   	push   %ebx
  6d:	68 ff 03 00 00       	push   $0x3ff
  72:	50                   	push   %eax
  73:	6a 00                	push   $0x0
  75:	e8 41 05 00 00       	call   5bb <read>
    if(n < 0) n = 0;
  7a:	31 d2                	xor    %edx,%edx
  7c:	85 c0                	test   %eax,%eax
  7e:	0f 48 c2             	cmovs  %edx,%eax
  81:	83 c4 10             	add    $0x10,%esp
  84:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  buf[n]=0;
  88:	c6 84 05 e8 fb ff ff 	movb   $0x0,-0x418(%ebp,%eax,1)
  8f:	00 

  long long sum=0, cur=0; int innum=0;
  for(int i=0;i<n;i++){
  90:	85 c0                	test   %eax,%eax
  92:	0f 8e 91 02 00 00    	jle    329 <main+0x329>
  98:	8d b5 e8 fb ff ff    	lea    -0x418(%ebp),%esi
  long long sum=0, cur=0; int innum=0;
  9e:	31 ff                	xor    %edi,%edi
  a0:	31 c9                	xor    %ecx,%ecx
  a2:	31 db                	xor    %ebx,%ebx
  a4:	c7 85 70 fb ff ff 00 	movl   $0x0,-0x490(%ebp)
  ab:	00 00 00 
  ae:	01 f0                	add    %esi,%eax
  b0:	89 fa                	mov    %edi,%edx
  b2:	89 85 80 fb ff ff    	mov    %eax,-0x480(%ebp)
  b8:	c7 85 74 fb ff ff 00 	movl   $0x0,-0x48c(%ebp)
  bf:	00 00 00 
  c2:	eb 3a                	jmp    fe <main+0xfe>
  c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    char c = buf[i];
    if(c>='0' && c<='9'){ innum=1; cur = cur*10 + (c-'0'); }
  c8:	89 c8                	mov    %ecx,%eax
  ca:	89 da                	mov    %ebx,%edx
  cc:	0f a4 c2 02          	shld   $0x2,%eax,%edx
  d0:	c1 e0 02             	shl    $0x2,%eax
  d3:	01 c8                	add    %ecx,%eax
  d5:	11 da                	adc    %ebx,%edx
  d7:	89 fb                	mov    %edi,%ebx
  d9:	0f be cb             	movsbl %bl,%ecx
  dc:	0f a4 c2 01          	shld   $0x1,%eax,%edx
  e0:	01 c0                	add    %eax,%eax
  e2:	83 e9 30             	sub    $0x30,%ecx
  e5:	89 cb                	mov    %ecx,%ebx
  e7:	c1 fb 1f             	sar    $0x1f,%ebx
  ea:	01 c1                	add    %eax,%ecx
  ec:	11 d3                	adc    %edx,%ebx
  ee:	ba 01 00 00 00       	mov    $0x1,%edx
  for(int i=0;i<n;i++){
  f3:	83 c6 01             	add    $0x1,%esi
  f6:	39 b5 80 fb ff ff    	cmp    %esi,-0x480(%ebp)
  fc:	74 2b                	je     129 <main+0x129>
    char c = buf[i];
  fe:	0f b6 3e             	movzbl (%esi),%edi
    if(c>='0' && c<='9'){ innum=1; cur = cur*10 + (c-'0'); }
 101:	8d 47 d0             	lea    -0x30(%edi),%eax
 104:	3c 09                	cmp    $0x9,%al
 106:	76 c0                	jbe    c8 <main+0xc8>
    else { if(innum){ sum+=cur; cur=0; innum=0; } }
 108:	85 d2                	test   %edx,%edx
 10a:	74 e7                	je     f3 <main+0xf3>
 10c:	01 8d 70 fb ff ff    	add    %ecx,-0x490(%ebp)
 112:	11 9d 74 fb ff ff    	adc    %ebx,-0x48c(%ebp)
 118:	31 d2                	xor    %edx,%edx
 11a:	31 c9                	xor    %ecx,%ecx
 11c:	31 db                	xor    %ebx,%ebx
  for(int i=0;i<n;i++){
 11e:	83 c6 01             	add    $0x1,%esi
 121:	39 b5 80 fb ff ff    	cmp    %esi,-0x480(%ebp)
 127:	75 d5                	jne    fe <main+0xfe>
  }
  if(innum) sum+=cur;
 129:	85 d2                	test   %edx,%edx
 12b:	74 0c                	je     139 <main+0x139>
 12d:	01 8d 70 fb ff ff    	add    %ecx,-0x490(%ebp)
 133:	11 9d 74 fb ff ff    	adc    %ebx,-0x48c(%ebp)

  int fd = open("result.txt", O_CREATE|O_WRONLY);
 139:	83 ec 08             	sub    $0x8,%esp
 13c:	68 01 02 00 00       	push   $0x201
 141:	68 f8 09 00 00       	push   $0x9f8
 146:	e8 98 04 00 00       	call   5e3 <open>
  if(fd < 0){ printf(1,"find_sum: open failed\n"); exit(); }
 14b:	83 c4 10             	add    $0x10,%esp
  int fd = open("result.txt", O_CREATE|O_WRONLY);
 14e:	89 c7                	mov    %eax,%edi
  if(fd < 0){ printf(1,"find_sum: open failed\n"); exit(); }
 150:	85 c0                	test   %eax,%eax
 152:	0f 88 eb 01 00 00    	js     343 <main+0x343>
  if(x==0){ dst[0]='0'; dst[1]='\n'; return 2; }
 158:	8b 95 74 fb ff ff    	mov    -0x48c(%ebp),%edx
 15e:	8b 85 70 fb ff ff    	mov    -0x490(%ebp),%eax
 164:	85 d2                	test   %edx,%edx
 166:	0f 84 9f 01 00 00    	je     30b <main+0x30b>
  if(x<0){ dst[p++]='-'; x=-x; }
 16c:	8b 95 74 fb ff ff    	mov    -0x48c(%ebp),%edx
 172:	8b 85 70 fb ff ff    	mov    -0x490(%ebp),%eax
  char t[32]; int i=0, p=0;
 178:	31 db                	xor    %ebx,%ebx
  if(x<0){ dst[p++]='-'; x=-x; }
 17a:	85 d2                	test   %edx,%edx
 17c:	79 1f                	jns    19d <main+0x19d>
 17e:	f7 d8                	neg    %eax
 180:	c6 85 a8 fb ff ff 2d 	movb   $0x2d,-0x458(%ebp)
 187:	bb 01 00 00 00       	mov    $0x1,%ebx
 18c:	83 d2 00             	adc    $0x0,%edx
 18f:	89 85 70 fb ff ff    	mov    %eax,-0x490(%ebp)
 195:	f7 da                	neg    %edx
 197:	89 95 74 fb ff ff    	mov    %edx,-0x48c(%ebp)
    if(c>='0' && c<='9'){ innum=1; cur = cur*10 + (c-'0'); }
 19d:	31 c9                	xor    %ecx,%ecx
 19f:	8b b5 70 fb ff ff    	mov    -0x490(%ebp),%esi
 1a5:	89 9d 70 fb ff ff    	mov    %ebx,-0x490(%ebp)
 1ab:	89 8d 7c fb ff ff    	mov    %ecx,-0x484(%ebp)
 1b1:	89 bd 78 fb ff ff    	mov    %edi,-0x488(%ebp)
 1b7:	8b bd 74 fb ff ff    	mov    -0x48c(%ebp),%edi
 1bd:	8d 76 00             	lea    0x0(%esi),%esi
  while(x>0){ t[i++] = '0' + (x%10); x/=10; }
 1c0:	89 fb                	mov    %edi,%ebx
 1c2:	89 f1                	mov    %esi,%ecx
 1c4:	89 f2                	mov    %esi,%edx
 1c6:	89 f8                	mov    %edi,%eax
 1c8:	0f ac d9 1c          	shrd   $0x1c,%ebx,%ecx
 1cc:	81 e2 ff ff ff 0f    	and    $0xfffffff,%edx
 1d2:	c1 f8 1f             	sar    $0x1f,%eax
 1d5:	81 e1 ff ff ff 0f    	and    $0xfffffff,%ecx
 1db:	89 85 80 fb ff ff    	mov    %eax,-0x480(%ebp)
 1e1:	83 e0 03             	and    $0x3,%eax
 1e4:	01 d1                	add    %edx,%ecx
 1e6:	89 fa                	mov    %edi,%edx
 1e8:	c1 ea 18             	shr    $0x18,%edx
 1eb:	01 d1                	add    %edx,%ecx
 1ed:	01 c1                	add    %eax,%ecx
 1ef:	b8 cd cc cc cc       	mov    $0xcccccccd,%eax
 1f4:	f7 e1                	mul    %ecx
 1f6:	8b 85 80 fb ff ff    	mov    -0x480(%ebp),%eax
 1fc:	83 e0 fc             	and    $0xfffffffc,%eax
 1ff:	89 d3                	mov    %edx,%ebx
 201:	83 e2 fc             	and    $0xfffffffc,%edx
 204:	c1 eb 02             	shr    $0x2,%ebx
 207:	01 da                	add    %ebx,%edx
 209:	29 d1                	sub    %edx,%ecx
 20b:	01 c1                	add    %eax,%ecx
 20d:	89 c8                	mov    %ecx,%eax
 20f:	89 8d 80 fb ff ff    	mov    %ecx,-0x480(%ebp)
 215:	99                   	cltd
 216:	29 ce                	sub    %ecx,%esi
 218:	b8 cd cc cc cc       	mov    $0xcccccccd,%eax
 21d:	19 d7                	sbb    %edx,%edi
 21f:	89 95 84 fb ff ff    	mov    %edx,-0x47c(%ebp)
 225:	69 d6 cc cc cc cc    	imul   $0xcccccccc,%esi,%edx
 22b:	69 cf cd cc cc cc    	imul   $0xcccccccd,%edi,%ecx
 231:	01 d1                	add    %edx,%ecx
 233:	f7 e6                	mul    %esi
 235:	89 d7                	mov    %edx,%edi
 237:	89 c6                	mov    %eax,%esi
 239:	01 cf                	add    %ecx,%edi
 23b:	89 fb                	mov    %edi,%ebx
 23d:	89 f9                	mov    %edi,%ecx
 23f:	c1 fb 1f             	sar    $0x1f,%ebx
 242:	31 d8                	xor    %ebx,%eax
 244:	29 d8                	sub    %ebx,%eax
 246:	83 e0 01             	and    $0x1,%eax
 249:	31 d8                	xor    %ebx,%eax
 24b:	29 d8                	sub    %ebx,%eax
 24d:	bb 05 00 00 00       	mov    $0x5,%ebx
 252:	f7 e3                	mul    %ebx
 254:	03 85 80 fb ff ff    	add    -0x480(%ebp),%eax
 25a:	c1 e9 1f             	shr    $0x1f,%ecx
 25d:	31 db                	xor    %ebx,%ebx
 25f:	01 ce                	add    %ecx,%esi
 261:	8b 95 7c fb ff ff    	mov    -0x484(%ebp),%edx
 267:	11 df                	adc    %ebx,%edi
 269:	83 c0 30             	add    $0x30,%eax
 26c:	0f ac fe 01          	shrd   $0x1,%edi,%esi
 270:	88 84 15 88 fb ff ff 	mov    %al,-0x478(%ebp,%edx,1)
 277:	d1 ff                	sar    $1,%edi
 279:	8d 5a 01             	lea    0x1(%edx),%ebx
 27c:	89 f0                	mov    %esi,%eax
 27e:	89 9d 7c fb ff ff    	mov    %ebx,-0x484(%ebp)
 284:	09 f8                	or     %edi,%eax
 286:	0f 85 34 ff ff ff    	jne    1c0 <main+0x1c0>
 28c:	8b bd 78 fb ff ff    	mov    -0x488(%ebp),%edi
 292:	89 d1                	mov    %edx,%ecx
 294:	8b 9d 70 fb ff ff    	mov    -0x490(%ebp),%ebx
 29a:	8d 85 88 fb ff ff    	lea    -0x478(%ebp),%eax
 2a0:	89 8d 7c fb ff ff    	mov    %ecx,-0x484(%ebp)
 2a6:	8d b5 a8 fb ff ff    	lea    -0x458(%ebp),%esi
 2ac:	01 d0                	add    %edx,%eax
 2ae:	89 bd 80 fb ff ff    	mov    %edi,-0x480(%ebp)
 2b4:	8d 14 1e             	lea    (%esi,%ebx,1),%edx
 2b7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2be:	00 
 2bf:	90                   	nop
  while(i--) dst[p++] = t[i];
 2c0:	0f b6 08             	movzbl (%eax),%ecx
 2c3:	89 c7                	mov    %eax,%edi
 2c5:	83 c2 01             	add    $0x1,%edx
 2c8:	83 e8 01             	sub    $0x1,%eax
 2cb:	88 4a ff             	mov    %cl,-0x1(%edx)
 2ce:	8d 8d 88 fb ff ff    	lea    -0x478(%ebp),%ecx
 2d4:	39 cf                	cmp    %ecx,%edi
 2d6:	75 e8                	jne    2c0 <main+0x2c0>
  dst[p++] = '\n';
 2d8:	8b 8d 7c fb ff ff    	mov    -0x484(%ebp),%ecx
 2de:	8b bd 80 fb ff ff    	mov    -0x480(%ebp),%edi
 2e4:	8d 44 19 02          	lea    0x2(%ecx,%ebx,1),%eax
 2e8:	83 e9 18             	sub    $0x18,%ecx
 2eb:	01 e9                	add    %ebp,%ecx
 2ed:	c6 84 0b c1 fb ff ff 	movb   $0xa,-0x43f(%ebx,%ecx,1)
 2f4:	0a 

  char out[64];
  int len = lltoa(sum, out);
  write(fd, out, len);
 2f5:	52                   	push   %edx
 2f6:	50                   	push   %eax
 2f7:	56                   	push   %esi
 2f8:	57                   	push   %edi
 2f9:	e8 c5 02 00 00       	call   5c3 <write>
  close(fd);
 2fe:	89 3c 24             	mov    %edi,(%esp)
 301:	e8 c5 02 00 00       	call   5cb <close>
  exit();
 306:	e8 98 02 00 00       	call   5a3 <exit>
  if(x==0){ dst[0]='0'; dst[1]='\n'; return 2; }
 30b:	85 c0                	test   %eax,%eax
 30d:	0f 85 59 fe ff ff    	jne    16c <main+0x16c>
 313:	66 c7 85 a8 fb ff ff 	movw   $0xa30,-0x458(%ebp)
 31a:	30 0a 
 31c:	b8 02 00 00 00       	mov    $0x2,%eax
 321:	8d b5 a8 fb ff ff    	lea    -0x458(%ebp),%esi
 327:	eb cc                	jmp    2f5 <main+0x2f5>
  int fd = open("result.txt", O_CREATE|O_WRONLY);
 329:	56                   	push   %esi
 32a:	56                   	push   %esi
 32b:	68 01 02 00 00       	push   $0x201
 330:	68 f8 09 00 00       	push   $0x9f8
 335:	e8 a9 02 00 00       	call   5e3 <open>
  if(fd < 0){ printf(1,"find_sum: open failed\n"); exit(); }
 33a:	83 c4 10             	add    $0x10,%esp
  int fd = open("result.txt", O_CREATE|O_WRONLY);
 33d:	89 c7                	mov    %eax,%edi
  if(fd < 0){ printf(1,"find_sum: open failed\n"); exit(); }
 33f:	85 c0                	test   %eax,%eax
 341:	79 d0                	jns    313 <main+0x313>
 343:	53                   	push   %ebx
 344:	53                   	push   %ebx
 345:	68 03 0a 00 00       	push   $0xa03
 34a:	6a 01                	push   $0x1
 34c:	e8 9f 03 00 00       	call   6f0 <printf>
 351:	e8 4d 02 00 00       	call   5a3 <exit>
 356:	66 90                	xchg   %ax,%ax
 358:	66 90                	xchg   %ax,%ax
 35a:	66 90                	xchg   %ax,%ax
 35c:	66 90                	xchg   %ax,%ax
 35e:	66 90                	xchg   %ax,%ax

00000360 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 360:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 361:	31 c0                	xor    %eax,%eax
{
 363:	89 e5                	mov    %esp,%ebp
 365:	53                   	push   %ebx
 366:	8b 4d 08             	mov    0x8(%ebp),%ecx
 369:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 36c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 370:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 374:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 377:	83 c0 01             	add    $0x1,%eax
 37a:	84 d2                	test   %dl,%dl
 37c:	75 f2                	jne    370 <strcpy+0x10>
    ;
  return os;
}
 37e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 381:	89 c8                	mov    %ecx,%eax
 383:	c9                   	leave
 384:	c3                   	ret
 385:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 38c:	00 
 38d:	8d 76 00             	lea    0x0(%esi),%esi

00000390 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 390:	55                   	push   %ebp
 391:	89 e5                	mov    %esp,%ebp
 393:	53                   	push   %ebx
 394:	8b 55 08             	mov    0x8(%ebp),%edx
 397:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 39a:	0f b6 02             	movzbl (%edx),%eax
 39d:	84 c0                	test   %al,%al
 39f:	75 17                	jne    3b8 <strcmp+0x28>
 3a1:	eb 3a                	jmp    3dd <strcmp+0x4d>
 3a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 3a8:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 3ac:	83 c2 01             	add    $0x1,%edx
 3af:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
 3b2:	84 c0                	test   %al,%al
 3b4:	74 1a                	je     3d0 <strcmp+0x40>
 3b6:	89 d9                	mov    %ebx,%ecx
 3b8:	0f b6 19             	movzbl (%ecx),%ebx
 3bb:	38 c3                	cmp    %al,%bl
 3bd:	74 e9                	je     3a8 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
 3bf:	29 d8                	sub    %ebx,%eax
}
 3c1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 3c4:	c9                   	leave
 3c5:	c3                   	ret
 3c6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3cd:	00 
 3ce:	66 90                	xchg   %ax,%ax
  return (uchar)*p - (uchar)*q;
 3d0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 3d4:	31 c0                	xor    %eax,%eax
 3d6:	29 d8                	sub    %ebx,%eax
}
 3d8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 3db:	c9                   	leave
 3dc:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 3dd:	0f b6 19             	movzbl (%ecx),%ebx
 3e0:	31 c0                	xor    %eax,%eax
 3e2:	eb db                	jmp    3bf <strcmp+0x2f>
 3e4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3eb:	00 
 3ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003f0 <strlen>:

uint
strlen(const char *s)
{
 3f0:	55                   	push   %ebp
 3f1:	89 e5                	mov    %esp,%ebp
 3f3:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 3f6:	80 3a 00             	cmpb   $0x0,(%edx)
 3f9:	74 15                	je     410 <strlen+0x20>
 3fb:	31 c0                	xor    %eax,%eax
 3fd:	8d 76 00             	lea    0x0(%esi),%esi
 400:	83 c0 01             	add    $0x1,%eax
 403:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 407:	89 c1                	mov    %eax,%ecx
 409:	75 f5                	jne    400 <strlen+0x10>
    ;
  return n;
}
 40b:	89 c8                	mov    %ecx,%eax
 40d:	5d                   	pop    %ebp
 40e:	c3                   	ret
 40f:	90                   	nop
  for(n = 0; s[n]; n++)
 410:	31 c9                	xor    %ecx,%ecx
}
 412:	5d                   	pop    %ebp
 413:	89 c8                	mov    %ecx,%eax
 415:	c3                   	ret
 416:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 41d:	00 
 41e:	66 90                	xchg   %ax,%ax

00000420 <memset>:

void*
memset(void *dst, int c, uint n)
{
 420:	55                   	push   %ebp
 421:	89 e5                	mov    %esp,%ebp
 423:	57                   	push   %edi
 424:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 427:	8b 4d 10             	mov    0x10(%ebp),%ecx
 42a:	8b 45 0c             	mov    0xc(%ebp),%eax
 42d:	89 d7                	mov    %edx,%edi
 42f:	fc                   	cld
 430:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 432:	8b 7d fc             	mov    -0x4(%ebp),%edi
 435:	89 d0                	mov    %edx,%eax
 437:	c9                   	leave
 438:	c3                   	ret
 439:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000440 <strchr>:

char*
strchr(const char *s, char c)
{
 440:	55                   	push   %ebp
 441:	89 e5                	mov    %esp,%ebp
 443:	8b 45 08             	mov    0x8(%ebp),%eax
 446:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 44a:	0f b6 10             	movzbl (%eax),%edx
 44d:	84 d2                	test   %dl,%dl
 44f:	75 12                	jne    463 <strchr+0x23>
 451:	eb 1d                	jmp    470 <strchr+0x30>
 453:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 458:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 45c:	83 c0 01             	add    $0x1,%eax
 45f:	84 d2                	test   %dl,%dl
 461:	74 0d                	je     470 <strchr+0x30>
    if(*s == c)
 463:	38 d1                	cmp    %dl,%cl
 465:	75 f1                	jne    458 <strchr+0x18>
      return (char*)s;
  return 0;
}
 467:	5d                   	pop    %ebp
 468:	c3                   	ret
 469:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 470:	31 c0                	xor    %eax,%eax
}
 472:	5d                   	pop    %ebp
 473:	c3                   	ret
 474:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 47b:	00 
 47c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000480 <gets>:

char*
gets(char *buf, int max)
{
 480:	55                   	push   %ebp
 481:	89 e5                	mov    %esp,%ebp
 483:	57                   	push   %edi
 484:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 485:	8d 75 e7             	lea    -0x19(%ebp),%esi
{
 488:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 489:	31 db                	xor    %ebx,%ebx
{
 48b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 48e:	eb 27                	jmp    4b7 <gets+0x37>
    cc = read(0, &c, 1);
 490:	83 ec 04             	sub    $0x4,%esp
 493:	6a 01                	push   $0x1
 495:	56                   	push   %esi
 496:	6a 00                	push   $0x0
 498:	e8 1e 01 00 00       	call   5bb <read>
    if(cc < 1)
 49d:	83 c4 10             	add    $0x10,%esp
 4a0:	85 c0                	test   %eax,%eax
 4a2:	7e 1d                	jle    4c1 <gets+0x41>
      break;
    buf[i++] = c;
 4a4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 4a8:	8b 55 08             	mov    0x8(%ebp),%edx
 4ab:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 4af:	3c 0a                	cmp    $0xa,%al
 4b1:	74 10                	je     4c3 <gets+0x43>
 4b3:	3c 0d                	cmp    $0xd,%al
 4b5:	74 0c                	je     4c3 <gets+0x43>
  for(i=0; i+1 < max; ){
 4b7:	89 df                	mov    %ebx,%edi
 4b9:	83 c3 01             	add    $0x1,%ebx
 4bc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 4bf:	7c cf                	jl     490 <gets+0x10>
 4c1:	89 fb                	mov    %edi,%ebx
      break;
  }
  buf[i] = '\0';
 4c3:	8b 45 08             	mov    0x8(%ebp),%eax
 4c6:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
  return buf;
}
 4ca:	8d 65 f4             	lea    -0xc(%ebp),%esp
 4cd:	5b                   	pop    %ebx
 4ce:	5e                   	pop    %esi
 4cf:	5f                   	pop    %edi
 4d0:	5d                   	pop    %ebp
 4d1:	c3                   	ret
 4d2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4d9:	00 
 4da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

000004e0 <stat>:

int
stat(const char *n, struct stat *st)
{
 4e0:	55                   	push   %ebp
 4e1:	89 e5                	mov    %esp,%ebp
 4e3:	56                   	push   %esi
 4e4:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4e5:	83 ec 08             	sub    $0x8,%esp
 4e8:	6a 00                	push   $0x0
 4ea:	ff 75 08             	push   0x8(%ebp)
 4ed:	e8 f1 00 00 00       	call   5e3 <open>
  if(fd < 0)
 4f2:	83 c4 10             	add    $0x10,%esp
 4f5:	85 c0                	test   %eax,%eax
 4f7:	78 27                	js     520 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 4f9:	83 ec 08             	sub    $0x8,%esp
 4fc:	ff 75 0c             	push   0xc(%ebp)
 4ff:	89 c3                	mov    %eax,%ebx
 501:	50                   	push   %eax
 502:	e8 f4 00 00 00       	call   5fb <fstat>
  close(fd);
 507:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 50a:	89 c6                	mov    %eax,%esi
  close(fd);
 50c:	e8 ba 00 00 00       	call   5cb <close>
  return r;
 511:	83 c4 10             	add    $0x10,%esp
}
 514:	8d 65 f8             	lea    -0x8(%ebp),%esp
 517:	89 f0                	mov    %esi,%eax
 519:	5b                   	pop    %ebx
 51a:	5e                   	pop    %esi
 51b:	5d                   	pop    %ebp
 51c:	c3                   	ret
 51d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 520:	be ff ff ff ff       	mov    $0xffffffff,%esi
 525:	eb ed                	jmp    514 <stat+0x34>
 527:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 52e:	00 
 52f:	90                   	nop

00000530 <atoi>:

int
atoi(const char *s)
{
 530:	55                   	push   %ebp
 531:	89 e5                	mov    %esp,%ebp
 533:	53                   	push   %ebx
 534:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 537:	0f be 02             	movsbl (%edx),%eax
 53a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 53d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 540:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 545:	77 1e                	ja     565 <atoi+0x35>
 547:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 54e:	00 
 54f:	90                   	nop
    n = n*10 + *s++ - '0';
 550:	83 c2 01             	add    $0x1,%edx
 553:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 556:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 55a:	0f be 02             	movsbl (%edx),%eax
 55d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 560:	80 fb 09             	cmp    $0x9,%bl
 563:	76 eb                	jbe    550 <atoi+0x20>
  return n;
}
 565:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 568:	89 c8                	mov    %ecx,%eax
 56a:	c9                   	leave
 56b:	c3                   	ret
 56c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000570 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 570:	55                   	push   %ebp
 571:	89 e5                	mov    %esp,%ebp
 573:	57                   	push   %edi
 574:	8b 45 10             	mov    0x10(%ebp),%eax
 577:	8b 55 08             	mov    0x8(%ebp),%edx
 57a:	56                   	push   %esi
 57b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 57e:	85 c0                	test   %eax,%eax
 580:	7e 13                	jle    595 <memmove+0x25>
 582:	01 d0                	add    %edx,%eax
  dst = vdst;
 584:	89 d7                	mov    %edx,%edi
 586:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 58d:	00 
 58e:	66 90                	xchg   %ax,%ax
    *dst++ = *src++;
 590:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 591:	39 f8                	cmp    %edi,%eax
 593:	75 fb                	jne    590 <memmove+0x20>
  return vdst;
}
 595:	5e                   	pop    %esi
 596:	89 d0                	mov    %edx,%eax
 598:	5f                   	pop    %edi
 599:	5d                   	pop    %ebp
 59a:	c3                   	ret

0000059b <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 59b:	b8 01 00 00 00       	mov    $0x1,%eax
 5a0:	cd 40                	int    $0x40
 5a2:	c3                   	ret

000005a3 <exit>:
SYSCALL(exit)
 5a3:	b8 02 00 00 00       	mov    $0x2,%eax
 5a8:	cd 40                	int    $0x40
 5aa:	c3                   	ret

000005ab <wait>:
SYSCALL(wait)
 5ab:	b8 03 00 00 00       	mov    $0x3,%eax
 5b0:	cd 40                	int    $0x40
 5b2:	c3                   	ret

000005b3 <pipe>:
SYSCALL(pipe)
 5b3:	b8 04 00 00 00       	mov    $0x4,%eax
 5b8:	cd 40                	int    $0x40
 5ba:	c3                   	ret

000005bb <read>:
SYSCALL(read)
 5bb:	b8 05 00 00 00       	mov    $0x5,%eax
 5c0:	cd 40                	int    $0x40
 5c2:	c3                   	ret

000005c3 <write>:
SYSCALL(write)
 5c3:	b8 10 00 00 00       	mov    $0x10,%eax
 5c8:	cd 40                	int    $0x40
 5ca:	c3                   	ret

000005cb <close>:
SYSCALL(close)
 5cb:	b8 15 00 00 00       	mov    $0x15,%eax
 5d0:	cd 40                	int    $0x40
 5d2:	c3                   	ret

000005d3 <kill>:
SYSCALL(kill)
 5d3:	b8 06 00 00 00       	mov    $0x6,%eax
 5d8:	cd 40                	int    $0x40
 5da:	c3                   	ret

000005db <exec>:
SYSCALL(exec)
 5db:	b8 07 00 00 00       	mov    $0x7,%eax
 5e0:	cd 40                	int    $0x40
 5e2:	c3                   	ret

000005e3 <open>:
SYSCALL(open)
 5e3:	b8 0f 00 00 00       	mov    $0xf,%eax
 5e8:	cd 40                	int    $0x40
 5ea:	c3                   	ret

000005eb <mknod>:
SYSCALL(mknod)
 5eb:	b8 11 00 00 00       	mov    $0x11,%eax
 5f0:	cd 40                	int    $0x40
 5f2:	c3                   	ret

000005f3 <unlink>:
SYSCALL(unlink)
 5f3:	b8 12 00 00 00       	mov    $0x12,%eax
 5f8:	cd 40                	int    $0x40
 5fa:	c3                   	ret

000005fb <fstat>:
SYSCALL(fstat)
 5fb:	b8 08 00 00 00       	mov    $0x8,%eax
 600:	cd 40                	int    $0x40
 602:	c3                   	ret

00000603 <link>:
SYSCALL(link)
 603:	b8 13 00 00 00       	mov    $0x13,%eax
 608:	cd 40                	int    $0x40
 60a:	c3                   	ret

0000060b <mkdir>:
SYSCALL(mkdir)
 60b:	b8 14 00 00 00       	mov    $0x14,%eax
 610:	cd 40                	int    $0x40
 612:	c3                   	ret

00000613 <chdir>:
SYSCALL(chdir)
 613:	b8 09 00 00 00       	mov    $0x9,%eax
 618:	cd 40                	int    $0x40
 61a:	c3                   	ret

0000061b <dup>:
SYSCALL(dup)
 61b:	b8 0a 00 00 00       	mov    $0xa,%eax
 620:	cd 40                	int    $0x40
 622:	c3                   	ret

00000623 <getpid>:
SYSCALL(getpid)
 623:	b8 0b 00 00 00       	mov    $0xb,%eax
 628:	cd 40                	int    $0x40
 62a:	c3                   	ret

0000062b <sbrk>:
SYSCALL(sbrk)
 62b:	b8 0c 00 00 00       	mov    $0xc,%eax
 630:	cd 40                	int    $0x40
 632:	c3                   	ret

00000633 <sleep>:
SYSCALL(sleep)
 633:	b8 0d 00 00 00       	mov    $0xd,%eax
 638:	cd 40                	int    $0x40
 63a:	c3                   	ret

0000063b <uptime>:
SYSCALL(uptime)
 63b:	b8 0e 00 00 00       	mov    $0xe,%eax
 640:	cd 40                	int    $0x40
 642:	c3                   	ret
 643:	66 90                	xchg   %ax,%ax
 645:	66 90                	xchg   %ax,%ax
 647:	66 90                	xchg   %ax,%ax
 649:	66 90                	xchg   %ax,%ax
 64b:	66 90                	xchg   %ax,%ax
 64d:	66 90                	xchg   %ax,%ax
 64f:	90                   	nop

00000650 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 650:	55                   	push   %ebp
 651:	89 e5                	mov    %esp,%ebp
 653:	57                   	push   %edi
 654:	56                   	push   %esi
 655:	53                   	push   %ebx
 656:	89 cb                	mov    %ecx,%ebx
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 658:	89 d1                	mov    %edx,%ecx
{
 65a:	83 ec 3c             	sub    $0x3c,%esp
 65d:	89 45 c0             	mov    %eax,-0x40(%ebp)
  if(sgn && xx < 0){
 660:	85 d2                	test   %edx,%edx
 662:	0f 89 80 00 00 00    	jns    6e8 <printint+0x98>
 668:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 66c:	74 7a                	je     6e8 <printint+0x98>
    x = -xx;
 66e:	f7 d9                	neg    %ecx
    neg = 1;
 670:	b8 01 00 00 00       	mov    $0x1,%eax
  } else {
    x = xx;
  }

  i = 0;
 675:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 678:	31 f6                	xor    %esi,%esi
 67a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 680:	89 c8                	mov    %ecx,%eax
 682:	31 d2                	xor    %edx,%edx
 684:	89 f7                	mov    %esi,%edi
 686:	f7 f3                	div    %ebx
 688:	8d 76 01             	lea    0x1(%esi),%esi
 68b:	0f b6 92 7c 0a 00 00 	movzbl 0xa7c(%edx),%edx
 692:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 696:	89 ca                	mov    %ecx,%edx
 698:	89 c1                	mov    %eax,%ecx
 69a:	39 da                	cmp    %ebx,%edx
 69c:	73 e2                	jae    680 <printint+0x30>
  if(neg)
 69e:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 6a1:	85 c0                	test   %eax,%eax
 6a3:	74 07                	je     6ac <printint+0x5c>
    buf[i++] = '-';
 6a5:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)

  while(--i >= 0)
 6aa:	89 f7                	mov    %esi,%edi
 6ac:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 6af:	8b 75 c0             	mov    -0x40(%ebp),%esi
 6b2:	01 df                	add    %ebx,%edi
 6b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    putc(fd, buf[i]);
 6b8:	0f b6 07             	movzbl (%edi),%eax
  write(fd, &c, 1);
 6bb:	83 ec 04             	sub    $0x4,%esp
 6be:	88 45 d7             	mov    %al,-0x29(%ebp)
 6c1:	8d 45 d7             	lea    -0x29(%ebp),%eax
 6c4:	6a 01                	push   $0x1
 6c6:	50                   	push   %eax
 6c7:	56                   	push   %esi
 6c8:	e8 f6 fe ff ff       	call   5c3 <write>
  while(--i >= 0)
 6cd:	89 f8                	mov    %edi,%eax
 6cf:	83 c4 10             	add    $0x10,%esp
 6d2:	83 ef 01             	sub    $0x1,%edi
 6d5:	39 c3                	cmp    %eax,%ebx
 6d7:	75 df                	jne    6b8 <printint+0x68>
}
 6d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6dc:	5b                   	pop    %ebx
 6dd:	5e                   	pop    %esi
 6de:	5f                   	pop    %edi
 6df:	5d                   	pop    %ebp
 6e0:	c3                   	ret
 6e1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 6e8:	31 c0                	xor    %eax,%eax
 6ea:	eb 89                	jmp    675 <printint+0x25>
 6ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000006f0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 6f0:	55                   	push   %ebp
 6f1:	89 e5                	mov    %esp,%ebp
 6f3:	57                   	push   %edi
 6f4:	56                   	push   %esi
 6f5:	53                   	push   %ebx
 6f6:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 6f9:	8b 75 0c             	mov    0xc(%ebp),%esi
{
 6fc:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i = 0; fmt[i]; i++){
 6ff:	0f b6 1e             	movzbl (%esi),%ebx
 702:	83 c6 01             	add    $0x1,%esi
 705:	84 db                	test   %bl,%bl
 707:	74 67                	je     770 <printf+0x80>
 709:	8d 4d 10             	lea    0x10(%ebp),%ecx
 70c:	31 d2                	xor    %edx,%edx
 70e:	89 4d d0             	mov    %ecx,-0x30(%ebp)
 711:	eb 34                	jmp    747 <printf+0x57>
 713:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 718:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 71b:	ba 25 00 00 00       	mov    $0x25,%edx
      if(c == '%'){
 720:	83 f8 25             	cmp    $0x25,%eax
 723:	74 18                	je     73d <printf+0x4d>
  write(fd, &c, 1);
 725:	83 ec 04             	sub    $0x4,%esp
 728:	8d 45 e7             	lea    -0x19(%ebp),%eax
 72b:	88 5d e7             	mov    %bl,-0x19(%ebp)
 72e:	6a 01                	push   $0x1
 730:	50                   	push   %eax
 731:	57                   	push   %edi
 732:	e8 8c fe ff ff       	call   5c3 <write>
 737:	8b 55 d4             	mov    -0x2c(%ebp),%edx
      } else {
        putc(fd, c);
 73a:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 73d:	0f b6 1e             	movzbl (%esi),%ebx
 740:	83 c6 01             	add    $0x1,%esi
 743:	84 db                	test   %bl,%bl
 745:	74 29                	je     770 <printf+0x80>
    c = fmt[i] & 0xff;
 747:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 74a:	85 d2                	test   %edx,%edx
 74c:	74 ca                	je     718 <printf+0x28>
      }
    } else if(state == '%'){
 74e:	83 fa 25             	cmp    $0x25,%edx
 751:	75 ea                	jne    73d <printf+0x4d>
      if(c == 'd'){
 753:	83 f8 25             	cmp    $0x25,%eax
 756:	0f 84 04 01 00 00    	je     860 <printf+0x170>
 75c:	83 e8 63             	sub    $0x63,%eax
 75f:	83 f8 15             	cmp    $0x15,%eax
 762:	77 1c                	ja     780 <printf+0x90>
 764:	ff 24 85 24 0a 00 00 	jmp    *0xa24(,%eax,4)
 76b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 770:	8d 65 f4             	lea    -0xc(%ebp),%esp
 773:	5b                   	pop    %ebx
 774:	5e                   	pop    %esi
 775:	5f                   	pop    %edi
 776:	5d                   	pop    %ebp
 777:	c3                   	ret
 778:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 77f:	00 
  write(fd, &c, 1);
 780:	83 ec 04             	sub    $0x4,%esp
 783:	8d 55 e7             	lea    -0x19(%ebp),%edx
 786:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 78a:	6a 01                	push   $0x1
 78c:	52                   	push   %edx
 78d:	89 55 d4             	mov    %edx,-0x2c(%ebp)
 790:	57                   	push   %edi
 791:	e8 2d fe ff ff       	call   5c3 <write>
 796:	83 c4 0c             	add    $0xc,%esp
 799:	88 5d e7             	mov    %bl,-0x19(%ebp)
 79c:	6a 01                	push   $0x1
 79e:	8b 55 d4             	mov    -0x2c(%ebp),%edx
 7a1:	52                   	push   %edx
 7a2:	57                   	push   %edi
 7a3:	e8 1b fe ff ff       	call   5c3 <write>
        putc(fd, c);
 7a8:	83 c4 10             	add    $0x10,%esp
      state = 0;
 7ab:	31 d2                	xor    %edx,%edx
 7ad:	eb 8e                	jmp    73d <printf+0x4d>
 7af:	90                   	nop
        printint(fd, *ap, 16, 0);
 7b0:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 7b3:	83 ec 0c             	sub    $0xc,%esp
 7b6:	b9 10 00 00 00       	mov    $0x10,%ecx
 7bb:	8b 13                	mov    (%ebx),%edx
 7bd:	6a 00                	push   $0x0
 7bf:	89 f8                	mov    %edi,%eax
        ap++;
 7c1:	83 c3 04             	add    $0x4,%ebx
        printint(fd, *ap, 16, 0);
 7c4:	e8 87 fe ff ff       	call   650 <printint>
        ap++;
 7c9:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 7cc:	83 c4 10             	add    $0x10,%esp
      state = 0;
 7cf:	31 d2                	xor    %edx,%edx
 7d1:	e9 67 ff ff ff       	jmp    73d <printf+0x4d>
        s = (char*)*ap;
 7d6:	8b 45 d0             	mov    -0x30(%ebp),%eax
 7d9:	8b 18                	mov    (%eax),%ebx
        ap++;
 7db:	83 c0 04             	add    $0x4,%eax
 7de:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 7e1:	85 db                	test   %ebx,%ebx
 7e3:	0f 84 87 00 00 00    	je     870 <printf+0x180>
        while(*s != 0){
 7e9:	0f b6 03             	movzbl (%ebx),%eax
      state = 0;
 7ec:	31 d2                	xor    %edx,%edx
        while(*s != 0){
 7ee:	84 c0                	test   %al,%al
 7f0:	0f 84 47 ff ff ff    	je     73d <printf+0x4d>
 7f6:	8d 55 e7             	lea    -0x19(%ebp),%edx
 7f9:	89 75 d4             	mov    %esi,-0x2c(%ebp)
 7fc:	89 de                	mov    %ebx,%esi
 7fe:	89 d3                	mov    %edx,%ebx
  write(fd, &c, 1);
 800:	83 ec 04             	sub    $0x4,%esp
 803:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 806:	83 c6 01             	add    $0x1,%esi
  write(fd, &c, 1);
 809:	6a 01                	push   $0x1
 80b:	53                   	push   %ebx
 80c:	57                   	push   %edi
 80d:	e8 b1 fd ff ff       	call   5c3 <write>
        while(*s != 0){
 812:	0f b6 06             	movzbl (%esi),%eax
 815:	83 c4 10             	add    $0x10,%esp
 818:	84 c0                	test   %al,%al
 81a:	75 e4                	jne    800 <printf+0x110>
      state = 0;
 81c:	8b 75 d4             	mov    -0x2c(%ebp),%esi
 81f:	31 d2                	xor    %edx,%edx
 821:	e9 17 ff ff ff       	jmp    73d <printf+0x4d>
        printint(fd, *ap, 10, 1);
 826:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 829:	83 ec 0c             	sub    $0xc,%esp
 82c:	b9 0a 00 00 00       	mov    $0xa,%ecx
 831:	8b 13                	mov    (%ebx),%edx
 833:	6a 01                	push   $0x1
 835:	eb 88                	jmp    7bf <printf+0xcf>
        putc(fd, *ap);
 837:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  write(fd, &c, 1);
 83a:	83 ec 04             	sub    $0x4,%esp
 83d:	8d 55 e7             	lea    -0x19(%ebp),%edx
        putc(fd, *ap);
 840:	8b 03                	mov    (%ebx),%eax
        ap++;
 842:	83 c3 04             	add    $0x4,%ebx
        putc(fd, *ap);
 845:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 848:	6a 01                	push   $0x1
 84a:	52                   	push   %edx
 84b:	57                   	push   %edi
 84c:	e8 72 fd ff ff       	call   5c3 <write>
        ap++;
 851:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 854:	83 c4 10             	add    $0x10,%esp
      state = 0;
 857:	31 d2                	xor    %edx,%edx
 859:	e9 df fe ff ff       	jmp    73d <printf+0x4d>
 85e:	66 90                	xchg   %ax,%ax
  write(fd, &c, 1);
 860:	83 ec 04             	sub    $0x4,%esp
 863:	88 5d e7             	mov    %bl,-0x19(%ebp)
 866:	8d 55 e7             	lea    -0x19(%ebp),%edx
 869:	6a 01                	push   $0x1
 86b:	e9 31 ff ff ff       	jmp    7a1 <printf+0xb1>
 870:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 875:	bb 1a 0a 00 00       	mov    $0xa1a,%ebx
 87a:	e9 77 ff ff ff       	jmp    7f6 <printf+0x106>
 87f:	90                   	nop

00000880 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 880:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 881:	a1 24 0d 00 00       	mov    0xd24,%eax
{
 886:	89 e5                	mov    %esp,%ebp
 888:	57                   	push   %edi
 889:	56                   	push   %esi
 88a:	53                   	push   %ebx
 88b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 88e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 891:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 898:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 89a:	39 c8                	cmp    %ecx,%eax
 89c:	73 32                	jae    8d0 <free+0x50>
 89e:	39 d1                	cmp    %edx,%ecx
 8a0:	72 04                	jb     8a6 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8a2:	39 d0                	cmp    %edx,%eax
 8a4:	72 32                	jb     8d8 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
 8a6:	8b 73 fc             	mov    -0x4(%ebx),%esi
 8a9:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 8ac:	39 fa                	cmp    %edi,%edx
 8ae:	74 30                	je     8e0 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8b0:	89 53 f8             	mov    %edx,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8b3:	8b 50 04             	mov    0x4(%eax),%edx
 8b6:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 8b9:	39 f1                	cmp    %esi,%ecx
 8bb:	74 3a                	je     8f7 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8bd:	89 08                	mov    %ecx,(%eax)
  } else
    p->s.ptr = bp;
  freep = p;
}
 8bf:	5b                   	pop    %ebx
  freep = p;
 8c0:	a3 24 0d 00 00       	mov    %eax,0xd24
}
 8c5:	5e                   	pop    %esi
 8c6:	5f                   	pop    %edi
 8c7:	5d                   	pop    %ebp
 8c8:	c3                   	ret
 8c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8d0:	39 d0                	cmp    %edx,%eax
 8d2:	72 04                	jb     8d8 <free+0x58>
 8d4:	39 d1                	cmp    %edx,%ecx
 8d6:	72 ce                	jb     8a6 <free+0x26>
{
 8d8:	89 d0                	mov    %edx,%eax
 8da:	eb bc                	jmp    898 <free+0x18>
 8dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 8e0:	03 72 04             	add    0x4(%edx),%esi
 8e3:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 8e6:	8b 10                	mov    (%eax),%edx
 8e8:	8b 12                	mov    (%edx),%edx
 8ea:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 8ed:	8b 50 04             	mov    0x4(%eax),%edx
 8f0:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 8f3:	39 f1                	cmp    %esi,%ecx
 8f5:	75 c6                	jne    8bd <free+0x3d>
    p->s.size += bp->s.size;
 8f7:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 8fa:	a3 24 0d 00 00       	mov    %eax,0xd24
    p->s.size += bp->s.size;
 8ff:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 902:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 905:	89 08                	mov    %ecx,(%eax)
}
 907:	5b                   	pop    %ebx
 908:	5e                   	pop    %esi
 909:	5f                   	pop    %edi
 90a:	5d                   	pop    %ebp
 90b:	c3                   	ret
 90c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000910 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 910:	55                   	push   %ebp
 911:	89 e5                	mov    %esp,%ebp
 913:	57                   	push   %edi
 914:	56                   	push   %esi
 915:	53                   	push   %ebx
 916:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 919:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 91c:	8b 15 24 0d 00 00    	mov    0xd24,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 922:	8d 78 07             	lea    0x7(%eax),%edi
 925:	c1 ef 03             	shr    $0x3,%edi
 928:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 92b:	85 d2                	test   %edx,%edx
 92d:	0f 84 8d 00 00 00    	je     9c0 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 933:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 935:	8b 48 04             	mov    0x4(%eax),%ecx
 938:	39 f9                	cmp    %edi,%ecx
 93a:	73 64                	jae    9a0 <malloc+0x90>
  if(nu < 4096)
 93c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 941:	39 df                	cmp    %ebx,%edi
 943:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 946:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 94d:	eb 0a                	jmp    959 <malloc+0x49>
 94f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 950:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 952:	8b 48 04             	mov    0x4(%eax),%ecx
 955:	39 f9                	cmp    %edi,%ecx
 957:	73 47                	jae    9a0 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 959:	89 c2                	mov    %eax,%edx
 95b:	3b 05 24 0d 00 00    	cmp    0xd24,%eax
 961:	75 ed                	jne    950 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 963:	83 ec 0c             	sub    $0xc,%esp
 966:	56                   	push   %esi
 967:	e8 bf fc ff ff       	call   62b <sbrk>
  if(p == (char*)-1)
 96c:	83 c4 10             	add    $0x10,%esp
 96f:	83 f8 ff             	cmp    $0xffffffff,%eax
 972:	74 1c                	je     990 <malloc+0x80>
  hp->s.size = nu;
 974:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 977:	83 ec 0c             	sub    $0xc,%esp
 97a:	83 c0 08             	add    $0x8,%eax
 97d:	50                   	push   %eax
 97e:	e8 fd fe ff ff       	call   880 <free>
  return freep;
 983:	8b 15 24 0d 00 00    	mov    0xd24,%edx
      if((p = morecore(nunits)) == 0)
 989:	83 c4 10             	add    $0x10,%esp
 98c:	85 d2                	test   %edx,%edx
 98e:	75 c0                	jne    950 <malloc+0x40>
        return 0;
  }
}
 990:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 993:	31 c0                	xor    %eax,%eax
}
 995:	5b                   	pop    %ebx
 996:	5e                   	pop    %esi
 997:	5f                   	pop    %edi
 998:	5d                   	pop    %ebp
 999:	c3                   	ret
 99a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 9a0:	39 cf                	cmp    %ecx,%edi
 9a2:	74 4c                	je     9f0 <malloc+0xe0>
        p->s.size -= nunits;
 9a4:	29 f9                	sub    %edi,%ecx
 9a6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 9a9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 9ac:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 9af:	89 15 24 0d 00 00    	mov    %edx,0xd24
}
 9b5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 9b8:	83 c0 08             	add    $0x8,%eax
}
 9bb:	5b                   	pop    %ebx
 9bc:	5e                   	pop    %esi
 9bd:	5f                   	pop    %edi
 9be:	5d                   	pop    %ebp
 9bf:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 9c0:	c7 05 24 0d 00 00 28 	movl   $0xd28,0xd24
 9c7:	0d 00 00 
    base.s.size = 0;
 9ca:	b8 28 0d 00 00       	mov    $0xd28,%eax
    base.s.ptr = freep = prevp = &base;
 9cf:	c7 05 28 0d 00 00 28 	movl   $0xd28,0xd28
 9d6:	0d 00 00 
    base.s.size = 0;
 9d9:	c7 05 2c 0d 00 00 00 	movl   $0x0,0xd2c
 9e0:	00 00 00 
    if(p->s.size >= nunits){
 9e3:	e9 54 ff ff ff       	jmp    93c <malloc+0x2c>
 9e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 9ef:	00 
        prevp->s.ptr = p->s.ptr;
 9f0:	8b 08                	mov    (%eax),%ecx
 9f2:	89 0a                	mov    %ecx,(%edx)
 9f4:	eb b9                	jmp    9af <malloc+0x9f>
