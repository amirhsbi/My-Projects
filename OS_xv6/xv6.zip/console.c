#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

#define INPUT_BUF 128
#define BACKSPACE 0x100
#define CRTPORT   0x3d4
#define C(x) ((x)-'@')

static ushort *crt = (ushort*)P2V(0xb8000);

struct {
  struct spinlock lock;
  int locking;
} cons;

static int panicked = 0;

struct {
  char buf[INPUT_BUF];
  uint r, w, e;        // read index, line start, one-past-end
  uint c;              // logical cursor
  int  esc_state;      // 0:none, 1:ESC, 2:ESC 

  int  ins_pos[INPUT_BUF]; 
  int  ins_top;

  // selection / clipboard
  int  sel_pending;
  int  sel_active;
  uint sel_anchor;
  uint sel_lo, sel_hi;

  char clip[INPUT_BUF];
  int  clip_len;
} input;

static void
cgaputc(int c){
  int pos;
  outb(CRTPORT, 14); pos = inb(CRTPORT+1) << 8;
  outb(CRTPORT, 15); pos |= inb(CRTPORT+1);

  if(c == '\n') pos += 80 - pos%80;
  else if(c == BACKSPACE){ if(pos > 0) --pos; }
  else crt[pos++] = (c&0xff) | 0x0700;

  if(pos < 0 || pos > 25*80) panic("pos");
  if((pos/80) >= 24){
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
    pos -= 80;
    memset(crt+pos, 0, sizeof(crt[0])*(24*80-pos));
  }

  outb(CRTPORT, 14); outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15); outb(CRTPORT+1, pos);
  crt[pos] = ' ' | 0x0700;
}

static void
consputc(int c){
  if(panicked){ cli(); for(;;); }
  if(c == BACKSPACE){ uartputc('\b'); uartputc(' '); uartputc('\b'); }
  else uartputc(c);
  cgaputc(c);
}
/* ------------------------------------------------ */

static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
static void ansi_right(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('C'); } }

static void move_cursor_to(uint newc){
  if(newc < input.w) newc = input.w;
  if(newc > input.e) newc = input.e;
  if(newc > input.c) ansi_right(newc - input.c);
  else if(newc < input.c) ansi_left(input.c - newc);
  input.c = newc;
}

static void redraw_line_at(uint phys_cur, uint target_cur){
  if(phys_cur > input.w) ansi_left(phys_cur - input.w);

  int inv = 0;
  for(uint j=input.w; j<input.e; j++){
    if(input.sel_active && j == input.sel_lo && !inv){ consputc(27); consputc('['); consputc('7'); consputc('m'); inv = 1; }
    if(input.sel_active && j == input.sel_hi && inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); inv = 0; }
    consputc(input.buf[j % INPUT_BUF]);
  }
  if(inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); }
  consputc(' ');
  ansi_left((input.e + 1) - target_cur);
  input.c = target_cur;
}
static void redraw_line(void){ redraw_line_at(input.c, input.c); }

static void selection_clear(void){
  if(input.sel_active || input.sel_pending){
    input.sel_active = 0;
    input.sel_pending = 0;
    redraw_line();
  }
}

static void delete_range(uint lo, uint hi){
  if(lo >= hi || hi > input.e) return;

  uint len  = hi - lo;
  uint phys = input.c;
  uint newc = (input.c <= lo) ? input.c : (input.c >= hi ? input.c - len : lo);

  
  for(uint j=hi; j<input.e; ++j)
    input.buf[(j - len) % INPUT_BUF] = input.buf[j % INPUT_BUF];
  input.e -= len;

  // fix Ctrl+Z stack
  for(int k=0; k<input.ins_top; ){
    if(input.ins_pos[k] >= (int)lo && input.ins_pos[k] < (int)hi){
      input.ins_top--;
      memmove(&input.ins_pos[k], &input.ins_pos[k+1],
              (input.ins_top - k) * sizeof(input.ins_pos[0]));
      continue;
    }
    if(input.ins_pos[k] >= (int)hi) input.ins_pos[k] -= len;
    k++;
  }

  redraw_line_at(phys, newc);
}

static void delete_at_keep_cursor(uint pos){
  delete_range(pos, pos+1);
}

static void insert_text(const char *s, int n){
  if(n <= 0) return;
  if((int)(input.e - input.r) + n >= INPUT_BUF) n = INPUT_BUF - 1 - (input.e - input.r);
  if(n <= 0) return;

  uint phys = input.c;

  for(int j = (int)input.e - 1; j >= (int)input.c; --j)
    input.buf[(uint)(j + n) % INPUT_BUF] = input.buf[(uint)j % INPUT_BUF];

  for(int k=0; k<input.ins_top; k++)
    if(input.ins_pos[k] >= (int)input.c) input.ins_pos[k] += n;

  for(int t=0; t<n; t++){
    input.buf[(input.c + t) % INPUT_BUF] = s[t];
    if(input.ins_top < INPUT_BUF) input.ins_pos[input.ins_top++] = input.c + t;
  }

  input.e += n;
  input.c += n;

  redraw_line_at(phys, input.c);
}

static uint next_word_start(void){
  uint i = input.c;
  while(i < input.e && input.buf[i % INPUT_BUF] != ' ') i++;
  while(i < input.e && input.buf[i % INPUT_BUF] == ' ') i++;
  return i;
}
static uint prev_word_start(void){
  uint i = input.c;
  if(i <= input.w) return input.w;
  int on_space      = (i < input.e && input.buf[i % INPUT_BUF] == ' ');
  int at_word_start = (input.buf[(i-1) % INPUT_BUF] == ' ');
  if(on_space || at_word_start){
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] == ' ') i--;
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] != ' ') i--;
  }else{
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] != ' ') i--;
  }
  return i;
}

static void printint(int xx, int base, int sign){
  static char digits[] = "0123456789abcdef";
  char buf[16]; int i; uint x;
  if(sign && (sign = xx < 0)) x = -xx; else x = xx;
  i = 0; do{ buf[i++] = digits[x % base]; }while((x /= base) != 0);
  if(sign) buf[i++] = '-';
  while(--i >= 0) consputc(buf[i]);
}
void cprintf(char *fmt, ...){
  int i, c, locking; uint *argp; char *s;
  locking = cons.locking; if(locking) acquire(&cons.lock);
  if(fmt == 0) panic("null fmt");
  argp = (uint*)(void*)(&fmt + 1);
  for(i=0; (c = fmt[i] & 0xff) != 0; i++){
    if(c != '%'){ consputc(c); continue; }
    c = fmt[++i] & 0xff; if(c == 0) break;
    switch(c){
    case 'd': printint(*argp++,10,1); break;
    case 'x': case 'p': printint(*argp++,16,0); break;
    case 's': s=(char*)*argp++; if(!s) s="(null)"; while(*s) consputc(*s++); break;
    case '%': consputc('%'); break;
    default: consputc('%'); consputc(c); break;
    }
  }
  if(locking) release(&cons.lock);
}
void panic(char *s){
  int i; uint pcs[10];
  cli(); cons.locking = 0;
  cprintf("lapicid %d: panic: "); cprintf(s); cprintf("\n");
  getcallerpcs(&s, pcs);
  for(i=0;i<10;i++) cprintf(" %p", pcs[i]);
  panicked = 1;
  for(;;);
}
static int is_printable(int ch){ return ch >= 32 && ch != 127; }

void
consoleintr(int (*getc)(void)){
  int ch, doprocdump = 0;

  acquire(&cons.lock);
  while((ch = getc()) >= 0){

    // ESC parsing for arrows
    if(input.esc_state == 1){ if(ch == '['){ input.esc_state = 2; continue; } input.esc_state = 0; continue; }
    else if(input.esc_state == 2){
      if(input.sel_active){ selection_clear(); continue; }
      if(ch == 'D'){ if(input.c > input.w){ input.c--; ansi_left(1); } }
      else if(ch == 'C'){ if(input.c < input.e){ input.c++; ansi_right(1); } }
      input.esc_state = 0; continue;
    }
    if(ch == 27){ input.esc_state = 1; continue; }

    if(input.sel_active){
      int keep = 0;
      if(ch == C('C') || ch == C('V') || ch == C('S') ||
         ch == 0x08 || ch == 0x7f || is_printable(ch) || ch == '\r' || ch == '\n') keep = 1;
      if(!keep){ selection_clear(); continue; }
    }

    switch(ch){
    case C('P'):
      doprocdump = 1; break;

    case C('S'):
      if(!input.sel_pending && !input.sel_active){
        input.sel_anchor = input.c; input.sel_pending = 1;
      }else if(input.sel_pending){
        if(input.c != input.sel_anchor){
          input.sel_lo = input.c < input.sel_anchor ? input.c : input.sel_anchor;
          input.sel_hi = input.c > input.sel_anchor ? input.c : input.sel_anchor;
          input.sel_active = 1; input.sel_pending = 0; redraw_line();
        }else input.sel_pending = 0;
      }else selection_clear();
      break;

    case C('U'):
      while(input.e != input.w && input.buf[(input.e-1) % INPUT_BUF] != '\n')
        delete_at_keep_cursor(input.e - 1);
      move_cursor_to(input.w);
      input.ins_top = 0;
      selection_clear();
      break;

    case C('D'):
      if(input.e == input.w){ input.w = input.e; wakeup(&input.r); }
      else move_cursor_to(next_word_start());
      break;

    case C('A'):
      move_cursor_to(prev_word_start());
      break;

    case C('C'): 
      if(input.sel_active){
        int n = input.sel_hi - input.sel_lo; if(n > INPUT_BUF-1) n = INPUT_BUF-1;
        for(int i=0;i<n;i++) input.clip[i] = input.buf[(input.sel_lo + i) % INPUT_BUF];
        input.clip_len = n; input.clip[n] = 0;
      }
      break;

    case C('V'): 
      if(input.clip_len > 0){
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
        insert_text(input.clip, input.clip_len);
      }
      break;

    case C('H'):
    case 0x7f:  
      if(input.sel_active){
        uint lo=input.sel_lo, hi=input.sel_hi;
        input.sel_active=0; input.sel_pending=0;
        delete_range(lo, hi);
      }else if(input.c > input.w){
        delete_at_keep_cursor(input.c - 1);
      }
      break;

    case C('Z'): 
      if(input.sel_active){ selection_clear(); break; }
      while(input.ins_top > 0){
        int pos = input.ins_pos[--input.ins_top];
        if(pos < (int)input.e){ delete_at_keep_cursor((uint)pos); break; }
      }
      break;

    default:
      if(ch == '\r') ch = '\n';
      if(ch != 0 && input.e - input.r < INPUT_BUF){
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
        if(ch == '\n'){
          input.buf[input.e % INPUT_BUF] = '\n';
          if(input.ins_top < INPUT_BUF) input.ins_pos[input.ins_top++] = input.e;
          input.e++; input.c = input.e;
          consputc('\n');
          input.w = input.e;
          input.ins_top = 0;
          wakeup(&input.r);
        }else{
          char cc = (char)ch;
          insert_text(&cc, 1);
        }
      }
      break;
    }
  }
  release(&cons.lock);
  if(doprocdump) procdump();
}


int
consoleread(struct inode *ip, char *dst, int n){
  uint target; int c;
  iunlock(ip);
  target = n;
  acquire(&cons.lock);
  while(n > 0){
    while(input.r == input.w){
      if(myproc()->killed){ release(&cons.lock); ilock(ip); return -1; }
      sleep(&input.r, &cons.lock);
    }
    c = input.buf[input.r++ % INPUT_BUF];
    if(c == C('D')){ if(n < target) input.r--; break; }
    *dst++ = c; --n;
    if(c == '\n') break;
  }
  release(&cons.lock);
  ilock(ip);
  return target - n;
}

int
consolewrite(struct inode *ip, char *buf, int n){
  int i;
  iunlock(ip);
  acquire(&cons.lock);
  for(i=0;i<n;i++) consputc(buf[i] & 0xff);
  release(&cons.lock);
  ilock(ip);
  return n;
}

void
consoleinit(void){
  initlock(&cons.lock, "console");
  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read  = consoleread;
  cons.locking = 1;

  input.r = input.w = input.e = input.c = 0;
  input.esc_state = 0;
  input.ins_top = 0;
  input.sel_pending = 0;
  input.sel_active  = 0;
  input.clip_len = 0;

  ioapicenable(IRQ_KBD, 0);
}
