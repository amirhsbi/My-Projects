
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc 70 67 11 80       	mov    $0x80116770,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 c0 3c 10 80       	mov    $0x80103cc0,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax
80100034:	66 90                	xchg   %ax,%ax
80100036:	66 90                	xchg   %ax,%ax
80100038:	66 90                	xchg   %ax,%ax
8010003a:	66 90                	xchg   %ax,%ax
8010003c:	66 90                	xchg   %ax,%ax
8010003e:	66 90                	xchg   %ax,%ax

80100040 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100040:	55                   	push   %ebp
80100041:	89 e5                	mov    %esp,%ebp
80100043:	53                   	push   %ebx

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100044:	bb 54 b5 10 80       	mov    $0x8010b554,%ebx
{
80100049:	83 ec 0c             	sub    $0xc,%esp
  initlock(&bcache.lock, "bcache");
8010004c:	68 00 7e 10 80       	push   $0x80107e00
80100051:	68 20 b5 10 80       	push   $0x8010b520
80100056:	e8 e5 4f 00 00       	call   80105040 <initlock>
  bcache.head.next = &bcache.head;
8010005b:	83 c4 10             	add    $0x10,%esp
8010005e:	b8 1c fc 10 80       	mov    $0x8010fc1c,%eax
  bcache.head.prev = &bcache.head;
80100063:	c7 05 6c fc 10 80 1c 	movl   $0x8010fc1c,0x8010fc6c
8010006a:	fc 10 80 
  bcache.head.next = &bcache.head;
8010006d:	c7 05 70 fc 10 80 1c 	movl   $0x8010fc1c,0x8010fc70
80100074:	fc 10 80 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100077:	eb 09                	jmp    80100082 <binit+0x42>
80100079:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100080:	89 d3                	mov    %edx,%ebx
    b->next = bcache.head.next;
80100082:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");
80100085:	83 ec 08             	sub    $0x8,%esp
80100088:	8d 43 0c             	lea    0xc(%ebx),%eax
    b->prev = &bcache.head;
8010008b:	c7 43 50 1c fc 10 80 	movl   $0x8010fc1c,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100092:	68 07 7e 10 80       	push   $0x80107e07
80100097:	50                   	push   %eax
80100098:	e8 73 4e 00 00       	call   80104f10 <initsleeplock>
    bcache.head.next->prev = b;
8010009d:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000a2:	8d 93 5c 02 00 00    	lea    0x25c(%ebx),%edx
801000a8:	83 c4 10             	add    $0x10,%esp
    bcache.head.next->prev = b;
801000ab:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
801000ae:	89 d8                	mov    %ebx,%eax
801000b0:	89 1d 70 fc 10 80    	mov    %ebx,0x8010fc70
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000b6:	81 fb c0 f9 10 80    	cmp    $0x8010f9c0,%ebx
801000bc:	75 c2                	jne    80100080 <binit+0x40>
  }
}
801000be:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000c1:	c9                   	leave
801000c2:	c3                   	ret
801000c3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801000ca:	00 
801000cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801000d0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000d0:	55                   	push   %ebp
801000d1:	89 e5                	mov    %esp,%ebp
801000d3:	57                   	push   %edi
801000d4:	56                   	push   %esi
801000d5:	53                   	push   %ebx
801000d6:	83 ec 18             	sub    $0x18,%esp
801000d9:	8b 75 08             	mov    0x8(%ebp),%esi
801000dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000df:	68 20 b5 10 80       	push   $0x8010b520
801000e4:	e8 47 51 00 00       	call   80105230 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000e9:	8b 1d 70 fc 10 80    	mov    0x8010fc70,%ebx
801000ef:	83 c4 10             	add    $0x10,%esp
801000f2:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
801000f8:	75 11                	jne    8010010b <bread+0x3b>
801000fa:	eb 24                	jmp    80100120 <bread+0x50>
801000fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100100:	8b 5b 54             	mov    0x54(%ebx),%ebx
80100103:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
80100109:	74 15                	je     80100120 <bread+0x50>
    if(b->dev == dev && b->blockno == blockno){
8010010b:	3b 73 04             	cmp    0x4(%ebx),%esi
8010010e:	75 f0                	jne    80100100 <bread+0x30>
80100110:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100113:	75 eb                	jne    80100100 <bread+0x30>
      b->refcnt++;
80100115:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100119:	eb 3f                	jmp    8010015a <bread+0x8a>
8010011b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100120:	8b 1d 6c fc 10 80    	mov    0x8010fc6c,%ebx
80100126:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
8010012c:	75 0d                	jne    8010013b <bread+0x6b>
8010012e:	eb 6e                	jmp    8010019e <bread+0xce>
80100130:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100133:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
80100139:	74 63                	je     8010019e <bread+0xce>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010013b:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010013e:	85 c0                	test   %eax,%eax
80100140:	75 ee                	jne    80100130 <bread+0x60>
80100142:	f6 03 04             	testb  $0x4,(%ebx)
80100145:	75 e9                	jne    80100130 <bread+0x60>
      b->dev = dev;
80100147:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010014a:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
8010014d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100153:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010015a:	83 ec 0c             	sub    $0xc,%esp
8010015d:	68 20 b5 10 80       	push   $0x8010b520
80100162:	e8 69 50 00 00       	call   801051d0 <release>
      acquiresleep(&b->lock);
80100167:	8d 43 0c             	lea    0xc(%ebx),%eax
8010016a:	89 04 24             	mov    %eax,(%esp)
8010016d:	e8 de 4d 00 00       	call   80104f50 <acquiresleep>
      return b;
80100172:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100175:	f6 03 02             	testb  $0x2,(%ebx)
80100178:	74 0e                	je     80100188 <bread+0xb8>
    iderw(b);
  }
  return b;
}
8010017a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010017d:	89 d8                	mov    %ebx,%eax
8010017f:	5b                   	pop    %ebx
80100180:	5e                   	pop    %esi
80100181:	5f                   	pop    %edi
80100182:	5d                   	pop    %ebp
80100183:	c3                   	ret
80100184:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    iderw(b);
80100188:	83 ec 0c             	sub    $0xc,%esp
8010018b:	53                   	push   %ebx
8010018c:	e8 cf 2d 00 00       	call   80102f60 <iderw>
80100191:	83 c4 10             	add    $0x10,%esp
}
80100194:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100197:	89 d8                	mov    %ebx,%eax
80100199:	5b                   	pop    %ebx
8010019a:	5e                   	pop    %esi
8010019b:	5f                   	pop    %edi
8010019c:	5d                   	pop    %ebp
8010019d:	c3                   	ret
  panic("bget: no buffers");
8010019e:	83 ec 0c             	sub    $0xc,%esp
801001a1:	68 0e 7e 10 80       	push   $0x80107e0e
801001a6:	e8 d5 01 00 00       	call   80100380 <panic>
801001ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801001b0 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
801001b0:	55                   	push   %ebp
801001b1:	89 e5                	mov    %esp,%ebp
801001b3:	53                   	push   %ebx
801001b4:	83 ec 10             	sub    $0x10,%esp
801001b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001ba:	8d 43 0c             	lea    0xc(%ebx),%eax
801001bd:	50                   	push   %eax
801001be:	e8 2d 4e 00 00       	call   80104ff0 <holdingsleep>
801001c3:	83 c4 10             	add    $0x10,%esp
801001c6:	85 c0                	test   %eax,%eax
801001c8:	74 0f                	je     801001d9 <bwrite+0x29>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001ca:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001cd:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801001d0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001d3:	c9                   	leave
  iderw(b);
801001d4:	e9 87 2d 00 00       	jmp    80102f60 <iderw>
    panic("bwrite");
801001d9:	83 ec 0c             	sub    $0xc,%esp
801001dc:	68 1f 7e 10 80       	push   $0x80107e1f
801001e1:	e8 9a 01 00 00       	call   80100380 <panic>
801001e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801001ed:	00 
801001ee:	66 90                	xchg   %ax,%ax

801001f0 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
801001f0:	55                   	push   %ebp
801001f1:	89 e5                	mov    %esp,%ebp
801001f3:	56                   	push   %esi
801001f4:	53                   	push   %ebx
801001f5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001f8:	8d 73 0c             	lea    0xc(%ebx),%esi
801001fb:	83 ec 0c             	sub    $0xc,%esp
801001fe:	56                   	push   %esi
801001ff:	e8 ec 4d 00 00       	call   80104ff0 <holdingsleep>
80100204:	83 c4 10             	add    $0x10,%esp
80100207:	85 c0                	test   %eax,%eax
80100209:	74 63                	je     8010026e <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
8010020b:	83 ec 0c             	sub    $0xc,%esp
8010020e:	56                   	push   %esi
8010020f:	e8 9c 4d 00 00       	call   80104fb0 <releasesleep>

  acquire(&bcache.lock);
80100214:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
8010021b:	e8 10 50 00 00       	call   80105230 <acquire>
  b->refcnt--;
80100220:	8b 43 4c             	mov    0x4c(%ebx),%eax
  if (b->refcnt == 0) {
80100223:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
80100226:	83 e8 01             	sub    $0x1,%eax
80100229:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
8010022c:	85 c0                	test   %eax,%eax
8010022e:	75 2c                	jne    8010025c <brelse+0x6c>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100230:	8b 53 54             	mov    0x54(%ebx),%edx
80100233:	8b 43 50             	mov    0x50(%ebx),%eax
80100236:	89 42 50             	mov    %eax,0x50(%edx)
    b->prev->next = b->next;
80100239:	8b 53 54             	mov    0x54(%ebx),%edx
8010023c:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
8010023f:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
    b->prev = &bcache.head;
80100244:	c7 43 50 1c fc 10 80 	movl   $0x8010fc1c,0x50(%ebx)
    b->next = bcache.head.next;
8010024b:	89 43 54             	mov    %eax,0x54(%ebx)
    bcache.head.next->prev = b;
8010024e:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
80100253:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
80100256:	89 1d 70 fc 10 80    	mov    %ebx,0x8010fc70
  }
  
  release(&bcache.lock);
8010025c:	c7 45 08 20 b5 10 80 	movl   $0x8010b520,0x8(%ebp)
}
80100263:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100266:	5b                   	pop    %ebx
80100267:	5e                   	pop    %esi
80100268:	5d                   	pop    %ebp
  release(&bcache.lock);
80100269:	e9 62 4f 00 00       	jmp    801051d0 <release>
    panic("brelse");
8010026e:	83 ec 0c             	sub    $0xc,%esp
80100271:	68 26 7e 10 80       	push   $0x80107e26
80100276:	e8 05 01 00 00       	call   80100380 <panic>
8010027b:	66 90                	xchg   %ax,%ax
8010027d:	66 90                	xchg   %ax,%ax
8010027f:	90                   	nop

80100280 <consoleread>:
  if(doprocdump) procdump();
}

/* -------------- std console I/O -------------- */
int
consoleread(struct inode *ip, char *dst, int n){
80100280:	55                   	push   %ebp
80100281:	89 e5                	mov    %esp,%ebp
80100283:	57                   	push   %edi
80100284:	56                   	push   %esi
80100285:	53                   	push   %ebx
80100286:	83 ec 18             	sub    $0x18,%esp
80100289:	8b 5d 10             	mov    0x10(%ebp),%ebx
8010028c:	8b 75 0c             	mov    0xc(%ebp),%esi
  uint target; int c;
  iunlock(ip);
8010028f:	ff 75 08             	push   0x8(%ebp)
  target = n;
80100292:	89 df                	mov    %ebx,%edi
  iunlock(ip);
80100294:	e8 77 22 00 00       	call   80102510 <iunlock>
  acquire(&cons.lock);
80100299:	c7 04 24 c0 01 11 80 	movl   $0x801101c0,(%esp)
801002a0:	e8 8b 4f 00 00       	call   80105230 <acquire>
  while(n > 0){
801002a5:	83 c4 10             	add    $0x10,%esp
801002a8:	85 db                	test   %ebx,%ebx
801002aa:	0f 8e 94 00 00 00    	jle    80100344 <consoleread+0xc4>
    while(input.r == input.w){
801002b0:	a1 00 ff 10 80       	mov    0x8010ff00,%eax
801002b5:	39 05 04 ff 10 80    	cmp    %eax,0x8010ff04
801002bb:	74 25                	je     801002e2 <consoleread+0x62>
801002bd:	eb 59                	jmp    80100318 <consoleread+0x98>
801002bf:	90                   	nop
      if(myproc()->killed){ release(&cons.lock); ilock(ip); return -1; }
      sleep(&input.r, &cons.lock);
801002c0:	83 ec 08             	sub    $0x8,%esp
801002c3:	68 c0 01 11 80       	push   $0x801101c0
801002c8:	68 00 ff 10 80       	push   $0x8010ff00
801002cd:	e8 de 49 00 00       	call   80104cb0 <sleep>
    while(input.r == input.w){
801002d2:	a1 00 ff 10 80       	mov    0x8010ff00,%eax
801002d7:	83 c4 10             	add    $0x10,%esp
801002da:	3b 05 04 ff 10 80    	cmp    0x8010ff04,%eax
801002e0:	75 36                	jne    80100318 <consoleread+0x98>
      if(myproc()->killed){ release(&cons.lock); ilock(ip); return -1; }
801002e2:	e8 09 43 00 00       	call   801045f0 <myproc>
801002e7:	8b 48 24             	mov    0x24(%eax),%ecx
801002ea:	85 c9                	test   %ecx,%ecx
801002ec:	74 d2                	je     801002c0 <consoleread+0x40>
801002ee:	83 ec 0c             	sub    $0xc,%esp
801002f1:	68 c0 01 11 80       	push   $0x801101c0
801002f6:	e8 d5 4e 00 00       	call   801051d0 <release>
801002fb:	5a                   	pop    %edx
801002fc:	ff 75 08             	push   0x8(%ebp)
801002ff:	e8 2c 21 00 00       	call   80102430 <ilock>
80100304:	83 c4 10             	add    $0x10,%esp
    if(c == '\n') break;
  }
  release(&cons.lock);
  ilock(ip);
  return target - n;
}
80100307:	8d 65 f4             	lea    -0xc(%ebp),%esp
      if(myproc()->killed){ release(&cons.lock); ilock(ip); return -1; }
8010030a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010030f:	5b                   	pop    %ebx
80100310:	5e                   	pop    %esi
80100311:	5f                   	pop    %edi
80100312:	5d                   	pop    %ebp
80100313:	c3                   	ret
80100314:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = input.buf[input.r++ % INPUT_BUF];
80100318:	8d 50 01             	lea    0x1(%eax),%edx
8010031b:	89 15 00 ff 10 80    	mov    %edx,0x8010ff00
80100321:	89 c2                	mov    %eax,%edx
80100323:	83 e2 7f             	and    $0x7f,%edx
80100326:	0f be 8a 80 fe 10 80 	movsbl -0x7fef0180(%edx),%ecx
    if(c == C('D')){ if(n < target) input.r--; break; }
8010032d:	80 f9 04             	cmp    $0x4,%cl
80100330:	74 37                	je     80100369 <consoleread+0xe9>
    *dst++ = c; --n;
80100332:	83 c6 01             	add    $0x1,%esi
80100335:	83 eb 01             	sub    $0x1,%ebx
80100338:	88 4e ff             	mov    %cl,-0x1(%esi)
    if(c == '\n') break;
8010033b:	83 f9 0a             	cmp    $0xa,%ecx
8010033e:	0f 85 64 ff ff ff    	jne    801002a8 <consoleread+0x28>
  release(&cons.lock);
80100344:	83 ec 0c             	sub    $0xc,%esp
80100347:	68 c0 01 11 80       	push   $0x801101c0
8010034c:	e8 7f 4e 00 00       	call   801051d0 <release>
  ilock(ip);
80100351:	58                   	pop    %eax
80100352:	ff 75 08             	push   0x8(%ebp)
80100355:	e8 d6 20 00 00       	call   80102430 <ilock>
  return target - n;
8010035a:	89 f8                	mov    %edi,%eax
8010035c:	83 c4 10             	add    $0x10,%esp
}
8010035f:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return target - n;
80100362:	29 d8                	sub    %ebx,%eax
}
80100364:	5b                   	pop    %ebx
80100365:	5e                   	pop    %esi
80100366:	5f                   	pop    %edi
80100367:	5d                   	pop    %ebp
80100368:	c3                   	ret
    if(c == C('D')){ if(n < target) input.r--; break; }
80100369:	39 fb                	cmp    %edi,%ebx
8010036b:	73 d7                	jae    80100344 <consoleread+0xc4>
8010036d:	a3 00 ff 10 80       	mov    %eax,0x8010ff00
80100372:	eb d0                	jmp    80100344 <consoleread+0xc4>
80100374:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010037b:	00 
8010037c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100380 <panic>:
void panic(char *s){
80100380:	55                   	push   %ebp
80100381:	89 e5                	mov    %esp,%ebp
80100383:	56                   	push   %esi
80100384:	53                   	push   %ebx
80100385:	83 ec 3c             	sub    $0x3c,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
80100388:	fa                   	cli
  cprintf("lapicid %d: panic: "); cprintf(s); cprintf("\n");
80100389:	68 2d 7e 10 80       	push   $0x80107e2d
  getcallerpcs(&s, pcs);
8010038e:	8d 5d d0             	lea    -0x30(%ebp),%ebx
80100391:	8d 75 f8             	lea    -0x8(%ebp),%esi
  cli(); cons.locking = 0;
80100394:	c7 05 f4 01 11 80 00 	movl   $0x0,0x801101f4
8010039b:	00 00 00 
  cprintf("lapicid %d: panic: "); cprintf(s); cprintf("\n");
8010039e:	e8 3d 09 00 00       	call   80100ce0 <cprintf>
801003a3:	58                   	pop    %eax
801003a4:	ff 75 08             	push   0x8(%ebp)
801003a7:	e8 34 09 00 00       	call   80100ce0 <cprintf>
801003ac:	c7 04 24 a0 82 10 80 	movl   $0x801082a0,(%esp)
801003b3:	e8 28 09 00 00       	call   80100ce0 <cprintf>
  getcallerpcs(&s, pcs);
801003b8:	8d 45 08             	lea    0x8(%ebp),%eax
801003bb:	5a                   	pop    %edx
801003bc:	59                   	pop    %ecx
801003bd:	53                   	push   %ebx
801003be:	50                   	push   %eax
801003bf:	e8 9c 4c 00 00       	call   80105060 <getcallerpcs>
  for(i=0;i<10;i++) cprintf(" %p", pcs[i]);
801003c4:	83 c4 10             	add    $0x10,%esp
801003c7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801003ce:	00 
801003cf:	90                   	nop
801003d0:	83 ec 08             	sub    $0x8,%esp
801003d3:	ff 33                	push   (%ebx)
801003d5:	83 c3 04             	add    $0x4,%ebx
801003d8:	68 41 7e 10 80       	push   $0x80107e41
801003dd:	e8 fe 08 00 00       	call   80100ce0 <cprintf>
801003e2:	83 c4 10             	add    $0x10,%esp
801003e5:	39 f3                	cmp    %esi,%ebx
801003e7:	75 e7                	jne    801003d0 <panic+0x50>
  panicked = 1;
801003e9:	c7 05 f8 01 11 80 01 	movl   $0x1,0x801101f8
801003f0:	00 00 00 
  for(;;);
801003f3:	eb fe                	jmp    801003f3 <panic+0x73>
801003f5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801003fc:	00 
801003fd:	8d 76 00             	lea    0x0(%esi),%esi

80100400 <consputc.part.0>:
consputc(int c){
80100400:	55                   	push   %ebp
80100401:	89 e5                	mov    %esp,%ebp
80100403:	57                   	push   %edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100404:	bf d4 03 00 00       	mov    $0x3d4,%edi
80100409:	56                   	push   %esi
8010040a:	53                   	push   %ebx
8010040b:	89 c3                	mov    %eax,%ebx
8010040d:	83 ec 18             	sub    $0x18,%esp
  else uartputc(c);
80100410:	50                   	push   %eax
80100411:	e8 2a 65 00 00       	call   80106940 <uartputc>
80100416:	b8 0e 00 00 00       	mov    $0xe,%eax
8010041b:	89 fa                	mov    %edi,%edx
8010041d:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010041e:	be d5 03 00 00       	mov    $0x3d5,%esi
80100423:	89 f2                	mov    %esi,%edx
80100425:	ec                   	in     (%dx),%al
  outb(CRTPORT, 14); pos = inb(CRTPORT+1) << 8;
80100426:	0f b6 c8             	movzbl %al,%ecx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100429:	89 fa                	mov    %edi,%edx
8010042b:	b8 0f 00 00 00       	mov    $0xf,%eax
80100430:	c1 e1 08             	shl    $0x8,%ecx
80100433:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100434:	89 f2                	mov    %esi,%edx
80100436:	ec                   	in     (%dx),%al
  outb(CRTPORT, 15); pos |= inb(CRTPORT+1);
80100437:	0f b6 c0             	movzbl %al,%eax
  if(c == '\n') pos += 80 - pos%80;
8010043a:	83 c4 10             	add    $0x10,%esp
  outb(CRTPORT, 15); pos |= inb(CRTPORT+1);
8010043d:	09 c8                	or     %ecx,%eax
  if(c == '\n') pos += 80 - pos%80;
8010043f:	83 fb 0a             	cmp    $0xa,%ebx
80100442:	74 6c                	je     801004b0 <consputc.part.0+0xb0>
  else crt[pos++] = (c&0xff) | 0x0700;
80100444:	0f b6 db             	movzbl %bl,%ebx
80100447:	8d 70 01             	lea    0x1(%eax),%esi
8010044a:	80 cf 07             	or     $0x7,%bh
8010044d:	66 89 9c 00 00 80 0b 	mov    %bx,-0x7ff48000(%eax,%eax,1)
80100454:	80 
  if(pos < 0 || pos > 25*80) panic("pos");
80100455:	81 fe d0 07 00 00    	cmp    $0x7d0,%esi
8010045b:	0f 8f a5 00 00 00    	jg     80100506 <consputc.part.0+0x106>
  if((pos/80) >= 24){
80100461:	81 fe 7f 07 00 00    	cmp    $0x77f,%esi
80100467:	7f 5f                	jg     801004c8 <consputc.part.0+0xc8>
  crt[pos] = ' ' | 0x0700;
80100469:	8d bc 36 00 80 0b 80 	lea    -0x7ff48000(%esi,%esi,1),%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100470:	bb d4 03 00 00       	mov    $0x3d4,%ebx
80100475:	b8 0e 00 00 00       	mov    $0xe,%eax
8010047a:	89 da                	mov    %ebx,%edx
8010047c:	ee                   	out    %al,(%dx)
8010047d:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
  outb(CRTPORT, 14); outb(CRTPORT+1, pos>>8);
80100482:	89 f0                	mov    %esi,%eax
80100484:	c1 f8 08             	sar    $0x8,%eax
80100487:	89 ca                	mov    %ecx,%edx
80100489:	ee                   	out    %al,(%dx)
8010048a:	b8 0f 00 00 00       	mov    $0xf,%eax
8010048f:	89 da                	mov    %ebx,%edx
80100491:	ee                   	out    %al,(%dx)
80100492:	89 f0                	mov    %esi,%eax
80100494:	89 ca                	mov    %ecx,%edx
80100496:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
80100497:	b8 20 07 00 00       	mov    $0x720,%eax
8010049c:	66 89 07             	mov    %ax,(%edi)
}
8010049f:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004a2:	5b                   	pop    %ebx
801004a3:	5e                   	pop    %esi
801004a4:	5f                   	pop    %edi
801004a5:	5d                   	pop    %ebp
801004a6:	c3                   	ret
801004a7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801004ae:	00 
801004af:	90                   	nop
  if(c == '\n') pos += 80 - pos%80;
801004b0:	ba cd cc cc cc       	mov    $0xcccccccd,%edx
801004b5:	f7 e2                	mul    %edx
801004b7:	c1 ea 06             	shr    $0x6,%edx
801004ba:	8d 04 92             	lea    (%edx,%edx,4),%eax
801004bd:	c1 e0 04             	shl    $0x4,%eax
801004c0:	8d 70 50             	lea    0x50(%eax),%esi
801004c3:	eb 90                	jmp    80100455 <consputc.part.0+0x55>
801004c5:	8d 76 00             	lea    0x0(%esi),%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
801004c8:	83 ec 04             	sub    $0x4,%esp
    pos -= 80;
801004cb:	83 ee 50             	sub    $0x50,%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
801004ce:	68 60 0e 00 00       	push   $0xe60
    memset(crt+pos, 0, sizeof(crt[0])*(24*80-pos));
801004d3:	8d bc 36 00 80 0b 80 	lea    -0x7ff48000(%esi,%esi,1),%edi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
801004da:	68 a0 80 0b 80       	push   $0x800b80a0
801004df:	68 00 80 0b 80       	push   $0x800b8000
801004e4:	e8 d7 4e 00 00       	call   801053c0 <memmove>
    memset(crt+pos, 0, sizeof(crt[0])*(24*80-pos));
801004e9:	b8 80 07 00 00       	mov    $0x780,%eax
801004ee:	83 c4 0c             	add    $0xc,%esp
801004f1:	29 f0                	sub    %esi,%eax
801004f3:	01 c0                	add    %eax,%eax
801004f5:	50                   	push   %eax
801004f6:	6a 00                	push   $0x0
801004f8:	57                   	push   %edi
801004f9:	e8 32 4e 00 00       	call   80105330 <memset>
801004fe:	83 c4 10             	add    $0x10,%esp
80100501:	e9 6a ff ff ff       	jmp    80100470 <consputc.part.0+0x70>
  if(pos < 0 || pos > 25*80) panic("pos");
80100506:	83 ec 0c             	sub    $0xc,%esp
80100509:	68 45 7e 10 80       	push   $0x80107e45
8010050e:	e8 6d fe ff ff       	call   80100380 <panic>
80100513:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010051a:	00 
8010051b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80100520 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n){
80100520:	55                   	push   %ebp
80100521:	89 e5                	mov    %esp,%ebp
80100523:	57                   	push   %edi
80100524:	56                   	push   %esi
80100525:	53                   	push   %ebx
80100526:	83 ec 18             	sub    $0x18,%esp
80100529:	8b 75 10             	mov    0x10(%ebp),%esi
  int i;
  iunlock(ip);
8010052c:	ff 75 08             	push   0x8(%ebp)
8010052f:	e8 dc 1f 00 00       	call   80102510 <iunlock>
  acquire(&cons.lock);
80100534:	c7 04 24 c0 01 11 80 	movl   $0x801101c0,(%esp)
8010053b:	e8 f0 4c 00 00       	call   80105230 <acquire>
  for(i=0;i<n;i++) consputc(buf[i] & 0xff);
80100540:	83 c4 10             	add    $0x10,%esp
80100543:	85 f6                	test   %esi,%esi
80100545:	7e 25                	jle    8010056c <consolewrite+0x4c>
80100547:	8b 5d 0c             	mov    0xc(%ebp),%ebx
8010054a:	8d 3c 33             	lea    (%ebx,%esi,1),%edi
  if(panicked){ cli(); for(;;); }
8010054d:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
  for(i=0;i<n;i++) consputc(buf[i] & 0xff);
80100553:	0f b6 03             	movzbl (%ebx),%eax
  if(panicked){ cli(); for(;;); }
80100556:	85 d2                	test   %edx,%edx
80100558:	74 06                	je     80100560 <consolewrite+0x40>
  asm volatile("cli");
8010055a:	fa                   	cli
8010055b:	eb fe                	jmp    8010055b <consolewrite+0x3b>
8010055d:	8d 76 00             	lea    0x0(%esi),%esi
80100560:	e8 9b fe ff ff       	call   80100400 <consputc.part.0>
  for(i=0;i<n;i++) consputc(buf[i] & 0xff);
80100565:	83 c3 01             	add    $0x1,%ebx
80100568:	39 fb                	cmp    %edi,%ebx
8010056a:	75 e1                	jne    8010054d <consolewrite+0x2d>
  release(&cons.lock);
8010056c:	83 ec 0c             	sub    $0xc,%esp
8010056f:	68 c0 01 11 80       	push   $0x801101c0
80100574:	e8 57 4c 00 00       	call   801051d0 <release>
  ilock(ip);
80100579:	58                   	pop    %eax
8010057a:	ff 75 08             	push   0x8(%ebp)
8010057d:	e8 ae 1e 00 00       	call   80102430 <ilock>
  return n;
}
80100582:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100585:	89 f0                	mov    %esi,%eax
80100587:	5b                   	pop    %ebx
80100588:	5e                   	pop    %esi
80100589:	5f                   	pop    %edi
8010058a:	5d                   	pop    %ebp
8010058b:	c3                   	ret
8010058c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100590 <printint>:
static void printint(int xx, int base, int sign){
80100590:	55                   	push   %ebp
80100591:	89 e5                	mov    %esp,%ebp
80100593:	57                   	push   %edi
80100594:	56                   	push   %esi
80100595:	53                   	push   %ebx
80100596:	89 d3                	mov    %edx,%ebx
80100598:	83 ec 2c             	sub    $0x2c,%esp
  if(sign && (sign = xx < 0)) x = -xx; else x = xx;
8010059b:	85 c0                	test   %eax,%eax
8010059d:	79 05                	jns    801005a4 <printint+0x14>
8010059f:	83 e1 01             	and    $0x1,%ecx
801005a2:	75 64                	jne    80100608 <printint+0x78>
801005a4:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
801005ab:	89 c1                	mov    %eax,%ecx
  i = 0; do{ buf[i++] = digits[x % base]; }while((x /= base) != 0);
801005ad:	31 f6                	xor    %esi,%esi
801005af:	90                   	nop
801005b0:	89 c8                	mov    %ecx,%eax
801005b2:	31 d2                	xor    %edx,%edx
801005b4:	89 f7                	mov    %esi,%edi
801005b6:	f7 f3                	div    %ebx
801005b8:	8d 76 01             	lea    0x1(%esi),%esi
801005bb:	0f b6 92 b0 83 10 80 	movzbl -0x7fef7c50(%edx),%edx
801005c2:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
801005c6:	89 ca                	mov    %ecx,%edx
801005c8:	89 c1                	mov    %eax,%ecx
801005ca:	39 da                	cmp    %ebx,%edx
801005cc:	73 e2                	jae    801005b0 <printint+0x20>
  if(sign) buf[i++] = '-';
801005ce:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
801005d1:	85 c9                	test   %ecx,%ecx
801005d3:	74 07                	je     801005dc <printint+0x4c>
801005d5:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
  while(--i >= 0) consputc(buf[i]);
801005da:	89 f7                	mov    %esi,%edi
801005dc:	8d 5d d8             	lea    -0x28(%ebp),%ebx
801005df:	01 df                	add    %ebx,%edi
  if(panicked){ cli(); for(;;); }
801005e1:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
  while(--i >= 0) consputc(buf[i]);
801005e7:	0f be 07             	movsbl (%edi),%eax
  if(panicked){ cli(); for(;;); }
801005ea:	85 d2                	test   %edx,%edx
801005ec:	74 0a                	je     801005f8 <printint+0x68>
801005ee:	fa                   	cli
801005ef:	eb fe                	jmp    801005ef <printint+0x5f>
801005f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801005f8:	e8 03 fe ff ff       	call   80100400 <consputc.part.0>
  while(--i >= 0) consputc(buf[i]);
801005fd:	8d 47 ff             	lea    -0x1(%edi),%eax
80100600:	39 df                	cmp    %ebx,%edi
80100602:	74 11                	je     80100615 <printint+0x85>
80100604:	89 c7                	mov    %eax,%edi
80100606:	eb d9                	jmp    801005e1 <printint+0x51>
  if(sign && (sign = xx < 0)) x = -xx; else x = xx;
80100608:	f7 d8                	neg    %eax
8010060a:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
80100611:	89 c1                	mov    %eax,%ecx
80100613:	eb 98                	jmp    801005ad <printint+0x1d>
}
80100615:	83 c4 2c             	add    $0x2c,%esp
80100618:	5b                   	pop    %ebx
80100619:	5e                   	pop    %esi
8010061a:	5f                   	pop    %edi
8010061b:	5d                   	pop    %ebp
8010061c:	c3                   	ret
8010061d:	8d 76 00             	lea    0x0(%esi),%esi

80100620 <move_cursor_to>:
  if(newc < input.w) newc = input.w;
80100620:	8b 15 04 ff 10 80    	mov    0x8010ff04,%edx
static void move_cursor_to(uint newc){
80100626:	55                   	push   %ebp
  if(newc < input.w) newc = input.w;
80100627:	39 d0                	cmp    %edx,%eax
80100629:	0f 43 d0             	cmovae %eax,%edx
  if(newc > input.e) newc = input.e;
8010062c:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
static void move_cursor_to(uint newc){
80100631:	89 e5                	mov    %esp,%ebp
80100633:	56                   	push   %esi
80100634:	53                   	push   %ebx
  if(newc > input.e) newc = input.e;
80100635:	39 c2                	cmp    %eax,%edx
  if(newc < input.w) newc = input.w;
80100637:	89 d3                	mov    %edx,%ebx
  if(newc > input.e) newc = input.e;
80100639:	0f 47 d8             	cmova  %eax,%ebx
  if(newc > input.c) ansi_right(newc - input.c);
8010063c:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
80100641:	39 d8                	cmp    %ebx,%eax
80100643:	72 43                	jb     80100688 <move_cursor_to+0x68>
  else if(newc < input.c) ansi_left(input.c - newc);
80100645:	39 c3                	cmp    %eax,%ebx
80100647:	72 0f                	jb     80100658 <move_cursor_to+0x38>
  input.c = newc;
80100649:	89 1d 0c ff 10 80    	mov    %ebx,0x8010ff0c
}
8010064f:	5b                   	pop    %ebx
80100650:	5e                   	pop    %esi
80100651:	5d                   	pop    %ebp
80100652:	c3                   	ret
80100653:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  else if(newc < input.c) ansi_left(input.c - newc);
80100658:	29 d8                	sub    %ebx,%eax
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
8010065a:	8d 70 ff             	lea    -0x1(%eax),%esi
8010065d:	85 c0                	test   %eax,%eax
8010065f:	7e e8                	jle    80100649 <move_cursor_to+0x29>
  if(panicked){ cli(); for(;;); }
80100661:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
80100667:	85 c9                	test   %ecx,%ecx
80100669:	75 55                	jne    801006c0 <move_cursor_to+0xa0>
8010066b:	b8 1b 00 00 00       	mov    $0x1b,%eax
80100670:	e8 8b fd ff ff       	call   80100400 <consputc.part.0>
80100675:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
8010067b:	85 d2                	test   %edx,%edx
8010067d:	74 61                	je     801006e0 <move_cursor_to+0xc0>
8010067f:	fa                   	cli
80100680:	eb fe                	jmp    80100680 <move_cursor_to+0x60>
80100682:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  if(newc > input.c) ansi_right(newc - input.c);
80100688:	89 da                	mov    %ebx,%edx
8010068a:	29 c2                	sub    %eax,%edx
static void ansi_right(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('C'); } }
8010068c:	8d 72 ff             	lea    -0x1(%edx),%esi
8010068f:	85 d2                	test   %edx,%edx
80100691:	7e b6                	jle    80100649 <move_cursor_to+0x29>
  if(panicked){ cli(); for(;;); }
80100693:	a1 f8 01 11 80       	mov    0x801101f8,%eax
80100698:	85 c0                	test   %eax,%eax
8010069a:	75 1c                	jne    801006b8 <move_cursor_to+0x98>
8010069c:	b8 1b 00 00 00       	mov    $0x1b,%eax
801006a1:	e8 5a fd ff ff       	call   80100400 <consputc.part.0>
801006a6:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801006ab:	85 c0                	test   %eax,%eax
801006ad:	74 19                	je     801006c8 <move_cursor_to+0xa8>
801006af:	fa                   	cli
801006b0:	eb fe                	jmp    801006b0 <move_cursor_to+0x90>
801006b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801006b8:	fa                   	cli
801006b9:	eb fe                	jmp    801006b9 <move_cursor_to+0x99>
801006bb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801006c0:	fa                   	cli
801006c1:	eb fe                	jmp    801006c1 <move_cursor_to+0xa1>
801006c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801006c8:	b8 5b 00 00 00       	mov    $0x5b,%eax
801006cd:	e8 2e fd ff ff       	call   80100400 <consputc.part.0>
801006d2:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801006d7:	85 c0                	test   %eax,%eax
801006d9:	74 25                	je     80100700 <move_cursor_to+0xe0>
801006db:	fa                   	cli
801006dc:	eb fe                	jmp    801006dc <move_cursor_to+0xbc>
801006de:	66 90                	xchg   %ax,%ax
801006e0:	b8 5b 00 00 00       	mov    $0x5b,%eax
801006e5:	e8 16 fd ff ff       	call   80100400 <consputc.part.0>
801006ea:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801006ef:	85 c0                	test   %eax,%eax
801006f1:	74 21                	je     80100714 <move_cursor_to+0xf4>
801006f3:	fa                   	cli
801006f4:	eb fe                	jmp    801006f4 <move_cursor_to+0xd4>
801006f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801006fd:	00 
801006fe:	66 90                	xchg   %ax,%ax
80100700:	b8 43 00 00 00       	mov    $0x43,%eax
80100705:	e8 f6 fc ff ff       	call   80100400 <consputc.part.0>
static void ansi_right(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('C'); } }
8010070a:	83 ee 01             	sub    $0x1,%esi
8010070d:	73 84                	jae    80100693 <move_cursor_to+0x73>
8010070f:	e9 35 ff ff ff       	jmp    80100649 <move_cursor_to+0x29>
80100714:	b8 44 00 00 00       	mov    $0x44,%eax
80100719:	e8 e2 fc ff ff       	call   80100400 <consputc.part.0>
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
8010071e:	83 ee 01             	sub    $0x1,%esi
80100721:	0f 83 3a ff ff ff    	jae    80100661 <move_cursor_to+0x41>
80100727:	e9 1d ff ff ff       	jmp    80100649 <move_cursor_to+0x29>
8010072c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100730 <redraw_line_at>:
static void redraw_line_at(uint phys_cur, uint target_cur){
80100730:	55                   	push   %ebp
80100731:	89 e5                	mov    %esp,%ebp
80100733:	57                   	push   %edi
80100734:	56                   	push   %esi
80100735:	89 d6                	mov    %edx,%esi
80100737:	53                   	push   %ebx
80100738:	83 ec 0c             	sub    $0xc,%esp
  if(phys_cur > input.w) ansi_left(phys_cur - input.w);
8010073b:	8b 1d 04 ff 10 80    	mov    0x8010ff04,%ebx
80100741:	39 c3                	cmp    %eax,%ebx
80100743:	72 7b                	jb     801007c0 <redraw_line_at+0x90>
  int inv = 0;
80100745:	31 ff                	xor    %edi,%edi
  for(uint j=input.w; j<input.e; j++){
80100747:	3b 1d 08 ff 10 80    	cmp    0x8010ff08,%ebx
8010074d:	0f 83 07 01 00 00    	jae    8010085a <redraw_line_at+0x12a>
    if(input.sel_active && j == input.sel_lo && !inv){ consputc(27); consputc('['); consputc('7'); consputc('m'); inv = 1; }
80100753:	8b 0d 1c 01 11 80    	mov    0x8011011c,%ecx
  if(panicked){ cli(); for(;;); }
80100759:	a1 f8 01 11 80       	mov    0x801101f8,%eax
    if(input.sel_active && j == input.sel_lo && !inv){ consputc(27); consputc('['); consputc('7'); consputc('m'); inv = 1; }
8010075e:	85 c9                	test   %ecx,%ecx
80100760:	74 18                	je     8010077a <redraw_line_at+0x4a>
80100762:	39 1d 24 01 11 80    	cmp    %ebx,0x80110124
80100768:	0f 84 82 00 00 00    	je     801007f0 <redraw_line_at+0xc0>
    if(input.sel_active && j == input.sel_hi && inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); inv = 0; }
8010076e:	39 1d 28 01 11 80    	cmp    %ebx,0x80110128
80100774:	0f 84 96 00 00 00    	je     80100810 <redraw_line_at+0xe0>
    consputc(input.buf[j % INPUT_BUF]);
8010077a:	89 d8                	mov    %ebx,%eax
  if(panicked){ cli(); for(;;); }
8010077c:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
    consputc(input.buf[j % INPUT_BUF]);
80100782:	83 e0 7f             	and    $0x7f,%eax
80100785:	0f be 80 80 fe 10 80 	movsbl -0x7fef0180(%eax),%eax
  if(panicked){ cli(); for(;;); }
8010078c:	85 d2                	test   %edx,%edx
8010078e:	74 08                	je     80100798 <redraw_line_at+0x68>
80100790:	fa                   	cli
80100791:	eb fe                	jmp    80100791 <redraw_line_at+0x61>
80100793:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100798:	e8 63 fc ff ff       	call   80100400 <consputc.part.0>
  for(uint j=input.w; j<input.e; j++){
8010079d:	83 c3 01             	add    $0x1,%ebx
801007a0:	3b 1d 08 ff 10 80    	cmp    0x8010ff08,%ebx
801007a6:	72 ab                	jb     80100753 <redraw_line_at+0x23>
  if(panicked){ cli(); for(;;); }
801007a8:	a1 f8 01 11 80       	mov    0x801101f8,%eax
  if(inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); }
801007ad:	85 ff                	test   %edi,%edi
801007af:	0f 84 a5 00 00 00    	je     8010085a <redraw_line_at+0x12a>
  if(panicked){ cli(); for(;;); }
801007b5:	85 c0                	test   %eax,%eax
801007b7:	0f 84 73 01 00 00    	je     80100930 <redraw_line_at+0x200>
801007bd:	fa                   	cli
801007be:	eb fe                	jmp    801007be <redraw_line_at+0x8e>
  if(phys_cur > input.w) ansi_left(phys_cur - input.w);
801007c0:	29 d8                	sub    %ebx,%eax
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
801007c2:	8d 78 ff             	lea    -0x1(%eax),%edi
801007c5:	85 c0                	test   %eax,%eax
801007c7:	0f 8e 78 ff ff ff    	jle    80100745 <redraw_line_at+0x15>
  if(panicked){ cli(); for(;;); }
801007cd:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801007d2:	85 c0                	test   %eax,%eax
801007d4:	75 34                	jne    8010080a <redraw_line_at+0xda>
801007d6:	b8 1b 00 00 00       	mov    $0x1b,%eax
801007db:	e8 20 fc ff ff       	call   80100400 <consputc.part.0>
801007e0:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801007e5:	85 c0                	test   %eax,%eax
801007e7:	0f 84 ab 00 00 00    	je     80100898 <redraw_line_at+0x168>
801007ed:	fa                   	cli
801007ee:	eb fe                	jmp    801007ee <redraw_line_at+0xbe>
    if(input.sel_active && j == input.sel_lo && !inv){ consputc(27); consputc('['); consputc('7'); consputc('m'); inv = 1; }
801007f0:	85 ff                	test   %edi,%edi
801007f2:	0f 84 d8 00 00 00    	je     801008d0 <redraw_line_at+0x1a0>
    if(input.sel_active && j == input.sel_hi && inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); inv = 0; }
801007f8:	39 1d 28 01 11 80    	cmp    %ebx,0x80110128
801007fe:	74 20                	je     80100820 <redraw_line_at+0xf0>
  int inv = 0;
80100800:	bf 01 00 00 00       	mov    $0x1,%edi
80100805:	e9 70 ff ff ff       	jmp    8010077a <redraw_line_at+0x4a>
8010080a:	fa                   	cli
  if(panicked){ cli(); for(;;); }
8010080b:	eb fe                	jmp    8010080b <redraw_line_at+0xdb>
8010080d:	8d 76 00             	lea    0x0(%esi),%esi
    if(input.sel_active && j == input.sel_hi && inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); inv = 0; }
80100810:	85 ff                	test   %edi,%edi
80100812:	75 0c                	jne    80100820 <redraw_line_at+0xf0>
  int inv = 0;
80100814:	31 ff                	xor    %edi,%edi
80100816:	e9 5f ff ff ff       	jmp    8010077a <redraw_line_at+0x4a>
8010081b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  if(panicked){ cli(); for(;;); }
80100820:	a1 f8 01 11 80       	mov    0x801101f8,%eax
80100825:	85 c0                	test   %eax,%eax
80100827:	0f 85 d3 00 00 00    	jne    80100900 <redraw_line_at+0x1d0>
8010082d:	b8 1b 00 00 00       	mov    $0x1b,%eax
80100832:	e8 c9 fb ff ff       	call   80100400 <consputc.part.0>
80100837:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010083c:	85 c0                	test   %eax,%eax
8010083e:	0f 84 0c 01 00 00    	je     80100950 <redraw_line_at+0x220>
80100844:	fa                   	cli
80100845:	eb fe                	jmp    80100845 <redraw_line_at+0x115>
80100847:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010084e:	00 
8010084f:	90                   	nop
80100850:	b8 6d 00 00 00       	mov    $0x6d,%eax
80100855:	e8 a6 fb ff ff       	call   80100400 <consputc.part.0>
8010085a:	8b 1d f8 01 11 80    	mov    0x801101f8,%ebx
80100860:	85 db                	test   %ebx,%ebx
80100862:	0f 85 90 00 00 00    	jne    801008f8 <redraw_line_at+0x1c8>
80100868:	b8 20 00 00 00       	mov    $0x20,%eax
8010086d:	e8 8e fb ff ff       	call   80100400 <consputc.part.0>
  ansi_left((input.e + 1) - target_cur);
80100872:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80100877:	83 c0 01             	add    $0x1,%eax
8010087a:	29 f0                	sub    %esi,%eax
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
8010087c:	8d 58 ff             	lea    -0x1(%eax),%ebx
8010087f:	85 c0                	test   %eax,%eax
80100881:	0f 8e 7c 01 00 00    	jle    80100a03 <redraw_line_at+0x2d3>
  if(panicked){ cli(); for(;;); }
80100887:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
8010088d:	85 c9                	test   %ecx,%ecx
8010088f:	74 7f                	je     80100910 <redraw_line_at+0x1e0>
80100891:	fa                   	cli
80100892:	eb fe                	jmp    80100892 <redraw_line_at+0x162>
80100894:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100898:	b8 5b 00 00 00       	mov    $0x5b,%eax
8010089d:	e8 5e fb ff ff       	call   80100400 <consputc.part.0>
801008a2:	8b 1d f8 01 11 80    	mov    0x801101f8,%ebx
801008a8:	85 db                	test   %ebx,%ebx
801008aa:	75 44                	jne    801008f0 <redraw_line_at+0x1c0>
801008ac:	b8 44 00 00 00       	mov    $0x44,%eax
801008b1:	e8 4a fb ff ff       	call   80100400 <consputc.part.0>
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
801008b6:	83 ef 01             	sub    $0x1,%edi
801008b9:	0f 83 0e ff ff ff    	jae    801007cd <redraw_line_at+0x9d>
  for(uint j=input.w; j<input.e; j++){
801008bf:	8b 1d 04 ff 10 80    	mov    0x8010ff04,%ebx
801008c5:	e9 7b fe ff ff       	jmp    80100745 <redraw_line_at+0x15>
801008ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  if(panicked){ cli(); for(;;); }
801008d0:	85 c0                	test   %eax,%eax
801008d2:	75 34                	jne    80100908 <redraw_line_at+0x1d8>
801008d4:	b8 1b 00 00 00       	mov    $0x1b,%eax
801008d9:	e8 22 fb ff ff       	call   80100400 <consputc.part.0>
801008de:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
801008e4:	85 d2                	test   %edx,%edx
801008e6:	0f 84 84 00 00 00    	je     80100970 <redraw_line_at+0x240>
801008ec:	fa                   	cli
801008ed:	eb fe                	jmp    801008ed <redraw_line_at+0x1bd>
801008ef:	90                   	nop
801008f0:	fa                   	cli
801008f1:	eb fe                	jmp    801008f1 <redraw_line_at+0x1c1>
801008f3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801008f8:	fa                   	cli
801008f9:	eb fe                	jmp    801008f9 <redraw_line_at+0x1c9>
801008fb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100900:	fa                   	cli
80100901:	eb fe                	jmp    80100901 <redraw_line_at+0x1d1>
80100903:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100908:	fa                   	cli
80100909:	eb fe                	jmp    80100909 <redraw_line_at+0x1d9>
8010090b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100910:	b8 1b 00 00 00       	mov    $0x1b,%eax
80100915:	e8 e6 fa ff ff       	call   80100400 <consputc.part.0>
8010091a:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
80100920:	85 d2                	test   %edx,%edx
80100922:	0f 84 a8 00 00 00    	je     801009d0 <redraw_line_at+0x2a0>
80100928:	fa                   	cli
80100929:	eb fe                	jmp    80100929 <redraw_line_at+0x1f9>
8010092b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100930:	b8 1b 00 00 00       	mov    $0x1b,%eax
80100935:	e8 c6 fa ff ff       	call   80100400 <consputc.part.0>
8010093a:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010093f:	85 c0                	test   %eax,%eax
80100941:	74 6d                	je     801009b0 <redraw_line_at+0x280>
80100943:	fa                   	cli
80100944:	eb fe                	jmp    80100944 <redraw_line_at+0x214>
80100946:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010094d:	00 
8010094e:	66 90                	xchg   %ax,%ax
80100950:	b8 5b 00 00 00       	mov    $0x5b,%eax
80100955:	e8 a6 fa ff ff       	call   80100400 <consputc.part.0>
8010095a:	8b 3d f8 01 11 80    	mov    0x801101f8,%edi
80100960:	85 ff                	test   %edi,%edi
80100962:	0f 84 c8 00 00 00    	je     80100a30 <redraw_line_at+0x300>
80100968:	fa                   	cli
80100969:	eb fe                	jmp    80100969 <redraw_line_at+0x239>
8010096b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100970:	b8 5b 00 00 00       	mov    $0x5b,%eax
80100975:	e8 86 fa ff ff       	call   80100400 <consputc.part.0>
8010097a:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010097f:	85 c0                	test   %eax,%eax
80100981:	74 0d                	je     80100990 <redraw_line_at+0x260>
80100983:	fa                   	cli
80100984:	eb fe                	jmp    80100984 <redraw_line_at+0x254>
80100986:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010098d:	00 
8010098e:	66 90                	xchg   %ax,%ax
80100990:	b8 37 00 00 00       	mov    $0x37,%eax
80100995:	e8 66 fa ff ff       	call   80100400 <consputc.part.0>
8010099a:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010099f:	85 c0                	test   %eax,%eax
801009a1:	0f 84 ba 00 00 00    	je     80100a61 <redraw_line_at+0x331>
801009a7:	fa                   	cli
801009a8:	eb fe                	jmp    801009a8 <redraw_line_at+0x278>
801009aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801009b0:	b8 5b 00 00 00       	mov    $0x5b,%eax
801009b5:	e8 46 fa ff ff       	call   80100400 <consputc.part.0>
801009ba:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801009bf:	85 c0                	test   %eax,%eax
801009c1:	74 4e                	je     80100a11 <redraw_line_at+0x2e1>
801009c3:	fa                   	cli
801009c4:	eb fe                	jmp    801009c4 <redraw_line_at+0x294>
801009c6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801009cd:	00 
801009ce:	66 90                	xchg   %ax,%ax
801009d0:	b8 5b 00 00 00       	mov    $0x5b,%eax
801009d5:	e8 26 fa ff ff       	call   80100400 <consputc.part.0>
801009da:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801009df:	85 c0                	test   %eax,%eax
801009e1:	74 0d                	je     801009f0 <redraw_line_at+0x2c0>
801009e3:	fa                   	cli
801009e4:	eb fe                	jmp    801009e4 <redraw_line_at+0x2b4>
801009e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801009ed:	00 
801009ee:	66 90                	xchg   %ax,%ax
801009f0:	b8 44 00 00 00       	mov    $0x44,%eax
801009f5:	e8 06 fa ff ff       	call   80100400 <consputc.part.0>
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
801009fa:	83 eb 01             	sub    $0x1,%ebx
801009fd:	0f 83 84 fe ff ff    	jae    80100887 <redraw_line_at+0x157>
  input.c = target_cur;
80100a03:	89 35 0c ff 10 80    	mov    %esi,0x8010ff0c
}
80100a09:	83 c4 0c             	add    $0xc,%esp
80100a0c:	5b                   	pop    %ebx
80100a0d:	5e                   	pop    %esi
80100a0e:	5f                   	pop    %edi
80100a0f:	5d                   	pop    %ebp
80100a10:	c3                   	ret
80100a11:	b8 30 00 00 00       	mov    $0x30,%eax
80100a16:	e8 e5 f9 ff ff       	call   80100400 <consputc.part.0>
  if(panicked){ cli(); for(;;); }
80100a1b:	8b 3d f8 01 11 80    	mov    0x801101f8,%edi
80100a21:	85 ff                	test   %edi,%edi
80100a23:	0f 84 27 fe ff ff    	je     80100850 <redraw_line_at+0x120>
80100a29:	fa                   	cli
80100a2a:	eb fe                	jmp    80100a2a <redraw_line_at+0x2fa>
80100a2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100a30:	b8 30 00 00 00       	mov    $0x30,%eax
80100a35:	e8 c6 f9 ff ff       	call   80100400 <consputc.part.0>
80100a3a:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
80100a40:	85 c9                	test   %ecx,%ecx
80100a42:	74 0c                	je     80100a50 <redraw_line_at+0x320>
80100a44:	fa                   	cli
80100a45:	eb fe                	jmp    80100a45 <redraw_line_at+0x315>
80100a47:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100a4e:	00 
80100a4f:	90                   	nop
80100a50:	b8 6d 00 00 00       	mov    $0x6d,%eax
  int inv = 0;
80100a55:	31 ff                	xor    %edi,%edi
80100a57:	e8 a4 f9 ff ff       	call   80100400 <consputc.part.0>
    if(input.sel_active && j == input.sel_hi && inv){ consputc(27); consputc('['); consputc('0'); consputc('m'); inv = 0; }
80100a5c:	e9 19 fd ff ff       	jmp    8010077a <redraw_line_at+0x4a>
80100a61:	b8 6d 00 00 00       	mov    $0x6d,%eax
80100a66:	e8 95 f9 ff ff       	call   80100400 <consputc.part.0>
80100a6b:	a1 1c 01 11 80       	mov    0x8011011c,%eax
80100a70:	85 c0                	test   %eax,%eax
80100a72:	0f 85 80 fd ff ff    	jne    801007f8 <redraw_line_at+0xc8>
80100a78:	e9 83 fd ff ff       	jmp    80100800 <redraw_line_at+0xd0>
80100a7d:	8d 76 00             	lea    0x0(%esi),%esi

80100a80 <delete_range>:
static void delete_range(uint lo, uint hi){
80100a80:	55                   	push   %ebp
80100a81:	89 e5                	mov    %esp,%ebp
80100a83:	57                   	push   %edi
80100a84:	56                   	push   %esi
80100a85:	53                   	push   %ebx
80100a86:	83 ec 2c             	sub    $0x2c,%esp
80100a89:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(lo >= hi || hi > input.e) return;
80100a8c:	39 d0                	cmp    %edx,%eax
80100a8e:	0f 83 c4 00 00 00    	jae    80100b58 <delete_range+0xd8>
80100a94:	8b 1d 08 ff 10 80    	mov    0x8010ff08,%ebx
80100a9a:	89 d6                	mov    %edx,%esi
80100a9c:	39 d3                	cmp    %edx,%ebx
80100a9e:	0f 82 b4 00 00 00    	jb     80100b58 <delete_range+0xd8>
  uint phys = input.c;
80100aa4:	8b 3d 0c ff 10 80    	mov    0x8010ff0c,%edi
80100aaa:	89 c1                	mov    %eax,%ecx
  uint newc = (input.c <= lo) ? input.c : (input.c >= hi ? input.c - len : lo);
80100aac:	29 d0                	sub    %edx,%eax
80100aae:	89 45 dc             	mov    %eax,-0x24(%ebp)
80100ab1:	89 7d d8             	mov    %edi,-0x28(%ebp)
80100ab4:	39 f9                	cmp    %edi,%ecx
80100ab6:	73 0a                	jae    80100ac2 <delete_range+0x42>
80100ab8:	01 f8                	add    %edi,%eax
80100aba:	39 d7                	cmp    %edx,%edi
80100abc:	0f 42 c1             	cmovb  %ecx,%eax
80100abf:	89 45 d8             	mov    %eax,-0x28(%ebp)
  for(uint j=hi; j<input.e; ++j)
80100ac2:	89 f0                	mov    %esi,%eax
80100ac4:	39 de                	cmp    %ebx,%esi
80100ac6:	73 2a                	jae    80100af2 <delete_range+0x72>
80100ac8:	89 7d e0             	mov    %edi,-0x20(%ebp)
80100acb:	8b 7d dc             	mov    -0x24(%ebp),%edi
80100ace:	66 90                	xchg   %ax,%ax
    input.buf[(j - len) % INPUT_BUF] = input.buf[j % INPUT_BUF];
80100ad0:	89 c2                	mov    %eax,%edx
80100ad2:	83 e2 7f             	and    $0x7f,%edx
80100ad5:	0f b6 8a 80 fe 10 80 	movzbl -0x7fef0180(%edx),%ecx
80100adc:	8d 14 38             	lea    (%eax,%edi,1),%edx
  for(uint j=hi; j<input.e; ++j)
80100adf:	83 c0 01             	add    $0x1,%eax
    input.buf[(j - len) % INPUT_BUF] = input.buf[j % INPUT_BUF];
80100ae2:	83 e2 7f             	and    $0x7f,%edx
80100ae5:	88 8a 80 fe 10 80    	mov    %cl,-0x7fef0180(%edx)
  for(uint j=hi; j<input.e; ++j)
80100aeb:	39 c3                	cmp    %eax,%ebx
80100aed:	75 e1                	jne    80100ad0 <delete_range+0x50>
80100aef:	8b 7d e0             	mov    -0x20(%ebp),%edi
  input.e -= len;
80100af2:	8b 45 dc             	mov    -0x24(%ebp),%eax
  for(int k=0; k<input.ins_top; ){
80100af5:	8b 0d 14 01 11 80    	mov    0x80110114,%ecx
  input.e -= len;
80100afb:	01 c3                	add    %eax,%ebx
80100afd:	89 1d 08 ff 10 80    	mov    %ebx,0x8010ff08
  for(int k=0; k<input.ins_top; ){
80100b03:	31 db                	xor    %ebx,%ebx
80100b05:	85 c9                	test   %ecx,%ecx
80100b07:	7e 37                	jle    80100b40 <delete_range+0xc0>
80100b09:	89 7d d4             	mov    %edi,-0x2c(%ebp)
80100b0c:	89 75 e0             	mov    %esi,-0x20(%ebp)
80100b0f:	90                   	nop
    if(input.ins_pos[k] >= (int)lo && input.ins_pos[k] < (int)hi){
80100b10:	8d 53 24             	lea    0x24(%ebx),%edx
80100b13:	8b 75 e4             	mov    -0x1c(%ebp),%esi
      memmove(&input.ins_pos[k], &input.ins_pos[k+1],
80100b16:	8d 7b 01             	lea    0x1(%ebx),%edi
    if(input.ins_pos[k] >= (int)lo && input.ins_pos[k] < (int)hi){
80100b19:	8b 04 95 84 fe 10 80 	mov    -0x7fef017c(,%edx,4),%eax
80100b20:	39 f0                	cmp    %esi,%eax
80100b22:	8b 75 e0             	mov    -0x20(%ebp),%esi
80100b25:	7c 39                	jl     80100b60 <delete_range+0xe0>
80100b27:	39 f0                	cmp    %esi,%eax
80100b29:	7c 45                	jl     80100b70 <delete_range+0xf0>
    if(input.ins_pos[k] >= (int)hi) input.ins_pos[k] -= len;
80100b2b:	8b 75 dc             	mov    -0x24(%ebp),%esi
80100b2e:	01 f0                	add    %esi,%eax
80100b30:	89 04 95 84 fe 10 80 	mov    %eax,-0x7fef017c(,%edx,4)
    k++;
80100b37:	89 fb                	mov    %edi,%ebx
  for(int k=0; k<input.ins_top; ){
80100b39:	39 d9                	cmp    %ebx,%ecx
80100b3b:	7f d3                	jg     80100b10 <delete_range+0x90>
80100b3d:	8b 7d d4             	mov    -0x2c(%ebp),%edi
  redraw_line_at(phys, newc);
80100b40:	8b 55 d8             	mov    -0x28(%ebp),%edx
}
80100b43:	8d 65 f4             	lea    -0xc(%ebp),%esp
  redraw_line_at(phys, newc);
80100b46:	89 f8                	mov    %edi,%eax
}
80100b48:	5b                   	pop    %ebx
80100b49:	5e                   	pop    %esi
80100b4a:	5f                   	pop    %edi
80100b4b:	5d                   	pop    %ebp
  redraw_line_at(phys, newc);
80100b4c:	e9 df fb ff ff       	jmp    80100730 <redraw_line_at>
80100b51:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
}
80100b58:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100b5b:	5b                   	pop    %ebx
80100b5c:	5e                   	pop    %esi
80100b5d:	5f                   	pop    %edi
80100b5e:	5d                   	pop    %ebp
80100b5f:	c3                   	ret
    if(input.ins_pos[k] >= (int)hi) input.ins_pos[k] -= len;
80100b60:	39 f0                	cmp    %esi,%eax
80100b62:	7c d3                	jl     80100b37 <delete_range+0xb7>
80100b64:	eb c5                	jmp    80100b2b <delete_range+0xab>
80100b66:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100b6d:	00 
80100b6e:	66 90                	xchg   %ax,%ax
      input.ins_top--;
80100b70:	83 e9 01             	sub    $0x1,%ecx
80100b73:	8d 04 9d 98 00 00 00 	lea    0x98(,%ebx,4),%eax
      memmove(&input.ins_pos[k], &input.ins_pos[k+1],
80100b7a:	83 ec 04             	sub    $0x4,%esp
      input.ins_top--;
80100b7d:	89 0d 14 01 11 80    	mov    %ecx,0x80110114
              (input.ins_top - k) * sizeof(input.ins_pos[0]));
80100b83:	29 d9                	sub    %ebx,%ecx
      memmove(&input.ins_pos[k], &input.ins_pos[k+1],
80100b85:	8d 90 80 fe 10 80    	lea    -0x7fef0180(%eax),%edx
80100b8b:	05 7c fe 10 80       	add    $0x8010fe7c,%eax
80100b90:	c1 e1 02             	shl    $0x2,%ecx
80100b93:	51                   	push   %ecx
80100b94:	52                   	push   %edx
80100b95:	50                   	push   %eax
80100b96:	e8 25 48 00 00       	call   801053c0 <memmove>
      continue;
80100b9b:	8b 0d 14 01 11 80    	mov    0x80110114,%ecx
80100ba1:	83 c4 10             	add    $0x10,%esp
80100ba4:	eb 93                	jmp    80100b39 <delete_range+0xb9>
80100ba6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100bad:	00 
80100bae:	66 90                	xchg   %ax,%ax

80100bb0 <insert_text>:
  if(n <= 0) return;
80100bb0:	85 d2                	test   %edx,%edx
80100bb2:	0f 8e 20 01 00 00    	jle    80100cd8 <insert_text+0x128>
static void insert_text(const char *s, int n){
80100bb8:	55                   	push   %ebp
80100bb9:	89 e5                	mov    %esp,%ebp
80100bbb:	57                   	push   %edi
80100bbc:	89 c7                	mov    %eax,%edi
80100bbe:	56                   	push   %esi
80100bbf:	53                   	push   %ebx
80100bc0:	83 ec 1c             	sub    $0x1c,%esp
  if((int)(input.e - input.r) + n >= INPUT_BUF) n = INPUT_BUF - 1 - (input.e - input.r);
80100bc3:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80100bc8:	8b 1d 00 ff 10 80    	mov    0x8010ff00,%ebx
80100bce:	89 c1                	mov    %eax,%ecx
80100bd0:	29 d9                	sub    %ebx,%ecx
80100bd2:	01 d1                	add    %edx,%ecx
80100bd4:	83 f9 7f             	cmp    $0x7f,%ecx
80100bd7:	0f 8f db 00 00 00    	jg     80100cb8 <insert_text+0x108>
  input.e += n;
80100bdd:	8d 1c 10             	lea    (%eax,%edx,1),%ebx
80100be0:	89 55 e0             	mov    %edx,-0x20(%ebp)
80100be3:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
  uint phys = input.c;
80100be6:	8b 1d 0c ff 10 80    	mov    0x8010ff0c,%ebx
  for(int j = (int)input.e - 1; j >= (int)input.c; --j)
80100bec:	83 e8 01             	sub    $0x1,%eax
80100bef:	8d 73 ff             	lea    -0x1(%ebx),%esi
80100bf2:	39 d8                	cmp    %ebx,%eax
80100bf4:	7c 2c                	jl     80100c22 <insert_text+0x72>
80100bf6:	89 5d dc             	mov    %ebx,-0x24(%ebp)
80100bf9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    input.buf[(uint)(j + n) % INPUT_BUF] = input.buf[(uint)j % INPUT_BUF];
80100c00:	89 c1                	mov    %eax,%ecx
80100c02:	83 e1 7f             	and    $0x7f,%ecx
80100c05:	0f b6 99 80 fe 10 80 	movzbl -0x7fef0180(%ecx),%ebx
80100c0c:	8d 0c 10             	lea    (%eax,%edx,1),%ecx
  for(int j = (int)input.e - 1; j >= (int)input.c; --j)
80100c0f:	83 e8 01             	sub    $0x1,%eax
    input.buf[(uint)(j + n) % INPUT_BUF] = input.buf[(uint)j % INPUT_BUF];
80100c12:	83 e1 7f             	and    $0x7f,%ecx
80100c15:	88 99 80 fe 10 80    	mov    %bl,-0x7fef0180(%ecx)
  for(int j = (int)input.e - 1; j >= (int)input.c; --j)
80100c1b:	39 c6                	cmp    %eax,%esi
80100c1d:	75 e1                	jne    80100c00 <insert_text+0x50>
80100c1f:	8b 5d dc             	mov    -0x24(%ebp),%ebx
  for(int k=0; k<input.ins_top; k++)
80100c22:	8b 0d 14 01 11 80    	mov    0x80110114,%ecx
80100c28:	31 c0                	xor    %eax,%eax
80100c2a:	85 c9                	test   %ecx,%ecx
80100c2c:	7e 1d                	jle    80100c4b <insert_text+0x9b>
80100c2e:	66 90                	xchg   %ax,%ax
    if(input.ins_pos[k] >= (int)input.c) input.ins_pos[k] += n;
80100c30:	8b 34 85 14 ff 10 80 	mov    -0x7fef00ec(,%eax,4),%esi
80100c37:	39 de                	cmp    %ebx,%esi
80100c39:	7c 09                	jl     80100c44 <insert_text+0x94>
80100c3b:	01 d6                	add    %edx,%esi
80100c3d:	89 34 85 14 ff 10 80 	mov    %esi,-0x7fef00ec(,%eax,4)
  for(int k=0; k<input.ins_top; k++)
80100c44:	83 c0 01             	add    $0x1,%eax
80100c47:	39 c8                	cmp    %ecx,%eax
80100c49:	75 e5                	jne    80100c30 <insert_text+0x80>
80100c4b:	89 5d dc             	mov    %ebx,-0x24(%ebp)
80100c4e:	01 da                	add    %ebx,%edx
80100c50:	89 d8                	mov    %ebx,%eax
    input.buf[(input.c + t) % INPUT_BUF] = s[t];
80100c52:	29 df                	sub    %ebx,%edi
80100c54:	eb 10                	jmp    80100c66 <insert_text+0xb6>
80100c56:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100c5d:	00 
80100c5e:	66 90                	xchg   %ax,%ax
    if(input.ins_top < INPUT_BUF) input.ins_pos[input.ins_top++] = input.c + t;
80100c60:	8b 0d 14 01 11 80    	mov    0x80110114,%ecx
    input.buf[(input.c + t) % INPUT_BUF] = s[t];
80100c66:	0f b6 1c 07          	movzbl (%edi,%eax,1),%ebx
80100c6a:	89 c6                	mov    %eax,%esi
80100c6c:	83 e6 7f             	and    $0x7f,%esi
80100c6f:	88 9e 80 fe 10 80    	mov    %bl,-0x7fef0180(%esi)
    if(input.ins_top < INPUT_BUF) input.ins_pos[input.ins_top++] = input.c + t;
80100c75:	83 f9 7f             	cmp    $0x7f,%ecx
80100c78:	7f 10                	jg     80100c8a <insert_text+0xda>
80100c7a:	8d 71 01             	lea    0x1(%ecx),%esi
80100c7d:	89 04 8d 14 ff 10 80 	mov    %eax,-0x7fef00ec(,%ecx,4)
80100c84:	89 35 14 01 11 80    	mov    %esi,0x80110114
  for(int t=0; t<n; t++){
80100c8a:	83 c0 01             	add    $0x1,%eax
80100c8d:	39 c2                	cmp    %eax,%edx
80100c8f:	75 cf                	jne    80100c60 <insert_text+0xb0>
  input.e += n;
80100c91:	8b 5d dc             	mov    -0x24(%ebp),%ebx
  input.c += n;
80100c94:	8b 55 e0             	mov    -0x20(%ebp),%edx
  input.e += n;
80100c97:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  input.c += n;
80100c9a:	01 da                	add    %ebx,%edx
  input.e += n;
80100c9c:	a3 08 ff 10 80       	mov    %eax,0x8010ff08
  redraw_line_at(phys, input.c);
80100ca1:	89 d8                	mov    %ebx,%eax
  input.c += n;
80100ca3:	89 15 0c ff 10 80    	mov    %edx,0x8010ff0c
}
80100ca9:	83 c4 1c             	add    $0x1c,%esp
80100cac:	5b                   	pop    %ebx
80100cad:	5e                   	pop    %esi
80100cae:	5f                   	pop    %edi
80100caf:	5d                   	pop    %ebp
  redraw_line_at(phys, input.c);
80100cb0:	e9 7b fa ff ff       	jmp    80100730 <redraw_line_at>
80100cb5:	8d 76 00             	lea    0x0(%esi),%esi
  if((int)(input.e - input.r) + n >= INPUT_BUF) n = INPUT_BUF - 1 - (input.e - input.r);
80100cb8:	8d 53 7f             	lea    0x7f(%ebx),%edx
80100cbb:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80100cbe:	29 c2                	sub    %eax,%edx
80100cc0:	89 55 e0             	mov    %edx,-0x20(%ebp)
  if(n <= 0) return;
80100cc3:	85 d2                	test   %edx,%edx
80100cc5:	0f 8f 1b ff ff ff    	jg     80100be6 <insert_text+0x36>
}
80100ccb:	83 c4 1c             	add    $0x1c,%esp
80100cce:	5b                   	pop    %ebx
80100ccf:	5e                   	pop    %esi
80100cd0:	5f                   	pop    %edi
80100cd1:	5d                   	pop    %ebp
80100cd2:	c3                   	ret
80100cd3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100cd8:	c3                   	ret
80100cd9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80100ce0 <cprintf>:
void cprintf(char *fmt, ...){
80100ce0:	55                   	push   %ebp
80100ce1:	89 e5                	mov    %esp,%ebp
80100ce3:	57                   	push   %edi
80100ce4:	56                   	push   %esi
80100ce5:	53                   	push   %ebx
80100ce6:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking; if(locking) acquire(&cons.lock);
80100ce9:	8b 3d f4 01 11 80    	mov    0x801101f4,%edi
  if(fmt == 0) panic("null fmt");
80100cef:	8b 75 08             	mov    0x8(%ebp),%esi
  locking = cons.locking; if(locking) acquire(&cons.lock);
80100cf2:	85 ff                	test   %edi,%edi
80100cf4:	0f 85 06 01 00 00    	jne    80100e00 <cprintf+0x120>
  if(fmt == 0) panic("null fmt");
80100cfa:	85 f6                	test   %esi,%esi
80100cfc:	0f 84 b7 01 00 00    	je     80100eb9 <cprintf+0x1d9>
  for(i=0; (c = fmt[i] & 0xff) != 0; i++){
80100d02:	0f b6 06             	movzbl (%esi),%eax
80100d05:	85 c0                	test   %eax,%eax
80100d07:	74 5f                	je     80100d68 <cprintf+0x88>
  argp = (uint*)(void*)(&fmt + 1);
80100d09:	8d 55 0c             	lea    0xc(%ebp),%edx
  for(i=0; (c = fmt[i] & 0xff) != 0; i++){
80100d0c:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80100d0f:	31 db                	xor    %ebx,%ebx
80100d11:	89 d7                	mov    %edx,%edi
    if(c != '%'){ consputc(c); continue; }
80100d13:	83 f8 25             	cmp    $0x25,%eax
80100d16:	75 58                	jne    80100d70 <cprintf+0x90>
    c = fmt[++i] & 0xff; if(c == 0) break;
80100d18:	83 c3 01             	add    $0x1,%ebx
80100d1b:	0f b6 0c 1e          	movzbl (%esi,%ebx,1),%ecx
80100d1f:	85 c9                	test   %ecx,%ecx
80100d21:	74 3a                	je     80100d5d <cprintf+0x7d>
    switch(c){
80100d23:	83 f9 70             	cmp    $0x70,%ecx
80100d26:	0f 84 b4 00 00 00    	je     80100de0 <cprintf+0x100>
80100d2c:	7f 72                	jg     80100da0 <cprintf+0xc0>
80100d2e:	83 f9 25             	cmp    $0x25,%ecx
80100d31:	74 4d                	je     80100d80 <cprintf+0xa0>
80100d33:	83 f9 64             	cmp    $0x64,%ecx
80100d36:	75 76                	jne    80100dae <cprintf+0xce>
    case 'd': printint(*argp++,10,1); break;
80100d38:	8d 47 04             	lea    0x4(%edi),%eax
80100d3b:	b9 01 00 00 00       	mov    $0x1,%ecx
80100d40:	ba 0a 00 00 00       	mov    $0xa,%edx
80100d45:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100d48:	8b 07                	mov    (%edi),%eax
80100d4a:	e8 41 f8 ff ff       	call   80100590 <printint>
80100d4f:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(i=0; (c = fmt[i] & 0xff) != 0; i++){
80100d52:	83 c3 01             	add    $0x1,%ebx
80100d55:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
80100d59:	85 c0                	test   %eax,%eax
80100d5b:	75 b6                	jne    80100d13 <cprintf+0x33>
80100d5d:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  if(locking) release(&cons.lock);
80100d60:	85 ff                	test   %edi,%edi
80100d62:	0f 85 bb 00 00 00    	jne    80100e23 <cprintf+0x143>
}
80100d68:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100d6b:	5b                   	pop    %ebx
80100d6c:	5e                   	pop    %esi
80100d6d:	5f                   	pop    %edi
80100d6e:	5d                   	pop    %ebp
80100d6f:	c3                   	ret
  if(panicked){ cli(); for(;;); }
80100d70:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
80100d76:	85 c9                	test   %ecx,%ecx
80100d78:	74 19                	je     80100d93 <cprintf+0xb3>
80100d7a:	fa                   	cli
80100d7b:	eb fe                	jmp    80100d7b <cprintf+0x9b>
80100d7d:	8d 76 00             	lea    0x0(%esi),%esi
80100d80:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
80100d86:	85 c9                	test   %ecx,%ecx
80100d88:	0f 85 f2 00 00 00    	jne    80100e80 <cprintf+0x1a0>
80100d8e:	b8 25 00 00 00       	mov    $0x25,%eax
80100d93:	e8 68 f6 ff ff       	call   80100400 <consputc.part.0>
    case '%': consputc('%'); break;
80100d98:	eb b8                	jmp    80100d52 <cprintf+0x72>
80100d9a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    switch(c){
80100da0:	83 f9 73             	cmp    $0x73,%ecx
80100da3:	0f 84 8f 00 00 00    	je     80100e38 <cprintf+0x158>
80100da9:	83 f9 78             	cmp    $0x78,%ecx
80100dac:	74 32                	je     80100de0 <cprintf+0x100>
  if(panicked){ cli(); for(;;); }
80100dae:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
80100db4:	85 d2                	test   %edx,%edx
80100db6:	0f 85 b8 00 00 00    	jne    80100e74 <cprintf+0x194>
80100dbc:	b8 25 00 00 00       	mov    $0x25,%eax
80100dc1:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80100dc4:	e8 37 f6 ff ff       	call   80100400 <consputc.part.0>
80100dc9:	a1 f8 01 11 80       	mov    0x801101f8,%eax
80100dce:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80100dd1:	85 c0                	test   %eax,%eax
80100dd3:	0f 84 cd 00 00 00    	je     80100ea6 <cprintf+0x1c6>
80100dd9:	fa                   	cli
80100dda:	eb fe                	jmp    80100dda <cprintf+0xfa>
80100ddc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    case 'x': case 'p': printint(*argp++,16,0); break;
80100de0:	8d 47 04             	lea    0x4(%edi),%eax
80100de3:	31 c9                	xor    %ecx,%ecx
80100de5:	ba 10 00 00 00       	mov    $0x10,%edx
80100dea:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100ded:	8b 07                	mov    (%edi),%eax
80100def:	e8 9c f7 ff ff       	call   80100590 <printint>
80100df4:	8b 7d e0             	mov    -0x20(%ebp),%edi
80100df7:	e9 56 ff ff ff       	jmp    80100d52 <cprintf+0x72>
80100dfc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  locking = cons.locking; if(locking) acquire(&cons.lock);
80100e00:	83 ec 0c             	sub    $0xc,%esp
80100e03:	68 c0 01 11 80       	push   $0x801101c0
80100e08:	e8 23 44 00 00       	call   80105230 <acquire>
  if(fmt == 0) panic("null fmt");
80100e0d:	83 c4 10             	add    $0x10,%esp
80100e10:	85 f6                	test   %esi,%esi
80100e12:	0f 84 a1 00 00 00    	je     80100eb9 <cprintf+0x1d9>
  for(i=0; (c = fmt[i] & 0xff) != 0; i++){
80100e18:	0f b6 06             	movzbl (%esi),%eax
80100e1b:	85 c0                	test   %eax,%eax
80100e1d:	0f 85 e6 fe ff ff    	jne    80100d09 <cprintf+0x29>
  if(locking) release(&cons.lock);
80100e23:	83 ec 0c             	sub    $0xc,%esp
80100e26:	68 c0 01 11 80       	push   $0x801101c0
80100e2b:	e8 a0 43 00 00       	call   801051d0 <release>
80100e30:	83 c4 10             	add    $0x10,%esp
80100e33:	e9 30 ff ff ff       	jmp    80100d68 <cprintf+0x88>
    case 's': s=(char*)*argp++; if(!s) s="(null)"; while(*s) consputc(*s++); break;
80100e38:	8b 17                	mov    (%edi),%edx
80100e3a:	8d 47 04             	lea    0x4(%edi),%eax
80100e3d:	85 d2                	test   %edx,%edx
80100e3f:	74 27                	je     80100e68 <cprintf+0x188>
80100e41:	0f b6 0a             	movzbl (%edx),%ecx
80100e44:	89 d7                	mov    %edx,%edi
80100e46:	84 c9                	test   %cl,%cl
80100e48:	74 68                	je     80100eb2 <cprintf+0x1d2>
80100e4a:	89 5d e0             	mov    %ebx,-0x20(%ebp)
80100e4d:	89 fb                	mov    %edi,%ebx
80100e4f:	89 f7                	mov    %esi,%edi
80100e51:	89 c6                	mov    %eax,%esi
80100e53:	0f be c1             	movsbl %cl,%eax
  if(panicked){ cli(); for(;;); }
80100e56:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
80100e5c:	85 d2                	test   %edx,%edx
80100e5e:	74 28                	je     80100e88 <cprintf+0x1a8>
80100e60:	fa                   	cli
80100e61:	eb fe                	jmp    80100e61 <cprintf+0x181>
80100e63:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100e68:	b9 28 00 00 00       	mov    $0x28,%ecx
    case 's': s=(char*)*argp++; if(!s) s="(null)"; while(*s) consputc(*s++); break;
80100e6d:	bf 49 7e 10 80       	mov    $0x80107e49,%edi
80100e72:	eb d6                	jmp    80100e4a <cprintf+0x16a>
80100e74:	fa                   	cli
  if(panicked){ cli(); for(;;); }
80100e75:	eb fe                	jmp    80100e75 <cprintf+0x195>
80100e77:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100e7e:	00 
80100e7f:	90                   	nop
80100e80:	fa                   	cli
80100e81:	eb fe                	jmp    80100e81 <cprintf+0x1a1>
80100e83:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100e88:	e8 73 f5 ff ff       	call   80100400 <consputc.part.0>
    case 's': s=(char*)*argp++; if(!s) s="(null)"; while(*s) consputc(*s++); break;
80100e8d:	0f be 43 01          	movsbl 0x1(%ebx),%eax
80100e91:	83 c3 01             	add    $0x1,%ebx
80100e94:	84 c0                	test   %al,%al
80100e96:	75 be                	jne    80100e56 <cprintf+0x176>
80100e98:	89 f0                	mov    %esi,%eax
80100e9a:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80100e9d:	89 fe                	mov    %edi,%esi
80100e9f:	89 c7                	mov    %eax,%edi
80100ea1:	e9 ac fe ff ff       	jmp    80100d52 <cprintf+0x72>
80100ea6:	89 c8                	mov    %ecx,%eax
80100ea8:	e8 53 f5 ff ff       	call   80100400 <consputc.part.0>
    default: consputc('%'); consputc(c); break;
80100ead:	e9 a0 fe ff ff       	jmp    80100d52 <cprintf+0x72>
    case 's': s=(char*)*argp++; if(!s) s="(null)"; while(*s) consputc(*s++); break;
80100eb2:	89 c7                	mov    %eax,%edi
80100eb4:	e9 99 fe ff ff       	jmp    80100d52 <cprintf+0x72>
  if(fmt == 0) panic("null fmt");
80100eb9:	83 ec 0c             	sub    $0xc,%esp
80100ebc:	68 50 7e 10 80       	push   $0x80107e50
80100ec1:	e8 ba f4 ff ff       	call   80100380 <panic>
80100ec6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100ecd:	00 
80100ece:	66 90                	xchg   %ax,%ax

80100ed0 <consoleintr>:
consoleintr(int (*getc)(void)){
80100ed0:	55                   	push   %ebp
80100ed1:	89 e5                	mov    %esp,%ebp
80100ed3:	57                   	push   %edi
  int ch, doprocdump = 0;
80100ed4:	31 ff                	xor    %edi,%edi
consoleintr(int (*getc)(void)){
80100ed6:	56                   	push   %esi
80100ed7:	53                   	push   %ebx
80100ed8:	83 ec 38             	sub    $0x38,%esp
80100edb:	8b 45 08             	mov    0x8(%ebp),%eax
80100ede:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  acquire(&cons.lock);
80100ee1:	68 c0 01 11 80       	push   $0x801101c0
80100ee6:	e8 45 43 00 00       	call   80105230 <acquire>
  while((ch = getc()) >= 0){
80100eeb:	83 c4 10             	add    $0x10,%esp
80100eee:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80100ef1:	ff d0                	call   *%eax
80100ef3:	89 c3                	mov    %eax,%ebx
80100ef5:	85 c0                	test   %eax,%eax
80100ef7:	78 79                	js     80100f72 <consoleintr+0xa2>
    if(input.esc_state == 1){ if(ch == '['){ input.esc_state = 2; continue; } input.esc_state = 0; continue; }
80100ef9:	a1 10 ff 10 80       	mov    0x8010ff10,%eax
80100efe:	83 f8 01             	cmp    $0x1,%eax
80100f01:	74 55                	je     80100f58 <consoleintr+0x88>
    else if(input.esc_state == 2){
80100f03:	83 f8 02             	cmp    $0x2,%eax
80100f06:	0f 84 8c 00 00 00    	je     80100f98 <consoleintr+0xc8>
    if(ch == 27){ input.esc_state = 1; continue; }
80100f0c:	83 fb 1b             	cmp    $0x1b,%ebx
80100f0f:	0f 84 53 01 00 00    	je     80101068 <consoleintr+0x198>
    if(input.sel_active){
80100f15:	a1 1c 01 11 80       	mov    0x8011011c,%eax
80100f1a:	85 c0                	test   %eax,%eax
80100f1c:	0f 84 ae 00 00 00    	je     80100fd0 <consoleintr+0x100>
      if(ch == C('C') || ch == C('V') || ch == C('S') ||
80100f22:	83 fb 16             	cmp    $0x16,%ebx
80100f25:	0f 8f 45 03 00 00    	jg     80101270 <consoleintr+0x3a0>
80100f2b:	83 fb 02             	cmp    $0x2,%ebx
80100f2e:	0f 8e 0c 01 00 00    	jle    80101040 <consoleintr+0x170>
80100f34:	b8 08 01 48 00       	mov    $0x480108,%eax
80100f39:	0f a3 d8             	bt     %ebx,%eax
80100f3c:	0f 83 9e 01 00 00    	jae    801010e0 <consoleintr+0x210>
    switch(ch){
80100f42:	8d 43 fd             	lea    -0x3(%ebx),%eax
80100f45:	83 f8 13             	cmp    $0x13,%eax
80100f48:	0f 87 84 05 00 00    	ja     801014d2 <consoleintr+0x602>
80100f4e:	ff 24 85 f4 82 10 80 	jmp    *-0x7fef7d0c(,%eax,4)
80100f55:	8d 76 00             	lea    0x0(%esi),%esi
    if(input.esc_state == 1){ if(ch == '['){ input.esc_state = 2; continue; } input.esc_state = 0; continue; }
80100f58:	31 c0                	xor    %eax,%eax
80100f5a:	83 fb 5b             	cmp    $0x5b,%ebx
80100f5d:	0f 94 c0             	sete   %al
80100f60:	01 c0                	add    %eax,%eax
80100f62:	a3 10 ff 10 80       	mov    %eax,0x8010ff10
  while((ch = getc()) >= 0){
80100f67:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80100f6a:	ff d0                	call   *%eax
80100f6c:	89 c3                	mov    %eax,%ebx
80100f6e:	85 c0                	test   %eax,%eax
80100f70:	79 87                	jns    80100ef9 <consoleintr+0x29>
  release(&cons.lock);
80100f72:	83 ec 0c             	sub    $0xc,%esp
80100f75:	68 c0 01 11 80       	push   $0x801101c0
80100f7a:	e8 51 42 00 00       	call   801051d0 <release>
  if(doprocdump) procdump();
80100f7f:	83 c4 10             	add    $0x10,%esp
80100f82:	85 ff                	test   %edi,%edi
80100f84:	0f 85 06 03 00 00    	jne    80101290 <consoleintr+0x3c0>
}
80100f8a:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100f8d:	5b                   	pop    %ebx
80100f8e:	5e                   	pop    %esi
80100f8f:	5f                   	pop    %edi
80100f90:	5d                   	pop    %ebp
80100f91:	c3                   	ret
80100f92:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(input.sel_active){ selection_clear(); continue; }
80100f98:	8b 35 1c 01 11 80    	mov    0x8011011c,%esi
80100f9e:	85 f6                	test   %esi,%esi
80100fa0:	0f 85 9a 00 00 00    	jne    80101040 <consoleintr+0x170>
      if(ch == 'D'){ if(input.c > input.w){ input.c--; ansi_left(1); } }
80100fa6:	83 fb 44             	cmp    $0x44,%ebx
80100fa9:	0f 84 61 02 00 00    	je     80101210 <consoleintr+0x340>
      else if(ch == 'C'){ if(input.c < input.e){ input.c++; ansi_right(1); } }
80100faf:	83 fb 43             	cmp    $0x43,%ebx
80100fb2:	0f 84 c8 00 00 00    	je     80101080 <consoleintr+0x1b0>
      input.esc_state = 0; continue;
80100fb8:	c7 05 10 ff 10 80 00 	movl   $0x0,0x8010ff10
80100fbf:	00 00 00 
80100fc2:	e9 27 ff ff ff       	jmp    80100eee <consoleintr+0x1e>
80100fc7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100fce:	00 
80100fcf:	90                   	nop
    switch(ch){
80100fd0:	83 fb 1a             	cmp    $0x1a,%ebx
80100fd3:	0f 8f f7 03 00 00    	jg     801013d0 <consoleintr+0x500>
80100fd9:	85 db                	test   %ebx,%ebx
80100fdb:	0f 84 0d ff ff ff    	je     80100eee <consoleintr+0x1e>
80100fe1:	83 fb 1a             	cmp    $0x1a,%ebx
80100fe4:	0f 87 ad 04 00 00    	ja     80101497 <consoleintr+0x5c7>
80100fea:	ff 24 9d 44 83 10 80 	jmp    *-0x7fef7cbc(,%ebx,4)
80100ff1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      while(input.e != input.w && input.buf[(input.e-1) % INPUT_BUF] != '\n')
80100ff8:	8d 42 ff             	lea    -0x1(%edx),%eax
80100ffb:	89 c3                	mov    %eax,%ebx
80100ffd:	83 e3 7f             	and    $0x7f,%ebx
80101000:	80 bb 80 fe 10 80 0a 	cmpb   $0xa,-0x7fef0180(%ebx)
80101007:	74 15                	je     8010101e <consoleintr+0x14e>
  delete_range(pos, pos+1);
80101009:	e8 72 fa ff ff       	call   80100a80 <delete_range>
      while(input.e != input.w && input.buf[(input.e-1) % INPUT_BUF] != '\n')
8010100e:	8b 15 08 ff 10 80    	mov    0x8010ff08,%edx
80101014:	8b 0d 04 ff 10 80    	mov    0x8010ff04,%ecx
8010101a:	39 ca                	cmp    %ecx,%edx
8010101c:	75 da                	jne    80100ff8 <consoleintr+0x128>
      move_cursor_to(input.w);
8010101e:	89 c8                	mov    %ecx,%eax
80101020:	e8 fb f5 ff ff       	call   80100620 <move_cursor_to>
  if(input.sel_active || input.sel_pending){
80101025:	a1 1c 01 11 80       	mov    0x8011011c,%eax
8010102a:	0b 05 18 01 11 80    	or     0x80110118,%eax
      input.ins_top = 0;
80101030:	c7 05 14 01 11 80 00 	movl   $0x0,0x80110114
80101037:	00 00 00 
  if(input.sel_active || input.sel_pending){
8010103a:	0f 84 ae fe ff ff    	je     80100eee <consoleintr+0x1e>
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
80101040:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
    input.sel_active = 0;
80101045:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
8010104c:	00 00 00 
    input.sel_pending = 0;
8010104f:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
80101056:	00 00 00 
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
80101059:	89 c2                	mov    %eax,%edx
8010105b:	e8 d0 f6 ff ff       	call   80100730 <redraw_line_at>
}
80101060:	e9 89 fe ff ff       	jmp    80100eee <consoleintr+0x1e>
80101065:	8d 76 00             	lea    0x0(%esi),%esi
    if(ch == 27){ input.esc_state = 1; continue; }
80101068:	c7 05 10 ff 10 80 01 	movl   $0x1,0x8010ff10
8010106f:	00 00 00 
80101072:	e9 77 fe ff ff       	jmp    80100eee <consoleintr+0x1e>
80101077:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010107e:	00 
8010107f:	90                   	nop
      else if(ch == 'C'){ if(input.c < input.e){ input.c++; ansi_right(1); } }
80101080:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
80101085:	3b 05 08 ff 10 80    	cmp    0x8010ff08,%eax
8010108b:	0f 83 27 ff ff ff    	jae    80100fb8 <consoleintr+0xe8>
80101091:	83 c0 01             	add    $0x1,%eax
80101094:	a3 0c ff 10 80       	mov    %eax,0x8010ff0c
  if(panicked){ cli(); for(;;); }
80101099:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010109e:	85 c0                	test   %eax,%eax
801010a0:	0f 85 ae 04 00 00    	jne    80101554 <consoleintr+0x684>
801010a6:	b8 1b 00 00 00       	mov    $0x1b,%eax
801010ab:	e8 50 f3 ff ff       	call   80100400 <consputc.part.0>
801010b0:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801010b5:	85 c0                	test   %eax,%eax
801010b7:	0f 85 aa 05 00 00    	jne    80101667 <consoleintr+0x797>
801010bd:	b8 5b 00 00 00       	mov    $0x5b,%eax
801010c2:	e8 39 f3 ff ff       	call   80100400 <consputc.part.0>
801010c7:	a1 f8 01 11 80       	mov    0x801101f8,%eax
801010cc:	85 c0                	test   %eax,%eax
801010ce:	0f 84 9c 05 00 00    	je     80101670 <consoleintr+0x7a0>
801010d4:	fa                   	cli
801010d5:	eb fe                	jmp    801010d5 <consoleintr+0x205>
801010d7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801010de:	00 
801010df:	90                   	nop
         ch == 0x08 || ch == 0x7f || is_printable(ch) || ch == '\r' || ch == '\n') keep = 1;
801010e0:	83 fb 0d             	cmp    $0xd,%ebx
801010e3:	0f 85 b7 01 00 00    	jne    801012a0 <consoleintr+0x3d0>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801010e9:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
801010ee:	2b 05 00 ff 10 80    	sub    0x8010ff00,%eax
      if(ch == '\r') ch = '\n';
801010f4:	83 fb 0d             	cmp    $0xd,%ebx
801010f7:	0f 84 13 02 00 00    	je     80101310 <consoleintr+0x440>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801010fd:	83 f8 7f             	cmp    $0x7f,%eax
80101100:	0f 87 e8 fd ff ff    	ja     80100eee <consoleintr+0x1e>
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
80101106:	8b 15 28 01 11 80    	mov    0x80110128,%edx
8010110c:	a1 24 01 11 80       	mov    0x80110124,%eax
80101111:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
80101118:	00 00 00 
8010111b:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
80101122:	00 00 00 
80101125:	e8 56 f9 ff ff       	call   80100a80 <delete_range>
          input.buf[input.e % INPUT_BUF] = '\n';
8010112a:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
8010112f:	e9 0e 02 00 00       	jmp    80101342 <consoleintr+0x472>
80101134:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(input.e == input.w){ input.w = input.e; wakeup(&input.r); }
80101138:	8b 15 08 ff 10 80    	mov    0x8010ff08,%edx
8010113e:	3b 15 04 ff 10 80    	cmp    0x8010ff04,%edx
80101144:	0f 84 ad 01 00 00    	je     801012f7 <consoleintr+0x427>
  uint i = input.c;
8010114a:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
  while(i < input.e && input.buf[i % INPUT_BUF] != ' ') i++;
8010114f:	39 d0                	cmp    %edx,%eax
80101151:	72 0c                	jb     8010115f <consoleintr+0x28f>
80101153:	eb 38                	jmp    8010118d <consoleintr+0x2bd>
80101155:	8d 76 00             	lea    0x0(%esi),%esi
80101158:	83 c0 01             	add    $0x1,%eax
8010115b:	39 c2                	cmp    %eax,%edx
8010115d:	74 30                	je     8010118f <consoleintr+0x2bf>
8010115f:	89 c1                	mov    %eax,%ecx
80101161:	83 e1 7f             	and    $0x7f,%ecx
80101164:	80 b9 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%ecx)
8010116b:	75 eb                	jne    80101158 <consoleintr+0x288>
  while(i < input.e && input.buf[i % INPUT_BUF] == ' ') i++;
8010116d:	39 d0                	cmp    %edx,%eax
8010116f:	72 0e                	jb     8010117f <consoleintr+0x2af>
80101171:	eb 1a                	jmp    8010118d <consoleintr+0x2bd>
80101173:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101178:	83 c0 01             	add    $0x1,%eax
8010117b:	39 c2                	cmp    %eax,%edx
8010117d:	74 10                	je     8010118f <consoleintr+0x2bf>
8010117f:	89 c1                	mov    %eax,%ecx
80101181:	83 e1 7f             	and    $0x7f,%ecx
80101184:	80 b9 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%ecx)
8010118b:	74 eb                	je     80101178 <consoleintr+0x2a8>
8010118d:	89 c2                	mov    %eax,%edx
      else move_cursor_to(next_word_start());
8010118f:	89 d0                	mov    %edx,%eax
80101191:	e8 8a f4 ff ff       	call   80100620 <move_cursor_to>
80101196:	e9 53 fd ff ff       	jmp    80100eee <consoleintr+0x1e>
  uint i = input.c;
8010119b:	8b 15 0c ff 10 80    	mov    0x8010ff0c,%edx
  if(i <= input.w) return input.w;
801011a1:	8b 0d 04 ff 10 80    	mov    0x8010ff04,%ecx
801011a7:	39 d1                	cmp    %edx,%ecx
801011a9:	73 55                	jae    80101200 <consoleintr+0x330>
  int on_space      = (i < input.e && input.buf[i % INPUT_BUF] == ' ');
801011ab:	3b 15 08 ff 10 80    	cmp    0x8010ff08,%edx
801011b1:	73 12                	jae    801011c5 <consoleintr+0x2f5>
801011b3:	89 d0                	mov    %edx,%eax
801011b5:	83 e0 7f             	and    $0x7f,%eax
801011b8:	80 b8 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%eax)
801011bf:	0f 84 a3 03 00 00    	je     80101568 <consoleintr+0x698>
  int at_word_start = (input.buf[(i-1) % INPUT_BUF] == ' ');
801011c5:	8d 42 ff             	lea    -0x1(%edx),%eax
801011c8:	89 c3                	mov    %eax,%ebx
801011ca:	83 e3 7f             	and    $0x7f,%ebx
  if(on_space || at_word_start){
801011cd:	80 bb 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%ebx)
801011d4:	75 0d                	jne    801011e3 <consoleintr+0x313>
801011d6:	e9 b8 01 00 00       	jmp    80101393 <consoleintr+0x4c3>
801011db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801011e0:	83 e8 01             	sub    $0x1,%eax
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] != ' ') i--;
801011e3:	89 c3                	mov    %eax,%ebx
801011e5:	89 d6                	mov    %edx,%esi
801011e7:	89 c2                	mov    %eax,%edx
801011e9:	83 e3 7f             	and    $0x7f,%ebx
801011ec:	80 bb 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%ebx)
801011f3:	0f 84 58 04 00 00    	je     80101651 <consoleintr+0x781>
801011f9:	39 c1                	cmp    %eax,%ecx
801011fb:	75 e3                	jne    801011e0 <consoleintr+0x310>
801011fd:	8d 76 00             	lea    0x0(%esi),%esi
      move_cursor_to(prev_word_start());
80101200:	89 c8                	mov    %ecx,%eax
80101202:	e8 19 f4 ff ff       	call   80100620 <move_cursor_to>
      break;
80101207:	e9 e2 fc ff ff       	jmp    80100eee <consoleintr+0x1e>
8010120c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(ch == 'D'){ if(input.c > input.w){ input.c--; ansi_left(1); } }
80101210:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
80101215:	39 05 04 ff 10 80    	cmp    %eax,0x8010ff04
8010121b:	0f 83 97 fd ff ff    	jae    80100fb8 <consoleintr+0xe8>
  if(panicked){ cli(); for(;;); }
80101221:	8b 0d f8 01 11 80    	mov    0x801101f8,%ecx
      if(ch == 'D'){ if(input.c > input.w){ input.c--; ansi_left(1); } }
80101227:	83 e8 01             	sub    $0x1,%eax
8010122a:	a3 0c ff 10 80       	mov    %eax,0x8010ff0c
  if(panicked){ cli(); for(;;); }
8010122f:	85 c9                	test   %ecx,%ecx
80101231:	0f 85 5d 02 00 00    	jne    80101494 <consoleintr+0x5c4>
80101237:	b8 1b 00 00 00       	mov    $0x1b,%eax
8010123c:	e8 bf f1 ff ff       	call   80100400 <consputc.part.0>
80101241:	8b 15 f8 01 11 80    	mov    0x801101f8,%edx
80101247:	85 d2                	test   %edx,%edx
80101249:	0f 85 11 03 00 00    	jne    80101560 <consoleintr+0x690>
8010124f:	b8 5b 00 00 00       	mov    $0x5b,%eax
80101254:	e8 a7 f1 ff ff       	call   80100400 <consputc.part.0>
80101259:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010125e:	85 c0                	test   %eax,%eax
80101260:	0f 84 f2 03 00 00    	je     80101658 <consoleintr+0x788>
80101266:	fa                   	cli
80101267:	eb fe                	jmp    80101267 <consoleintr+0x397>
80101269:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80101270:	83 fb 7f             	cmp    $0x7f,%ebx
80101273:	74 3b                	je     801012b0 <consoleintr+0x3e0>
         ch == 0x08 || ch == 0x7f || is_printable(ch) || ch == '\r' || ch == '\n') keep = 1;
80101275:	83 fb 1f             	cmp    $0x1f,%ebx
80101278:	0f 8e c2 fd ff ff    	jle    80101040 <consoleintr+0x170>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
8010127e:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80101283:	2b 05 00 ff 10 80    	sub    0x8010ff00,%eax
80101289:	e9 58 02 00 00       	jmp    801014e6 <consoleintr+0x616>
8010128e:	66 90                	xchg   %ax,%ax
}
80101290:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101293:	5b                   	pop    %ebx
80101294:	5e                   	pop    %esi
80101295:	5f                   	pop    %edi
80101296:	5d                   	pop    %ebp
  if(doprocdump) procdump();
80101297:	e9 b4 3b 00 00       	jmp    80104e50 <procdump>
8010129c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
         ch == 0x08 || ch == 0x7f || is_printable(ch) || ch == '\r' || ch == '\n') keep = 1;
801012a0:	83 fb 0a             	cmp    $0xa,%ebx
801012a3:	0f 84 40 fe ff ff    	je     801010e9 <consoleintr+0x219>
801012a9:	e9 92 fd ff ff       	jmp    80101040 <consoleintr+0x170>
801012ae:	66 90                	xchg   %ax,%ax
        delete_range(lo, hi);
801012b0:	8b 15 28 01 11 80    	mov    0x80110128,%edx
801012b6:	a1 24 01 11 80       	mov    0x80110124,%eax
        input.sel_active=0; input.sel_pending=0;
801012bb:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
801012c2:	00 00 00 
801012c5:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
801012cc:	00 00 00 
        delete_range(lo, hi);
801012cf:	e8 ac f7 ff ff       	call   80100a80 <delete_range>
801012d4:	e9 15 fc ff ff       	jmp    80100eee <consoleintr+0x1e>
801012d9:	b8 0a 00 00 00       	mov    $0xa,%eax
801012de:	e8 1d f1 ff ff       	call   80100400 <consputc.part.0>
          input.w = input.e;
801012e3:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
          input.ins_top = 0;
801012e8:	c7 05 14 01 11 80 00 	movl   $0x0,0x80110114
801012ef:	00 00 00 
          input.w = input.e;
801012f2:	a3 04 ff 10 80       	mov    %eax,0x8010ff04
          wakeup(&input.r);
801012f7:	83 ec 0c             	sub    $0xc,%esp
801012fa:	68 00 ff 10 80       	push   $0x8010ff00
801012ff:	e8 6c 3a 00 00       	call   80104d70 <wakeup>
80101304:	83 c4 10             	add    $0x10,%esp
80101307:	e9 e2 fb ff ff       	jmp    80100eee <consoleintr+0x1e>
8010130c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      if(ch != 0 && input.e - input.r < INPUT_BUF){
80101310:	83 f8 7f             	cmp    $0x7f,%eax
80101313:	0f 87 d5 fb ff ff    	ja     80100eee <consoleintr+0x1e>
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
80101319:	a1 24 01 11 80       	mov    0x80110124,%eax
8010131e:	8b 15 28 01 11 80    	mov    0x80110128,%edx
80101324:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
8010132b:	00 00 00 
8010132e:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
80101335:	00 00 00 
80101338:	e8 43 f7 ff ff       	call   80100a80 <delete_range>
          input.buf[input.e % INPUT_BUF] = '\n';
8010133d:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80101342:	89 c2                	mov    %eax,%edx
80101344:	83 e2 7f             	and    $0x7f,%edx
80101347:	c6 82 80 fe 10 80 0a 	movb   $0xa,-0x7fef0180(%edx)
          if(input.ins_top < INPUT_BUF) input.ins_pos[input.ins_top++] = input.e;
8010134e:	8b 15 14 01 11 80    	mov    0x80110114,%edx
80101354:	83 fa 7f             	cmp    $0x7f,%edx
80101357:	7f 10                	jg     80101369 <consoleintr+0x499>
80101359:	8d 4a 01             	lea    0x1(%edx),%ecx
8010135c:	89 04 95 14 ff 10 80 	mov    %eax,-0x7fef00ec(,%edx,4)
80101363:	89 0d 14 01 11 80    	mov    %ecx,0x80110114
          input.e++; input.c = input.e;
80101369:	83 c0 01             	add    $0x1,%eax
8010136c:	a3 08 ff 10 80       	mov    %eax,0x8010ff08
80101371:	a3 0c ff 10 80       	mov    %eax,0x8010ff0c
  if(panicked){ cli(); for(;;); }
80101376:	a1 f8 01 11 80       	mov    0x801101f8,%eax
8010137b:	85 c0                	test   %eax,%eax
8010137d:	0f 84 56 ff ff ff    	je     801012d9 <consoleintr+0x409>
80101383:	fa                   	cli
80101384:	eb fe                	jmp    80101384 <consoleintr+0x4b4>
80101386:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010138d:	00 
8010138e:	66 90                	xchg   %ax,%ax
80101390:	83 e8 01             	sub    $0x1,%eax
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] == ' ') i--;
80101393:	89 c6                	mov    %eax,%esi
80101395:	89 d3                	mov    %edx,%ebx
80101397:	89 c2                	mov    %eax,%edx
80101399:	83 e6 7f             	and    $0x7f,%esi
8010139c:	80 be 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%esi)
801013a3:	75 0d                	jne    801013b2 <consoleintr+0x4e2>
801013a5:	39 c1                	cmp    %eax,%ecx
801013a7:	75 e7                	jne    80101390 <consoleintr+0x4c0>
801013a9:	e9 52 fe ff ff       	jmp    80101200 <consoleintr+0x330>
801013ae:	66 90                	xchg   %ax,%ax
    while(i > input.w && input.buf[(i-1) % INPUT_BUF] != ' ') i--;
801013b0:	89 c3                	mov    %eax,%ebx
801013b2:	39 d9                	cmp    %ebx,%ecx
801013b4:	73 11                	jae    801013c7 <consoleintr+0x4f7>
801013b6:	8d 43 ff             	lea    -0x1(%ebx),%eax
801013b9:	89 c2                	mov    %eax,%edx
801013bb:	83 e2 7f             	and    $0x7f,%edx
801013be:	80 ba 80 fe 10 80 20 	cmpb   $0x20,-0x7fef0180(%edx)
801013c5:	75 e9                	jne    801013b0 <consoleintr+0x4e0>
801013c7:	89 d9                	mov    %ebx,%ecx
801013c9:	e9 32 fe ff ff       	jmp    80101200 <consoleintr+0x330>
801013ce:	66 90                	xchg   %ax,%ax
    switch(ch){
801013d0:	83 fb 7f             	cmp    $0x7f,%ebx
801013d3:	0f 85 f6 01 00 00    	jne    801015cf <consoleintr+0x6ff>
      }else if(input.c > input.w){
801013d9:	8b 15 0c ff 10 80    	mov    0x8010ff0c,%edx
801013df:	39 15 04 ff 10 80    	cmp    %edx,0x8010ff04
801013e5:	0f 83 03 fb ff ff    	jae    80100eee <consoleintr+0x1e>
        delete_at_keep_cursor(input.c - 1);
801013eb:	8d 42 ff             	lea    -0x1(%edx),%eax
  delete_range(pos, pos+1);
801013ee:	e8 8d f6 ff ff       	call   80100a80 <delete_range>
}
801013f3:	e9 f6 fa ff ff       	jmp    80100eee <consoleintr+0x1e>
      if(input.sel_active){ selection_clear(); break; }
801013f8:	a1 14 01 11 80       	mov    0x80110114,%eax
        if(pos < (int)input.e){ delete_at_keep_cursor((uint)pos); break; }
801013fd:	8b 1d 08 ff 10 80    	mov    0x8010ff08,%ebx
80101403:	31 d2                	xor    %edx,%edx
80101405:	eb 20                	jmp    80101427 <consoleintr+0x557>
80101407:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010140e:	00 
8010140f:	90                   	nop
        int pos = input.ins_pos[--input.ins_top];
80101410:	83 e8 01             	sub    $0x1,%eax
80101413:	ba 01 00 00 00       	mov    $0x1,%edx
80101418:	8b 0c 85 14 ff 10 80 	mov    -0x7fef00ec(,%eax,4),%ecx
        if(pos < (int)input.e){ delete_at_keep_cursor((uint)pos); break; }
8010141f:	39 cb                	cmp    %ecx,%ebx
80101421:	0f 8f 16 02 00 00    	jg     8010163d <consoleintr+0x76d>
      while(input.ins_top > 0){
80101427:	85 c0                	test   %eax,%eax
80101429:	7f e5                	jg     80101410 <consoleintr+0x540>
8010142b:	84 d2                	test   %dl,%dl
8010142d:	0f 84 bb fa ff ff    	je     80100eee <consoleintr+0x1e>
80101433:	a3 14 01 11 80       	mov    %eax,0x80110114
80101438:	e9 b1 fa ff ff       	jmp    80100eee <consoleintr+0x1e>
      doprocdump = 1; break;
8010143d:	bf 01 00 00 00       	mov    $0x1,%edi
80101442:	e9 a7 fa ff ff       	jmp    80100eee <consoleintr+0x1e>
        int n = input.sel_hi - input.sel_lo; if(n > INPUT_BUF-1) n = INPUT_BUF-1;
80101447:	8b 1d 24 01 11 80    	mov    0x80110124,%ebx
8010144d:	8b 15 28 01 11 80    	mov    0x80110128,%edx
80101453:	b9 7f 00 00 00       	mov    $0x7f,%ecx
80101458:	29 da                	sub    %ebx,%edx
8010145a:	39 ca                	cmp    %ecx,%edx
8010145c:	0f 4e ca             	cmovle %edx,%ecx
        for(int i=0;i<n;i++) input.clip[i] = input.buf[(input.sel_lo + i) % INPUT_BUF];
8010145f:	31 c0                	xor    %eax,%eax
80101461:	85 d2                	test   %edx,%edx
80101463:	7e 1d                	jle    80101482 <consoleintr+0x5b2>
80101465:	8d 76 00             	lea    0x0(%esi),%esi
80101468:	8d 14 03             	lea    (%ebx,%eax,1),%edx
8010146b:	83 c0 01             	add    $0x1,%eax
8010146e:	83 e2 7f             	and    $0x7f,%edx
80101471:	0f b6 92 80 fe 10 80 	movzbl -0x7fef0180(%edx),%edx
80101478:	88 90 2b 01 11 80    	mov    %dl,-0x7feefed5(%eax)
8010147e:	39 c8                	cmp    %ecx,%eax
80101480:	7c e6                	jl     80101468 <consoleintr+0x598>
        input.clip_len = n; input.clip[n] = 0;
80101482:	89 0d ac 01 11 80    	mov    %ecx,0x801101ac
80101488:	c6 81 2c 01 11 80 00 	movb   $0x0,-0x7feefed4(%ecx)
8010148f:	e9 5a fa ff ff       	jmp    80100eee <consoleintr+0x1e>
80101494:	fa                   	cli
  if(panicked){ cli(); for(;;); }
80101495:	eb fe                	jmp    80101495 <consoleintr+0x5c5>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
80101497:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
      if(ch == '\r') ch = '\n';
8010149c:	83 fb 0d             	cmp    $0xd,%ebx
8010149f:	0f 84 da 01 00 00    	je     8010167f <consoleintr+0x7af>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801014a5:	2b 05 00 ff 10 80    	sub    0x8010ff00,%eax
801014ab:	83 f8 7f             	cmp    $0x7f,%eax
801014ae:	0f 87 3a fa ff ff    	ja     80100eee <consoleintr+0x1e>
        if(ch == '\n'){
801014b4:	83 fb 0a             	cmp    $0xa,%ebx
801014b7:	0f 84 6d fc ff ff    	je     8010112a <consoleintr+0x25a>
          insert_text(&cc, 1);
801014bd:	ba 01 00 00 00       	mov    $0x1,%edx
801014c2:	8d 45 e7             	lea    -0x19(%ebp),%eax
          char cc = (char)ch;
801014c5:	88 5d e7             	mov    %bl,-0x19(%ebp)
          insert_text(&cc, 1);
801014c8:	e8 e3 f6 ff ff       	call   80100bb0 <insert_text>
801014cd:	e9 1c fa ff ff       	jmp    80100eee <consoleintr+0x1e>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801014d2:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
801014d7:	2b 05 00 ff 10 80    	sub    0x8010ff00,%eax
      if(ch == '\r') ch = '\n';
801014dd:	83 fb 0d             	cmp    $0xd,%ebx
801014e0:	0f 84 2a fe ff ff    	je     80101310 <consoleintr+0x440>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801014e6:	83 f8 7f             	cmp    $0x7f,%eax
801014e9:	0f 87 ff f9 ff ff    	ja     80100eee <consoleintr+0x1e>
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
801014ef:	31 d2                	xor    %edx,%edx
801014f1:	a1 24 01 11 80       	mov    0x80110124,%eax
801014f6:	89 15 1c 01 11 80    	mov    %edx,0x8011011c
801014fc:	89 15 18 01 11 80    	mov    %edx,0x80110118
80101502:	8b 15 28 01 11 80    	mov    0x80110128,%edx
80101508:	e8 73 f5 ff ff       	call   80100a80 <delete_range>
8010150d:	eb a5                	jmp    801014b4 <consoleintr+0x5e4>
8010150f:	90                   	nop
      if(!input.sel_pending && !input.sel_active){
80101510:	8b 1d 18 01 11 80    	mov    0x80110118,%ebx
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
80101516:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
      if(!input.sel_pending && !input.sel_active){
8010151b:	85 db                	test   %ebx,%ebx
8010151d:	0f 85 cd 00 00 00    	jne    801015f0 <consoleintr+0x720>
        input.sel_anchor = input.c; input.sel_pending = 1;
80101523:	a3 20 01 11 80       	mov    %eax,0x80110120
80101528:	c7 05 18 01 11 80 01 	movl   $0x1,0x80110118
8010152f:	00 00 00 
80101532:	e9 b7 f9 ff ff       	jmp    80100eee <consoleintr+0x1e>
      if(input.clip_len > 0){
80101537:	8b 15 ac 01 11 80    	mov    0x801101ac,%edx
8010153d:	85 d2                	test   %edx,%edx
8010153f:	0f 8e a9 f9 ff ff    	jle    80100eee <consoleintr+0x1e>
        insert_text(input.clip, input.clip_len);
80101545:	b8 2c 01 11 80       	mov    $0x8011012c,%eax
8010154a:	e8 61 f6 ff ff       	call   80100bb0 <insert_text>
8010154f:	e9 9a f9 ff ff       	jmp    80100eee <consoleintr+0x1e>
80101554:	fa                   	cli
  if(panicked){ cli(); for(;;); }
80101555:	eb fe                	jmp    80101555 <consoleintr+0x685>
80101557:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010155e:	00 
8010155f:	90                   	nop
80101560:	fa                   	cli
80101561:	eb fe                	jmp    80101561 <consoleintr+0x691>
80101563:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101568:	8d 42 ff             	lea    -0x1(%edx),%eax
8010156b:	e9 23 fe ff ff       	jmp    80101393 <consoleintr+0x4c3>
      if(input.clip_len > 0){
80101570:	8b 0d ac 01 11 80    	mov    0x801101ac,%ecx
80101576:	85 c9                	test   %ecx,%ecx
80101578:	0f 8e 70 f9 ff ff    	jle    80100eee <consoleintr+0x1e>
        if(input.sel_active){ uint lo=input.sel_lo, hi=input.sel_hi; input.sel_active=0; input.sel_pending=0; delete_range(lo, hi); }
8010157e:	8b 15 28 01 11 80    	mov    0x80110128,%edx
80101584:	a1 24 01 11 80       	mov    0x80110124,%eax
80101589:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
80101590:	00 00 00 
80101593:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
8010159a:	00 00 00 
8010159d:	e8 de f4 ff ff       	call   80100a80 <delete_range>
        insert_text(input.clip, input.clip_len);
801015a2:	8b 15 ac 01 11 80    	mov    0x801101ac,%edx
801015a8:	eb 9b                	jmp    80101545 <consoleintr+0x675>
      if(!input.sel_pending && !input.sel_active){
801015aa:	8b 35 18 01 11 80    	mov    0x80110118,%esi
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
801015b0:	a1 0c ff 10 80       	mov    0x8010ff0c,%eax
      if(!input.sel_pending && !input.sel_active){
801015b5:	85 f6                	test   %esi,%esi
801015b7:	75 37                	jne    801015f0 <consoleintr+0x720>
    input.sel_active = 0;
801015b9:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
801015c0:	00 00 00 
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
801015c3:	89 c2                	mov    %eax,%edx
801015c5:	e8 66 f1 ff ff       	call   80100730 <redraw_line_at>
}
801015ca:	e9 1f f9 ff ff       	jmp    80100eee <consoleintr+0x1e>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
801015cf:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
801015d4:	2b 05 00 ff 10 80    	sub    0x8010ff00,%eax
801015da:	83 f8 7f             	cmp    $0x7f,%eax
801015dd:	0f 86 da fe ff ff    	jbe    801014bd <consoleintr+0x5ed>
801015e3:	e9 06 f9 ff ff       	jmp    80100eee <consoleintr+0x1e>
801015e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801015ef:	00 
        if(input.c != input.sel_anchor){
801015f0:	8b 15 20 01 11 80    	mov    0x80110120,%edx
801015f6:	39 d0                	cmp    %edx,%eax
801015f8:	74 34                	je     8010162e <consoleintr+0x75e>
          input.sel_active = 1; input.sel_pending = 0; redraw_line();
801015fa:	c7 05 1c 01 11 80 01 	movl   $0x1,0x8011011c
80101601:	00 00 00 
          input.sel_lo = input.c < input.sel_anchor ? input.c : input.sel_anchor;
80101604:	89 d1                	mov    %edx,%ecx
          input.sel_hi = input.c > input.sel_anchor ? input.c : input.sel_anchor;
80101606:	0f 43 d0             	cmovae %eax,%edx
          input.sel_active = 1; input.sel_pending = 0; redraw_line();
80101609:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
80101610:	00 00 00 
          input.sel_lo = input.c < input.sel_anchor ? input.c : input.sel_anchor;
80101613:	0f 46 c8             	cmovbe %eax,%ecx
          input.sel_hi = input.c > input.sel_anchor ? input.c : input.sel_anchor;
80101616:	89 15 28 01 11 80    	mov    %edx,0x80110128
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
8010161c:	89 c2                	mov    %eax,%edx
          input.sel_lo = input.c < input.sel_anchor ? input.c : input.sel_anchor;
8010161e:	89 0d 24 01 11 80    	mov    %ecx,0x80110124
static void redraw_line(void){ redraw_line_at(input.c, input.c); }
80101624:	e8 07 f1 ff ff       	call   80100730 <redraw_line_at>
80101629:	e9 c0 f8 ff ff       	jmp    80100eee <consoleintr+0x1e>
        }else input.sel_pending = 0;
8010162e:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
80101635:	00 00 00 
80101638:	e9 b1 f8 ff ff       	jmp    80100eee <consoleintr+0x1e>
8010163d:	a3 14 01 11 80       	mov    %eax,0x80110114
  delete_range(pos, pos+1);
80101642:	8d 51 01             	lea    0x1(%ecx),%edx
80101645:	89 c8                	mov    %ecx,%eax
80101647:	e8 34 f4 ff ff       	call   80100a80 <delete_range>
}
8010164c:	e9 9d f8 ff ff       	jmp    80100eee <consoleintr+0x1e>
80101651:	89 f1                	mov    %esi,%ecx
80101653:	e9 a8 fb ff ff       	jmp    80101200 <consoleintr+0x330>
80101658:	b8 44 00 00 00       	mov    $0x44,%eax
8010165d:	e8 9e ed ff ff       	call   80100400 <consputc.part.0>
static void ansi_left(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('D'); } }
80101662:	e9 51 f9 ff ff       	jmp    80100fb8 <consoleintr+0xe8>
80101667:	fa                   	cli
  if(panicked){ cli(); for(;;); }
80101668:	eb fe                	jmp    80101668 <consoleintr+0x798>
8010166a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101670:	b8 43 00 00 00       	mov    $0x43,%eax
80101675:	e8 86 ed ff ff       	call   80100400 <consputc.part.0>
static void ansi_right(int n){ while(n-- > 0){ consputc(27); consputc('['); consputc('C'); } }
8010167a:	e9 39 f9 ff ff       	jmp    80100fb8 <consoleintr+0xe8>
      if(ch != 0 && input.e - input.r < INPUT_BUF){
8010167f:	89 c2                	mov    %eax,%edx
80101681:	2b 15 00 ff 10 80    	sub    0x8010ff00,%edx
80101687:	83 fa 7f             	cmp    $0x7f,%edx
8010168a:	0f 86 b2 fc ff ff    	jbe    80101342 <consoleintr+0x472>
80101690:	e9 59 f8 ff ff       	jmp    80100eee <consoleintr+0x1e>
80101695:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010169c:	00 
8010169d:	8d 76 00             	lea    0x0(%esi),%esi

801016a0 <consoleinit>:

void
consoleinit(void){
801016a0:	55                   	push   %ebp
801016a1:	89 e5                	mov    %esp,%ebp
801016a3:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
801016a6:	68 59 7e 10 80       	push   $0x80107e59
801016ab:	68 c0 01 11 80       	push   $0x801101c0
801016b0:	e8 8b 39 00 00       	call   80105040 <initlock>
  input.ins_top = 0;
  input.sel_pending = 0;
  input.sel_active  = 0;
  input.clip_len = 0;

  ioapicenable(IRQ_KBD, 0);
801016b5:	58                   	pop    %eax
801016b6:	5a                   	pop    %edx
801016b7:	6a 00                	push   $0x0
801016b9:	6a 01                	push   $0x1
  devsw[CONSOLE].write = consolewrite;
801016bb:	c7 05 ac 0b 11 80 20 	movl   $0x80100520,0x80110bac
801016c2:	05 10 80 
  devsw[CONSOLE].read  = consoleread;
801016c5:	c7 05 a8 0b 11 80 80 	movl   $0x80100280,0x80110ba8
801016cc:	02 10 80 
  cons.locking = 1;
801016cf:	c7 05 f4 01 11 80 01 	movl   $0x1,0x801101f4
801016d6:	00 00 00 
  input.r = input.w = input.e = input.c = 0;
801016d9:	c7 05 0c ff 10 80 00 	movl   $0x0,0x8010ff0c
801016e0:	00 00 00 
801016e3:	c7 05 08 ff 10 80 00 	movl   $0x0,0x8010ff08
801016ea:	00 00 00 
801016ed:	c7 05 04 ff 10 80 00 	movl   $0x0,0x8010ff04
801016f4:	00 00 00 
801016f7:	c7 05 00 ff 10 80 00 	movl   $0x0,0x8010ff00
801016fe:	00 00 00 
  input.esc_state = 0;
80101701:	c7 05 10 ff 10 80 00 	movl   $0x0,0x8010ff10
80101708:	00 00 00 
  input.ins_top = 0;
8010170b:	c7 05 14 01 11 80 00 	movl   $0x0,0x80110114
80101712:	00 00 00 
  input.sel_pending = 0;
80101715:	c7 05 18 01 11 80 00 	movl   $0x0,0x80110118
8010171c:	00 00 00 
  input.sel_active  = 0;
8010171f:	c7 05 1c 01 11 80 00 	movl   $0x0,0x8011011c
80101726:	00 00 00 
  input.clip_len = 0;
80101729:	c7 05 ac 01 11 80 00 	movl   $0x0,0x801101ac
80101730:	00 00 00 
  ioapicenable(IRQ_KBD, 0);
80101733:	e8 b8 19 00 00       	call   801030f0 <ioapicenable>
}
80101738:	83 c4 10             	add    $0x10,%esp
8010173b:	c9                   	leave
8010173c:	c3                   	ret
8010173d:	66 90                	xchg   %ax,%ax
8010173f:	90                   	nop

80101740 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80101740:	55                   	push   %ebp
80101741:	89 e5                	mov    %esp,%ebp
80101743:	57                   	push   %edi
80101744:	56                   	push   %esi
80101745:	53                   	push   %ebx
80101746:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
8010174c:	e8 9f 2e 00 00       	call   801045f0 <myproc>
80101751:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)

  begin_op();
80101757:	e8 74 22 00 00       	call   801039d0 <begin_op>

  if((ip = namei(path)) == 0){
8010175c:	83 ec 0c             	sub    $0xc,%esp
8010175f:	ff 75 08             	push   0x8(%ebp)
80101762:	e8 a9 15 00 00       	call   80102d10 <namei>
80101767:	83 c4 10             	add    $0x10,%esp
8010176a:	85 c0                	test   %eax,%eax
8010176c:	0f 84 30 03 00 00    	je     80101aa2 <exec+0x362>
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80101772:	83 ec 0c             	sub    $0xc,%esp
80101775:	89 c7                	mov    %eax,%edi
80101777:	50                   	push   %eax
80101778:	e8 b3 0c 00 00       	call   80102430 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
8010177d:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80101783:	6a 34                	push   $0x34
80101785:	6a 00                	push   $0x0
80101787:	50                   	push   %eax
80101788:	57                   	push   %edi
80101789:	e8 b2 0f 00 00       	call   80102740 <readi>
8010178e:	83 c4 20             	add    $0x20,%esp
80101791:	83 f8 34             	cmp    $0x34,%eax
80101794:	0f 85 01 01 00 00    	jne    8010189b <exec+0x15b>
    goto bad;
  if(elf.magic != ELF_MAGIC)
8010179a:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
801017a1:	45 4c 46 
801017a4:	0f 85 f1 00 00 00    	jne    8010189b <exec+0x15b>
    goto bad;

  if((pgdir = setupkvm()) == 0)
801017aa:	e8 01 63 00 00       	call   80107ab0 <setupkvm>
801017af:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)
801017b5:	85 c0                	test   %eax,%eax
801017b7:	0f 84 de 00 00 00    	je     8010189b <exec+0x15b>
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801017bd:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
801017c4:	00 
801017c5:	8b b5 40 ff ff ff    	mov    -0xc0(%ebp),%esi
801017cb:	0f 84 a1 02 00 00    	je     80101a72 <exec+0x332>
  sz = 0;
801017d1:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
801017d8:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801017db:	31 db                	xor    %ebx,%ebx
801017dd:	e9 8c 00 00 00       	jmp    8010186e <exec+0x12e>
801017e2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
801017e8:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
801017ef:	75 6c                	jne    8010185d <exec+0x11d>
      continue;
    if(ph.memsz < ph.filesz)
801017f1:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
801017f7:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
801017fd:	0f 82 87 00 00 00    	jb     8010188a <exec+0x14a>
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
80101803:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80101809:	72 7f                	jb     8010188a <exec+0x14a>
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
8010180b:	83 ec 04             	sub    $0x4,%esp
8010180e:	50                   	push   %eax
8010180f:	ff b5 f0 fe ff ff    	push   -0x110(%ebp)
80101815:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
8010181b:	e8 c0 60 00 00       	call   801078e0 <allocuvm>
80101820:	83 c4 10             	add    $0x10,%esp
80101823:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80101829:	85 c0                	test   %eax,%eax
8010182b:	74 5d                	je     8010188a <exec+0x14a>
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
8010182d:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80101833:	a9 ff 0f 00 00       	test   $0xfff,%eax
80101838:	75 50                	jne    8010188a <exec+0x14a>
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
8010183a:	83 ec 0c             	sub    $0xc,%esp
8010183d:	ff b5 14 ff ff ff    	push   -0xec(%ebp)
80101843:	ff b5 08 ff ff ff    	push   -0xf8(%ebp)
80101849:	57                   	push   %edi
8010184a:	50                   	push   %eax
8010184b:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80101851:	e8 ba 5f 00 00       	call   80107810 <loaduvm>
80101856:	83 c4 20             	add    $0x20,%esp
80101859:	85 c0                	test   %eax,%eax
8010185b:	78 2d                	js     8010188a <exec+0x14a>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
8010185d:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80101864:	83 c3 01             	add    $0x1,%ebx
80101867:	83 c6 20             	add    $0x20,%esi
8010186a:	39 d8                	cmp    %ebx,%eax
8010186c:	7e 52                	jle    801018c0 <exec+0x180>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
8010186e:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80101874:	6a 20                	push   $0x20
80101876:	56                   	push   %esi
80101877:	50                   	push   %eax
80101878:	57                   	push   %edi
80101879:	e8 c2 0e 00 00       	call   80102740 <readi>
8010187e:	83 c4 10             	add    $0x10,%esp
80101881:	83 f8 20             	cmp    $0x20,%eax
80101884:	0f 84 5e ff ff ff    	je     801017e8 <exec+0xa8>
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
8010188a:	83 ec 0c             	sub    $0xc,%esp
8010188d:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80101893:	e8 98 61 00 00       	call   80107a30 <freevm>
  if(ip){
80101898:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
8010189b:	83 ec 0c             	sub    $0xc,%esp
8010189e:	57                   	push   %edi
8010189f:	e8 1c 0e 00 00       	call   801026c0 <iunlockput>
    end_op();
801018a4:	e8 97 21 00 00       	call   80103a40 <end_op>
801018a9:	83 c4 10             	add    $0x10,%esp
    return -1;
801018ac:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  }
  return -1;
}
801018b1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801018b4:	5b                   	pop    %ebx
801018b5:	5e                   	pop    %esi
801018b6:	5f                   	pop    %edi
801018b7:	5d                   	pop    %ebp
801018b8:	c3                   	ret
801018b9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  sz = PGROUNDUP(sz);
801018c0:	8b b5 f0 fe ff ff    	mov    -0x110(%ebp),%esi
801018c6:	81 c6 ff 0f 00 00    	add    $0xfff,%esi
801018cc:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
801018d2:	8d 9e 00 20 00 00    	lea    0x2000(%esi),%ebx
  iunlockput(ip);
801018d8:	83 ec 0c             	sub    $0xc,%esp
801018db:	57                   	push   %edi
801018dc:	e8 df 0d 00 00       	call   801026c0 <iunlockput>
  end_op();
801018e1:	e8 5a 21 00 00       	call   80103a40 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
801018e6:	83 c4 0c             	add    $0xc,%esp
801018e9:	53                   	push   %ebx
801018ea:	56                   	push   %esi
801018eb:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
801018f1:	56                   	push   %esi
801018f2:	e8 e9 5f 00 00       	call   801078e0 <allocuvm>
801018f7:	83 c4 10             	add    $0x10,%esp
801018fa:	89 c7                	mov    %eax,%edi
801018fc:	85 c0                	test   %eax,%eax
801018fe:	0f 84 86 00 00 00    	je     8010198a <exec+0x24a>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80101904:	83 ec 08             	sub    $0x8,%esp
80101907:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
  sp = sz;
8010190d:	89 fb                	mov    %edi,%ebx
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
8010190f:	50                   	push   %eax
80101910:	56                   	push   %esi
  for(argc = 0; argv[argc]; argc++) {
80101911:	31 f6                	xor    %esi,%esi
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80101913:	e8 38 62 00 00       	call   80107b50 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80101918:	8b 45 0c             	mov    0xc(%ebp),%eax
8010191b:	83 c4 10             	add    $0x10,%esp
8010191e:	8b 10                	mov    (%eax),%edx
80101920:	85 d2                	test   %edx,%edx
80101922:	0f 84 56 01 00 00    	je     80101a7e <exec+0x33e>
80101928:	89 bd f0 fe ff ff    	mov    %edi,-0x110(%ebp)
8010192e:	8b 7d 0c             	mov    0xc(%ebp),%edi
80101931:	eb 23                	jmp    80101956 <exec+0x216>
80101933:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80101938:	8d 46 01             	lea    0x1(%esi),%eax
    ustack[3+argc] = sp;
8010193b:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
80101942:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
  for(argc = 0; argv[argc]; argc++) {
80101948:	8b 14 87             	mov    (%edi,%eax,4),%edx
8010194b:	85 d2                	test   %edx,%edx
8010194d:	74 51                	je     801019a0 <exec+0x260>
    if(argc >= MAXARG)
8010194f:	83 f8 20             	cmp    $0x20,%eax
80101952:	74 36                	je     8010198a <exec+0x24a>
80101954:	89 c6                	mov    %eax,%esi
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80101956:	83 ec 0c             	sub    $0xc,%esp
80101959:	52                   	push   %edx
8010195a:	e8 c1 3b 00 00       	call   80105520 <strlen>
8010195f:	29 c3                	sub    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80101961:	58                   	pop    %eax
80101962:	ff 34 b7             	push   (%edi,%esi,4)
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80101965:	83 eb 01             	sub    $0x1,%ebx
80101968:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
8010196b:	e8 b0 3b 00 00       	call   80105520 <strlen>
80101970:	83 c0 01             	add    $0x1,%eax
80101973:	50                   	push   %eax
80101974:	ff 34 b7             	push   (%edi,%esi,4)
80101977:	53                   	push   %ebx
80101978:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
8010197e:	e8 9d 63 00 00       	call   80107d20 <copyout>
80101983:	83 c4 20             	add    $0x20,%esp
80101986:	85 c0                	test   %eax,%eax
80101988:	79 ae                	jns    80101938 <exec+0x1f8>
    freevm(pgdir);
8010198a:	83 ec 0c             	sub    $0xc,%esp
8010198d:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80101993:	e8 98 60 00 00       	call   80107a30 <freevm>
80101998:	83 c4 10             	add    $0x10,%esp
8010199b:	e9 0c ff ff ff       	jmp    801018ac <exec+0x16c>
  ustack[2] = sp - (argc+1)*4;  // argv pointer
801019a0:	8d 14 b5 08 00 00 00 	lea    0x8(,%esi,4),%edx
  ustack[3+argc] = 0;
801019a7:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
801019ad:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
801019b3:	8d 46 04             	lea    0x4(%esi),%eax
  sp -= (3+argc+1) * 4;
801019b6:	8d 72 0c             	lea    0xc(%edx),%esi
  ustack[3+argc] = 0;
801019b9:	c7 84 85 58 ff ff ff 	movl   $0x0,-0xa8(%ebp,%eax,4)
801019c0:	00 00 00 00 
  ustack[1] = argc;
801019c4:	8b 85 f0 fe ff ff    	mov    -0x110(%ebp),%eax
  ustack[0] = 0xffffffff;  // fake return PC
801019ca:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
801019d1:	ff ff ff 
  ustack[1] = argc;
801019d4:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
801019da:	89 d8                	mov    %ebx,%eax
  sp -= (3+argc+1) * 4;
801019dc:	29 f3                	sub    %esi,%ebx
  ustack[2] = sp - (argc+1)*4;  // argv pointer
801019de:	29 d0                	sub    %edx,%eax
801019e0:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
801019e6:	56                   	push   %esi
801019e7:	51                   	push   %ecx
801019e8:	53                   	push   %ebx
801019e9:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
801019ef:	e8 2c 63 00 00       	call   80107d20 <copyout>
801019f4:	83 c4 10             	add    $0x10,%esp
801019f7:	85 c0                	test   %eax,%eax
801019f9:	78 8f                	js     8010198a <exec+0x24a>
  for(last=s=path; *s; s++)
801019fb:	8b 45 08             	mov    0x8(%ebp),%eax
801019fe:	8b 55 08             	mov    0x8(%ebp),%edx
80101a01:	0f b6 00             	movzbl (%eax),%eax
80101a04:	84 c0                	test   %al,%al
80101a06:	74 17                	je     80101a1f <exec+0x2df>
80101a08:	89 d1                	mov    %edx,%ecx
80101a0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      last = s+1;
80101a10:	83 c1 01             	add    $0x1,%ecx
80101a13:	3c 2f                	cmp    $0x2f,%al
  for(last=s=path; *s; s++)
80101a15:	0f b6 01             	movzbl (%ecx),%eax
      last = s+1;
80101a18:	0f 44 d1             	cmove  %ecx,%edx
  for(last=s=path; *s; s++)
80101a1b:	84 c0                	test   %al,%al
80101a1d:	75 f1                	jne    80101a10 <exec+0x2d0>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80101a1f:	83 ec 04             	sub    $0x4,%esp
80101a22:	6a 10                	push   $0x10
80101a24:	52                   	push   %edx
80101a25:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
80101a2b:	8d 46 6c             	lea    0x6c(%esi),%eax
80101a2e:	50                   	push   %eax
80101a2f:	e8 ac 3a 00 00       	call   801054e0 <safestrcpy>
  curproc->pgdir = pgdir;
80101a34:	8b 8d f4 fe ff ff    	mov    -0x10c(%ebp),%ecx
  oldpgdir = curproc->pgdir;
80101a3a:	89 f0                	mov    %esi,%eax
80101a3c:	8b 76 04             	mov    0x4(%esi),%esi
  curproc->sz = sz;
80101a3f:	89 38                	mov    %edi,(%eax)
  curproc->pgdir = pgdir;
80101a41:	89 48 04             	mov    %ecx,0x4(%eax)
  curproc->tf->eip = elf.entry;  // main
80101a44:	89 c1                	mov    %eax,%ecx
80101a46:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80101a4c:	8b 40 18             	mov    0x18(%eax),%eax
80101a4f:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80101a52:	8b 41 18             	mov    0x18(%ecx),%eax
80101a55:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80101a58:	89 0c 24             	mov    %ecx,(%esp)
80101a5b:	e8 20 5c 00 00       	call   80107680 <switchuvm>
  freevm(oldpgdir);
80101a60:	89 34 24             	mov    %esi,(%esp)
80101a63:	e8 c8 5f 00 00       	call   80107a30 <freevm>
  return 0;
80101a68:	83 c4 10             	add    $0x10,%esp
80101a6b:	31 c0                	xor    %eax,%eax
80101a6d:	e9 3f fe ff ff       	jmp    801018b1 <exec+0x171>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80101a72:	bb 00 20 00 00       	mov    $0x2000,%ebx
80101a77:	31 f6                	xor    %esi,%esi
80101a79:	e9 5a fe ff ff       	jmp    801018d8 <exec+0x198>
  for(argc = 0; argv[argc]; argc++) {
80101a7e:	be 10 00 00 00       	mov    $0x10,%esi
80101a83:	ba 04 00 00 00       	mov    $0x4,%edx
80101a88:	b8 03 00 00 00       	mov    $0x3,%eax
80101a8d:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80101a94:	00 00 00 
80101a97:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
80101a9d:	e9 17 ff ff ff       	jmp    801019b9 <exec+0x279>
    end_op();
80101aa2:	e8 99 1f 00 00       	call   80103a40 <end_op>
    cprintf("exec: fail\n");
80101aa7:	83 ec 0c             	sub    $0xc,%esp
80101aaa:	68 61 7e 10 80       	push   $0x80107e61
80101aaf:	e8 2c f2 ff ff       	call   80100ce0 <cprintf>
    return -1;
80101ab4:	83 c4 10             	add    $0x10,%esp
80101ab7:	e9 f0 fd ff ff       	jmp    801018ac <exec+0x16c>
80101abc:	66 90                	xchg   %ax,%ax
80101abe:	66 90                	xchg   %ax,%ax

80101ac0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80101ac0:	55                   	push   %ebp
80101ac1:	89 e5                	mov    %esp,%ebp
80101ac3:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80101ac6:	68 6d 7e 10 80       	push   $0x80107e6d
80101acb:	68 00 02 11 80       	push   $0x80110200
80101ad0:	e8 6b 35 00 00       	call   80105040 <initlock>
}
80101ad5:	83 c4 10             	add    $0x10,%esp
80101ad8:	c9                   	leave
80101ad9:	c3                   	ret
80101ada:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101ae0 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80101ae0:	55                   	push   %ebp
80101ae1:	89 e5                	mov    %esp,%ebp
80101ae3:	53                   	push   %ebx
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80101ae4:	bb 34 02 11 80       	mov    $0x80110234,%ebx
{
80101ae9:	83 ec 10             	sub    $0x10,%esp
  acquire(&ftable.lock);
80101aec:	68 00 02 11 80       	push   $0x80110200
80101af1:	e8 3a 37 00 00       	call   80105230 <acquire>
80101af6:	83 c4 10             	add    $0x10,%esp
80101af9:	eb 10                	jmp    80101b0b <filealloc+0x2b>
80101afb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80101b00:	83 c3 18             	add    $0x18,%ebx
80101b03:	81 fb 94 0b 11 80    	cmp    $0x80110b94,%ebx
80101b09:	74 25                	je     80101b30 <filealloc+0x50>
    if(f->ref == 0){
80101b0b:	8b 43 04             	mov    0x4(%ebx),%eax
80101b0e:	85 c0                	test   %eax,%eax
80101b10:	75 ee                	jne    80101b00 <filealloc+0x20>
      f->ref = 1;
      release(&ftable.lock);
80101b12:	83 ec 0c             	sub    $0xc,%esp
      f->ref = 1;
80101b15:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80101b1c:	68 00 02 11 80       	push   $0x80110200
80101b21:	e8 aa 36 00 00       	call   801051d0 <release>
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}
80101b26:	89 d8                	mov    %ebx,%eax
      return f;
80101b28:	83 c4 10             	add    $0x10,%esp
}
80101b2b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101b2e:	c9                   	leave
80101b2f:	c3                   	ret
  release(&ftable.lock);
80101b30:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80101b33:	31 db                	xor    %ebx,%ebx
  release(&ftable.lock);
80101b35:	68 00 02 11 80       	push   $0x80110200
80101b3a:	e8 91 36 00 00       	call   801051d0 <release>
}
80101b3f:	89 d8                	mov    %ebx,%eax
  return 0;
80101b41:	83 c4 10             	add    $0x10,%esp
}
80101b44:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101b47:	c9                   	leave
80101b48:	c3                   	ret
80101b49:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80101b50 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80101b50:	55                   	push   %ebp
80101b51:	89 e5                	mov    %esp,%ebp
80101b53:	53                   	push   %ebx
80101b54:	83 ec 10             	sub    $0x10,%esp
80101b57:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80101b5a:	68 00 02 11 80       	push   $0x80110200
80101b5f:	e8 cc 36 00 00       	call   80105230 <acquire>
  if(f->ref < 1)
80101b64:	8b 43 04             	mov    0x4(%ebx),%eax
80101b67:	83 c4 10             	add    $0x10,%esp
80101b6a:	85 c0                	test   %eax,%eax
80101b6c:	7e 1a                	jle    80101b88 <filedup+0x38>
    panic("filedup");
  f->ref++;
80101b6e:	83 c0 01             	add    $0x1,%eax
  release(&ftable.lock);
80101b71:	83 ec 0c             	sub    $0xc,%esp
  f->ref++;
80101b74:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80101b77:	68 00 02 11 80       	push   $0x80110200
80101b7c:	e8 4f 36 00 00       	call   801051d0 <release>
  return f;
}
80101b81:	89 d8                	mov    %ebx,%eax
80101b83:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101b86:	c9                   	leave
80101b87:	c3                   	ret
    panic("filedup");
80101b88:	83 ec 0c             	sub    $0xc,%esp
80101b8b:	68 74 7e 10 80       	push   $0x80107e74
80101b90:	e8 eb e7 ff ff       	call   80100380 <panic>
80101b95:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101b9c:	00 
80101b9d:	8d 76 00             	lea    0x0(%esi),%esi

80101ba0 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80101ba0:	55                   	push   %ebp
80101ba1:	89 e5                	mov    %esp,%ebp
80101ba3:	57                   	push   %edi
80101ba4:	56                   	push   %esi
80101ba5:	53                   	push   %ebx
80101ba6:	83 ec 28             	sub    $0x28,%esp
80101ba9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80101bac:	68 00 02 11 80       	push   $0x80110200
80101bb1:	e8 7a 36 00 00       	call   80105230 <acquire>
  if(f->ref < 1)
80101bb6:	8b 53 04             	mov    0x4(%ebx),%edx
80101bb9:	83 c4 10             	add    $0x10,%esp
80101bbc:	85 d2                	test   %edx,%edx
80101bbe:	0f 8e a5 00 00 00    	jle    80101c69 <fileclose+0xc9>
    panic("fileclose");
  if(--f->ref > 0){
80101bc4:	83 ea 01             	sub    $0x1,%edx
80101bc7:	89 53 04             	mov    %edx,0x4(%ebx)
80101bca:	75 44                	jne    80101c10 <fileclose+0x70>
    release(&ftable.lock);
    return;
  }
  ff = *f;
80101bcc:	0f b6 43 09          	movzbl 0x9(%ebx),%eax
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);
80101bd0:	83 ec 0c             	sub    $0xc,%esp
  ff = *f;
80101bd3:	8b 3b                	mov    (%ebx),%edi
  f->type = FD_NONE;
80101bd5:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  ff = *f;
80101bdb:	8b 73 0c             	mov    0xc(%ebx),%esi
80101bde:	88 45 e7             	mov    %al,-0x19(%ebp)
80101be1:	8b 43 10             	mov    0x10(%ebx),%eax
80101be4:	89 45 e0             	mov    %eax,-0x20(%ebp)
  release(&ftable.lock);
80101be7:	68 00 02 11 80       	push   $0x80110200
80101bec:	e8 df 35 00 00       	call   801051d0 <release>

  if(ff.type == FD_PIPE)
80101bf1:	83 c4 10             	add    $0x10,%esp
80101bf4:	83 ff 01             	cmp    $0x1,%edi
80101bf7:	74 57                	je     80101c50 <fileclose+0xb0>
    pipeclose(ff.pipe, ff.writable);
  else if(ff.type == FD_INODE){
80101bf9:	83 ff 02             	cmp    $0x2,%edi
80101bfc:	74 2a                	je     80101c28 <fileclose+0x88>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80101bfe:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c01:	5b                   	pop    %ebx
80101c02:	5e                   	pop    %esi
80101c03:	5f                   	pop    %edi
80101c04:	5d                   	pop    %ebp
80101c05:	c3                   	ret
80101c06:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101c0d:	00 
80101c0e:	66 90                	xchg   %ax,%ax
    release(&ftable.lock);
80101c10:	c7 45 08 00 02 11 80 	movl   $0x80110200,0x8(%ebp)
}
80101c17:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c1a:	5b                   	pop    %ebx
80101c1b:	5e                   	pop    %esi
80101c1c:	5f                   	pop    %edi
80101c1d:	5d                   	pop    %ebp
    release(&ftable.lock);
80101c1e:	e9 ad 35 00 00       	jmp    801051d0 <release>
80101c23:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    begin_op();
80101c28:	e8 a3 1d 00 00       	call   801039d0 <begin_op>
    iput(ff.ip);
80101c2d:	83 ec 0c             	sub    $0xc,%esp
80101c30:	ff 75 e0             	push   -0x20(%ebp)
80101c33:	e8 28 09 00 00       	call   80102560 <iput>
    end_op();
80101c38:	83 c4 10             	add    $0x10,%esp
}
80101c3b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c3e:	5b                   	pop    %ebx
80101c3f:	5e                   	pop    %esi
80101c40:	5f                   	pop    %edi
80101c41:	5d                   	pop    %ebp
    end_op();
80101c42:	e9 f9 1d 00 00       	jmp    80103a40 <end_op>
80101c47:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101c4e:	00 
80101c4f:	90                   	nop
    pipeclose(ff.pipe, ff.writable);
80101c50:	0f be 5d e7          	movsbl -0x19(%ebp),%ebx
80101c54:	83 ec 08             	sub    $0x8,%esp
80101c57:	53                   	push   %ebx
80101c58:	56                   	push   %esi
80101c59:	e8 32 25 00 00       	call   80104190 <pipeclose>
80101c5e:	83 c4 10             	add    $0x10,%esp
}
80101c61:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c64:	5b                   	pop    %ebx
80101c65:	5e                   	pop    %esi
80101c66:	5f                   	pop    %edi
80101c67:	5d                   	pop    %ebp
80101c68:	c3                   	ret
    panic("fileclose");
80101c69:	83 ec 0c             	sub    $0xc,%esp
80101c6c:	68 7c 7e 10 80       	push   $0x80107e7c
80101c71:	e8 0a e7 ff ff       	call   80100380 <panic>
80101c76:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101c7d:	00 
80101c7e:	66 90                	xchg   %ax,%ax

80101c80 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80101c80:	55                   	push   %ebp
80101c81:	89 e5                	mov    %esp,%ebp
80101c83:	53                   	push   %ebx
80101c84:	83 ec 04             	sub    $0x4,%esp
80101c87:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80101c8a:	83 3b 02             	cmpl   $0x2,(%ebx)
80101c8d:	75 31                	jne    80101cc0 <filestat+0x40>
    ilock(f->ip);
80101c8f:	83 ec 0c             	sub    $0xc,%esp
80101c92:	ff 73 10             	push   0x10(%ebx)
80101c95:	e8 96 07 00 00       	call   80102430 <ilock>
    stati(f->ip, st);
80101c9a:	58                   	pop    %eax
80101c9b:	5a                   	pop    %edx
80101c9c:	ff 75 0c             	push   0xc(%ebp)
80101c9f:	ff 73 10             	push   0x10(%ebx)
80101ca2:	e8 69 0a 00 00       	call   80102710 <stati>
    iunlock(f->ip);
80101ca7:	59                   	pop    %ecx
80101ca8:	ff 73 10             	push   0x10(%ebx)
80101cab:	e8 60 08 00 00       	call   80102510 <iunlock>
    return 0;
  }
  return -1;
}
80101cb0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80101cb3:	83 c4 10             	add    $0x10,%esp
80101cb6:	31 c0                	xor    %eax,%eax
}
80101cb8:	c9                   	leave
80101cb9:	c3                   	ret
80101cba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101cc0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
80101cc3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80101cc8:	c9                   	leave
80101cc9:	c3                   	ret
80101cca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101cd0 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80101cd0:	55                   	push   %ebp
80101cd1:	89 e5                	mov    %esp,%ebp
80101cd3:	57                   	push   %edi
80101cd4:	56                   	push   %esi
80101cd5:	53                   	push   %ebx
80101cd6:	83 ec 0c             	sub    $0xc,%esp
80101cd9:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101cdc:	8b 75 0c             	mov    0xc(%ebp),%esi
80101cdf:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
80101ce2:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80101ce6:	74 60                	je     80101d48 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
80101ce8:	8b 03                	mov    (%ebx),%eax
80101cea:	83 f8 01             	cmp    $0x1,%eax
80101ced:	74 41                	je     80101d30 <fileread+0x60>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
80101cef:	83 f8 02             	cmp    $0x2,%eax
80101cf2:	75 5b                	jne    80101d4f <fileread+0x7f>
    ilock(f->ip);
80101cf4:	83 ec 0c             	sub    $0xc,%esp
80101cf7:	ff 73 10             	push   0x10(%ebx)
80101cfa:	e8 31 07 00 00       	call   80102430 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80101cff:	57                   	push   %edi
80101d00:	ff 73 14             	push   0x14(%ebx)
80101d03:	56                   	push   %esi
80101d04:	ff 73 10             	push   0x10(%ebx)
80101d07:	e8 34 0a 00 00       	call   80102740 <readi>
80101d0c:	83 c4 20             	add    $0x20,%esp
80101d0f:	89 c6                	mov    %eax,%esi
80101d11:	85 c0                	test   %eax,%eax
80101d13:	7e 03                	jle    80101d18 <fileread+0x48>
      f->off += r;
80101d15:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80101d18:	83 ec 0c             	sub    $0xc,%esp
80101d1b:	ff 73 10             	push   0x10(%ebx)
80101d1e:	e8 ed 07 00 00       	call   80102510 <iunlock>
    return r;
80101d23:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80101d26:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d29:	89 f0                	mov    %esi,%eax
80101d2b:	5b                   	pop    %ebx
80101d2c:	5e                   	pop    %esi
80101d2d:	5f                   	pop    %edi
80101d2e:	5d                   	pop    %ebp
80101d2f:	c3                   	ret
    return piperead(f->pipe, addr, n);
80101d30:	8b 43 0c             	mov    0xc(%ebx),%eax
80101d33:	89 45 08             	mov    %eax,0x8(%ebp)
}
80101d36:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d39:	5b                   	pop    %ebx
80101d3a:	5e                   	pop    %esi
80101d3b:	5f                   	pop    %edi
80101d3c:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
80101d3d:	e9 0e 26 00 00       	jmp    80104350 <piperead>
80101d42:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80101d48:	be ff ff ff ff       	mov    $0xffffffff,%esi
80101d4d:	eb d7                	jmp    80101d26 <fileread+0x56>
  panic("fileread");
80101d4f:	83 ec 0c             	sub    $0xc,%esp
80101d52:	68 86 7e 10 80       	push   $0x80107e86
80101d57:	e8 24 e6 ff ff       	call   80100380 <panic>
80101d5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101d60 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80101d60:	55                   	push   %ebp
80101d61:	89 e5                	mov    %esp,%ebp
80101d63:	57                   	push   %edi
80101d64:	56                   	push   %esi
80101d65:	53                   	push   %ebx
80101d66:	83 ec 1c             	sub    $0x1c,%esp
80101d69:	8b 45 0c             	mov    0xc(%ebp),%eax
80101d6c:	8b 5d 08             	mov    0x8(%ebp),%ebx
80101d6f:	89 45 dc             	mov    %eax,-0x24(%ebp)
80101d72:	8b 45 10             	mov    0x10(%ebp),%eax
  int r;

  if(f->writable == 0)
80101d75:	80 7b 09 00          	cmpb   $0x0,0x9(%ebx)
{
80101d79:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(f->writable == 0)
80101d7c:	0f 84 bb 00 00 00    	je     80101e3d <filewrite+0xdd>
    return -1;
  if(f->type == FD_PIPE)
80101d82:	8b 03                	mov    (%ebx),%eax
80101d84:	83 f8 01             	cmp    $0x1,%eax
80101d87:	0f 84 bf 00 00 00    	je     80101e4c <filewrite+0xec>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
80101d8d:	83 f8 02             	cmp    $0x2,%eax
80101d90:	0f 85 c8 00 00 00    	jne    80101e5e <filewrite+0xfe>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80101d96:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    int i = 0;
80101d99:	31 f6                	xor    %esi,%esi
    while(i < n){
80101d9b:	85 c0                	test   %eax,%eax
80101d9d:	7f 30                	jg     80101dcf <filewrite+0x6f>
80101d9f:	e9 94 00 00 00       	jmp    80101e38 <filewrite+0xd8>
80101da4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
80101da8:	01 43 14             	add    %eax,0x14(%ebx)
      iunlock(f->ip);
80101dab:	83 ec 0c             	sub    $0xc,%esp
        f->off += r;
80101dae:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
80101db1:	ff 73 10             	push   0x10(%ebx)
80101db4:	e8 57 07 00 00       	call   80102510 <iunlock>
      end_op();
80101db9:	e8 82 1c 00 00       	call   80103a40 <end_op>

      if(r < 0)
        break;
      if(r != n1)
80101dbe:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101dc1:	83 c4 10             	add    $0x10,%esp
80101dc4:	39 c7                	cmp    %eax,%edi
80101dc6:	75 5c                	jne    80101e24 <filewrite+0xc4>
        panic("short filewrite");
      i += r;
80101dc8:	01 fe                	add    %edi,%esi
    while(i < n){
80101dca:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
80101dcd:	7e 69                	jle    80101e38 <filewrite+0xd8>
      int n1 = n - i;
80101dcf:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      if(n1 > max)
80101dd2:	b8 00 06 00 00       	mov    $0x600,%eax
      int n1 = n - i;
80101dd7:	29 f7                	sub    %esi,%edi
      if(n1 > max)
80101dd9:	39 c7                	cmp    %eax,%edi
80101ddb:	0f 4f f8             	cmovg  %eax,%edi
      begin_op();
80101dde:	e8 ed 1b 00 00       	call   801039d0 <begin_op>
      ilock(f->ip);
80101de3:	83 ec 0c             	sub    $0xc,%esp
80101de6:	ff 73 10             	push   0x10(%ebx)
80101de9:	e8 42 06 00 00       	call   80102430 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80101dee:	57                   	push   %edi
80101def:	ff 73 14             	push   0x14(%ebx)
80101df2:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101df5:	01 f0                	add    %esi,%eax
80101df7:	50                   	push   %eax
80101df8:	ff 73 10             	push   0x10(%ebx)
80101dfb:	e8 40 0a 00 00       	call   80102840 <writei>
80101e00:	83 c4 20             	add    $0x20,%esp
80101e03:	85 c0                	test   %eax,%eax
80101e05:	7f a1                	jg     80101da8 <filewrite+0x48>
80101e07:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
80101e0a:	83 ec 0c             	sub    $0xc,%esp
80101e0d:	ff 73 10             	push   0x10(%ebx)
80101e10:	e8 fb 06 00 00       	call   80102510 <iunlock>
      end_op();
80101e15:	e8 26 1c 00 00       	call   80103a40 <end_op>
      if(r < 0)
80101e1a:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101e1d:	83 c4 10             	add    $0x10,%esp
80101e20:	85 c0                	test   %eax,%eax
80101e22:	75 14                	jne    80101e38 <filewrite+0xd8>
        panic("short filewrite");
80101e24:	83 ec 0c             	sub    $0xc,%esp
80101e27:	68 8f 7e 10 80       	push   $0x80107e8f
80101e2c:	e8 4f e5 ff ff       	call   80100380 <panic>
80101e31:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    }
    return i == n ? n : -1;
80101e38:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
80101e3b:	74 05                	je     80101e42 <filewrite+0xe2>
80101e3d:	be ff ff ff ff       	mov    $0xffffffff,%esi
  }
  panic("filewrite");
}
80101e42:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101e45:	89 f0                	mov    %esi,%eax
80101e47:	5b                   	pop    %ebx
80101e48:	5e                   	pop    %esi
80101e49:	5f                   	pop    %edi
80101e4a:	5d                   	pop    %ebp
80101e4b:	c3                   	ret
    return pipewrite(f->pipe, addr, n);
80101e4c:	8b 43 0c             	mov    0xc(%ebx),%eax
80101e4f:	89 45 08             	mov    %eax,0x8(%ebp)
}
80101e52:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101e55:	5b                   	pop    %ebx
80101e56:	5e                   	pop    %esi
80101e57:	5f                   	pop    %edi
80101e58:	5d                   	pop    %ebp
    return pipewrite(f->pipe, addr, n);
80101e59:	e9 d2 23 00 00       	jmp    80104230 <pipewrite>
  panic("filewrite");
80101e5e:	83 ec 0c             	sub    $0xc,%esp
80101e61:	68 95 7e 10 80       	push   $0x80107e95
80101e66:	e8 15 e5 ff ff       	call   80100380 <panic>
80101e6b:	66 90                	xchg   %ax,%ax
80101e6d:	66 90                	xchg   %ax,%ax
80101e6f:	90                   	nop

80101e70 <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
80101e70:	55                   	push   %ebp
80101e71:	89 e5                	mov    %esp,%ebp
80101e73:	57                   	push   %edi
80101e74:	56                   	push   %esi
80101e75:	53                   	push   %ebx
80101e76:	83 ec 1c             	sub    $0x1c,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  for(b = 0; b < sb.size; b += BPB){
80101e79:	8b 0d 54 28 11 80    	mov    0x80112854,%ecx
{
80101e7f:	89 45 dc             	mov    %eax,-0x24(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101e82:	85 c9                	test   %ecx,%ecx
80101e84:	0f 84 8c 00 00 00    	je     80101f16 <balloc+0xa6>
80101e8a:	31 ff                	xor    %edi,%edi
    bp = bread(dev, BBLOCK(b, sb));
80101e8c:	89 f8                	mov    %edi,%eax
80101e8e:	83 ec 08             	sub    $0x8,%esp
80101e91:	89 fe                	mov    %edi,%esi
80101e93:	c1 f8 0c             	sar    $0xc,%eax
80101e96:	03 05 6c 28 11 80    	add    0x8011286c,%eax
80101e9c:	50                   	push   %eax
80101e9d:	ff 75 dc             	push   -0x24(%ebp)
80101ea0:	e8 2b e2 ff ff       	call   801000d0 <bread>
80101ea5:	83 c4 10             	add    $0x10,%esp
80101ea8:	89 7d d8             	mov    %edi,-0x28(%ebp)
80101eab:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
80101eae:	a1 54 28 11 80       	mov    0x80112854,%eax
80101eb3:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101eb6:	31 c0                	xor    %eax,%eax
80101eb8:	eb 32                	jmp    80101eec <balloc+0x7c>
80101eba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      m = 1 << (bi % 8);
80101ec0:	89 c1                	mov    %eax,%ecx
80101ec2:	bb 01 00 00 00       	mov    $0x1,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101ec7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      m = 1 << (bi % 8);
80101eca:	83 e1 07             	and    $0x7,%ecx
80101ecd:	d3 e3                	shl    %cl,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101ecf:	89 c1                	mov    %eax,%ecx
80101ed1:	c1 f9 03             	sar    $0x3,%ecx
80101ed4:	0f b6 7c 0f 5c       	movzbl 0x5c(%edi,%ecx,1),%edi
80101ed9:	89 fa                	mov    %edi,%edx
80101edb:	85 df                	test   %ebx,%edi
80101edd:	74 49                	je     80101f28 <balloc+0xb8>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
80101edf:	83 c0 01             	add    $0x1,%eax
80101ee2:	83 c6 01             	add    $0x1,%esi
80101ee5:	3d 00 10 00 00       	cmp    $0x1000,%eax
80101eea:	74 07                	je     80101ef3 <balloc+0x83>
80101eec:	8b 55 e0             	mov    -0x20(%ebp),%edx
80101eef:	39 d6                	cmp    %edx,%esi
80101ef1:	72 cd                	jb     80101ec0 <balloc+0x50>
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
80101ef3:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101ef6:	83 ec 0c             	sub    $0xc,%esp
80101ef9:	ff 75 e4             	push   -0x1c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101efc:	81 c7 00 10 00 00    	add    $0x1000,%edi
    brelse(bp);
80101f02:	e8 e9 e2 ff ff       	call   801001f0 <brelse>
  for(b = 0; b < sb.size; b += BPB){
80101f07:	83 c4 10             	add    $0x10,%esp
80101f0a:	3b 3d 54 28 11 80    	cmp    0x80112854,%edi
80101f10:	0f 82 76 ff ff ff    	jb     80101e8c <balloc+0x1c>
  }
  panic("balloc: out of blocks");
80101f16:	83 ec 0c             	sub    $0xc,%esp
80101f19:	68 9f 7e 10 80       	push   $0x80107e9f
80101f1e:	e8 5d e4 ff ff       	call   80100380 <panic>
80101f23:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        bp->data[bi/8] |= m;  // Mark block in use.
80101f28:	8b 7d e4             	mov    -0x1c(%ebp),%edi
        log_write(bp);
80101f2b:	83 ec 0c             	sub    $0xc,%esp
        bp->data[bi/8] |= m;  // Mark block in use.
80101f2e:	09 da                	or     %ebx,%edx
80101f30:	88 54 0f 5c          	mov    %dl,0x5c(%edi,%ecx,1)
        log_write(bp);
80101f34:	57                   	push   %edi
80101f35:	e8 76 1c 00 00       	call   80103bb0 <log_write>
        brelse(bp);
80101f3a:	89 3c 24             	mov    %edi,(%esp)
80101f3d:	e8 ae e2 ff ff       	call   801001f0 <brelse>
  bp = bread(dev, bno);
80101f42:	58                   	pop    %eax
80101f43:	5a                   	pop    %edx
80101f44:	56                   	push   %esi
80101f45:	ff 75 dc             	push   -0x24(%ebp)
80101f48:	e8 83 e1 ff ff       	call   801000d0 <bread>
  memset(bp->data, 0, BSIZE);
80101f4d:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, bno);
80101f50:	89 c3                	mov    %eax,%ebx
  memset(bp->data, 0, BSIZE);
80101f52:	8d 40 5c             	lea    0x5c(%eax),%eax
80101f55:	68 00 02 00 00       	push   $0x200
80101f5a:	6a 00                	push   $0x0
80101f5c:	50                   	push   %eax
80101f5d:	e8 ce 33 00 00       	call   80105330 <memset>
  log_write(bp);
80101f62:	89 1c 24             	mov    %ebx,(%esp)
80101f65:	e8 46 1c 00 00       	call   80103bb0 <log_write>
  brelse(bp);
80101f6a:	89 1c 24             	mov    %ebx,(%esp)
80101f6d:	e8 7e e2 ff ff       	call   801001f0 <brelse>
}
80101f72:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f75:	89 f0                	mov    %esi,%eax
80101f77:	5b                   	pop    %ebx
80101f78:	5e                   	pop    %esi
80101f79:	5f                   	pop    %edi
80101f7a:	5d                   	pop    %ebp
80101f7b:	c3                   	ret
80101f7c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101f80 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
80101f80:	55                   	push   %ebp
80101f81:	89 e5                	mov    %esp,%ebp
80101f83:	57                   	push   %edi
  struct inode *ip, *empty;

  acquire(&icache.lock);

  // Is the inode already cached?
  empty = 0;
80101f84:	31 ff                	xor    %edi,%edi
{
80101f86:	56                   	push   %esi
80101f87:	89 c6                	mov    %eax,%esi
80101f89:	53                   	push   %ebx
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101f8a:	bb 34 0c 11 80       	mov    $0x80110c34,%ebx
{
80101f8f:	83 ec 28             	sub    $0x28,%esp
80101f92:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  acquire(&icache.lock);
80101f95:	68 00 0c 11 80       	push   $0x80110c00
80101f9a:	e8 91 32 00 00       	call   80105230 <acquire>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101f9f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  acquire(&icache.lock);
80101fa2:	83 c4 10             	add    $0x10,%esp
80101fa5:	eb 1b                	jmp    80101fc2 <iget+0x42>
80101fa7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101fae:	00 
80101faf:	90                   	nop
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101fb0:	39 33                	cmp    %esi,(%ebx)
80101fb2:	74 6c                	je     80102020 <iget+0xa0>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101fb4:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101fba:	81 fb 54 28 11 80    	cmp    $0x80112854,%ebx
80101fc0:	74 26                	je     80101fe8 <iget+0x68>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101fc2:	8b 43 08             	mov    0x8(%ebx),%eax
80101fc5:	85 c0                	test   %eax,%eax
80101fc7:	7f e7                	jg     80101fb0 <iget+0x30>
      ip->ref++;
      release(&icache.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101fc9:	85 ff                	test   %edi,%edi
80101fcb:	75 e7                	jne    80101fb4 <iget+0x34>
80101fcd:	85 c0                	test   %eax,%eax
80101fcf:	75 76                	jne    80102047 <iget+0xc7>
      empty = ip;
80101fd1:	89 df                	mov    %ebx,%edi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101fd3:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101fd9:	81 fb 54 28 11 80    	cmp    $0x80112854,%ebx
80101fdf:	75 e1                	jne    80101fc2 <iget+0x42>
80101fe1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  }

  // Recycle an inode cache entry.
  if(empty == 0)
80101fe8:	85 ff                	test   %edi,%edi
80101fea:	74 79                	je     80102065 <iget+0xe5>
  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  release(&icache.lock);
80101fec:	83 ec 0c             	sub    $0xc,%esp
  ip->dev = dev;
80101fef:	89 37                	mov    %esi,(%edi)
  ip->inum = inum;
80101ff1:	89 57 04             	mov    %edx,0x4(%edi)
  ip->ref = 1;
80101ff4:	c7 47 08 01 00 00 00 	movl   $0x1,0x8(%edi)
  ip->valid = 0;
80101ffb:	c7 47 4c 00 00 00 00 	movl   $0x0,0x4c(%edi)
  release(&icache.lock);
80102002:	68 00 0c 11 80       	push   $0x80110c00
80102007:	e8 c4 31 00 00       	call   801051d0 <release>

  return ip;
8010200c:	83 c4 10             	add    $0x10,%esp
}
8010200f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102012:	89 f8                	mov    %edi,%eax
80102014:	5b                   	pop    %ebx
80102015:	5e                   	pop    %esi
80102016:	5f                   	pop    %edi
80102017:	5d                   	pop    %ebp
80102018:	c3                   	ret
80102019:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80102020:	39 53 04             	cmp    %edx,0x4(%ebx)
80102023:	75 8f                	jne    80101fb4 <iget+0x34>
      ip->ref++;
80102025:	83 c0 01             	add    $0x1,%eax
      release(&icache.lock);
80102028:	83 ec 0c             	sub    $0xc,%esp
      return ip;
8010202b:	89 df                	mov    %ebx,%edi
      ip->ref++;
8010202d:	89 43 08             	mov    %eax,0x8(%ebx)
      release(&icache.lock);
80102030:	68 00 0c 11 80       	push   $0x80110c00
80102035:	e8 96 31 00 00       	call   801051d0 <release>
      return ip;
8010203a:	83 c4 10             	add    $0x10,%esp
}
8010203d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102040:	89 f8                	mov    %edi,%eax
80102042:	5b                   	pop    %ebx
80102043:	5e                   	pop    %esi
80102044:	5f                   	pop    %edi
80102045:	5d                   	pop    %ebp
80102046:	c3                   	ret
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80102047:	81 c3 90 00 00 00    	add    $0x90,%ebx
8010204d:	81 fb 54 28 11 80    	cmp    $0x80112854,%ebx
80102053:	74 10                	je     80102065 <iget+0xe5>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80102055:	8b 43 08             	mov    0x8(%ebx),%eax
80102058:	85 c0                	test   %eax,%eax
8010205a:	0f 8f 50 ff ff ff    	jg     80101fb0 <iget+0x30>
80102060:	e9 68 ff ff ff       	jmp    80101fcd <iget+0x4d>
    panic("iget: no inodes");
80102065:	83 ec 0c             	sub    $0xc,%esp
80102068:	68 b5 7e 10 80       	push   $0x80107eb5
8010206d:	e8 0e e3 ff ff       	call   80100380 <panic>
80102072:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102079:	00 
8010207a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80102080 <bfree>:
{
80102080:	55                   	push   %ebp
80102081:	89 c1                	mov    %eax,%ecx
  bp = bread(dev, BBLOCK(b, sb));
80102083:	89 d0                	mov    %edx,%eax
80102085:	c1 e8 0c             	shr    $0xc,%eax
{
80102088:	89 e5                	mov    %esp,%ebp
8010208a:	56                   	push   %esi
8010208b:	53                   	push   %ebx
  bp = bread(dev, BBLOCK(b, sb));
8010208c:	03 05 6c 28 11 80    	add    0x8011286c,%eax
{
80102092:	89 d3                	mov    %edx,%ebx
  bp = bread(dev, BBLOCK(b, sb));
80102094:	83 ec 08             	sub    $0x8,%esp
80102097:	50                   	push   %eax
80102098:	51                   	push   %ecx
80102099:	e8 32 e0 ff ff       	call   801000d0 <bread>
  m = 1 << (bi % 8);
8010209e:	89 d9                	mov    %ebx,%ecx
  if((bp->data[bi/8] & m) == 0)
801020a0:	c1 fb 03             	sar    $0x3,%ebx
801020a3:	83 c4 10             	add    $0x10,%esp
  bp = bread(dev, BBLOCK(b, sb));
801020a6:	89 c6                	mov    %eax,%esi
  m = 1 << (bi % 8);
801020a8:	83 e1 07             	and    $0x7,%ecx
801020ab:	b8 01 00 00 00       	mov    $0x1,%eax
  if((bp->data[bi/8] & m) == 0)
801020b0:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
  m = 1 << (bi % 8);
801020b6:	d3 e0                	shl    %cl,%eax
  if((bp->data[bi/8] & m) == 0)
801020b8:	0f b6 4c 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%ecx
801020bd:	85 c1                	test   %eax,%ecx
801020bf:	74 23                	je     801020e4 <bfree+0x64>
  bp->data[bi/8] &= ~m;
801020c1:	f7 d0                	not    %eax
  log_write(bp);
801020c3:	83 ec 0c             	sub    $0xc,%esp
  bp->data[bi/8] &= ~m;
801020c6:	21 c8                	and    %ecx,%eax
801020c8:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
801020cc:	56                   	push   %esi
801020cd:	e8 de 1a 00 00       	call   80103bb0 <log_write>
  brelse(bp);
801020d2:	89 34 24             	mov    %esi,(%esp)
801020d5:	e8 16 e1 ff ff       	call   801001f0 <brelse>
}
801020da:	83 c4 10             	add    $0x10,%esp
801020dd:	8d 65 f8             	lea    -0x8(%ebp),%esp
801020e0:	5b                   	pop    %ebx
801020e1:	5e                   	pop    %esi
801020e2:	5d                   	pop    %ebp
801020e3:	c3                   	ret
    panic("freeing free block");
801020e4:	83 ec 0c             	sub    $0xc,%esp
801020e7:	68 c5 7e 10 80       	push   $0x80107ec5
801020ec:	e8 8f e2 ff ff       	call   80100380 <panic>
801020f1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801020f8:	00 
801020f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102100 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80102100:	55                   	push   %ebp
80102101:	89 e5                	mov    %esp,%ebp
80102103:	57                   	push   %edi
80102104:	56                   	push   %esi
80102105:	89 c6                	mov    %eax,%esi
80102107:	53                   	push   %ebx
80102108:	83 ec 1c             	sub    $0x1c,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
8010210b:	83 fa 0b             	cmp    $0xb,%edx
8010210e:	0f 86 8c 00 00 00    	jbe    801021a0 <bmap+0xa0>
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    return addr;
  }
  bn -= NDIRECT;
80102114:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
80102117:	83 fb 7f             	cmp    $0x7f,%ebx
8010211a:	0f 87 a2 00 00 00    	ja     801021c2 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
80102120:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80102126:	85 c0                	test   %eax,%eax
80102128:	74 5e                	je     80102188 <bmap+0x88>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
8010212a:	83 ec 08             	sub    $0x8,%esp
8010212d:	50                   	push   %eax
8010212e:	ff 36                	push   (%esi)
80102130:	e8 9b df ff ff       	call   801000d0 <bread>
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
80102135:	83 c4 10             	add    $0x10,%esp
80102138:	8d 5c 98 5c          	lea    0x5c(%eax,%ebx,4),%ebx
    bp = bread(ip->dev, addr);
8010213c:	89 c2                	mov    %eax,%edx
    if((addr = a[bn]) == 0){
8010213e:	8b 3b                	mov    (%ebx),%edi
80102140:	85 ff                	test   %edi,%edi
80102142:	74 1c                	je     80102160 <bmap+0x60>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
80102144:	83 ec 0c             	sub    $0xc,%esp
80102147:	52                   	push   %edx
80102148:	e8 a3 e0 ff ff       	call   801001f0 <brelse>
8010214d:	83 c4 10             	add    $0x10,%esp
    return addr;
  }

  panic("bmap: out of range");
}
80102150:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102153:	89 f8                	mov    %edi,%eax
80102155:	5b                   	pop    %ebx
80102156:	5e                   	pop    %esi
80102157:	5f                   	pop    %edi
80102158:	5d                   	pop    %ebp
80102159:	c3                   	ret
8010215a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102160:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      a[bn] = addr = balloc(ip->dev);
80102163:	8b 06                	mov    (%esi),%eax
80102165:	e8 06 fd ff ff       	call   80101e70 <balloc>
      log_write(bp);
8010216a:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010216d:	83 ec 0c             	sub    $0xc,%esp
      a[bn] = addr = balloc(ip->dev);
80102170:	89 03                	mov    %eax,(%ebx)
80102172:	89 c7                	mov    %eax,%edi
      log_write(bp);
80102174:	52                   	push   %edx
80102175:	e8 36 1a 00 00       	call   80103bb0 <log_write>
8010217a:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010217d:	83 c4 10             	add    $0x10,%esp
80102180:	eb c2                	jmp    80102144 <bmap+0x44>
80102182:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
80102188:	8b 06                	mov    (%esi),%eax
8010218a:	e8 e1 fc ff ff       	call   80101e70 <balloc>
8010218f:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
80102195:	eb 93                	jmp    8010212a <bmap+0x2a>
80102197:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010219e:	00 
8010219f:	90                   	nop
    if((addr = ip->addrs[bn]) == 0)
801021a0:	8d 5a 14             	lea    0x14(%edx),%ebx
801021a3:	8b 7c 98 0c          	mov    0xc(%eax,%ebx,4),%edi
801021a7:	85 ff                	test   %edi,%edi
801021a9:	75 a5                	jne    80102150 <bmap+0x50>
      ip->addrs[bn] = addr = balloc(ip->dev);
801021ab:	8b 00                	mov    (%eax),%eax
801021ad:	e8 be fc ff ff       	call   80101e70 <balloc>
801021b2:	89 44 9e 0c          	mov    %eax,0xc(%esi,%ebx,4)
801021b6:	89 c7                	mov    %eax,%edi
}
801021b8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801021bb:	5b                   	pop    %ebx
801021bc:	89 f8                	mov    %edi,%eax
801021be:	5e                   	pop    %esi
801021bf:	5f                   	pop    %edi
801021c0:	5d                   	pop    %ebp
801021c1:	c3                   	ret
  panic("bmap: out of range");
801021c2:	83 ec 0c             	sub    $0xc,%esp
801021c5:	68 d8 7e 10 80       	push   $0x80107ed8
801021ca:	e8 b1 e1 ff ff       	call   80100380 <panic>
801021cf:	90                   	nop

801021d0 <readsb>:
{
801021d0:	55                   	push   %ebp
801021d1:	89 e5                	mov    %esp,%ebp
801021d3:	56                   	push   %esi
801021d4:	53                   	push   %ebx
801021d5:	8b 75 0c             	mov    0xc(%ebp),%esi
  bp = bread(dev, 1);
801021d8:	83 ec 08             	sub    $0x8,%esp
801021db:	6a 01                	push   $0x1
801021dd:	ff 75 08             	push   0x8(%ebp)
801021e0:	e8 eb de ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
801021e5:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
801021e8:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
801021ea:	8d 40 5c             	lea    0x5c(%eax),%eax
801021ed:	6a 1c                	push   $0x1c
801021ef:	50                   	push   %eax
801021f0:	56                   	push   %esi
801021f1:	e8 ca 31 00 00       	call   801053c0 <memmove>
  brelse(bp);
801021f6:	83 c4 10             	add    $0x10,%esp
801021f9:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801021fc:	8d 65 f8             	lea    -0x8(%ebp),%esp
801021ff:	5b                   	pop    %ebx
80102200:	5e                   	pop    %esi
80102201:	5d                   	pop    %ebp
  brelse(bp);
80102202:	e9 e9 df ff ff       	jmp    801001f0 <brelse>
80102207:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010220e:	00 
8010220f:	90                   	nop

80102210 <iinit>:
{
80102210:	55                   	push   %ebp
80102211:	89 e5                	mov    %esp,%ebp
80102213:	53                   	push   %ebx
80102214:	bb 40 0c 11 80       	mov    $0x80110c40,%ebx
80102219:	83 ec 0c             	sub    $0xc,%esp
  initlock(&icache.lock, "icache");
8010221c:	68 eb 7e 10 80       	push   $0x80107eeb
80102221:	68 00 0c 11 80       	push   $0x80110c00
80102226:	e8 15 2e 00 00       	call   80105040 <initlock>
  for(i = 0; i < NINODE; i++) {
8010222b:	83 c4 10             	add    $0x10,%esp
8010222e:	66 90                	xchg   %ax,%ax
    initsleeplock(&icache.inode[i].lock, "inode");
80102230:	83 ec 08             	sub    $0x8,%esp
80102233:	68 f2 7e 10 80       	push   $0x80107ef2
80102238:	53                   	push   %ebx
  for(i = 0; i < NINODE; i++) {
80102239:	81 c3 90 00 00 00    	add    $0x90,%ebx
    initsleeplock(&icache.inode[i].lock, "inode");
8010223f:	e8 cc 2c 00 00       	call   80104f10 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
80102244:	83 c4 10             	add    $0x10,%esp
80102247:	81 fb 60 28 11 80    	cmp    $0x80112860,%ebx
8010224d:	75 e1                	jne    80102230 <iinit+0x20>
  bp = bread(dev, 1);
8010224f:	83 ec 08             	sub    $0x8,%esp
80102252:	6a 01                	push   $0x1
80102254:	ff 75 08             	push   0x8(%ebp)
80102257:	e8 74 de ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
8010225c:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
8010225f:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
80102261:	8d 40 5c             	lea    0x5c(%eax),%eax
80102264:	6a 1c                	push   $0x1c
80102266:	50                   	push   %eax
80102267:	68 54 28 11 80       	push   $0x80112854
8010226c:	e8 4f 31 00 00       	call   801053c0 <memmove>
  brelse(bp);
80102271:	89 1c 24             	mov    %ebx,(%esp)
80102274:	e8 77 df ff ff       	call   801001f0 <brelse>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
80102279:	ff 35 6c 28 11 80    	push   0x8011286c
8010227f:	ff 35 68 28 11 80    	push   0x80112868
80102285:	ff 35 64 28 11 80    	push   0x80112864
8010228b:	ff 35 60 28 11 80    	push   0x80112860
80102291:	ff 35 5c 28 11 80    	push   0x8011285c
80102297:	ff 35 58 28 11 80    	push   0x80112858
8010229d:	ff 35 54 28 11 80    	push   0x80112854
801022a3:	68 c4 83 10 80       	push   $0x801083c4
801022a8:	e8 33 ea ff ff       	call   80100ce0 <cprintf>
}
801022ad:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801022b0:	83 c4 30             	add    $0x30,%esp
801022b3:	c9                   	leave
801022b4:	c3                   	ret
801022b5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801022bc:	00 
801022bd:	8d 76 00             	lea    0x0(%esi),%esi

801022c0 <ialloc>:
{
801022c0:	55                   	push   %ebp
801022c1:	89 e5                	mov    %esp,%ebp
801022c3:	57                   	push   %edi
801022c4:	56                   	push   %esi
801022c5:	53                   	push   %ebx
801022c6:	83 ec 1c             	sub    $0x1c,%esp
801022c9:	8b 45 0c             	mov    0xc(%ebp),%eax
  for(inum = 1; inum < sb.ninodes; inum++){
801022cc:	83 3d 5c 28 11 80 01 	cmpl   $0x1,0x8011285c
{
801022d3:	8b 75 08             	mov    0x8(%ebp),%esi
801022d6:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
801022d9:	0f 86 91 00 00 00    	jbe    80102370 <ialloc+0xb0>
801022df:	bf 01 00 00 00       	mov    $0x1,%edi
801022e4:	eb 21                	jmp    80102307 <ialloc+0x47>
801022e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801022ed:	00 
801022ee:	66 90                	xchg   %ax,%ax
    brelse(bp);
801022f0:	83 ec 0c             	sub    $0xc,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
801022f3:	83 c7 01             	add    $0x1,%edi
    brelse(bp);
801022f6:	53                   	push   %ebx
801022f7:	e8 f4 de ff ff       	call   801001f0 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
801022fc:	83 c4 10             	add    $0x10,%esp
801022ff:	3b 3d 5c 28 11 80    	cmp    0x8011285c,%edi
80102305:	73 69                	jae    80102370 <ialloc+0xb0>
    bp = bread(dev, IBLOCK(inum, sb));
80102307:	89 f8                	mov    %edi,%eax
80102309:	83 ec 08             	sub    $0x8,%esp
8010230c:	c1 e8 03             	shr    $0x3,%eax
8010230f:	03 05 68 28 11 80    	add    0x80112868,%eax
80102315:	50                   	push   %eax
80102316:	56                   	push   %esi
80102317:	e8 b4 dd ff ff       	call   801000d0 <bread>
    if(dip->type == 0){  // a free inode
8010231c:	83 c4 10             	add    $0x10,%esp
    bp = bread(dev, IBLOCK(inum, sb));
8010231f:	89 c3                	mov    %eax,%ebx
    dip = (struct dinode*)bp->data + inum%IPB;
80102321:	89 f8                	mov    %edi,%eax
80102323:	83 e0 07             	and    $0x7,%eax
80102326:	c1 e0 06             	shl    $0x6,%eax
80102329:	8d 4c 03 5c          	lea    0x5c(%ebx,%eax,1),%ecx
    if(dip->type == 0){  // a free inode
8010232d:	66 83 39 00          	cmpw   $0x0,(%ecx)
80102331:	75 bd                	jne    801022f0 <ialloc+0x30>
      memset(dip, 0, sizeof(*dip));
80102333:	83 ec 04             	sub    $0x4,%esp
80102336:	6a 40                	push   $0x40
80102338:	6a 00                	push   $0x0
8010233a:	51                   	push   %ecx
8010233b:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010233e:	e8 ed 2f 00 00       	call   80105330 <memset>
      dip->type = type;
80102343:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
80102347:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010234a:	66 89 01             	mov    %ax,(%ecx)
      log_write(bp);   // mark it allocated on the disk
8010234d:	89 1c 24             	mov    %ebx,(%esp)
80102350:	e8 5b 18 00 00       	call   80103bb0 <log_write>
      brelse(bp);
80102355:	89 1c 24             	mov    %ebx,(%esp)
80102358:	e8 93 de ff ff       	call   801001f0 <brelse>
      return iget(dev, inum);
8010235d:	83 c4 10             	add    $0x10,%esp
}
80102360:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return iget(dev, inum);
80102363:	89 fa                	mov    %edi,%edx
}
80102365:	5b                   	pop    %ebx
      return iget(dev, inum);
80102366:	89 f0                	mov    %esi,%eax
}
80102368:	5e                   	pop    %esi
80102369:	5f                   	pop    %edi
8010236a:	5d                   	pop    %ebp
      return iget(dev, inum);
8010236b:	e9 10 fc ff ff       	jmp    80101f80 <iget>
  panic("ialloc: no inodes");
80102370:	83 ec 0c             	sub    $0xc,%esp
80102373:	68 f8 7e 10 80       	push   $0x80107ef8
80102378:	e8 03 e0 ff ff       	call   80100380 <panic>
8010237d:	8d 76 00             	lea    0x0(%esi),%esi

80102380 <iupdate>:
{
80102380:	55                   	push   %ebp
80102381:	89 e5                	mov    %esp,%ebp
80102383:	56                   	push   %esi
80102384:	53                   	push   %ebx
80102385:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80102388:	8b 43 04             	mov    0x4(%ebx),%eax
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010238b:	83 c3 5c             	add    $0x5c,%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
8010238e:	83 ec 08             	sub    $0x8,%esp
80102391:	c1 e8 03             	shr    $0x3,%eax
80102394:	03 05 68 28 11 80    	add    0x80112868,%eax
8010239a:	50                   	push   %eax
8010239b:	ff 73 a4             	push   -0x5c(%ebx)
8010239e:	e8 2d dd ff ff       	call   801000d0 <bread>
  dip->type = ip->type;
801023a3:	0f b7 53 f4          	movzwl -0xc(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801023a7:	83 c4 0c             	add    $0xc,%esp
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801023aa:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
801023ac:	8b 43 a8             	mov    -0x58(%ebx),%eax
801023af:	83 e0 07             	and    $0x7,%eax
801023b2:	c1 e0 06             	shl    $0x6,%eax
801023b5:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
  dip->type = ip->type;
801023b9:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
801023bc:	0f b7 53 f6          	movzwl -0xa(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801023c0:	83 c0 0c             	add    $0xc,%eax
  dip->major = ip->major;
801023c3:	66 89 50 f6          	mov    %dx,-0xa(%eax)
  dip->minor = ip->minor;
801023c7:	0f b7 53 f8          	movzwl -0x8(%ebx),%edx
801023cb:	66 89 50 f8          	mov    %dx,-0x8(%eax)
  dip->nlink = ip->nlink;
801023cf:	0f b7 53 fa          	movzwl -0x6(%ebx),%edx
801023d3:	66 89 50 fa          	mov    %dx,-0x6(%eax)
  dip->size = ip->size;
801023d7:	8b 53 fc             	mov    -0x4(%ebx),%edx
801023da:	89 50 fc             	mov    %edx,-0x4(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801023dd:	6a 34                	push   $0x34
801023df:	53                   	push   %ebx
801023e0:	50                   	push   %eax
801023e1:	e8 da 2f 00 00       	call   801053c0 <memmove>
  log_write(bp);
801023e6:	89 34 24             	mov    %esi,(%esp)
801023e9:	e8 c2 17 00 00       	call   80103bb0 <log_write>
  brelse(bp);
801023ee:	83 c4 10             	add    $0x10,%esp
801023f1:	89 75 08             	mov    %esi,0x8(%ebp)
}
801023f4:	8d 65 f8             	lea    -0x8(%ebp),%esp
801023f7:	5b                   	pop    %ebx
801023f8:	5e                   	pop    %esi
801023f9:	5d                   	pop    %ebp
  brelse(bp);
801023fa:	e9 f1 dd ff ff       	jmp    801001f0 <brelse>
801023ff:	90                   	nop

80102400 <idup>:
{
80102400:	55                   	push   %ebp
80102401:	89 e5                	mov    %esp,%ebp
80102403:	53                   	push   %ebx
80102404:	83 ec 10             	sub    $0x10,%esp
80102407:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
8010240a:	68 00 0c 11 80       	push   $0x80110c00
8010240f:	e8 1c 2e 00 00       	call   80105230 <acquire>
  ip->ref++;
80102414:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
80102418:	c7 04 24 00 0c 11 80 	movl   $0x80110c00,(%esp)
8010241f:	e8 ac 2d 00 00       	call   801051d0 <release>
}
80102424:	89 d8                	mov    %ebx,%eax
80102426:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102429:	c9                   	leave
8010242a:	c3                   	ret
8010242b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102430 <ilock>:
{
80102430:	55                   	push   %ebp
80102431:	89 e5                	mov    %esp,%ebp
80102433:	56                   	push   %esi
80102434:	53                   	push   %ebx
80102435:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
80102438:	85 db                	test   %ebx,%ebx
8010243a:	0f 84 b7 00 00 00    	je     801024f7 <ilock+0xc7>
80102440:	8b 53 08             	mov    0x8(%ebx),%edx
80102443:	85 d2                	test   %edx,%edx
80102445:	0f 8e ac 00 00 00    	jle    801024f7 <ilock+0xc7>
  acquiresleep(&ip->lock);
8010244b:	83 ec 0c             	sub    $0xc,%esp
8010244e:	8d 43 0c             	lea    0xc(%ebx),%eax
80102451:	50                   	push   %eax
80102452:	e8 f9 2a 00 00       	call   80104f50 <acquiresleep>
  if(ip->valid == 0){
80102457:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010245a:	83 c4 10             	add    $0x10,%esp
8010245d:	85 c0                	test   %eax,%eax
8010245f:	74 0f                	je     80102470 <ilock+0x40>
}
80102461:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102464:	5b                   	pop    %ebx
80102465:	5e                   	pop    %esi
80102466:	5d                   	pop    %ebp
80102467:	c3                   	ret
80102468:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010246f:	00 
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80102470:	8b 43 04             	mov    0x4(%ebx),%eax
80102473:	83 ec 08             	sub    $0x8,%esp
80102476:	c1 e8 03             	shr    $0x3,%eax
80102479:	03 05 68 28 11 80    	add    0x80112868,%eax
8010247f:	50                   	push   %eax
80102480:	ff 33                	push   (%ebx)
80102482:	e8 49 dc ff ff       	call   801000d0 <bread>
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
80102487:	83 c4 0c             	add    $0xc,%esp
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
8010248a:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + ip->inum%IPB;
8010248c:	8b 43 04             	mov    0x4(%ebx),%eax
8010248f:	83 e0 07             	and    $0x7,%eax
80102492:	c1 e0 06             	shl    $0x6,%eax
80102495:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    ip->type = dip->type;
80102499:	0f b7 10             	movzwl (%eax),%edx
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
8010249c:	83 c0 0c             	add    $0xc,%eax
    ip->type = dip->type;
8010249f:	66 89 53 50          	mov    %dx,0x50(%ebx)
    ip->major = dip->major;
801024a3:	0f b7 50 f6          	movzwl -0xa(%eax),%edx
801024a7:	66 89 53 52          	mov    %dx,0x52(%ebx)
    ip->minor = dip->minor;
801024ab:	0f b7 50 f8          	movzwl -0x8(%eax),%edx
801024af:	66 89 53 54          	mov    %dx,0x54(%ebx)
    ip->nlink = dip->nlink;
801024b3:	0f b7 50 fa          	movzwl -0x6(%eax),%edx
801024b7:	66 89 53 56          	mov    %dx,0x56(%ebx)
    ip->size = dip->size;
801024bb:	8b 50 fc             	mov    -0x4(%eax),%edx
801024be:	89 53 58             	mov    %edx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801024c1:	6a 34                	push   $0x34
801024c3:	50                   	push   %eax
801024c4:	8d 43 5c             	lea    0x5c(%ebx),%eax
801024c7:	50                   	push   %eax
801024c8:	e8 f3 2e 00 00       	call   801053c0 <memmove>
    brelse(bp);
801024cd:	89 34 24             	mov    %esi,(%esp)
801024d0:	e8 1b dd ff ff       	call   801001f0 <brelse>
    if(ip->type == 0)
801024d5:	83 c4 10             	add    $0x10,%esp
801024d8:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
    ip->valid = 1;
801024dd:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
801024e4:	0f 85 77 ff ff ff    	jne    80102461 <ilock+0x31>
      panic("ilock: no type");
801024ea:	83 ec 0c             	sub    $0xc,%esp
801024ed:	68 10 7f 10 80       	push   $0x80107f10
801024f2:	e8 89 de ff ff       	call   80100380 <panic>
    panic("ilock");
801024f7:	83 ec 0c             	sub    $0xc,%esp
801024fa:	68 0a 7f 10 80       	push   $0x80107f0a
801024ff:	e8 7c de ff ff       	call   80100380 <panic>
80102504:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010250b:	00 
8010250c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80102510 <iunlock>:
{
80102510:	55                   	push   %ebp
80102511:	89 e5                	mov    %esp,%ebp
80102513:	56                   	push   %esi
80102514:	53                   	push   %ebx
80102515:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80102518:	85 db                	test   %ebx,%ebx
8010251a:	74 28                	je     80102544 <iunlock+0x34>
8010251c:	83 ec 0c             	sub    $0xc,%esp
8010251f:	8d 73 0c             	lea    0xc(%ebx),%esi
80102522:	56                   	push   %esi
80102523:	e8 c8 2a 00 00       	call   80104ff0 <holdingsleep>
80102528:	83 c4 10             	add    $0x10,%esp
8010252b:	85 c0                	test   %eax,%eax
8010252d:	74 15                	je     80102544 <iunlock+0x34>
8010252f:	8b 43 08             	mov    0x8(%ebx),%eax
80102532:	85 c0                	test   %eax,%eax
80102534:	7e 0e                	jle    80102544 <iunlock+0x34>
  releasesleep(&ip->lock);
80102536:	89 75 08             	mov    %esi,0x8(%ebp)
}
80102539:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010253c:	5b                   	pop    %ebx
8010253d:	5e                   	pop    %esi
8010253e:	5d                   	pop    %ebp
  releasesleep(&ip->lock);
8010253f:	e9 6c 2a 00 00       	jmp    80104fb0 <releasesleep>
    panic("iunlock");
80102544:	83 ec 0c             	sub    $0xc,%esp
80102547:	68 1f 7f 10 80       	push   $0x80107f1f
8010254c:	e8 2f de ff ff       	call   80100380 <panic>
80102551:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102558:	00 
80102559:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102560 <iput>:
{
80102560:	55                   	push   %ebp
80102561:	89 e5                	mov    %esp,%ebp
80102563:	57                   	push   %edi
80102564:	56                   	push   %esi
80102565:	53                   	push   %ebx
80102566:	83 ec 28             	sub    $0x28,%esp
80102569:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquiresleep(&ip->lock);
8010256c:	8d 7b 0c             	lea    0xc(%ebx),%edi
8010256f:	57                   	push   %edi
80102570:	e8 db 29 00 00       	call   80104f50 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
80102575:	8b 53 4c             	mov    0x4c(%ebx),%edx
80102578:	83 c4 10             	add    $0x10,%esp
8010257b:	85 d2                	test   %edx,%edx
8010257d:	74 07                	je     80102586 <iput+0x26>
8010257f:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80102584:	74 32                	je     801025b8 <iput+0x58>
  releasesleep(&ip->lock);
80102586:	83 ec 0c             	sub    $0xc,%esp
80102589:	57                   	push   %edi
8010258a:	e8 21 2a 00 00       	call   80104fb0 <releasesleep>
  acquire(&icache.lock);
8010258f:	c7 04 24 00 0c 11 80 	movl   $0x80110c00,(%esp)
80102596:	e8 95 2c 00 00       	call   80105230 <acquire>
  ip->ref--;
8010259b:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
8010259f:	83 c4 10             	add    $0x10,%esp
801025a2:	c7 45 08 00 0c 11 80 	movl   $0x80110c00,0x8(%ebp)
}
801025a9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801025ac:	5b                   	pop    %ebx
801025ad:	5e                   	pop    %esi
801025ae:	5f                   	pop    %edi
801025af:	5d                   	pop    %ebp
  release(&icache.lock);
801025b0:	e9 1b 2c 00 00       	jmp    801051d0 <release>
801025b5:	8d 76 00             	lea    0x0(%esi),%esi
    acquire(&icache.lock);
801025b8:	83 ec 0c             	sub    $0xc,%esp
801025bb:	68 00 0c 11 80       	push   $0x80110c00
801025c0:	e8 6b 2c 00 00       	call   80105230 <acquire>
    int r = ip->ref;
801025c5:	8b 73 08             	mov    0x8(%ebx),%esi
    release(&icache.lock);
801025c8:	c7 04 24 00 0c 11 80 	movl   $0x80110c00,(%esp)
801025cf:	e8 fc 2b 00 00       	call   801051d0 <release>
    if(r == 1){
801025d4:	83 c4 10             	add    $0x10,%esp
801025d7:	83 fe 01             	cmp    $0x1,%esi
801025da:	75 aa                	jne    80102586 <iput+0x26>
801025dc:	8d 8b 8c 00 00 00    	lea    0x8c(%ebx),%ecx
801025e2:	89 7d e4             	mov    %edi,-0x1c(%ebp)
801025e5:	8d 73 5c             	lea    0x5c(%ebx),%esi
801025e8:	89 df                	mov    %ebx,%edi
801025ea:	89 cb                	mov    %ecx,%ebx
801025ec:	eb 09                	jmp    801025f7 <iput+0x97>
801025ee:	66 90                	xchg   %ax,%ax
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
801025f0:	83 c6 04             	add    $0x4,%esi
801025f3:	39 de                	cmp    %ebx,%esi
801025f5:	74 19                	je     80102610 <iput+0xb0>
    if(ip->addrs[i]){
801025f7:	8b 16                	mov    (%esi),%edx
801025f9:	85 d2                	test   %edx,%edx
801025fb:	74 f3                	je     801025f0 <iput+0x90>
      bfree(ip->dev, ip->addrs[i]);
801025fd:	8b 07                	mov    (%edi),%eax
801025ff:	e8 7c fa ff ff       	call   80102080 <bfree>
      ip->addrs[i] = 0;
80102604:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
8010260a:	eb e4                	jmp    801025f0 <iput+0x90>
8010260c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80102610:	89 fb                	mov    %edi,%ebx
80102612:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80102615:	8b 83 8c 00 00 00    	mov    0x8c(%ebx),%eax
8010261b:	85 c0                	test   %eax,%eax
8010261d:	75 2d                	jne    8010264c <iput+0xec>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
  iupdate(ip);
8010261f:	83 ec 0c             	sub    $0xc,%esp
  ip->size = 0;
80102622:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
80102629:	53                   	push   %ebx
8010262a:	e8 51 fd ff ff       	call   80102380 <iupdate>
      ip->type = 0;
8010262f:	31 c0                	xor    %eax,%eax
80102631:	66 89 43 50          	mov    %ax,0x50(%ebx)
      iupdate(ip);
80102635:	89 1c 24             	mov    %ebx,(%esp)
80102638:	e8 43 fd ff ff       	call   80102380 <iupdate>
      ip->valid = 0;
8010263d:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
80102644:	83 c4 10             	add    $0x10,%esp
80102647:	e9 3a ff ff ff       	jmp    80102586 <iput+0x26>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
8010264c:	83 ec 08             	sub    $0x8,%esp
8010264f:	50                   	push   %eax
80102650:	ff 33                	push   (%ebx)
80102652:	e8 79 da ff ff       	call   801000d0 <bread>
    for(j = 0; j < NINDIRECT; j++){
80102657:	83 c4 10             	add    $0x10,%esp
8010265a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
8010265d:	8d 88 5c 02 00 00    	lea    0x25c(%eax),%ecx
80102663:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102666:	8d 70 5c             	lea    0x5c(%eax),%esi
80102669:	89 cf                	mov    %ecx,%edi
8010266b:	eb 0a                	jmp    80102677 <iput+0x117>
8010266d:	8d 76 00             	lea    0x0(%esi),%esi
80102670:	83 c6 04             	add    $0x4,%esi
80102673:	39 fe                	cmp    %edi,%esi
80102675:	74 0f                	je     80102686 <iput+0x126>
      if(a[j])
80102677:	8b 16                	mov    (%esi),%edx
80102679:	85 d2                	test   %edx,%edx
8010267b:	74 f3                	je     80102670 <iput+0x110>
        bfree(ip->dev, a[j]);
8010267d:	8b 03                	mov    (%ebx),%eax
8010267f:	e8 fc f9 ff ff       	call   80102080 <bfree>
80102684:	eb ea                	jmp    80102670 <iput+0x110>
    brelse(bp);
80102686:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102689:	83 ec 0c             	sub    $0xc,%esp
8010268c:	8b 7d e4             	mov    -0x1c(%ebp),%edi
8010268f:	50                   	push   %eax
80102690:	e8 5b db ff ff       	call   801001f0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80102695:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
8010269b:	8b 03                	mov    (%ebx),%eax
8010269d:	e8 de f9 ff ff       	call   80102080 <bfree>
    ip->addrs[NDIRECT] = 0;
801026a2:	83 c4 10             	add    $0x10,%esp
801026a5:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
801026ac:	00 00 00 
801026af:	e9 6b ff ff ff       	jmp    8010261f <iput+0xbf>
801026b4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801026bb:	00 
801026bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801026c0 <iunlockput>:
{
801026c0:	55                   	push   %ebp
801026c1:	89 e5                	mov    %esp,%ebp
801026c3:	56                   	push   %esi
801026c4:	53                   	push   %ebx
801026c5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
801026c8:	85 db                	test   %ebx,%ebx
801026ca:	74 34                	je     80102700 <iunlockput+0x40>
801026cc:	83 ec 0c             	sub    $0xc,%esp
801026cf:	8d 73 0c             	lea    0xc(%ebx),%esi
801026d2:	56                   	push   %esi
801026d3:	e8 18 29 00 00       	call   80104ff0 <holdingsleep>
801026d8:	83 c4 10             	add    $0x10,%esp
801026db:	85 c0                	test   %eax,%eax
801026dd:	74 21                	je     80102700 <iunlockput+0x40>
801026df:	8b 43 08             	mov    0x8(%ebx),%eax
801026e2:	85 c0                	test   %eax,%eax
801026e4:	7e 1a                	jle    80102700 <iunlockput+0x40>
  releasesleep(&ip->lock);
801026e6:	83 ec 0c             	sub    $0xc,%esp
801026e9:	56                   	push   %esi
801026ea:	e8 c1 28 00 00       	call   80104fb0 <releasesleep>
  iput(ip);
801026ef:	83 c4 10             	add    $0x10,%esp
801026f2:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801026f5:	8d 65 f8             	lea    -0x8(%ebp),%esp
801026f8:	5b                   	pop    %ebx
801026f9:	5e                   	pop    %esi
801026fa:	5d                   	pop    %ebp
  iput(ip);
801026fb:	e9 60 fe ff ff       	jmp    80102560 <iput>
    panic("iunlock");
80102700:	83 ec 0c             	sub    $0xc,%esp
80102703:	68 1f 7f 10 80       	push   $0x80107f1f
80102708:	e8 73 dc ff ff       	call   80100380 <panic>
8010270d:	8d 76 00             	lea    0x0(%esi),%esi

80102710 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80102710:	55                   	push   %ebp
80102711:	89 e5                	mov    %esp,%ebp
80102713:	8b 55 08             	mov    0x8(%ebp),%edx
80102716:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80102719:	8b 0a                	mov    (%edx),%ecx
8010271b:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
8010271e:	8b 4a 04             	mov    0x4(%edx),%ecx
80102721:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80102724:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80102728:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
8010272b:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
8010272f:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80102733:	8b 52 58             	mov    0x58(%edx),%edx
80102736:	89 50 10             	mov    %edx,0x10(%eax)
}
80102739:	5d                   	pop    %ebp
8010273a:	c3                   	ret
8010273b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102740 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
80102740:	55                   	push   %ebp
80102741:	89 e5                	mov    %esp,%ebp
80102743:	57                   	push   %edi
80102744:	56                   	push   %esi
80102745:	53                   	push   %ebx
80102746:	83 ec 1c             	sub    $0x1c,%esp
80102749:	8b 75 08             	mov    0x8(%ebp),%esi
8010274c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010274f:	8b 7d 10             	mov    0x10(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80102752:	66 83 7e 50 03       	cmpw   $0x3,0x50(%esi)
{
80102757:	89 45 e0             	mov    %eax,-0x20(%ebp)
8010275a:	89 75 d8             	mov    %esi,-0x28(%ebp)
8010275d:	8b 45 14             	mov    0x14(%ebp),%eax
  if(ip->type == T_DEV){
80102760:	0f 84 aa 00 00 00    	je     80102810 <readi+0xd0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80102766:	8b 75 d8             	mov    -0x28(%ebp),%esi
80102769:	8b 56 58             	mov    0x58(%esi),%edx
8010276c:	39 fa                	cmp    %edi,%edx
8010276e:	0f 82 bd 00 00 00    	jb     80102831 <readi+0xf1>
80102774:	89 f9                	mov    %edi,%ecx
80102776:	31 db                	xor    %ebx,%ebx
80102778:	01 c1                	add    %eax,%ecx
8010277a:	0f 92 c3             	setb   %bl
8010277d:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80102780:	0f 82 ab 00 00 00    	jb     80102831 <readi+0xf1>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
80102786:	89 d3                	mov    %edx,%ebx
80102788:	29 fb                	sub    %edi,%ebx
8010278a:	39 ca                	cmp    %ecx,%edx
8010278c:	0f 42 c3             	cmovb  %ebx,%eax

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
8010278f:	85 c0                	test   %eax,%eax
80102791:	74 73                	je     80102806 <readi+0xc6>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80102793:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80102796:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80102799:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801027a0:	8b 5d d8             	mov    -0x28(%ebp),%ebx
801027a3:	89 fa                	mov    %edi,%edx
801027a5:	c1 ea 09             	shr    $0x9,%edx
801027a8:	89 d8                	mov    %ebx,%eax
801027aa:	e8 51 f9 ff ff       	call   80102100 <bmap>
801027af:	83 ec 08             	sub    $0x8,%esp
801027b2:	50                   	push   %eax
801027b3:	ff 33                	push   (%ebx)
801027b5:	e8 16 d9 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
801027ba:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
801027bd:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801027c2:	89 c2                	mov    %eax,%edx
    m = min(n - tot, BSIZE - off%BSIZE);
801027c4:	89 f8                	mov    %edi,%eax
801027c6:	25 ff 01 00 00       	and    $0x1ff,%eax
801027cb:	29 f3                	sub    %esi,%ebx
801027cd:	29 c1                	sub    %eax,%ecx
    memmove(dst, bp->data + off%BSIZE, m);
801027cf:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
801027d3:	39 d9                	cmp    %ebx,%ecx
801027d5:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
801027d8:	83 c4 0c             	add    $0xc,%esp
801027db:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
801027dc:	01 de                	add    %ebx,%esi
801027de:	01 df                	add    %ebx,%edi
    memmove(dst, bp->data + off%BSIZE, m);
801027e0:	89 55 dc             	mov    %edx,-0x24(%ebp)
801027e3:	50                   	push   %eax
801027e4:	ff 75 e0             	push   -0x20(%ebp)
801027e7:	e8 d4 2b 00 00       	call   801053c0 <memmove>
    brelse(bp);
801027ec:	8b 55 dc             	mov    -0x24(%ebp),%edx
801027ef:	89 14 24             	mov    %edx,(%esp)
801027f2:	e8 f9 d9 ff ff       	call   801001f0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
801027f7:	01 5d e0             	add    %ebx,-0x20(%ebp)
801027fa:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
801027fd:	83 c4 10             	add    $0x10,%esp
80102800:	39 de                	cmp    %ebx,%esi
80102802:	72 9c                	jb     801027a0 <readi+0x60>
80102804:	89 d8                	mov    %ebx,%eax
  }
  return n;
}
80102806:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102809:	5b                   	pop    %ebx
8010280a:	5e                   	pop    %esi
8010280b:	5f                   	pop    %edi
8010280c:	5d                   	pop    %ebp
8010280d:	c3                   	ret
8010280e:	66 90                	xchg   %ax,%ax
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80102810:	0f bf 56 52          	movswl 0x52(%esi),%edx
80102814:	66 83 fa 09          	cmp    $0x9,%dx
80102818:	77 17                	ja     80102831 <readi+0xf1>
8010281a:	8b 14 d5 a0 0b 11 80 	mov    -0x7feef460(,%edx,8),%edx
80102821:	85 d2                	test   %edx,%edx
80102823:	74 0c                	je     80102831 <readi+0xf1>
    return devsw[ip->major].read(ip, dst, n);
80102825:	89 45 10             	mov    %eax,0x10(%ebp)
}
80102828:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010282b:	5b                   	pop    %ebx
8010282c:	5e                   	pop    %esi
8010282d:	5f                   	pop    %edi
8010282e:	5d                   	pop    %ebp
    return devsw[ip->major].read(ip, dst, n);
8010282f:	ff e2                	jmp    *%edx
      return -1;
80102831:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102836:	eb ce                	jmp    80102806 <readi+0xc6>
80102838:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010283f:	00 

80102840 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80102840:	55                   	push   %ebp
80102841:	89 e5                	mov    %esp,%ebp
80102843:	57                   	push   %edi
80102844:	56                   	push   %esi
80102845:	53                   	push   %ebx
80102846:	83 ec 1c             	sub    $0x1c,%esp
80102849:	8b 45 08             	mov    0x8(%ebp),%eax
8010284c:	8b 7d 0c             	mov    0xc(%ebp),%edi
8010284f:	8b 75 14             	mov    0x14(%ebp),%esi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80102852:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
{
80102857:	89 7d dc             	mov    %edi,-0x24(%ebp)
8010285a:	89 75 e0             	mov    %esi,-0x20(%ebp)
8010285d:	8b 7d 10             	mov    0x10(%ebp),%edi
  if(ip->type == T_DEV){
80102860:	0f 84 ba 00 00 00    	je     80102920 <writei+0xe0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80102866:	39 78 58             	cmp    %edi,0x58(%eax)
80102869:	0f 82 ea 00 00 00    	jb     80102959 <writei+0x119>
    return -1;
  if(off + n > MAXFILE*BSIZE)
8010286f:	8b 75 e0             	mov    -0x20(%ebp),%esi
80102872:	89 f2                	mov    %esi,%edx
80102874:	01 fa                	add    %edi,%edx
80102876:	0f 82 dd 00 00 00    	jb     80102959 <writei+0x119>
8010287c:	81 fa 00 18 01 00    	cmp    $0x11800,%edx
80102882:	0f 87 d1 00 00 00    	ja     80102959 <writei+0x119>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80102888:	85 f6                	test   %esi,%esi
8010288a:	0f 84 85 00 00 00    	je     80102915 <writei+0xd5>
80102890:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80102897:	89 45 d8             	mov    %eax,-0x28(%ebp)
8010289a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801028a0:	8b 75 d8             	mov    -0x28(%ebp),%esi
801028a3:	89 fa                	mov    %edi,%edx
801028a5:	c1 ea 09             	shr    $0x9,%edx
801028a8:	89 f0                	mov    %esi,%eax
801028aa:	e8 51 f8 ff ff       	call   80102100 <bmap>
801028af:	83 ec 08             	sub    $0x8,%esp
801028b2:	50                   	push   %eax
801028b3:	ff 36                	push   (%esi)
801028b5:	e8 16 d8 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
801028ba:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801028bd:	8b 5d e0             	mov    -0x20(%ebp),%ebx
801028c0:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801028c5:	89 c6                	mov    %eax,%esi
    m = min(n - tot, BSIZE - off%BSIZE);
801028c7:	89 f8                	mov    %edi,%eax
801028c9:	25 ff 01 00 00       	and    $0x1ff,%eax
801028ce:	29 d3                	sub    %edx,%ebx
801028d0:	29 c1                	sub    %eax,%ecx
    memmove(bp->data + off%BSIZE, src, m);
801028d2:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
801028d6:	39 d9                	cmp    %ebx,%ecx
801028d8:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
801028db:	83 c4 0c             	add    $0xc,%esp
801028de:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
801028df:	01 df                	add    %ebx,%edi
    memmove(bp->data + off%BSIZE, src, m);
801028e1:	ff 75 dc             	push   -0x24(%ebp)
801028e4:	50                   	push   %eax
801028e5:	e8 d6 2a 00 00       	call   801053c0 <memmove>
    log_write(bp);
801028ea:	89 34 24             	mov    %esi,(%esp)
801028ed:	e8 be 12 00 00       	call   80103bb0 <log_write>
    brelse(bp);
801028f2:	89 34 24             	mov    %esi,(%esp)
801028f5:	e8 f6 d8 ff ff       	call   801001f0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
801028fa:	01 5d e4             	add    %ebx,-0x1c(%ebp)
801028fd:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80102900:	83 c4 10             	add    $0x10,%esp
80102903:	01 5d dc             	add    %ebx,-0x24(%ebp)
80102906:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80102909:	39 d8                	cmp    %ebx,%eax
8010290b:	72 93                	jb     801028a0 <writei+0x60>
  }

  if(n > 0 && off > ip->size){
8010290d:	8b 45 d8             	mov    -0x28(%ebp),%eax
80102910:	39 78 58             	cmp    %edi,0x58(%eax)
80102913:	72 33                	jb     80102948 <writei+0x108>
    ip->size = off;
    iupdate(ip);
  }
  return n;
80102915:	8b 45 e0             	mov    -0x20(%ebp),%eax
}
80102918:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010291b:	5b                   	pop    %ebx
8010291c:	5e                   	pop    %esi
8010291d:	5f                   	pop    %edi
8010291e:	5d                   	pop    %ebp
8010291f:	c3                   	ret
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
80102920:	0f bf 40 52          	movswl 0x52(%eax),%eax
80102924:	66 83 f8 09          	cmp    $0x9,%ax
80102928:	77 2f                	ja     80102959 <writei+0x119>
8010292a:	8b 04 c5 a4 0b 11 80 	mov    -0x7feef45c(,%eax,8),%eax
80102931:	85 c0                	test   %eax,%eax
80102933:	74 24                	je     80102959 <writei+0x119>
    return devsw[ip->major].write(ip, src, n);
80102935:	89 75 10             	mov    %esi,0x10(%ebp)
}
80102938:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010293b:	5b                   	pop    %ebx
8010293c:	5e                   	pop    %esi
8010293d:	5f                   	pop    %edi
8010293e:	5d                   	pop    %ebp
    return devsw[ip->major].write(ip, src, n);
8010293f:	ff e0                	jmp    *%eax
80102941:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    iupdate(ip);
80102948:	83 ec 0c             	sub    $0xc,%esp
    ip->size = off;
8010294b:	89 78 58             	mov    %edi,0x58(%eax)
    iupdate(ip);
8010294e:	50                   	push   %eax
8010294f:	e8 2c fa ff ff       	call   80102380 <iupdate>
80102954:	83 c4 10             	add    $0x10,%esp
80102957:	eb bc                	jmp    80102915 <writei+0xd5>
      return -1;
80102959:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010295e:	eb b8                	jmp    80102918 <writei+0xd8>

80102960 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80102960:	55                   	push   %ebp
80102961:	89 e5                	mov    %esp,%ebp
80102963:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
80102966:	6a 0e                	push   $0xe
80102968:	ff 75 0c             	push   0xc(%ebp)
8010296b:	ff 75 08             	push   0x8(%ebp)
8010296e:	e8 bd 2a 00 00       	call   80105430 <strncmp>
}
80102973:	c9                   	leave
80102974:	c3                   	ret
80102975:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010297c:	00 
8010297d:	8d 76 00             	lea    0x0(%esi),%esi

80102980 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
80102980:	55                   	push   %ebp
80102981:	89 e5                	mov    %esp,%ebp
80102983:	57                   	push   %edi
80102984:	56                   	push   %esi
80102985:	53                   	push   %ebx
80102986:	83 ec 1c             	sub    $0x1c,%esp
80102989:	8b 5d 08             	mov    0x8(%ebp),%ebx
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
8010298c:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80102991:	0f 85 85 00 00 00    	jne    80102a1c <dirlookup+0x9c>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
80102997:	8b 53 58             	mov    0x58(%ebx),%edx
8010299a:	31 ff                	xor    %edi,%edi
8010299c:	8d 75 d8             	lea    -0x28(%ebp),%esi
8010299f:	85 d2                	test   %edx,%edx
801029a1:	74 3e                	je     801029e1 <dirlookup+0x61>
801029a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801029a8:	6a 10                	push   $0x10
801029aa:	57                   	push   %edi
801029ab:	56                   	push   %esi
801029ac:	53                   	push   %ebx
801029ad:	e8 8e fd ff ff       	call   80102740 <readi>
801029b2:	83 c4 10             	add    $0x10,%esp
801029b5:	83 f8 10             	cmp    $0x10,%eax
801029b8:	75 55                	jne    80102a0f <dirlookup+0x8f>
      panic("dirlookup read");
    if(de.inum == 0)
801029ba:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
801029bf:	74 18                	je     801029d9 <dirlookup+0x59>
  return strncmp(s, t, DIRSIZ);
801029c1:	83 ec 04             	sub    $0x4,%esp
801029c4:	8d 45 da             	lea    -0x26(%ebp),%eax
801029c7:	6a 0e                	push   $0xe
801029c9:	50                   	push   %eax
801029ca:	ff 75 0c             	push   0xc(%ebp)
801029cd:	e8 5e 2a 00 00       	call   80105430 <strncmp>
      continue;
    if(namecmp(name, de.name) == 0){
801029d2:	83 c4 10             	add    $0x10,%esp
801029d5:	85 c0                	test   %eax,%eax
801029d7:	74 17                	je     801029f0 <dirlookup+0x70>
  for(off = 0; off < dp->size; off += sizeof(de)){
801029d9:	83 c7 10             	add    $0x10,%edi
801029dc:	3b 7b 58             	cmp    0x58(%ebx),%edi
801029df:	72 c7                	jb     801029a8 <dirlookup+0x28>
      return iget(dp->dev, inum);
    }
  }

  return 0;
}
801029e1:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801029e4:	31 c0                	xor    %eax,%eax
}
801029e6:	5b                   	pop    %ebx
801029e7:	5e                   	pop    %esi
801029e8:	5f                   	pop    %edi
801029e9:	5d                   	pop    %ebp
801029ea:	c3                   	ret
801029eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(poff)
801029f0:	8b 45 10             	mov    0x10(%ebp),%eax
801029f3:	85 c0                	test   %eax,%eax
801029f5:	74 05                	je     801029fc <dirlookup+0x7c>
        *poff = off;
801029f7:	8b 45 10             	mov    0x10(%ebp),%eax
801029fa:	89 38                	mov    %edi,(%eax)
      inum = de.inum;
801029fc:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80102a00:	8b 03                	mov    (%ebx),%eax
80102a02:	e8 79 f5 ff ff       	call   80101f80 <iget>
}
80102a07:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102a0a:	5b                   	pop    %ebx
80102a0b:	5e                   	pop    %esi
80102a0c:	5f                   	pop    %edi
80102a0d:	5d                   	pop    %ebp
80102a0e:	c3                   	ret
      panic("dirlookup read");
80102a0f:	83 ec 0c             	sub    $0xc,%esp
80102a12:	68 39 7f 10 80       	push   $0x80107f39
80102a17:	e8 64 d9 ff ff       	call   80100380 <panic>
    panic("dirlookup not DIR");
80102a1c:	83 ec 0c             	sub    $0xc,%esp
80102a1f:	68 27 7f 10 80       	push   $0x80107f27
80102a24:	e8 57 d9 ff ff       	call   80100380 <panic>
80102a29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102a30 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80102a30:	55                   	push   %ebp
80102a31:	89 e5                	mov    %esp,%ebp
80102a33:	57                   	push   %edi
80102a34:	56                   	push   %esi
80102a35:	53                   	push   %ebx
80102a36:	89 c3                	mov    %eax,%ebx
80102a38:	83 ec 1c             	sub    $0x1c,%esp
  struct inode *ip, *next;

  if(*path == '/')
80102a3b:	80 38 2f             	cmpb   $0x2f,(%eax)
{
80102a3e:	89 55 dc             	mov    %edx,-0x24(%ebp)
80102a41:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  if(*path == '/')
80102a44:	0f 84 9e 01 00 00    	je     80102be8 <namex+0x1b8>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80102a4a:	e8 a1 1b 00 00       	call   801045f0 <myproc>
  acquire(&icache.lock);
80102a4f:	83 ec 0c             	sub    $0xc,%esp
    ip = idup(myproc()->cwd);
80102a52:	8b 70 68             	mov    0x68(%eax),%esi
  acquire(&icache.lock);
80102a55:	68 00 0c 11 80       	push   $0x80110c00
80102a5a:	e8 d1 27 00 00       	call   80105230 <acquire>
  ip->ref++;
80102a5f:	83 46 08 01          	addl   $0x1,0x8(%esi)
  release(&icache.lock);
80102a63:	c7 04 24 00 0c 11 80 	movl   $0x80110c00,(%esp)
80102a6a:	e8 61 27 00 00       	call   801051d0 <release>
80102a6f:	83 c4 10             	add    $0x10,%esp
80102a72:	eb 07                	jmp    80102a7b <namex+0x4b>
80102a74:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    path++;
80102a78:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80102a7b:	0f b6 03             	movzbl (%ebx),%eax
80102a7e:	3c 2f                	cmp    $0x2f,%al
80102a80:	74 f6                	je     80102a78 <namex+0x48>
  if(*path == 0)
80102a82:	84 c0                	test   %al,%al
80102a84:	0f 84 06 01 00 00    	je     80102b90 <namex+0x160>
  while(*path != '/' && *path != 0)
80102a8a:	0f b6 03             	movzbl (%ebx),%eax
80102a8d:	84 c0                	test   %al,%al
80102a8f:	0f 84 10 01 00 00    	je     80102ba5 <namex+0x175>
80102a95:	89 df                	mov    %ebx,%edi
80102a97:	3c 2f                	cmp    $0x2f,%al
80102a99:	0f 84 06 01 00 00    	je     80102ba5 <namex+0x175>
80102a9f:	90                   	nop
80102aa0:	0f b6 47 01          	movzbl 0x1(%edi),%eax
    path++;
80102aa4:	83 c7 01             	add    $0x1,%edi
  while(*path != '/' && *path != 0)
80102aa7:	3c 2f                	cmp    $0x2f,%al
80102aa9:	74 04                	je     80102aaf <namex+0x7f>
80102aab:	84 c0                	test   %al,%al
80102aad:	75 f1                	jne    80102aa0 <namex+0x70>
  len = path - s;
80102aaf:	89 f8                	mov    %edi,%eax
80102ab1:	29 d8                	sub    %ebx,%eax
  if(len >= DIRSIZ)
80102ab3:	83 f8 0d             	cmp    $0xd,%eax
80102ab6:	0f 8e ac 00 00 00    	jle    80102b68 <namex+0x138>
    memmove(name, s, DIRSIZ);
80102abc:	83 ec 04             	sub    $0x4,%esp
80102abf:	6a 0e                	push   $0xe
80102ac1:	53                   	push   %ebx
80102ac2:	89 fb                	mov    %edi,%ebx
80102ac4:	ff 75 e4             	push   -0x1c(%ebp)
80102ac7:	e8 f4 28 00 00       	call   801053c0 <memmove>
80102acc:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80102acf:	80 3f 2f             	cmpb   $0x2f,(%edi)
80102ad2:	75 0c                	jne    80102ae0 <namex+0xb0>
80102ad4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    path++;
80102ad8:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80102adb:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80102ade:	74 f8                	je     80102ad8 <namex+0xa8>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
80102ae0:	83 ec 0c             	sub    $0xc,%esp
80102ae3:	56                   	push   %esi
80102ae4:	e8 47 f9 ff ff       	call   80102430 <ilock>
    if(ip->type != T_DIR){
80102ae9:	83 c4 10             	add    $0x10,%esp
80102aec:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80102af1:	0f 85 b7 00 00 00    	jne    80102bae <namex+0x17e>
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
80102af7:	8b 45 dc             	mov    -0x24(%ebp),%eax
80102afa:	85 c0                	test   %eax,%eax
80102afc:	74 09                	je     80102b07 <namex+0xd7>
80102afe:	80 3b 00             	cmpb   $0x0,(%ebx)
80102b01:	0f 84 f7 00 00 00    	je     80102bfe <namex+0x1ce>
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
80102b07:	83 ec 04             	sub    $0x4,%esp
80102b0a:	6a 00                	push   $0x0
80102b0c:	ff 75 e4             	push   -0x1c(%ebp)
80102b0f:	56                   	push   %esi
80102b10:	e8 6b fe ff ff       	call   80102980 <dirlookup>
80102b15:	83 c4 10             	add    $0x10,%esp
80102b18:	89 c7                	mov    %eax,%edi
80102b1a:	85 c0                	test   %eax,%eax
80102b1c:	0f 84 8c 00 00 00    	je     80102bae <namex+0x17e>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80102b22:	83 ec 0c             	sub    $0xc,%esp
80102b25:	8d 4e 0c             	lea    0xc(%esi),%ecx
80102b28:	51                   	push   %ecx
80102b29:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80102b2c:	e8 bf 24 00 00       	call   80104ff0 <holdingsleep>
80102b31:	83 c4 10             	add    $0x10,%esp
80102b34:	85 c0                	test   %eax,%eax
80102b36:	0f 84 02 01 00 00    	je     80102c3e <namex+0x20e>
80102b3c:	8b 56 08             	mov    0x8(%esi),%edx
80102b3f:	85 d2                	test   %edx,%edx
80102b41:	0f 8e f7 00 00 00    	jle    80102c3e <namex+0x20e>
  releasesleep(&ip->lock);
80102b47:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80102b4a:	83 ec 0c             	sub    $0xc,%esp
80102b4d:	51                   	push   %ecx
80102b4e:	e8 5d 24 00 00       	call   80104fb0 <releasesleep>
  iput(ip);
80102b53:	89 34 24             	mov    %esi,(%esp)
      iunlockput(ip);
      return 0;
    }
    iunlockput(ip);
    ip = next;
80102b56:	89 fe                	mov    %edi,%esi
  iput(ip);
80102b58:	e8 03 fa ff ff       	call   80102560 <iput>
80102b5d:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80102b60:	e9 16 ff ff ff       	jmp    80102a7b <namex+0x4b>
80102b65:	8d 76 00             	lea    0x0(%esi),%esi
    name[len] = 0;
80102b68:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80102b6b:	8d 0c 02             	lea    (%edx,%eax,1),%ecx
    memmove(name, s, len);
80102b6e:	83 ec 04             	sub    $0x4,%esp
80102b71:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80102b74:	50                   	push   %eax
80102b75:	53                   	push   %ebx
    name[len] = 0;
80102b76:	89 fb                	mov    %edi,%ebx
    memmove(name, s, len);
80102b78:	ff 75 e4             	push   -0x1c(%ebp)
80102b7b:	e8 40 28 00 00       	call   801053c0 <memmove>
    name[len] = 0;
80102b80:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80102b83:	83 c4 10             	add    $0x10,%esp
80102b86:	c6 01 00             	movb   $0x0,(%ecx)
80102b89:	e9 41 ff ff ff       	jmp    80102acf <namex+0x9f>
80102b8e:	66 90                	xchg   %ax,%ax
  }
  if(nameiparent){
80102b90:	8b 45 dc             	mov    -0x24(%ebp),%eax
80102b93:	85 c0                	test   %eax,%eax
80102b95:	0f 85 93 00 00 00    	jne    80102c2e <namex+0x1fe>
    iput(ip);
    return 0;
  }
  return ip;
}
80102b9b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102b9e:	89 f0                	mov    %esi,%eax
80102ba0:	5b                   	pop    %ebx
80102ba1:	5e                   	pop    %esi
80102ba2:	5f                   	pop    %edi
80102ba3:	5d                   	pop    %ebp
80102ba4:	c3                   	ret
  while(*path != '/' && *path != 0)
80102ba5:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80102ba8:	89 df                	mov    %ebx,%edi
80102baa:	31 c0                	xor    %eax,%eax
80102bac:	eb c0                	jmp    80102b6e <namex+0x13e>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80102bae:	83 ec 0c             	sub    $0xc,%esp
80102bb1:	8d 5e 0c             	lea    0xc(%esi),%ebx
80102bb4:	53                   	push   %ebx
80102bb5:	e8 36 24 00 00       	call   80104ff0 <holdingsleep>
80102bba:	83 c4 10             	add    $0x10,%esp
80102bbd:	85 c0                	test   %eax,%eax
80102bbf:	74 7d                	je     80102c3e <namex+0x20e>
80102bc1:	8b 4e 08             	mov    0x8(%esi),%ecx
80102bc4:	85 c9                	test   %ecx,%ecx
80102bc6:	7e 76                	jle    80102c3e <namex+0x20e>
  releasesleep(&ip->lock);
80102bc8:	83 ec 0c             	sub    $0xc,%esp
80102bcb:	53                   	push   %ebx
80102bcc:	e8 df 23 00 00       	call   80104fb0 <releasesleep>
  iput(ip);
80102bd1:	89 34 24             	mov    %esi,(%esp)
      return 0;
80102bd4:	31 f6                	xor    %esi,%esi
  iput(ip);
80102bd6:	e8 85 f9 ff ff       	call   80102560 <iput>
      return 0;
80102bdb:	83 c4 10             	add    $0x10,%esp
}
80102bde:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102be1:	89 f0                	mov    %esi,%eax
80102be3:	5b                   	pop    %ebx
80102be4:	5e                   	pop    %esi
80102be5:	5f                   	pop    %edi
80102be6:	5d                   	pop    %ebp
80102be7:	c3                   	ret
    ip = iget(ROOTDEV, ROOTINO);
80102be8:	ba 01 00 00 00       	mov    $0x1,%edx
80102bed:	b8 01 00 00 00       	mov    $0x1,%eax
80102bf2:	e8 89 f3 ff ff       	call   80101f80 <iget>
80102bf7:	89 c6                	mov    %eax,%esi
80102bf9:	e9 7d fe ff ff       	jmp    80102a7b <namex+0x4b>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80102bfe:	83 ec 0c             	sub    $0xc,%esp
80102c01:	8d 5e 0c             	lea    0xc(%esi),%ebx
80102c04:	53                   	push   %ebx
80102c05:	e8 e6 23 00 00       	call   80104ff0 <holdingsleep>
80102c0a:	83 c4 10             	add    $0x10,%esp
80102c0d:	85 c0                	test   %eax,%eax
80102c0f:	74 2d                	je     80102c3e <namex+0x20e>
80102c11:	8b 7e 08             	mov    0x8(%esi),%edi
80102c14:	85 ff                	test   %edi,%edi
80102c16:	7e 26                	jle    80102c3e <namex+0x20e>
  releasesleep(&ip->lock);
80102c18:	83 ec 0c             	sub    $0xc,%esp
80102c1b:	53                   	push   %ebx
80102c1c:	e8 8f 23 00 00       	call   80104fb0 <releasesleep>
}
80102c21:	83 c4 10             	add    $0x10,%esp
}
80102c24:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102c27:	89 f0                	mov    %esi,%eax
80102c29:	5b                   	pop    %ebx
80102c2a:	5e                   	pop    %esi
80102c2b:	5f                   	pop    %edi
80102c2c:	5d                   	pop    %ebp
80102c2d:	c3                   	ret
    iput(ip);
80102c2e:	83 ec 0c             	sub    $0xc,%esp
80102c31:	56                   	push   %esi
      return 0;
80102c32:	31 f6                	xor    %esi,%esi
    iput(ip);
80102c34:	e8 27 f9 ff ff       	call   80102560 <iput>
    return 0;
80102c39:	83 c4 10             	add    $0x10,%esp
80102c3c:	eb a0                	jmp    80102bde <namex+0x1ae>
    panic("iunlock");
80102c3e:	83 ec 0c             	sub    $0xc,%esp
80102c41:	68 1f 7f 10 80       	push   $0x80107f1f
80102c46:	e8 35 d7 ff ff       	call   80100380 <panic>
80102c4b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102c50 <dirlink>:
{
80102c50:	55                   	push   %ebp
80102c51:	89 e5                	mov    %esp,%ebp
80102c53:	57                   	push   %edi
80102c54:	56                   	push   %esi
80102c55:	53                   	push   %ebx
80102c56:	83 ec 20             	sub    $0x20,%esp
80102c59:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if((ip = dirlookup(dp, name, 0)) != 0){
80102c5c:	6a 00                	push   $0x0
80102c5e:	ff 75 0c             	push   0xc(%ebp)
80102c61:	53                   	push   %ebx
80102c62:	e8 19 fd ff ff       	call   80102980 <dirlookup>
80102c67:	83 c4 10             	add    $0x10,%esp
80102c6a:	85 c0                	test   %eax,%eax
80102c6c:	75 67                	jne    80102cd5 <dirlink+0x85>
  for(off = 0; off < dp->size; off += sizeof(de)){
80102c6e:	8b 7b 58             	mov    0x58(%ebx),%edi
80102c71:	8d 75 d8             	lea    -0x28(%ebp),%esi
80102c74:	85 ff                	test   %edi,%edi
80102c76:	74 29                	je     80102ca1 <dirlink+0x51>
80102c78:	31 ff                	xor    %edi,%edi
80102c7a:	8d 75 d8             	lea    -0x28(%ebp),%esi
80102c7d:	eb 09                	jmp    80102c88 <dirlink+0x38>
80102c7f:	90                   	nop
80102c80:	83 c7 10             	add    $0x10,%edi
80102c83:	3b 7b 58             	cmp    0x58(%ebx),%edi
80102c86:	73 19                	jae    80102ca1 <dirlink+0x51>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102c88:	6a 10                	push   $0x10
80102c8a:	57                   	push   %edi
80102c8b:	56                   	push   %esi
80102c8c:	53                   	push   %ebx
80102c8d:	e8 ae fa ff ff       	call   80102740 <readi>
80102c92:	83 c4 10             	add    $0x10,%esp
80102c95:	83 f8 10             	cmp    $0x10,%eax
80102c98:	75 4e                	jne    80102ce8 <dirlink+0x98>
    if(de.inum == 0)
80102c9a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80102c9f:	75 df                	jne    80102c80 <dirlink+0x30>
  strncpy(de.name, name, DIRSIZ);
80102ca1:	83 ec 04             	sub    $0x4,%esp
80102ca4:	8d 45 da             	lea    -0x26(%ebp),%eax
80102ca7:	6a 0e                	push   $0xe
80102ca9:	ff 75 0c             	push   0xc(%ebp)
80102cac:	50                   	push   %eax
80102cad:	e8 ce 27 00 00       	call   80105480 <strncpy>
  de.inum = inum;
80102cb2:	8b 45 10             	mov    0x10(%ebp),%eax
80102cb5:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102cb9:	6a 10                	push   $0x10
80102cbb:	57                   	push   %edi
80102cbc:	56                   	push   %esi
80102cbd:	53                   	push   %ebx
80102cbe:	e8 7d fb ff ff       	call   80102840 <writei>
80102cc3:	83 c4 20             	add    $0x20,%esp
80102cc6:	83 f8 10             	cmp    $0x10,%eax
80102cc9:	75 2a                	jne    80102cf5 <dirlink+0xa5>
  return 0;
80102ccb:	31 c0                	xor    %eax,%eax
}
80102ccd:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102cd0:	5b                   	pop    %ebx
80102cd1:	5e                   	pop    %esi
80102cd2:	5f                   	pop    %edi
80102cd3:	5d                   	pop    %ebp
80102cd4:	c3                   	ret
    iput(ip);
80102cd5:	83 ec 0c             	sub    $0xc,%esp
80102cd8:	50                   	push   %eax
80102cd9:	e8 82 f8 ff ff       	call   80102560 <iput>
    return -1;
80102cde:	83 c4 10             	add    $0x10,%esp
80102ce1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102ce6:	eb e5                	jmp    80102ccd <dirlink+0x7d>
      panic("dirlink read");
80102ce8:	83 ec 0c             	sub    $0xc,%esp
80102ceb:	68 48 7f 10 80       	push   $0x80107f48
80102cf0:	e8 8b d6 ff ff       	call   80100380 <panic>
    panic("dirlink");
80102cf5:	83 ec 0c             	sub    $0xc,%esp
80102cf8:	68 a4 81 10 80       	push   $0x801081a4
80102cfd:	e8 7e d6 ff ff       	call   80100380 <panic>
80102d02:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102d09:	00 
80102d0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80102d10 <namei>:

struct inode*
namei(char *path)
{
80102d10:	55                   	push   %ebp
  char name[DIRSIZ];
  return namex(path, 0, name);
80102d11:	31 d2                	xor    %edx,%edx
{
80102d13:	89 e5                	mov    %esp,%ebp
80102d15:	83 ec 18             	sub    $0x18,%esp
  return namex(path, 0, name);
80102d18:	8b 45 08             	mov    0x8(%ebp),%eax
80102d1b:	8d 4d ea             	lea    -0x16(%ebp),%ecx
80102d1e:	e8 0d fd ff ff       	call   80102a30 <namex>
}
80102d23:	c9                   	leave
80102d24:	c3                   	ret
80102d25:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102d2c:	00 
80102d2d:	8d 76 00             	lea    0x0(%esi),%esi

80102d30 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80102d30:	55                   	push   %ebp
  return namex(path, 1, name);
80102d31:	ba 01 00 00 00       	mov    $0x1,%edx
{
80102d36:	89 e5                	mov    %esp,%ebp
  return namex(path, 1, name);
80102d38:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80102d3b:	8b 45 08             	mov    0x8(%ebp),%eax
}
80102d3e:	5d                   	pop    %ebp
  return namex(path, 1, name);
80102d3f:	e9 ec fc ff ff       	jmp    80102a30 <namex>
80102d44:	66 90                	xchg   %ax,%ax
80102d46:	66 90                	xchg   %ax,%ax
80102d48:	66 90                	xchg   %ax,%ax
80102d4a:	66 90                	xchg   %ax,%ax
80102d4c:	66 90                	xchg   %ax,%ax
80102d4e:	66 90                	xchg   %ax,%ax

80102d50 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
80102d50:	55                   	push   %ebp
80102d51:	89 e5                	mov    %esp,%ebp
80102d53:	57                   	push   %edi
80102d54:	56                   	push   %esi
80102d55:	53                   	push   %ebx
80102d56:	83 ec 0c             	sub    $0xc,%esp
  if(b == 0)
80102d59:	85 c0                	test   %eax,%eax
80102d5b:	0f 84 b4 00 00 00    	je     80102e15 <idestart+0xc5>
    panic("idestart");
  if(b->blockno >= FSSIZE)
80102d61:	8b 70 08             	mov    0x8(%eax),%esi
80102d64:	89 c3                	mov    %eax,%ebx
80102d66:	81 fe e7 03 00 00    	cmp    $0x3e7,%esi
80102d6c:	0f 87 96 00 00 00    	ja     80102e08 <idestart+0xb8>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102d72:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
80102d77:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102d7e:	00 
80102d7f:	90                   	nop
80102d80:	89 ca                	mov    %ecx,%edx
80102d82:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102d83:	83 e0 c0             	and    $0xffffffc0,%eax
80102d86:	3c 40                	cmp    $0x40,%al
80102d88:	75 f6                	jne    80102d80 <idestart+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102d8a:	31 ff                	xor    %edi,%edi
80102d8c:	ba f6 03 00 00       	mov    $0x3f6,%edx
80102d91:	89 f8                	mov    %edi,%eax
80102d93:	ee                   	out    %al,(%dx)
80102d94:	b8 01 00 00 00       	mov    $0x1,%eax
80102d99:	ba f2 01 00 00       	mov    $0x1f2,%edx
80102d9e:	ee                   	out    %al,(%dx)
80102d9f:	ba f3 01 00 00       	mov    $0x1f3,%edx
80102da4:	89 f0                	mov    %esi,%eax
80102da6:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80102da7:	89 f0                	mov    %esi,%eax
80102da9:	ba f4 01 00 00       	mov    $0x1f4,%edx
80102dae:	c1 f8 08             	sar    $0x8,%eax
80102db1:	ee                   	out    %al,(%dx)
80102db2:	ba f5 01 00 00       	mov    $0x1f5,%edx
80102db7:	89 f8                	mov    %edi,%eax
80102db9:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
80102dba:	0f b6 43 04          	movzbl 0x4(%ebx),%eax
80102dbe:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102dc3:	c1 e0 04             	shl    $0x4,%eax
80102dc6:	83 e0 10             	and    $0x10,%eax
80102dc9:	83 c8 e0             	or     $0xffffffe0,%eax
80102dcc:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
80102dcd:	f6 03 04             	testb  $0x4,(%ebx)
80102dd0:	75 16                	jne    80102de8 <idestart+0x98>
80102dd2:	b8 20 00 00 00       	mov    $0x20,%eax
80102dd7:	89 ca                	mov    %ecx,%edx
80102dd9:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
80102dda:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102ddd:	5b                   	pop    %ebx
80102dde:	5e                   	pop    %esi
80102ddf:	5f                   	pop    %edi
80102de0:	5d                   	pop    %ebp
80102de1:	c3                   	ret
80102de2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102de8:	b8 30 00 00 00       	mov    $0x30,%eax
80102ded:	89 ca                	mov    %ecx,%edx
80102def:	ee                   	out    %al,(%dx)
  asm volatile("cld; rep outsl" :
80102df0:	b9 80 00 00 00       	mov    $0x80,%ecx
    outsl(0x1f0, b->data, BSIZE/4);
80102df5:	8d 73 5c             	lea    0x5c(%ebx),%esi
80102df8:	ba f0 01 00 00       	mov    $0x1f0,%edx
80102dfd:	fc                   	cld
80102dfe:	f3 6f                	rep outsl %ds:(%esi),(%dx)
}
80102e00:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102e03:	5b                   	pop    %ebx
80102e04:	5e                   	pop    %esi
80102e05:	5f                   	pop    %edi
80102e06:	5d                   	pop    %ebp
80102e07:	c3                   	ret
    panic("incorrect blockno");
80102e08:	83 ec 0c             	sub    $0xc,%esp
80102e0b:	68 5e 7f 10 80       	push   $0x80107f5e
80102e10:	e8 6b d5 ff ff       	call   80100380 <panic>
    panic("idestart");
80102e15:	83 ec 0c             	sub    $0xc,%esp
80102e18:	68 55 7f 10 80       	push   $0x80107f55
80102e1d:	e8 5e d5 ff ff       	call   80100380 <panic>
80102e22:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e29:	00 
80102e2a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80102e30 <ideinit>:
{
80102e30:	55                   	push   %ebp
80102e31:	89 e5                	mov    %esp,%ebp
80102e33:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
80102e36:	68 70 7f 10 80       	push   $0x80107f70
80102e3b:	68 a0 28 11 80       	push   $0x801128a0
80102e40:	e8 fb 21 00 00       	call   80105040 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
80102e45:	58                   	pop    %eax
80102e46:	a1 24 2a 11 80       	mov    0x80112a24,%eax
80102e4b:	5a                   	pop    %edx
80102e4c:	83 e8 01             	sub    $0x1,%eax
80102e4f:	50                   	push   %eax
80102e50:	6a 0e                	push   $0xe
80102e52:	e8 99 02 00 00       	call   801030f0 <ioapicenable>
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102e57:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102e5a:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
80102e5f:	90                   	nop
80102e60:	89 ca                	mov    %ecx,%edx
80102e62:	ec                   	in     (%dx),%al
80102e63:	83 e0 c0             	and    $0xffffffc0,%eax
80102e66:	3c 40                	cmp    $0x40,%al
80102e68:	75 f6                	jne    80102e60 <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102e6a:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
80102e6f:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102e74:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102e75:	89 ca                	mov    %ecx,%edx
80102e77:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80102e78:	84 c0                	test   %al,%al
80102e7a:	75 1e                	jne    80102e9a <ideinit+0x6a>
80102e7c:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
80102e81:	ba f7 01 00 00       	mov    $0x1f7,%edx
80102e86:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e8d:	00 
80102e8e:	66 90                	xchg   %ax,%ax
  for(i=0; i<1000; i++){
80102e90:	83 e9 01             	sub    $0x1,%ecx
80102e93:	74 0f                	je     80102ea4 <ideinit+0x74>
80102e95:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80102e96:	84 c0                	test   %al,%al
80102e98:	74 f6                	je     80102e90 <ideinit+0x60>
      havedisk1 = 1;
80102e9a:	c7 05 80 28 11 80 01 	movl   $0x1,0x80112880
80102ea1:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ea4:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80102ea9:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102eae:	ee                   	out    %al,(%dx)
}
80102eaf:	c9                   	leave
80102eb0:	c3                   	ret
80102eb1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102eb8:	00 
80102eb9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102ec0 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102ec0:	55                   	push   %ebp
80102ec1:	89 e5                	mov    %esp,%ebp
80102ec3:	57                   	push   %edi
80102ec4:	56                   	push   %esi
80102ec5:	53                   	push   %ebx
80102ec6:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102ec9:	68 a0 28 11 80       	push   $0x801128a0
80102ece:	e8 5d 23 00 00       	call   80105230 <acquire>

  if((b = idequeue) == 0){
80102ed3:	8b 1d 84 28 11 80    	mov    0x80112884,%ebx
80102ed9:	83 c4 10             	add    $0x10,%esp
80102edc:	85 db                	test   %ebx,%ebx
80102ede:	74 63                	je     80102f43 <ideintr+0x83>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80102ee0:	8b 43 58             	mov    0x58(%ebx),%eax
80102ee3:	a3 84 28 11 80       	mov    %eax,0x80112884

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80102ee8:	8b 33                	mov    (%ebx),%esi
80102eea:	f7 c6 04 00 00 00    	test   $0x4,%esi
80102ef0:	75 2f                	jne    80102f21 <ideintr+0x61>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102ef2:	ba f7 01 00 00       	mov    $0x1f7,%edx
80102ef7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102efe:	00 
80102eff:	90                   	nop
80102f00:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102f01:	89 c1                	mov    %eax,%ecx
80102f03:	83 e1 c0             	and    $0xffffffc0,%ecx
80102f06:	80 f9 40             	cmp    $0x40,%cl
80102f09:	75 f5                	jne    80102f00 <ideintr+0x40>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
80102f0b:	a8 21                	test   $0x21,%al
80102f0d:	75 12                	jne    80102f21 <ideintr+0x61>
    insl(0x1f0, b->data, BSIZE/4);
80102f0f:	8d 7b 5c             	lea    0x5c(%ebx),%edi
  asm volatile("cld; rep insl" :
80102f12:	b9 80 00 00 00       	mov    $0x80,%ecx
80102f17:	ba f0 01 00 00       	mov    $0x1f0,%edx
80102f1c:	fc                   	cld
80102f1d:	f3 6d                	rep insl (%dx),%es:(%edi)

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
80102f1f:	8b 33                	mov    (%ebx),%esi
  b->flags &= ~B_DIRTY;
80102f21:	83 e6 fb             	and    $0xfffffffb,%esi
  wakeup(b);
80102f24:	83 ec 0c             	sub    $0xc,%esp
  b->flags &= ~B_DIRTY;
80102f27:	83 ce 02             	or     $0x2,%esi
80102f2a:	89 33                	mov    %esi,(%ebx)
  wakeup(b);
80102f2c:	53                   	push   %ebx
80102f2d:	e8 3e 1e 00 00       	call   80104d70 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
80102f32:	a1 84 28 11 80       	mov    0x80112884,%eax
80102f37:	83 c4 10             	add    $0x10,%esp
80102f3a:	85 c0                	test   %eax,%eax
80102f3c:	74 05                	je     80102f43 <ideintr+0x83>
    idestart(idequeue);
80102f3e:	e8 0d fe ff ff       	call   80102d50 <idestart>
    release(&idelock);
80102f43:	83 ec 0c             	sub    $0xc,%esp
80102f46:	68 a0 28 11 80       	push   $0x801128a0
80102f4b:	e8 80 22 00 00       	call   801051d0 <release>

  release(&idelock);
}
80102f50:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102f53:	5b                   	pop    %ebx
80102f54:	5e                   	pop    %esi
80102f55:	5f                   	pop    %edi
80102f56:	5d                   	pop    %ebp
80102f57:	c3                   	ret
80102f58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f5f:	00 

80102f60 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
80102f60:	55                   	push   %ebp
80102f61:	89 e5                	mov    %esp,%ebp
80102f63:	53                   	push   %ebx
80102f64:	83 ec 10             	sub    $0x10,%esp
80102f67:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
80102f6a:	8d 43 0c             	lea    0xc(%ebx),%eax
80102f6d:	50                   	push   %eax
80102f6e:	e8 7d 20 00 00       	call   80104ff0 <holdingsleep>
80102f73:	83 c4 10             	add    $0x10,%esp
80102f76:	85 c0                	test   %eax,%eax
80102f78:	0f 84 c3 00 00 00    	je     80103041 <iderw+0xe1>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
80102f7e:	8b 03                	mov    (%ebx),%eax
80102f80:	83 e0 06             	and    $0x6,%eax
80102f83:	83 f8 02             	cmp    $0x2,%eax
80102f86:	0f 84 a8 00 00 00    	je     80103034 <iderw+0xd4>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
80102f8c:	8b 53 04             	mov    0x4(%ebx),%edx
80102f8f:	85 d2                	test   %edx,%edx
80102f91:	74 0d                	je     80102fa0 <iderw+0x40>
80102f93:	a1 80 28 11 80       	mov    0x80112880,%eax
80102f98:	85 c0                	test   %eax,%eax
80102f9a:	0f 84 87 00 00 00    	je     80103027 <iderw+0xc7>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80102fa0:	83 ec 0c             	sub    $0xc,%esp
80102fa3:	68 a0 28 11 80       	push   $0x801128a0
80102fa8:	e8 83 22 00 00       	call   80105230 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102fad:	a1 84 28 11 80       	mov    0x80112884,%eax
  b->qnext = 0;
80102fb2:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102fb9:	83 c4 10             	add    $0x10,%esp
80102fbc:	85 c0                	test   %eax,%eax
80102fbe:	74 60                	je     80103020 <iderw+0xc0>
80102fc0:	89 c2                	mov    %eax,%edx
80102fc2:	8b 40 58             	mov    0x58(%eax),%eax
80102fc5:	85 c0                	test   %eax,%eax
80102fc7:	75 f7                	jne    80102fc0 <iderw+0x60>
80102fc9:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
80102fcc:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
80102fce:	39 1d 84 28 11 80    	cmp    %ebx,0x80112884
80102fd4:	74 3a                	je     80103010 <iderw+0xb0>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102fd6:	8b 03                	mov    (%ebx),%eax
80102fd8:	83 e0 06             	and    $0x6,%eax
80102fdb:	83 f8 02             	cmp    $0x2,%eax
80102fde:	74 1b                	je     80102ffb <iderw+0x9b>
    sleep(b, &idelock);
80102fe0:	83 ec 08             	sub    $0x8,%esp
80102fe3:	68 a0 28 11 80       	push   $0x801128a0
80102fe8:	53                   	push   %ebx
80102fe9:	e8 c2 1c 00 00       	call   80104cb0 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102fee:	8b 03                	mov    (%ebx),%eax
80102ff0:	83 c4 10             	add    $0x10,%esp
80102ff3:	83 e0 06             	and    $0x6,%eax
80102ff6:	83 f8 02             	cmp    $0x2,%eax
80102ff9:	75 e5                	jne    80102fe0 <iderw+0x80>
  }


  release(&idelock);
80102ffb:	c7 45 08 a0 28 11 80 	movl   $0x801128a0,0x8(%ebp)
}
80103002:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103005:	c9                   	leave
  release(&idelock);
80103006:	e9 c5 21 00 00       	jmp    801051d0 <release>
8010300b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    idestart(b);
80103010:	89 d8                	mov    %ebx,%eax
80103012:	e8 39 fd ff ff       	call   80102d50 <idestart>
80103017:	eb bd                	jmp    80102fd6 <iderw+0x76>
80103019:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80103020:	ba 84 28 11 80       	mov    $0x80112884,%edx
80103025:	eb a5                	jmp    80102fcc <iderw+0x6c>
    panic("iderw: ide disk 1 not present");
80103027:	83 ec 0c             	sub    $0xc,%esp
8010302a:	68 9f 7f 10 80       	push   $0x80107f9f
8010302f:	e8 4c d3 ff ff       	call   80100380 <panic>
    panic("iderw: nothing to do");
80103034:	83 ec 0c             	sub    $0xc,%esp
80103037:	68 8a 7f 10 80       	push   $0x80107f8a
8010303c:	e8 3f d3 ff ff       	call   80100380 <panic>
    panic("iderw: buf not locked");
80103041:	83 ec 0c             	sub    $0xc,%esp
80103044:	68 74 7f 10 80       	push   $0x80107f74
80103049:	e8 32 d3 ff ff       	call   80100380 <panic>
8010304e:	66 90                	xchg   %ax,%ax

80103050 <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
80103050:	55                   	push   %ebp
80103051:	89 e5                	mov    %esp,%ebp
80103053:	56                   	push   %esi
80103054:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80103055:	c7 05 d4 28 11 80 00 	movl   $0xfec00000,0x801128d4
8010305c:	00 c0 fe 
  ioapic->reg = reg;
8010305f:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
80103066:	00 00 00 
  return ioapic->data;
80103069:	8b 15 d4 28 11 80    	mov    0x801128d4,%edx
8010306f:	8b 72 10             	mov    0x10(%edx),%esi
  ioapic->reg = reg;
80103072:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
  return ioapic->data;
80103078:	8b 1d d4 28 11 80    	mov    0x801128d4,%ebx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
8010307e:	0f b6 15 20 2a 11 80 	movzbl 0x80112a20,%edx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80103085:	c1 ee 10             	shr    $0x10,%esi
80103088:	89 f0                	mov    %esi,%eax
8010308a:	0f b6 f0             	movzbl %al,%esi
  return ioapic->data;
8010308d:	8b 43 10             	mov    0x10(%ebx),%eax
  id = ioapicread(REG_ID) >> 24;
80103090:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80103093:	39 c2                	cmp    %eax,%edx
80103095:	74 16                	je     801030ad <ioapicinit+0x5d>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80103097:	83 ec 0c             	sub    $0xc,%esp
8010309a:	68 18 84 10 80       	push   $0x80108418
8010309f:	e8 3c dc ff ff       	call   80100ce0 <cprintf>
  ioapic->reg = reg;
801030a4:	8b 1d d4 28 11 80    	mov    0x801128d4,%ebx
801030aa:	83 c4 10             	add    $0x10,%esp
{
801030ad:	ba 10 00 00 00       	mov    $0x10,%edx
801030b2:	31 c0                	xor    %eax,%eax
801030b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  ioapic->reg = reg;
801030b8:	89 13                	mov    %edx,(%ebx)
801030ba:	8d 48 20             	lea    0x20(%eax),%ecx
  ioapic->data = data;
801030bd:	8b 1d d4 28 11 80    	mov    0x801128d4,%ebx

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
801030c3:	83 c0 01             	add    $0x1,%eax
801030c6:	81 c9 00 00 01 00    	or     $0x10000,%ecx
  ioapic->data = data;
801030cc:	89 4b 10             	mov    %ecx,0x10(%ebx)
  ioapic->reg = reg;
801030cf:	8d 4a 01             	lea    0x1(%edx),%ecx
  for(i = 0; i <= maxintr; i++){
801030d2:	83 c2 02             	add    $0x2,%edx
  ioapic->reg = reg;
801030d5:	89 0b                	mov    %ecx,(%ebx)
  ioapic->data = data;
801030d7:	8b 1d d4 28 11 80    	mov    0x801128d4,%ebx
801030dd:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
  for(i = 0; i <= maxintr; i++){
801030e4:	39 c6                	cmp    %eax,%esi
801030e6:	7d d0                	jge    801030b8 <ioapicinit+0x68>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
801030e8:	8d 65 f8             	lea    -0x8(%ebp),%esp
801030eb:	5b                   	pop    %ebx
801030ec:	5e                   	pop    %esi
801030ed:	5d                   	pop    %ebp
801030ee:	c3                   	ret
801030ef:	90                   	nop

801030f0 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
801030f0:	55                   	push   %ebp
  ioapic->reg = reg;
801030f1:	8b 0d d4 28 11 80    	mov    0x801128d4,%ecx
{
801030f7:	89 e5                	mov    %esp,%ebp
801030f9:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
801030fc:	8d 50 20             	lea    0x20(%eax),%edx
801030ff:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80103103:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80103105:	8b 0d d4 28 11 80    	mov    0x801128d4,%ecx
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010310b:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
8010310e:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80103111:	8b 55 0c             	mov    0xc(%ebp),%edx
  ioapic->reg = reg;
80103114:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80103116:	a1 d4 28 11 80       	mov    0x801128d4,%eax
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010311b:	c1 e2 18             	shl    $0x18,%edx
  ioapic->data = data;
8010311e:	89 50 10             	mov    %edx,0x10(%eax)
}
80103121:	5d                   	pop    %ebp
80103122:	c3                   	ret
80103123:	66 90                	xchg   %ax,%ax
80103125:	66 90                	xchg   %ax,%ax
80103127:	66 90                	xchg   %ax,%ax
80103129:	66 90                	xchg   %ax,%ax
8010312b:	66 90                	xchg   %ax,%ax
8010312d:	66 90                	xchg   %ax,%ax
8010312f:	90                   	nop

80103130 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80103130:	55                   	push   %ebp
80103131:	89 e5                	mov    %esp,%ebp
80103133:	53                   	push   %ebx
80103134:	83 ec 04             	sub    $0x4,%esp
80103137:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
8010313a:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80103140:	75 76                	jne    801031b8 <kfree+0x88>
80103142:	81 fb 70 67 11 80    	cmp    $0x80116770,%ebx
80103148:	72 6e                	jb     801031b8 <kfree+0x88>
8010314a:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80103150:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
80103155:	77 61                	ja     801031b8 <kfree+0x88>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80103157:	83 ec 04             	sub    $0x4,%esp
8010315a:	68 00 10 00 00       	push   $0x1000
8010315f:	6a 01                	push   $0x1
80103161:	53                   	push   %ebx
80103162:	e8 c9 21 00 00       	call   80105330 <memset>

  if(kmem.use_lock)
80103167:	8b 15 14 29 11 80    	mov    0x80112914,%edx
8010316d:	83 c4 10             	add    $0x10,%esp
80103170:	85 d2                	test   %edx,%edx
80103172:	75 1c                	jne    80103190 <kfree+0x60>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
80103174:	a1 18 29 11 80       	mov    0x80112918,%eax
80103179:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
  if(kmem.use_lock)
8010317b:	a1 14 29 11 80       	mov    0x80112914,%eax
  kmem.freelist = r;
80103180:	89 1d 18 29 11 80    	mov    %ebx,0x80112918
  if(kmem.use_lock)
80103186:	85 c0                	test   %eax,%eax
80103188:	75 1e                	jne    801031a8 <kfree+0x78>
    release(&kmem.lock);
}
8010318a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010318d:	c9                   	leave
8010318e:	c3                   	ret
8010318f:	90                   	nop
    acquire(&kmem.lock);
80103190:	83 ec 0c             	sub    $0xc,%esp
80103193:	68 e0 28 11 80       	push   $0x801128e0
80103198:	e8 93 20 00 00       	call   80105230 <acquire>
8010319d:	83 c4 10             	add    $0x10,%esp
801031a0:	eb d2                	jmp    80103174 <kfree+0x44>
801031a2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    release(&kmem.lock);
801031a8:	c7 45 08 e0 28 11 80 	movl   $0x801128e0,0x8(%ebp)
}
801031af:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801031b2:	c9                   	leave
    release(&kmem.lock);
801031b3:	e9 18 20 00 00       	jmp    801051d0 <release>
    panic("kfree");
801031b8:	83 ec 0c             	sub    $0xc,%esp
801031bb:	68 bd 7f 10 80       	push   $0x80107fbd
801031c0:	e8 bb d1 ff ff       	call   80100380 <panic>
801031c5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801031cc:	00 
801031cd:	8d 76 00             	lea    0x0(%esi),%esi

801031d0 <freerange>:
{
801031d0:	55                   	push   %ebp
801031d1:	89 e5                	mov    %esp,%ebp
801031d3:	56                   	push   %esi
801031d4:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
801031d5:	8b 45 08             	mov    0x8(%ebp),%eax
{
801031d8:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801031db:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801031e1:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801031e7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801031ed:	39 de                	cmp    %ebx,%esi
801031ef:	72 23                	jb     80103214 <freerange+0x44>
801031f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
801031f8:	83 ec 0c             	sub    $0xc,%esp
801031fb:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80103201:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80103207:	50                   	push   %eax
80103208:	e8 23 ff ff ff       	call   80103130 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010320d:	83 c4 10             	add    $0x10,%esp
80103210:	39 de                	cmp    %ebx,%esi
80103212:	73 e4                	jae    801031f8 <freerange+0x28>
}
80103214:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103217:	5b                   	pop    %ebx
80103218:	5e                   	pop    %esi
80103219:	5d                   	pop    %ebp
8010321a:	c3                   	ret
8010321b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103220 <kinit2>:
{
80103220:	55                   	push   %ebp
80103221:	89 e5                	mov    %esp,%ebp
80103223:	56                   	push   %esi
80103224:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80103225:	8b 45 08             	mov    0x8(%ebp),%eax
{
80103228:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
8010322b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80103231:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80103237:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010323d:	39 de                	cmp    %ebx,%esi
8010323f:	72 23                	jb     80103264 <kinit2+0x44>
80103241:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
80103248:	83 ec 0c             	sub    $0xc,%esp
8010324b:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80103251:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80103257:	50                   	push   %eax
80103258:	e8 d3 fe ff ff       	call   80103130 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010325d:	83 c4 10             	add    $0x10,%esp
80103260:	39 de                	cmp    %ebx,%esi
80103262:	73 e4                	jae    80103248 <kinit2+0x28>
  kmem.use_lock = 1;
80103264:	c7 05 14 29 11 80 01 	movl   $0x1,0x80112914
8010326b:	00 00 00 
}
8010326e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103271:	5b                   	pop    %ebx
80103272:	5e                   	pop    %esi
80103273:	5d                   	pop    %ebp
80103274:	c3                   	ret
80103275:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010327c:	00 
8010327d:	8d 76 00             	lea    0x0(%esi),%esi

80103280 <kinit1>:
{
80103280:	55                   	push   %ebp
80103281:	89 e5                	mov    %esp,%ebp
80103283:	56                   	push   %esi
80103284:	53                   	push   %ebx
80103285:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
80103288:	83 ec 08             	sub    $0x8,%esp
8010328b:	68 c3 7f 10 80       	push   $0x80107fc3
80103290:	68 e0 28 11 80       	push   $0x801128e0
80103295:	e8 a6 1d 00 00       	call   80105040 <initlock>
  p = (char*)PGROUNDUP((uint)vstart);
8010329a:	8b 45 08             	mov    0x8(%ebp),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010329d:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
801032a0:	c7 05 14 29 11 80 00 	movl   $0x0,0x80112914
801032a7:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
801032aa:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801032b0:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801032b6:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801032bc:	39 de                	cmp    %ebx,%esi
801032be:	72 1c                	jb     801032dc <kinit1+0x5c>
    kfree(p);
801032c0:	83 ec 0c             	sub    $0xc,%esp
801032c3:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801032c9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
801032cf:	50                   	push   %eax
801032d0:	e8 5b fe ff ff       	call   80103130 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801032d5:	83 c4 10             	add    $0x10,%esp
801032d8:	39 de                	cmp    %ebx,%esi
801032da:	73 e4                	jae    801032c0 <kinit1+0x40>
}
801032dc:	8d 65 f8             	lea    -0x8(%ebp),%esp
801032df:	5b                   	pop    %ebx
801032e0:	5e                   	pop    %esi
801032e1:	5d                   	pop    %ebp
801032e2:	c3                   	ret
801032e3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801032ea:	00 
801032eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801032f0 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
801032f0:	55                   	push   %ebp
801032f1:	89 e5                	mov    %esp,%ebp
801032f3:	53                   	push   %ebx
801032f4:	83 ec 04             	sub    $0x4,%esp
  struct run *r;

  if(kmem.use_lock)
801032f7:	a1 14 29 11 80       	mov    0x80112914,%eax
801032fc:	85 c0                	test   %eax,%eax
801032fe:	75 20                	jne    80103320 <kalloc+0x30>
    acquire(&kmem.lock);
  r = kmem.freelist;
80103300:	8b 1d 18 29 11 80    	mov    0x80112918,%ebx
  if(r)
80103306:	85 db                	test   %ebx,%ebx
80103308:	74 07                	je     80103311 <kalloc+0x21>
    kmem.freelist = r->next;
8010330a:	8b 03                	mov    (%ebx),%eax
8010330c:	a3 18 29 11 80       	mov    %eax,0x80112918
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;
}
80103311:	89 d8                	mov    %ebx,%eax
80103313:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103316:	c9                   	leave
80103317:	c3                   	ret
80103318:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010331f:	00 
    acquire(&kmem.lock);
80103320:	83 ec 0c             	sub    $0xc,%esp
80103323:	68 e0 28 11 80       	push   $0x801128e0
80103328:	e8 03 1f 00 00       	call   80105230 <acquire>
  r = kmem.freelist;
8010332d:	8b 1d 18 29 11 80    	mov    0x80112918,%ebx
  if(kmem.use_lock)
80103333:	a1 14 29 11 80       	mov    0x80112914,%eax
  if(r)
80103338:	83 c4 10             	add    $0x10,%esp
8010333b:	85 db                	test   %ebx,%ebx
8010333d:	74 08                	je     80103347 <kalloc+0x57>
    kmem.freelist = r->next;
8010333f:	8b 13                	mov    (%ebx),%edx
80103341:	89 15 18 29 11 80    	mov    %edx,0x80112918
  if(kmem.use_lock)
80103347:	85 c0                	test   %eax,%eax
80103349:	74 c6                	je     80103311 <kalloc+0x21>
    release(&kmem.lock);
8010334b:	83 ec 0c             	sub    $0xc,%esp
8010334e:	68 e0 28 11 80       	push   $0x801128e0
80103353:	e8 78 1e 00 00       	call   801051d0 <release>
}
80103358:	89 d8                	mov    %ebx,%eax
    release(&kmem.lock);
8010335a:	83 c4 10             	add    $0x10,%esp
}
8010335d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103360:	c9                   	leave
80103361:	c3                   	ret
80103362:	66 90                	xchg   %ax,%ax
80103364:	66 90                	xchg   %ax,%ax
80103366:	66 90                	xchg   %ax,%ax
80103368:	66 90                	xchg   %ax,%ax
8010336a:	66 90                	xchg   %ax,%ax
8010336c:	66 90                	xchg   %ax,%ax
8010336e:	66 90                	xchg   %ax,%ax

80103370 <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103370:	ba 64 00 00 00       	mov    $0x64,%edx
80103375:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80103376:	a8 01                	test   $0x1,%al
80103378:	0f 84 c2 00 00 00    	je     80103440 <kbdgetc+0xd0>
{
8010337e:	55                   	push   %ebp
8010337f:	ba 60 00 00 00       	mov    $0x60,%edx
80103384:	89 e5                	mov    %esp,%ebp
80103386:	53                   	push   %ebx
80103387:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);

  if(data == 0xE0){
    shift |= E0ESC;
80103388:	8b 1d 1c 29 11 80    	mov    0x8011291c,%ebx
  data = inb(KBDATAP);
8010338e:	0f b6 c8             	movzbl %al,%ecx
  if(data == 0xE0){
80103391:	3c e0                	cmp    $0xe0,%al
80103393:	74 5b                	je     801033f0 <kbdgetc+0x80>
    return 0;
  } else if(data & 0x80){
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
80103395:	89 da                	mov    %ebx,%edx
80103397:	83 e2 40             	and    $0x40,%edx
  } else if(data & 0x80){
8010339a:	84 c0                	test   %al,%al
8010339c:	78 62                	js     80103400 <kbdgetc+0x90>
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
8010339e:	85 d2                	test   %edx,%edx
801033a0:	74 09                	je     801033ab <kbdgetc+0x3b>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
801033a2:	83 c8 80             	or     $0xffffff80,%eax
    shift &= ~E0ESC;
801033a5:	83 e3 bf             	and    $0xffffffbf,%ebx
    data |= 0x80;
801033a8:	0f b6 c8             	movzbl %al,%ecx
  }

  shift |= shiftcode[data];
801033ab:	0f b6 91 80 86 10 80 	movzbl -0x7fef7980(%ecx),%edx
  shift ^= togglecode[data];
801033b2:	0f b6 81 80 85 10 80 	movzbl -0x7fef7a80(%ecx),%eax
  shift |= shiftcode[data];
801033b9:	09 da                	or     %ebx,%edx
  shift ^= togglecode[data];
801033bb:	31 c2                	xor    %eax,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801033bd:	89 d0                	mov    %edx,%eax
  shift ^= togglecode[data];
801033bf:	89 15 1c 29 11 80    	mov    %edx,0x8011291c
  c = charcode[shift & (CTL | SHIFT)][data];
801033c5:	83 e0 03             	and    $0x3,%eax
  if(shift & CAPSLOCK){
801033c8:	83 e2 08             	and    $0x8,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801033cb:	8b 04 85 60 85 10 80 	mov    -0x7fef7aa0(,%eax,4),%eax
801033d2:	0f b6 04 08          	movzbl (%eax,%ecx,1),%eax
  if(shift & CAPSLOCK){
801033d6:	74 0b                	je     801033e3 <kbdgetc+0x73>
    if('a' <= c && c <= 'z')
801033d8:	8d 50 9f             	lea    -0x61(%eax),%edx
801033db:	83 fa 19             	cmp    $0x19,%edx
801033de:	77 48                	ja     80103428 <kbdgetc+0xb8>
      c += 'A' - 'a';
801033e0:	83 e8 20             	sub    $0x20,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
801033e3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801033e6:	c9                   	leave
801033e7:	c3                   	ret
801033e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801033ef:	00 
    shift |= E0ESC;
801033f0:	83 cb 40             	or     $0x40,%ebx
    return 0;
801033f3:	31 c0                	xor    %eax,%eax
    shift |= E0ESC;
801033f5:	89 1d 1c 29 11 80    	mov    %ebx,0x8011291c
}
801033fb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801033fe:	c9                   	leave
801033ff:	c3                   	ret
    data = (shift & E0ESC ? data : data & 0x7F);
80103400:	83 e0 7f             	and    $0x7f,%eax
80103403:	85 d2                	test   %edx,%edx
80103405:	0f 44 c8             	cmove  %eax,%ecx
    shift &= ~(shiftcode[data] | E0ESC);
80103408:	0f b6 81 80 86 10 80 	movzbl -0x7fef7980(%ecx),%eax
8010340f:	83 c8 40             	or     $0x40,%eax
80103412:	0f b6 c0             	movzbl %al,%eax
80103415:	f7 d0                	not    %eax
80103417:	21 d8                	and    %ebx,%eax
80103419:	a3 1c 29 11 80       	mov    %eax,0x8011291c
    return 0;
8010341e:	31 c0                	xor    %eax,%eax
80103420:	eb d9                	jmp    801033fb <kbdgetc+0x8b>
80103422:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    else if('A' <= c && c <= 'Z')
80103428:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010342b:	8d 50 20             	lea    0x20(%eax),%edx
}
8010342e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103431:	c9                   	leave
      c += 'a' - 'A';
80103432:	83 f9 1a             	cmp    $0x1a,%ecx
80103435:	0f 42 c2             	cmovb  %edx,%eax
}
80103438:	c3                   	ret
80103439:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80103440:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80103445:	c3                   	ret
80103446:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010344d:	00 
8010344e:	66 90                	xchg   %ax,%ax

80103450 <kbdintr>:

void
kbdintr(void)
{
80103450:	55                   	push   %ebp
80103451:	89 e5                	mov    %esp,%ebp
80103453:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80103456:	68 70 33 10 80       	push   $0x80103370
8010345b:	e8 70 da ff ff       	call   80100ed0 <consoleintr>
}
80103460:	83 c4 10             	add    $0x10,%esp
80103463:	c9                   	leave
80103464:	c3                   	ret
80103465:	66 90                	xchg   %ax,%ax
80103467:	66 90                	xchg   %ax,%ax
80103469:	66 90                	xchg   %ax,%ax
8010346b:	66 90                	xchg   %ax,%ax
8010346d:	66 90                	xchg   %ax,%ax
8010346f:	90                   	nop

80103470 <lapicinit>:
}

void
lapicinit(void)
{
  if(!lapic)
80103470:	a1 20 29 11 80       	mov    0x80112920,%eax
80103475:	85 c0                	test   %eax,%eax
80103477:	0f 84 c3 00 00 00    	je     80103540 <lapicinit+0xd0>
  lapic[index] = value;
8010347d:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
80103484:	01 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103487:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010348a:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
80103491:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103494:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80103497:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
8010349e:	00 02 00 
  lapic[ID];  // wait for write to finish, by reading
801034a1:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034a4:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
801034ab:	96 98 00 
  lapic[ID];  // wait for write to finish, by reading
801034ae:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034b1:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
801034b8:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801034bb:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034be:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
801034c5:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801034c8:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(LINT0, MASKED);
  lapicw(LINT1, MASKED);

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
801034cb:	8b 50 30             	mov    0x30(%eax),%edx
801034ce:	81 e2 00 00 fc 00    	and    $0xfc0000,%edx
801034d4:	75 72                	jne    80103548 <lapicinit+0xd8>
  lapic[index] = value;
801034d6:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
801034dd:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801034e0:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034e3:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801034ea:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801034ed:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034f0:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801034f7:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801034fa:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801034fd:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80103504:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103507:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010350a:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
80103511:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103514:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80103517:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
8010351e:	85 08 00 
  lapic[ID];  // wait for write to finish, by reading
80103521:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(EOI, 0);

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  while(lapic[ICRLO] & DELIVS)
80103524:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103528:	8b 90 00 03 00 00    	mov    0x300(%eax),%edx
8010352e:	80 e6 10             	and    $0x10,%dh
80103531:	75 f5                	jne    80103528 <lapicinit+0xb8>
  lapic[index] = value;
80103533:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
8010353a:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
8010353d:	8b 40 20             	mov    0x20(%eax),%eax
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
}
80103540:	c3                   	ret
80103541:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  lapic[index] = value;
80103548:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
8010354f:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80103552:	8b 50 20             	mov    0x20(%eax),%edx
}
80103555:	e9 7c ff ff ff       	jmp    801034d6 <lapicinit+0x66>
8010355a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103560 <lapicid>:

int
lapicid(void)
{
  if (!lapic)
80103560:	a1 20 29 11 80       	mov    0x80112920,%eax
80103565:	85 c0                	test   %eax,%eax
80103567:	74 07                	je     80103570 <lapicid+0x10>
    return 0;
  return lapic[ID] >> 24;
80103569:	8b 40 20             	mov    0x20(%eax),%eax
8010356c:	c1 e8 18             	shr    $0x18,%eax
8010356f:	c3                   	ret
    return 0;
80103570:	31 c0                	xor    %eax,%eax
}
80103572:	c3                   	ret
80103573:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010357a:	00 
8010357b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103580 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  if(lapic)
80103580:	a1 20 29 11 80       	mov    0x80112920,%eax
80103585:	85 c0                	test   %eax,%eax
80103587:	74 0d                	je     80103596 <lapiceoi+0x16>
  lapic[index] = value;
80103589:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80103590:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103593:	8b 40 20             	mov    0x20(%eax),%eax
    lapicw(EOI, 0);
}
80103596:	c3                   	ret
80103597:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010359e:	00 
8010359f:	90                   	nop

801035a0 <microdelay>:
// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
}
801035a0:	c3                   	ret
801035a1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801035a8:	00 
801035a9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801035b0 <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
801035b0:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801035b1:	b8 0f 00 00 00       	mov    $0xf,%eax
801035b6:	ba 70 00 00 00       	mov    $0x70,%edx
801035bb:	89 e5                	mov    %esp,%ebp
801035bd:	53                   	push   %ebx
801035be:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801035c1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801035c4:	ee                   	out    %al,(%dx)
801035c5:	b8 0a 00 00 00       	mov    $0xa,%eax
801035ca:	ba 71 00 00 00       	mov    $0x71,%edx
801035cf:	ee                   	out    %al,(%dx)
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
  outb(CMOS_PORT+1, 0x0A);
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
  wrv[0] = 0;
801035d0:	31 c0                	xor    %eax,%eax
  lapic[index] = value;
801035d2:	c1 e3 18             	shl    $0x18,%ebx
  wrv[0] = 0;
801035d5:	66 a3 67 04 00 80    	mov    %ax,0x80000467
  wrv[1] = addr >> 4;
801035db:	89 c8                	mov    %ecx,%eax
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
    lapicw(ICRHI, apicid<<24);
    lapicw(ICRLO, STARTUP | (addr>>12));
801035dd:	c1 e9 0c             	shr    $0xc,%ecx
  lapic[index] = value;
801035e0:	89 da                	mov    %ebx,%edx
  wrv[1] = addr >> 4;
801035e2:	c1 e8 04             	shr    $0x4,%eax
    lapicw(ICRLO, STARTUP | (addr>>12));
801035e5:	80 cd 06             	or     $0x6,%ch
  wrv[1] = addr >> 4;
801035e8:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapic[index] = value;
801035ee:	a1 20 29 11 80       	mov    0x80112920,%eax
801035f3:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
801035f9:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
801035fc:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
80103603:	c5 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103606:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103609:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
80103610:	85 00 00 
  lapic[ID];  // wait for write to finish, by reading
80103613:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103616:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
8010361c:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
8010361f:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80103625:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80103628:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
8010362e:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80103631:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80103637:	8b 40 20             	mov    0x20(%eax),%eax
    microdelay(200);
  }
}
8010363a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010363d:	c9                   	leave
8010363e:	c3                   	ret
8010363f:	90                   	nop

80103640 <cmostime>:
}

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80103640:	55                   	push   %ebp
80103641:	b8 0b 00 00 00       	mov    $0xb,%eax
80103646:	ba 70 00 00 00       	mov    $0x70,%edx
8010364b:	89 e5                	mov    %esp,%ebp
8010364d:	57                   	push   %edi
8010364e:	56                   	push   %esi
8010364f:	53                   	push   %ebx
80103650:	83 ec 4c             	sub    $0x4c,%esp
80103653:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103654:	ba 71 00 00 00       	mov    $0x71,%edx
80103659:	ec                   	in     (%dx),%al
  struct rtcdate t1, t2;
  int sb, bcd;

  sb = cmos_read(CMOS_STATB);

  bcd = (sb & (1 << 2)) == 0;
8010365a:	83 e0 04             	and    $0x4,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010365d:	bf 70 00 00 00       	mov    $0x70,%edi
80103662:	88 45 b3             	mov    %al,-0x4d(%ebp)
80103665:	8d 76 00             	lea    0x0(%esi),%esi
80103668:	31 c0                	xor    %eax,%eax
8010366a:	89 fa                	mov    %edi,%edx
8010366c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010366d:	b9 71 00 00 00       	mov    $0x71,%ecx
80103672:	89 ca                	mov    %ecx,%edx
80103674:	ec                   	in     (%dx),%al
80103675:	88 45 b7             	mov    %al,-0x49(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103678:	89 fa                	mov    %edi,%edx
8010367a:	b8 02 00 00 00       	mov    $0x2,%eax
8010367f:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103680:	89 ca                	mov    %ecx,%edx
80103682:	ec                   	in     (%dx),%al
80103683:	88 45 b6             	mov    %al,-0x4a(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103686:	89 fa                	mov    %edi,%edx
80103688:	b8 04 00 00 00       	mov    $0x4,%eax
8010368d:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010368e:	89 ca                	mov    %ecx,%edx
80103690:	ec                   	in     (%dx),%al
80103691:	88 45 b5             	mov    %al,-0x4b(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103694:	89 fa                	mov    %edi,%edx
80103696:	b8 07 00 00 00       	mov    $0x7,%eax
8010369b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010369c:	89 ca                	mov    %ecx,%edx
8010369e:	ec                   	in     (%dx),%al
8010369f:	88 45 b4             	mov    %al,-0x4c(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801036a2:	89 fa                	mov    %edi,%edx
801036a4:	b8 08 00 00 00       	mov    $0x8,%eax
801036a9:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801036aa:	89 ca                	mov    %ecx,%edx
801036ac:	ec                   	in     (%dx),%al
801036ad:	89 c6                	mov    %eax,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801036af:	89 fa                	mov    %edi,%edx
801036b1:	b8 09 00 00 00       	mov    $0x9,%eax
801036b6:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801036b7:	89 ca                	mov    %ecx,%edx
801036b9:	ec                   	in     (%dx),%al
801036ba:	0f b6 d8             	movzbl %al,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801036bd:	89 fa                	mov    %edi,%edx
801036bf:	b8 0a 00 00 00       	mov    $0xa,%eax
801036c4:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801036c5:	89 ca                	mov    %ecx,%edx
801036c7:	ec                   	in     (%dx),%al

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
801036c8:	84 c0                	test   %al,%al
801036ca:	78 9c                	js     80103668 <cmostime+0x28>
  return inb(CMOS_RETURN);
801036cc:	0f b6 45 b7          	movzbl -0x49(%ebp),%eax
801036d0:	89 f2                	mov    %esi,%edx
801036d2:	89 5d cc             	mov    %ebx,-0x34(%ebp)
801036d5:	0f b6 f2             	movzbl %dl,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801036d8:	89 fa                	mov    %edi,%edx
801036da:	89 45 b8             	mov    %eax,-0x48(%ebp)
801036dd:	0f b6 45 b6          	movzbl -0x4a(%ebp),%eax
801036e1:	89 75 c8             	mov    %esi,-0x38(%ebp)
801036e4:	89 45 bc             	mov    %eax,-0x44(%ebp)
801036e7:	0f b6 45 b5          	movzbl -0x4b(%ebp),%eax
801036eb:	89 45 c0             	mov    %eax,-0x40(%ebp)
801036ee:	0f b6 45 b4          	movzbl -0x4c(%ebp),%eax
801036f2:	89 45 c4             	mov    %eax,-0x3c(%ebp)
801036f5:	31 c0                	xor    %eax,%eax
801036f7:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801036f8:	89 ca                	mov    %ecx,%edx
801036fa:	ec                   	in     (%dx),%al
801036fb:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801036fe:	89 fa                	mov    %edi,%edx
80103700:	89 45 d0             	mov    %eax,-0x30(%ebp)
80103703:	b8 02 00 00 00       	mov    $0x2,%eax
80103708:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103709:	89 ca                	mov    %ecx,%edx
8010370b:	ec                   	in     (%dx),%al
8010370c:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010370f:	89 fa                	mov    %edi,%edx
80103711:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80103714:	b8 04 00 00 00       	mov    $0x4,%eax
80103719:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010371a:	89 ca                	mov    %ecx,%edx
8010371c:	ec                   	in     (%dx),%al
8010371d:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103720:	89 fa                	mov    %edi,%edx
80103722:	89 45 d8             	mov    %eax,-0x28(%ebp)
80103725:	b8 07 00 00 00       	mov    $0x7,%eax
8010372a:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010372b:	89 ca                	mov    %ecx,%edx
8010372d:	ec                   	in     (%dx),%al
8010372e:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103731:	89 fa                	mov    %edi,%edx
80103733:	89 45 dc             	mov    %eax,-0x24(%ebp)
80103736:	b8 08 00 00 00       	mov    $0x8,%eax
8010373b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010373c:	89 ca                	mov    %ecx,%edx
8010373e:	ec                   	in     (%dx),%al
8010373f:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103742:	89 fa                	mov    %edi,%edx
80103744:	89 45 e0             	mov    %eax,-0x20(%ebp)
80103747:	b8 09 00 00 00       	mov    $0x9,%eax
8010374c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010374d:	89 ca                	mov    %ecx,%edx
8010374f:	ec                   	in     (%dx),%al
80103750:	0f b6 c0             	movzbl %al,%eax
        continue;
    fill_rtcdate(&t2);
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80103753:	83 ec 04             	sub    $0x4,%esp
  return inb(CMOS_RETURN);
80103756:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80103759:	8d 45 d0             	lea    -0x30(%ebp),%eax
8010375c:	6a 18                	push   $0x18
8010375e:	50                   	push   %eax
8010375f:	8d 45 b8             	lea    -0x48(%ebp),%eax
80103762:	50                   	push   %eax
80103763:	e8 08 1c 00 00       	call   80105370 <memcmp>
80103768:	83 c4 10             	add    $0x10,%esp
8010376b:	85 c0                	test   %eax,%eax
8010376d:	0f 85 f5 fe ff ff    	jne    80103668 <cmostime+0x28>
      break;
  }

  // convert
  if(bcd) {
80103773:	0f b6 75 b3          	movzbl -0x4d(%ebp),%esi
80103777:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010377a:	89 f0                	mov    %esi,%eax
8010377c:	84 c0                	test   %al,%al
8010377e:	75 78                	jne    801037f8 <cmostime+0x1b8>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
80103780:	8b 45 b8             	mov    -0x48(%ebp),%eax
80103783:	89 c2                	mov    %eax,%edx
80103785:	83 e0 0f             	and    $0xf,%eax
80103788:	c1 ea 04             	shr    $0x4,%edx
8010378b:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010378e:	8d 04 50             	lea    (%eax,%edx,2),%eax
80103791:	89 45 b8             	mov    %eax,-0x48(%ebp)
    CONV(minute);
80103794:	8b 45 bc             	mov    -0x44(%ebp),%eax
80103797:	89 c2                	mov    %eax,%edx
80103799:	83 e0 0f             	and    $0xf,%eax
8010379c:	c1 ea 04             	shr    $0x4,%edx
8010379f:	8d 14 92             	lea    (%edx,%edx,4),%edx
801037a2:	8d 04 50             	lea    (%eax,%edx,2),%eax
801037a5:	89 45 bc             	mov    %eax,-0x44(%ebp)
    CONV(hour  );
801037a8:	8b 45 c0             	mov    -0x40(%ebp),%eax
801037ab:	89 c2                	mov    %eax,%edx
801037ad:	83 e0 0f             	and    $0xf,%eax
801037b0:	c1 ea 04             	shr    $0x4,%edx
801037b3:	8d 14 92             	lea    (%edx,%edx,4),%edx
801037b6:	8d 04 50             	lea    (%eax,%edx,2),%eax
801037b9:	89 45 c0             	mov    %eax,-0x40(%ebp)
    CONV(day   );
801037bc:	8b 45 c4             	mov    -0x3c(%ebp),%eax
801037bf:	89 c2                	mov    %eax,%edx
801037c1:	83 e0 0f             	and    $0xf,%eax
801037c4:	c1 ea 04             	shr    $0x4,%edx
801037c7:	8d 14 92             	lea    (%edx,%edx,4),%edx
801037ca:	8d 04 50             	lea    (%eax,%edx,2),%eax
801037cd:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    CONV(month );
801037d0:	8b 45 c8             	mov    -0x38(%ebp),%eax
801037d3:	89 c2                	mov    %eax,%edx
801037d5:	83 e0 0f             	and    $0xf,%eax
801037d8:	c1 ea 04             	shr    $0x4,%edx
801037db:	8d 14 92             	lea    (%edx,%edx,4),%edx
801037de:	8d 04 50             	lea    (%eax,%edx,2),%eax
801037e1:	89 45 c8             	mov    %eax,-0x38(%ebp)
    CONV(year  );
801037e4:	8b 45 cc             	mov    -0x34(%ebp),%eax
801037e7:	89 c2                	mov    %eax,%edx
801037e9:	83 e0 0f             	and    $0xf,%eax
801037ec:	c1 ea 04             	shr    $0x4,%edx
801037ef:	8d 14 92             	lea    (%edx,%edx,4),%edx
801037f2:	8d 04 50             	lea    (%eax,%edx,2),%eax
801037f5:	89 45 cc             	mov    %eax,-0x34(%ebp)
#undef     CONV
  }

  *r = t1;
801037f8:	8b 45 b8             	mov    -0x48(%ebp),%eax
801037fb:	89 03                	mov    %eax,(%ebx)
801037fd:	8b 45 bc             	mov    -0x44(%ebp),%eax
80103800:	89 43 04             	mov    %eax,0x4(%ebx)
80103803:	8b 45 c0             	mov    -0x40(%ebp),%eax
80103806:	89 43 08             	mov    %eax,0x8(%ebx)
80103809:	8b 45 c4             	mov    -0x3c(%ebp),%eax
8010380c:	89 43 0c             	mov    %eax,0xc(%ebx)
8010380f:	8b 45 c8             	mov    -0x38(%ebp),%eax
80103812:	89 43 10             	mov    %eax,0x10(%ebx)
80103815:	8b 45 cc             	mov    -0x34(%ebp),%eax
80103818:	89 43 14             	mov    %eax,0x14(%ebx)
  r->year += 2000;
8010381b:	81 43 14 d0 07 00 00 	addl   $0x7d0,0x14(%ebx)
}
80103822:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103825:	5b                   	pop    %ebx
80103826:	5e                   	pop    %esi
80103827:	5f                   	pop    %edi
80103828:	5d                   	pop    %ebp
80103829:	c3                   	ret
8010382a:	66 90                	xchg   %ax,%ax
8010382c:	66 90                	xchg   %ax,%ax
8010382e:	66 90                	xchg   %ax,%ax

80103830 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80103830:	8b 0d 88 29 11 80    	mov    0x80112988,%ecx
80103836:	85 c9                	test   %ecx,%ecx
80103838:	0f 8e 8a 00 00 00    	jle    801038c8 <install_trans+0x98>
{
8010383e:	55                   	push   %ebp
8010383f:	89 e5                	mov    %esp,%ebp
80103841:	57                   	push   %edi
  for (tail = 0; tail < log.lh.n; tail++) {
80103842:	31 ff                	xor    %edi,%edi
{
80103844:	56                   	push   %esi
80103845:	53                   	push   %ebx
80103846:	83 ec 0c             	sub    $0xc,%esp
80103849:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80103850:	a1 74 29 11 80       	mov    0x80112974,%eax
80103855:	83 ec 08             	sub    $0x8,%esp
80103858:	01 f8                	add    %edi,%eax
8010385a:	83 c0 01             	add    $0x1,%eax
8010385d:	50                   	push   %eax
8010385e:	ff 35 84 29 11 80    	push   0x80112984
80103864:	e8 67 c8 ff ff       	call   801000d0 <bread>
80103869:	89 c6                	mov    %eax,%esi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
8010386b:	58                   	pop    %eax
8010386c:	5a                   	pop    %edx
8010386d:	ff 34 bd 8c 29 11 80 	push   -0x7feed674(,%edi,4)
80103874:	ff 35 84 29 11 80    	push   0x80112984
  for (tail = 0; tail < log.lh.n; tail++) {
8010387a:	83 c7 01             	add    $0x1,%edi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
8010387d:	e8 4e c8 ff ff       	call   801000d0 <bread>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80103882:	83 c4 0c             	add    $0xc,%esp
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80103885:	89 c3                	mov    %eax,%ebx
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80103887:	8d 46 5c             	lea    0x5c(%esi),%eax
8010388a:	68 00 02 00 00       	push   $0x200
8010388f:	50                   	push   %eax
80103890:	8d 43 5c             	lea    0x5c(%ebx),%eax
80103893:	50                   	push   %eax
80103894:	e8 27 1b 00 00       	call   801053c0 <memmove>
    bwrite(dbuf);  // write dst to disk
80103899:	89 1c 24             	mov    %ebx,(%esp)
8010389c:	e8 0f c9 ff ff       	call   801001b0 <bwrite>
    brelse(lbuf);
801038a1:	89 34 24             	mov    %esi,(%esp)
801038a4:	e8 47 c9 ff ff       	call   801001f0 <brelse>
    brelse(dbuf);
801038a9:	89 1c 24             	mov    %ebx,(%esp)
801038ac:	e8 3f c9 ff ff       	call   801001f0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801038b1:	83 c4 10             	add    $0x10,%esp
801038b4:	39 3d 88 29 11 80    	cmp    %edi,0x80112988
801038ba:	7f 94                	jg     80103850 <install_trans+0x20>
  }
}
801038bc:	8d 65 f4             	lea    -0xc(%ebp),%esp
801038bf:	5b                   	pop    %ebx
801038c0:	5e                   	pop    %esi
801038c1:	5f                   	pop    %edi
801038c2:	5d                   	pop    %ebp
801038c3:	c3                   	ret
801038c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801038c8:	c3                   	ret
801038c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801038d0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
801038d0:	55                   	push   %ebp
801038d1:	89 e5                	mov    %esp,%ebp
801038d3:	53                   	push   %ebx
801038d4:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
801038d7:	ff 35 74 29 11 80    	push   0x80112974
801038dd:	ff 35 84 29 11 80    	push   0x80112984
801038e3:	e8 e8 c7 ff ff       	call   801000d0 <bread>
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
  for (i = 0; i < log.lh.n; i++) {
801038e8:	83 c4 10             	add    $0x10,%esp
  struct buf *buf = bread(log.dev, log.start);
801038eb:	89 c3                	mov    %eax,%ebx
  hb->n = log.lh.n;
801038ed:	a1 88 29 11 80       	mov    0x80112988,%eax
801038f2:	89 43 5c             	mov    %eax,0x5c(%ebx)
  for (i = 0; i < log.lh.n; i++) {
801038f5:	85 c0                	test   %eax,%eax
801038f7:	7e 19                	jle    80103912 <write_head+0x42>
801038f9:	31 d2                	xor    %edx,%edx
801038fb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    hb->block[i] = log.lh.block[i];
80103900:	8b 0c 95 8c 29 11 80 	mov    -0x7feed674(,%edx,4),%ecx
80103907:	89 4c 93 60          	mov    %ecx,0x60(%ebx,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
8010390b:	83 c2 01             	add    $0x1,%edx
8010390e:	39 d0                	cmp    %edx,%eax
80103910:	75 ee                	jne    80103900 <write_head+0x30>
  }
  bwrite(buf);
80103912:	83 ec 0c             	sub    $0xc,%esp
80103915:	53                   	push   %ebx
80103916:	e8 95 c8 ff ff       	call   801001b0 <bwrite>
  brelse(buf);
8010391b:	89 1c 24             	mov    %ebx,(%esp)
8010391e:	e8 cd c8 ff ff       	call   801001f0 <brelse>
}
80103923:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103926:	83 c4 10             	add    $0x10,%esp
80103929:	c9                   	leave
8010392a:	c3                   	ret
8010392b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103930 <initlog>:
{
80103930:	55                   	push   %ebp
80103931:	89 e5                	mov    %esp,%ebp
80103933:	53                   	push   %ebx
80103934:	83 ec 2c             	sub    $0x2c,%esp
80103937:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
8010393a:	68 c8 7f 10 80       	push   $0x80107fc8
8010393f:	68 40 29 11 80       	push   $0x80112940
80103944:	e8 f7 16 00 00       	call   80105040 <initlock>
  readsb(dev, &sb);
80103949:	58                   	pop    %eax
8010394a:	8d 45 dc             	lea    -0x24(%ebp),%eax
8010394d:	5a                   	pop    %edx
8010394e:	50                   	push   %eax
8010394f:	53                   	push   %ebx
80103950:	e8 7b e8 ff ff       	call   801021d0 <readsb>
  log.start = sb.logstart;
80103955:	8b 45 ec             	mov    -0x14(%ebp),%eax
  struct buf *buf = bread(log.dev, log.start);
80103958:	59                   	pop    %ecx
  log.dev = dev;
80103959:	89 1d 84 29 11 80    	mov    %ebx,0x80112984
  log.size = sb.nlog;
8010395f:	8b 55 e8             	mov    -0x18(%ebp),%edx
  log.start = sb.logstart;
80103962:	a3 74 29 11 80       	mov    %eax,0x80112974
  log.size = sb.nlog;
80103967:	89 15 78 29 11 80    	mov    %edx,0x80112978
  struct buf *buf = bread(log.dev, log.start);
8010396d:	5a                   	pop    %edx
8010396e:	50                   	push   %eax
8010396f:	53                   	push   %ebx
80103970:	e8 5b c7 ff ff       	call   801000d0 <bread>
  for (i = 0; i < log.lh.n; i++) {
80103975:	83 c4 10             	add    $0x10,%esp
  log.lh.n = lh->n;
80103978:	8b 58 5c             	mov    0x5c(%eax),%ebx
8010397b:	89 1d 88 29 11 80    	mov    %ebx,0x80112988
  for (i = 0; i < log.lh.n; i++) {
80103981:	85 db                	test   %ebx,%ebx
80103983:	7e 1d                	jle    801039a2 <initlog+0x72>
80103985:	31 d2                	xor    %edx,%edx
80103987:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010398e:	00 
8010398f:	90                   	nop
    log.lh.block[i] = lh->block[i];
80103990:	8b 4c 90 60          	mov    0x60(%eax,%edx,4),%ecx
80103994:	89 0c 95 8c 29 11 80 	mov    %ecx,-0x7feed674(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
8010399b:	83 c2 01             	add    $0x1,%edx
8010399e:	39 d3                	cmp    %edx,%ebx
801039a0:	75 ee                	jne    80103990 <initlog+0x60>
  brelse(buf);
801039a2:	83 ec 0c             	sub    $0xc,%esp
801039a5:	50                   	push   %eax
801039a6:	e8 45 c8 ff ff       	call   801001f0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
801039ab:	e8 80 fe ff ff       	call   80103830 <install_trans>
  log.lh.n = 0;
801039b0:	c7 05 88 29 11 80 00 	movl   $0x0,0x80112988
801039b7:	00 00 00 
  write_head(); // clear the log
801039ba:	e8 11 ff ff ff       	call   801038d0 <write_head>
}
801039bf:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801039c2:	83 c4 10             	add    $0x10,%esp
801039c5:	c9                   	leave
801039c6:	c3                   	ret
801039c7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801039ce:	00 
801039cf:	90                   	nop

801039d0 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
801039d0:	55                   	push   %ebp
801039d1:	89 e5                	mov    %esp,%ebp
801039d3:	83 ec 14             	sub    $0x14,%esp
  acquire(&log.lock);
801039d6:	68 40 29 11 80       	push   $0x80112940
801039db:	e8 50 18 00 00       	call   80105230 <acquire>
801039e0:	83 c4 10             	add    $0x10,%esp
801039e3:	eb 18                	jmp    801039fd <begin_op+0x2d>
801039e5:	8d 76 00             	lea    0x0(%esi),%esi
  while(1){
    if(log.committing){
      sleep(&log, &log.lock);
801039e8:	83 ec 08             	sub    $0x8,%esp
801039eb:	68 40 29 11 80       	push   $0x80112940
801039f0:	68 40 29 11 80       	push   $0x80112940
801039f5:	e8 b6 12 00 00       	call   80104cb0 <sleep>
801039fa:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
801039fd:	a1 80 29 11 80       	mov    0x80112980,%eax
80103a02:	85 c0                	test   %eax,%eax
80103a04:	75 e2                	jne    801039e8 <begin_op+0x18>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80103a06:	a1 7c 29 11 80       	mov    0x8011297c,%eax
80103a0b:	8b 15 88 29 11 80    	mov    0x80112988,%edx
80103a11:	83 c0 01             	add    $0x1,%eax
80103a14:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
80103a17:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
80103a1a:	83 fa 1e             	cmp    $0x1e,%edx
80103a1d:	7f c9                	jg     801039e8 <begin_op+0x18>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
80103a1f:	83 ec 0c             	sub    $0xc,%esp
      log.outstanding += 1;
80103a22:	a3 7c 29 11 80       	mov    %eax,0x8011297c
      release(&log.lock);
80103a27:	68 40 29 11 80       	push   $0x80112940
80103a2c:	e8 9f 17 00 00       	call   801051d0 <release>
      break;
    }
  }
}
80103a31:	83 c4 10             	add    $0x10,%esp
80103a34:	c9                   	leave
80103a35:	c3                   	ret
80103a36:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103a3d:	00 
80103a3e:	66 90                	xchg   %ax,%ax

80103a40 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80103a40:	55                   	push   %ebp
80103a41:	89 e5                	mov    %esp,%ebp
80103a43:	57                   	push   %edi
80103a44:	56                   	push   %esi
80103a45:	53                   	push   %ebx
80103a46:	83 ec 18             	sub    $0x18,%esp
  int do_commit = 0;

  acquire(&log.lock);
80103a49:	68 40 29 11 80       	push   $0x80112940
80103a4e:	e8 dd 17 00 00       	call   80105230 <acquire>
  log.outstanding -= 1;
80103a53:	a1 7c 29 11 80       	mov    0x8011297c,%eax
  if(log.committing)
80103a58:	8b 35 80 29 11 80    	mov    0x80112980,%esi
80103a5e:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
80103a61:	8d 58 ff             	lea    -0x1(%eax),%ebx
80103a64:	89 1d 7c 29 11 80    	mov    %ebx,0x8011297c
  if(log.committing)
80103a6a:	85 f6                	test   %esi,%esi
80103a6c:	0f 85 22 01 00 00    	jne    80103b94 <end_op+0x154>
    panic("log.committing");
  if(log.outstanding == 0){
80103a72:	85 db                	test   %ebx,%ebx
80103a74:	0f 85 f6 00 00 00    	jne    80103b70 <end_op+0x130>
    do_commit = 1;
    log.committing = 1;
80103a7a:	c7 05 80 29 11 80 01 	movl   $0x1,0x80112980
80103a81:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
80103a84:	83 ec 0c             	sub    $0xc,%esp
80103a87:	68 40 29 11 80       	push   $0x80112940
80103a8c:	e8 3f 17 00 00       	call   801051d0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80103a91:	8b 0d 88 29 11 80    	mov    0x80112988,%ecx
80103a97:	83 c4 10             	add    $0x10,%esp
80103a9a:	85 c9                	test   %ecx,%ecx
80103a9c:	7f 42                	jg     80103ae0 <end_op+0xa0>
    acquire(&log.lock);
80103a9e:	83 ec 0c             	sub    $0xc,%esp
80103aa1:	68 40 29 11 80       	push   $0x80112940
80103aa6:	e8 85 17 00 00       	call   80105230 <acquire>
    log.committing = 0;
80103aab:	c7 05 80 29 11 80 00 	movl   $0x0,0x80112980
80103ab2:	00 00 00 
    wakeup(&log);
80103ab5:	c7 04 24 40 29 11 80 	movl   $0x80112940,(%esp)
80103abc:	e8 af 12 00 00       	call   80104d70 <wakeup>
    release(&log.lock);
80103ac1:	c7 04 24 40 29 11 80 	movl   $0x80112940,(%esp)
80103ac8:	e8 03 17 00 00       	call   801051d0 <release>
80103acd:	83 c4 10             	add    $0x10,%esp
}
80103ad0:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103ad3:	5b                   	pop    %ebx
80103ad4:	5e                   	pop    %esi
80103ad5:	5f                   	pop    %edi
80103ad6:	5d                   	pop    %ebp
80103ad7:	c3                   	ret
80103ad8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103adf:	00 
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80103ae0:	a1 74 29 11 80       	mov    0x80112974,%eax
80103ae5:	83 ec 08             	sub    $0x8,%esp
80103ae8:	01 d8                	add    %ebx,%eax
80103aea:	83 c0 01             	add    $0x1,%eax
80103aed:	50                   	push   %eax
80103aee:	ff 35 84 29 11 80    	push   0x80112984
80103af4:	e8 d7 c5 ff ff       	call   801000d0 <bread>
80103af9:	89 c6                	mov    %eax,%esi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80103afb:	58                   	pop    %eax
80103afc:	5a                   	pop    %edx
80103afd:	ff 34 9d 8c 29 11 80 	push   -0x7feed674(,%ebx,4)
80103b04:	ff 35 84 29 11 80    	push   0x80112984
  for (tail = 0; tail < log.lh.n; tail++) {
80103b0a:	83 c3 01             	add    $0x1,%ebx
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80103b0d:	e8 be c5 ff ff       	call   801000d0 <bread>
    memmove(to->data, from->data, BSIZE);
80103b12:	83 c4 0c             	add    $0xc,%esp
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80103b15:	89 c7                	mov    %eax,%edi
    memmove(to->data, from->data, BSIZE);
80103b17:	8d 40 5c             	lea    0x5c(%eax),%eax
80103b1a:	68 00 02 00 00       	push   $0x200
80103b1f:	50                   	push   %eax
80103b20:	8d 46 5c             	lea    0x5c(%esi),%eax
80103b23:	50                   	push   %eax
80103b24:	e8 97 18 00 00       	call   801053c0 <memmove>
    bwrite(to);  // write the log
80103b29:	89 34 24             	mov    %esi,(%esp)
80103b2c:	e8 7f c6 ff ff       	call   801001b0 <bwrite>
    brelse(from);
80103b31:	89 3c 24             	mov    %edi,(%esp)
80103b34:	e8 b7 c6 ff ff       	call   801001f0 <brelse>
    brelse(to);
80103b39:	89 34 24             	mov    %esi,(%esp)
80103b3c:	e8 af c6 ff ff       	call   801001f0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80103b41:	83 c4 10             	add    $0x10,%esp
80103b44:	3b 1d 88 29 11 80    	cmp    0x80112988,%ebx
80103b4a:	7c 94                	jl     80103ae0 <end_op+0xa0>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
80103b4c:	e8 7f fd ff ff       	call   801038d0 <write_head>
    install_trans(); // Now install writes to home locations
80103b51:	e8 da fc ff ff       	call   80103830 <install_trans>
    log.lh.n = 0;
80103b56:	c7 05 88 29 11 80 00 	movl   $0x0,0x80112988
80103b5d:	00 00 00 
    write_head();    // Erase the transaction from the log
80103b60:	e8 6b fd ff ff       	call   801038d0 <write_head>
80103b65:	e9 34 ff ff ff       	jmp    80103a9e <end_op+0x5e>
80103b6a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    wakeup(&log);
80103b70:	83 ec 0c             	sub    $0xc,%esp
80103b73:	68 40 29 11 80       	push   $0x80112940
80103b78:	e8 f3 11 00 00       	call   80104d70 <wakeup>
  release(&log.lock);
80103b7d:	c7 04 24 40 29 11 80 	movl   $0x80112940,(%esp)
80103b84:	e8 47 16 00 00       	call   801051d0 <release>
80103b89:	83 c4 10             	add    $0x10,%esp
}
80103b8c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103b8f:	5b                   	pop    %ebx
80103b90:	5e                   	pop    %esi
80103b91:	5f                   	pop    %edi
80103b92:	5d                   	pop    %ebp
80103b93:	c3                   	ret
    panic("log.committing");
80103b94:	83 ec 0c             	sub    $0xc,%esp
80103b97:	68 cc 7f 10 80       	push   $0x80107fcc
80103b9c:	e8 df c7 ff ff       	call   80100380 <panic>
80103ba1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103ba8:	00 
80103ba9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80103bb0 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
80103bb0:	55                   	push   %ebp
80103bb1:	89 e5                	mov    %esp,%ebp
80103bb3:	53                   	push   %ebx
80103bb4:	83 ec 04             	sub    $0x4,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103bb7:	8b 15 88 29 11 80    	mov    0x80112988,%edx
{
80103bbd:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80103bc0:	83 fa 1d             	cmp    $0x1d,%edx
80103bc3:	7f 7d                	jg     80103c42 <log_write+0x92>
80103bc5:	a1 78 29 11 80       	mov    0x80112978,%eax
80103bca:	83 e8 01             	sub    $0x1,%eax
80103bcd:	39 c2                	cmp    %eax,%edx
80103bcf:	7d 71                	jge    80103c42 <log_write+0x92>
    panic("too big a transaction");
  if (log.outstanding < 1)
80103bd1:	a1 7c 29 11 80       	mov    0x8011297c,%eax
80103bd6:	85 c0                	test   %eax,%eax
80103bd8:	7e 75                	jle    80103c4f <log_write+0x9f>
    panic("log_write outside of trans");

  acquire(&log.lock);
80103bda:	83 ec 0c             	sub    $0xc,%esp
80103bdd:	68 40 29 11 80       	push   $0x80112940
80103be2:	e8 49 16 00 00       	call   80105230 <acquire>
  for (i = 0; i < log.lh.n; i++) {
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103be7:	8b 4b 08             	mov    0x8(%ebx),%ecx
  for (i = 0; i < log.lh.n; i++) {
80103bea:	83 c4 10             	add    $0x10,%esp
80103bed:	31 c0                	xor    %eax,%eax
80103bef:	8b 15 88 29 11 80    	mov    0x80112988,%edx
80103bf5:	85 d2                	test   %edx,%edx
80103bf7:	7f 0e                	jg     80103c07 <log_write+0x57>
80103bf9:	eb 15                	jmp    80103c10 <log_write+0x60>
80103bfb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103c00:	83 c0 01             	add    $0x1,%eax
80103c03:	39 c2                	cmp    %eax,%edx
80103c05:	74 29                	je     80103c30 <log_write+0x80>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80103c07:	39 0c 85 8c 29 11 80 	cmp    %ecx,-0x7feed674(,%eax,4)
80103c0e:	75 f0                	jne    80103c00 <log_write+0x50>
      break;
  }
  log.lh.block[i] = b->blockno;
80103c10:	89 0c 85 8c 29 11 80 	mov    %ecx,-0x7feed674(,%eax,4)
  if (i == log.lh.n)
80103c17:	39 c2                	cmp    %eax,%edx
80103c19:	74 1c                	je     80103c37 <log_write+0x87>
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
80103c1b:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
}
80103c1e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  release(&log.lock);
80103c21:	c7 45 08 40 29 11 80 	movl   $0x80112940,0x8(%ebp)
}
80103c28:	c9                   	leave
  release(&log.lock);
80103c29:	e9 a2 15 00 00       	jmp    801051d0 <release>
80103c2e:	66 90                	xchg   %ax,%ax
  log.lh.block[i] = b->blockno;
80103c30:	89 0c 95 8c 29 11 80 	mov    %ecx,-0x7feed674(,%edx,4)
    log.lh.n++;
80103c37:	83 c2 01             	add    $0x1,%edx
80103c3a:	89 15 88 29 11 80    	mov    %edx,0x80112988
80103c40:	eb d9                	jmp    80103c1b <log_write+0x6b>
    panic("too big a transaction");
80103c42:	83 ec 0c             	sub    $0xc,%esp
80103c45:	68 db 7f 10 80       	push   $0x80107fdb
80103c4a:	e8 31 c7 ff ff       	call   80100380 <panic>
    panic("log_write outside of trans");
80103c4f:	83 ec 0c             	sub    $0xc,%esp
80103c52:	68 f1 7f 10 80       	push   $0x80107ff1
80103c57:	e8 24 c7 ff ff       	call   80100380 <panic>
80103c5c:	66 90                	xchg   %ax,%ax
80103c5e:	66 90                	xchg   %ax,%ax

80103c60 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
80103c60:	55                   	push   %ebp
80103c61:	89 e5                	mov    %esp,%ebp
80103c63:	53                   	push   %ebx
80103c64:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
80103c67:	e8 64 09 00 00       	call   801045d0 <cpuid>
80103c6c:	89 c3                	mov    %eax,%ebx
80103c6e:	e8 5d 09 00 00       	call   801045d0 <cpuid>
80103c73:	83 ec 04             	sub    $0x4,%esp
80103c76:	53                   	push   %ebx
80103c77:	50                   	push   %eax
80103c78:	68 0c 80 10 80       	push   $0x8010800c
80103c7d:	e8 5e d0 ff ff       	call   80100ce0 <cprintf>
  idtinit();       // load idt register
80103c82:	e8 e9 28 00 00       	call   80106570 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
80103c87:	e8 e4 08 00 00       	call   80104570 <mycpu>
80103c8c:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
80103c8e:	b8 01 00 00 00       	mov    $0x1,%eax
80103c93:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
80103c9a:	e8 01 0c 00 00       	call   801048a0 <scheduler>
80103c9f:	90                   	nop

80103ca0 <mpenter>:
{
80103ca0:	55                   	push   %ebp
80103ca1:	89 e5                	mov    %esp,%ebp
80103ca3:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80103ca6:	e8 c5 39 00 00       	call   80107670 <switchkvm>
  seginit();
80103cab:	e8 30 39 00 00       	call   801075e0 <seginit>
  lapicinit();
80103cb0:	e8 bb f7 ff ff       	call   80103470 <lapicinit>
  mpmain();
80103cb5:	e8 a6 ff ff ff       	call   80103c60 <mpmain>
80103cba:	66 90                	xchg   %ax,%ax
80103cbc:	66 90                	xchg   %ax,%ax
80103cbe:	66 90                	xchg   %ax,%ax

80103cc0 <main>:
{
80103cc0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80103cc4:	83 e4 f0             	and    $0xfffffff0,%esp
80103cc7:	ff 71 fc             	push   -0x4(%ecx)
80103cca:	55                   	push   %ebp
80103ccb:	89 e5                	mov    %esp,%ebp
80103ccd:	53                   	push   %ebx
80103cce:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
80103ccf:	83 ec 08             	sub    $0x8,%esp
80103cd2:	68 00 00 40 80       	push   $0x80400000
80103cd7:	68 70 67 11 80       	push   $0x80116770
80103cdc:	e8 9f f5 ff ff       	call   80103280 <kinit1>
  kvmalloc();      // kernel page table
80103ce1:	e8 4a 3e 00 00       	call   80107b30 <kvmalloc>
  mpinit();        // detect other processors
80103ce6:	e8 85 01 00 00       	call   80103e70 <mpinit>
  lapicinit();     // interrupt controller
80103ceb:	e8 80 f7 ff ff       	call   80103470 <lapicinit>
  seginit();       // segment descriptors
80103cf0:	e8 eb 38 00 00       	call   801075e0 <seginit>
  picinit();       // disable pic
80103cf5:	e8 86 03 00 00       	call   80104080 <picinit>
  ioapicinit();    // another interrupt controller
80103cfa:	e8 51 f3 ff ff       	call   80103050 <ioapicinit>
  consoleinit();   // console hardware
80103cff:	e8 9c d9 ff ff       	call   801016a0 <consoleinit>
  uartinit();      // serial port
80103d04:	e8 47 2b 00 00       	call   80106850 <uartinit>
  pinit();         // process table
80103d09:	e8 42 08 00 00       	call   80104550 <pinit>
  tvinit();        // trap vectors
80103d0e:	e8 dd 27 00 00       	call   801064f0 <tvinit>
  binit();         // buffer cache
80103d13:	e8 28 c3 ff ff       	call   80100040 <binit>
  fileinit();      // file table
80103d18:	e8 a3 dd ff ff       	call   80101ac0 <fileinit>
  ideinit();       // disk 
80103d1d:	e8 0e f1 ff ff       	call   80102e30 <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80103d22:	83 c4 0c             	add    $0xc,%esp
80103d25:	68 8a 00 00 00       	push   $0x8a
80103d2a:	68 8c b4 10 80       	push   $0x8010b48c
80103d2f:	68 00 70 00 80       	push   $0x80007000
80103d34:	e8 87 16 00 00       	call   801053c0 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
80103d39:	83 c4 10             	add    $0x10,%esp
80103d3c:	69 05 24 2a 11 80 b0 	imul   $0xb0,0x80112a24,%eax
80103d43:	00 00 00 
80103d46:	05 40 2a 11 80       	add    $0x80112a40,%eax
80103d4b:	3d 40 2a 11 80       	cmp    $0x80112a40,%eax
80103d50:	76 7e                	jbe    80103dd0 <main+0x110>
80103d52:	bb 40 2a 11 80       	mov    $0x80112a40,%ebx
80103d57:	eb 20                	jmp    80103d79 <main+0xb9>
80103d59:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103d60:	69 05 24 2a 11 80 b0 	imul   $0xb0,0x80112a24,%eax
80103d67:	00 00 00 
80103d6a:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80103d70:	05 40 2a 11 80       	add    $0x80112a40,%eax
80103d75:	39 c3                	cmp    %eax,%ebx
80103d77:	73 57                	jae    80103dd0 <main+0x110>
    if(c == mycpu())  // We've started already.
80103d79:	e8 f2 07 00 00       	call   80104570 <mycpu>
80103d7e:	39 c3                	cmp    %eax,%ebx
80103d80:	74 de                	je     80103d60 <main+0xa0>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80103d82:	e8 69 f5 ff ff       	call   801032f0 <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
    *(void(**)(void))(code-8) = mpenter;
    *(int**)(code-12) = (void *) V2P(entrypgdir);

    lapicstartap(c->apicid, V2P(code));
80103d87:	83 ec 08             	sub    $0x8,%esp
    *(void(**)(void))(code-8) = mpenter;
80103d8a:	c7 05 f8 6f 00 80 a0 	movl   $0x80103ca0,0x80006ff8
80103d91:	3c 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80103d94:	c7 05 f4 6f 00 80 00 	movl   $0x10a000,0x80006ff4
80103d9b:	a0 10 00 
    *(void**)(code-4) = stack + KSTACKSIZE;
80103d9e:	05 00 10 00 00       	add    $0x1000,%eax
80103da3:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    lapicstartap(c->apicid, V2P(code));
80103da8:	0f b6 03             	movzbl (%ebx),%eax
80103dab:	68 00 70 00 00       	push   $0x7000
80103db0:	50                   	push   %eax
80103db1:	e8 fa f7 ff ff       	call   801035b0 <lapicstartap>

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80103db6:	83 c4 10             	add    $0x10,%esp
80103db9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80103dc0:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80103dc6:	85 c0                	test   %eax,%eax
80103dc8:	74 f6                	je     80103dc0 <main+0x100>
80103dca:	eb 94                	jmp    80103d60 <main+0xa0>
80103dcc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80103dd0:	83 ec 08             	sub    $0x8,%esp
80103dd3:	68 00 00 00 8e       	push   $0x8e000000
80103dd8:	68 00 00 40 80       	push   $0x80400000
80103ddd:	e8 3e f4 ff ff       	call   80103220 <kinit2>
  userinit();      // first user process
80103de2:	e8 39 08 00 00       	call   80104620 <userinit>
  mpmain();        // finish this processor's setup
80103de7:	e8 74 fe ff ff       	call   80103c60 <mpmain>
80103dec:	66 90                	xchg   %ax,%ax
80103dee:	66 90                	xchg   %ax,%ax

80103df0 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80103df0:	55                   	push   %ebp
80103df1:	89 e5                	mov    %esp,%ebp
80103df3:	57                   	push   %edi
80103df4:	56                   	push   %esi
  uchar *e, *p, *addr;

  addr = P2V(a);
80103df5:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
{
80103dfb:	53                   	push   %ebx
  e = addr+len;
80103dfc:	8d 1c 16             	lea    (%esi,%edx,1),%ebx
{
80103dff:	83 ec 0c             	sub    $0xc,%esp
  for(p = addr; p < e; p += sizeof(struct mp))
80103e02:	39 de                	cmp    %ebx,%esi
80103e04:	72 10                	jb     80103e16 <mpsearch1+0x26>
80103e06:	eb 50                	jmp    80103e58 <mpsearch1+0x68>
80103e08:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103e0f:	00 
80103e10:	89 fe                	mov    %edi,%esi
80103e12:	39 df                	cmp    %ebx,%edi
80103e14:	73 42                	jae    80103e58 <mpsearch1+0x68>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103e16:	83 ec 04             	sub    $0x4,%esp
80103e19:	8d 7e 10             	lea    0x10(%esi),%edi
80103e1c:	6a 04                	push   $0x4
80103e1e:	68 20 80 10 80       	push   $0x80108020
80103e23:	56                   	push   %esi
80103e24:	e8 47 15 00 00       	call   80105370 <memcmp>
80103e29:	83 c4 10             	add    $0x10,%esp
80103e2c:	85 c0                	test   %eax,%eax
80103e2e:	75 e0                	jne    80103e10 <mpsearch1+0x20>
80103e30:	89 f2                	mov    %esi,%edx
80103e32:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    sum += addr[i];
80103e38:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
80103e3b:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
80103e3e:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
80103e40:	39 fa                	cmp    %edi,%edx
80103e42:	75 f4                	jne    80103e38 <mpsearch1+0x48>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103e44:	84 c0                	test   %al,%al
80103e46:	75 c8                	jne    80103e10 <mpsearch1+0x20>
      return (struct mp*)p;
  return 0;
}
80103e48:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103e4b:	89 f0                	mov    %esi,%eax
80103e4d:	5b                   	pop    %ebx
80103e4e:	5e                   	pop    %esi
80103e4f:	5f                   	pop    %edi
80103e50:	5d                   	pop    %ebp
80103e51:	c3                   	ret
80103e52:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80103e58:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80103e5b:	31 f6                	xor    %esi,%esi
}
80103e5d:	5b                   	pop    %ebx
80103e5e:	89 f0                	mov    %esi,%eax
80103e60:	5e                   	pop    %esi
80103e61:	5f                   	pop    %edi
80103e62:	5d                   	pop    %ebp
80103e63:	c3                   	ret
80103e64:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103e6b:	00 
80103e6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80103e70 <mpinit>:
  return conf;
}

void
mpinit(void)
{
80103e70:	55                   	push   %ebp
80103e71:	89 e5                	mov    %esp,%ebp
80103e73:	57                   	push   %edi
80103e74:	56                   	push   %esi
80103e75:	53                   	push   %ebx
80103e76:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80103e79:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80103e80:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80103e87:	c1 e0 08             	shl    $0x8,%eax
80103e8a:	09 d0                	or     %edx,%eax
80103e8c:	c1 e0 04             	shl    $0x4,%eax
80103e8f:	75 1b                	jne    80103eac <mpinit+0x3c>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80103e91:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80103e98:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
80103e9f:	c1 e0 08             	shl    $0x8,%eax
80103ea2:	09 d0                	or     %edx,%eax
80103ea4:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80103ea7:	2d 00 04 00 00       	sub    $0x400,%eax
    if((mp = mpsearch1(p, 1024)))
80103eac:	ba 00 04 00 00       	mov    $0x400,%edx
80103eb1:	e8 3a ff ff ff       	call   80103df0 <mpsearch1>
80103eb6:	89 c3                	mov    %eax,%ebx
80103eb8:	85 c0                	test   %eax,%eax
80103eba:	0f 84 58 01 00 00    	je     80104018 <mpinit+0x1a8>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80103ec0:	8b 73 04             	mov    0x4(%ebx),%esi
80103ec3:	85 f6                	test   %esi,%esi
80103ec5:	0f 84 3d 01 00 00    	je     80104008 <mpinit+0x198>
  if(memcmp(conf, "PCMP", 4) != 0)
80103ecb:	83 ec 04             	sub    $0x4,%esp
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80103ece:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
80103ed4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
80103ed7:	6a 04                	push   $0x4
80103ed9:	68 25 80 10 80       	push   $0x80108025
80103ede:	50                   	push   %eax
80103edf:	e8 8c 14 00 00       	call   80105370 <memcmp>
80103ee4:	83 c4 10             	add    $0x10,%esp
80103ee7:	85 c0                	test   %eax,%eax
80103ee9:	0f 85 19 01 00 00    	jne    80104008 <mpinit+0x198>
  if(conf->version != 1 && conf->version != 4)
80103eef:	0f b6 86 06 00 00 80 	movzbl -0x7ffffffa(%esi),%eax
80103ef6:	3c 01                	cmp    $0x1,%al
80103ef8:	74 08                	je     80103f02 <mpinit+0x92>
80103efa:	3c 04                	cmp    $0x4,%al
80103efc:	0f 85 06 01 00 00    	jne    80104008 <mpinit+0x198>
  if(sum((uchar*)conf, conf->length) != 0)
80103f02:	0f b7 96 04 00 00 80 	movzwl -0x7ffffffc(%esi),%edx
  for(i=0; i<len; i++)
80103f09:	66 85 d2             	test   %dx,%dx
80103f0c:	74 22                	je     80103f30 <mpinit+0xc0>
80103f0e:	8d 3c 32             	lea    (%edx,%esi,1),%edi
80103f11:	89 f0                	mov    %esi,%eax
  sum = 0;
80103f13:	31 d2                	xor    %edx,%edx
80103f15:	8d 76 00             	lea    0x0(%esi),%esi
    sum += addr[i];
80103f18:	0f b6 88 00 00 00 80 	movzbl -0x80000000(%eax),%ecx
  for(i=0; i<len; i++)
80103f1f:	83 c0 01             	add    $0x1,%eax
    sum += addr[i];
80103f22:	01 ca                	add    %ecx,%edx
  for(i=0; i<len; i++)
80103f24:	39 f8                	cmp    %edi,%eax
80103f26:	75 f0                	jne    80103f18 <mpinit+0xa8>
  if(sum((uchar*)conf, conf->length) != 0)
80103f28:	84 d2                	test   %dl,%dl
80103f2a:	0f 85 d8 00 00 00    	jne    80104008 <mpinit+0x198>
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
80103f30:	8b 86 24 00 00 80    	mov    -0x7fffffdc(%esi),%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103f36:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80103f39:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
  lapic = (uint*)conf->lapicaddr;
80103f3c:	a3 20 29 11 80       	mov    %eax,0x80112920
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103f41:	0f b7 96 04 00 00 80 	movzwl -0x7ffffffc(%esi),%edx
80103f48:	8d 86 2c 00 00 80    	lea    -0x7fffffd4(%esi),%eax
80103f4e:	01 d7                	add    %edx,%edi
80103f50:	89 fa                	mov    %edi,%edx
  ismp = 1;
80103f52:	bf 01 00 00 00       	mov    $0x1,%edi
80103f57:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103f5e:	00 
80103f5f:	90                   	nop
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103f60:	39 d0                	cmp    %edx,%eax
80103f62:	73 19                	jae    80103f7d <mpinit+0x10d>
    switch(*p){
80103f64:	0f b6 08             	movzbl (%eax),%ecx
80103f67:	80 f9 02             	cmp    $0x2,%cl
80103f6a:	0f 84 80 00 00 00    	je     80103ff0 <mpinit+0x180>
80103f70:	77 6e                	ja     80103fe0 <mpinit+0x170>
80103f72:	84 c9                	test   %cl,%cl
80103f74:	74 3a                	je     80103fb0 <mpinit+0x140>
      p += sizeof(struct mpioapic);
      continue;
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
80103f76:	83 c0 08             	add    $0x8,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103f79:	39 d0                	cmp    %edx,%eax
80103f7b:	72 e7                	jb     80103f64 <mpinit+0xf4>
    default:
      ismp = 0;
      break;
    }
  }
  if(!ismp)
80103f7d:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103f80:	85 ff                	test   %edi,%edi
80103f82:	0f 84 dd 00 00 00    	je     80104065 <mpinit+0x1f5>
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
80103f88:	80 7b 0c 00          	cmpb   $0x0,0xc(%ebx)
80103f8c:	74 15                	je     80103fa3 <mpinit+0x133>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103f8e:	b8 70 00 00 00       	mov    $0x70,%eax
80103f93:	ba 22 00 00 00       	mov    $0x22,%edx
80103f98:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103f99:	ba 23 00 00 00       	mov    $0x23,%edx
80103f9e:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
80103f9f:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103fa2:	ee                   	out    %al,(%dx)
  }
}
80103fa3:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103fa6:	5b                   	pop    %ebx
80103fa7:	5e                   	pop    %esi
80103fa8:	5f                   	pop    %edi
80103fa9:	5d                   	pop    %ebp
80103faa:	c3                   	ret
80103fab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(ncpu < NCPU) {
80103fb0:	8b 0d 24 2a 11 80    	mov    0x80112a24,%ecx
80103fb6:	83 f9 07             	cmp    $0x7,%ecx
80103fb9:	7f 19                	jg     80103fd4 <mpinit+0x164>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103fbb:	69 f1 b0 00 00 00    	imul   $0xb0,%ecx,%esi
80103fc1:	0f b6 58 01          	movzbl 0x1(%eax),%ebx
        ncpu++;
80103fc5:	83 c1 01             	add    $0x1,%ecx
80103fc8:	89 0d 24 2a 11 80    	mov    %ecx,0x80112a24
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80103fce:	88 9e 40 2a 11 80    	mov    %bl,-0x7feed5c0(%esi)
      p += sizeof(struct mpproc);
80103fd4:	83 c0 14             	add    $0x14,%eax
      continue;
80103fd7:	eb 87                	jmp    80103f60 <mpinit+0xf0>
80103fd9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    switch(*p){
80103fe0:	83 e9 03             	sub    $0x3,%ecx
80103fe3:	80 f9 01             	cmp    $0x1,%cl
80103fe6:	76 8e                	jbe    80103f76 <mpinit+0x106>
80103fe8:	31 ff                	xor    %edi,%edi
80103fea:	e9 71 ff ff ff       	jmp    80103f60 <mpinit+0xf0>
80103fef:	90                   	nop
      ioapicid = ioapic->apicno;
80103ff0:	0f b6 48 01          	movzbl 0x1(%eax),%ecx
      p += sizeof(struct mpioapic);
80103ff4:	83 c0 08             	add    $0x8,%eax
      ioapicid = ioapic->apicno;
80103ff7:	88 0d 20 2a 11 80    	mov    %cl,0x80112a20
      continue;
80103ffd:	e9 5e ff ff ff       	jmp    80103f60 <mpinit+0xf0>
80104002:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    panic("Expect to run on an SMP");
80104008:	83 ec 0c             	sub    $0xc,%esp
8010400b:	68 2a 80 10 80       	push   $0x8010802a
80104010:	e8 6b c3 ff ff       	call   80100380 <panic>
80104015:	8d 76 00             	lea    0x0(%esi),%esi
{
80104018:	bb 00 00 0f 80       	mov    $0x800f0000,%ebx
8010401d:	eb 0b                	jmp    8010402a <mpinit+0x1ba>
8010401f:	90                   	nop
  for(p = addr; p < e; p += sizeof(struct mp))
80104020:	89 f3                	mov    %esi,%ebx
80104022:	81 fe 00 00 10 80    	cmp    $0x80100000,%esi
80104028:	74 de                	je     80104008 <mpinit+0x198>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
8010402a:	83 ec 04             	sub    $0x4,%esp
8010402d:	8d 73 10             	lea    0x10(%ebx),%esi
80104030:	6a 04                	push   $0x4
80104032:	68 20 80 10 80       	push   $0x80108020
80104037:	53                   	push   %ebx
80104038:	e8 33 13 00 00       	call   80105370 <memcmp>
8010403d:	83 c4 10             	add    $0x10,%esp
80104040:	85 c0                	test   %eax,%eax
80104042:	75 dc                	jne    80104020 <mpinit+0x1b0>
80104044:	89 da                	mov    %ebx,%edx
80104046:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010404d:	00 
8010404e:	66 90                	xchg   %ax,%ax
    sum += addr[i];
80104050:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
80104053:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
80104056:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
80104058:	39 d6                	cmp    %edx,%esi
8010405a:	75 f4                	jne    80104050 <mpinit+0x1e0>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
8010405c:	84 c0                	test   %al,%al
8010405e:	75 c0                	jne    80104020 <mpinit+0x1b0>
80104060:	e9 5b fe ff ff       	jmp    80103ec0 <mpinit+0x50>
    panic("Didn't find a suitable machine");
80104065:	83 ec 0c             	sub    $0xc,%esp
80104068:	68 4c 84 10 80       	push   $0x8010844c
8010406d:	e8 0e c3 ff ff       	call   80100380 <panic>
80104072:	66 90                	xchg   %ax,%ax
80104074:	66 90                	xchg   %ax,%ax
80104076:	66 90                	xchg   %ax,%ax
80104078:	66 90                	xchg   %ax,%ax
8010407a:	66 90                	xchg   %ax,%ax
8010407c:	66 90                	xchg   %ax,%ax
8010407e:	66 90                	xchg   %ax,%ax

80104080 <picinit>:
80104080:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104085:	ba 21 00 00 00       	mov    $0x21,%edx
8010408a:	ee                   	out    %al,(%dx)
8010408b:	ba a1 00 00 00       	mov    $0xa1,%edx
80104090:	ee                   	out    %al,(%dx)
picinit(void)
{
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80104091:	c3                   	ret
80104092:	66 90                	xchg   %ax,%ax
80104094:	66 90                	xchg   %ax,%ax
80104096:	66 90                	xchg   %ax,%ax
80104098:	66 90                	xchg   %ax,%ax
8010409a:	66 90                	xchg   %ax,%ax
8010409c:	66 90                	xchg   %ax,%ax
8010409e:	66 90                	xchg   %ax,%ax

801040a0 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
801040a0:	55                   	push   %ebp
801040a1:	89 e5                	mov    %esp,%ebp
801040a3:	57                   	push   %edi
801040a4:	56                   	push   %esi
801040a5:	53                   	push   %ebx
801040a6:	83 ec 0c             	sub    $0xc,%esp
801040a9:	8b 75 08             	mov    0x8(%ebp),%esi
801040ac:	8b 7d 0c             	mov    0xc(%ebp),%edi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
801040af:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
801040b5:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
801040bb:	e8 20 da ff ff       	call   80101ae0 <filealloc>
801040c0:	89 06                	mov    %eax,(%esi)
801040c2:	85 c0                	test   %eax,%eax
801040c4:	0f 84 a5 00 00 00    	je     8010416f <pipealloc+0xcf>
801040ca:	e8 11 da ff ff       	call   80101ae0 <filealloc>
801040cf:	89 07                	mov    %eax,(%edi)
801040d1:	85 c0                	test   %eax,%eax
801040d3:	0f 84 84 00 00 00    	je     8010415d <pipealloc+0xbd>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
801040d9:	e8 12 f2 ff ff       	call   801032f0 <kalloc>
801040de:	89 c3                	mov    %eax,%ebx
801040e0:	85 c0                	test   %eax,%eax
801040e2:	0f 84 a0 00 00 00    	je     80104188 <pipealloc+0xe8>
    goto bad;
  p->readopen = 1;
801040e8:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
801040ef:	00 00 00 
  p->writeopen = 1;
  p->nwrite = 0;
  p->nread = 0;
  initlock(&p->lock, "pipe");
801040f2:	83 ec 08             	sub    $0x8,%esp
  p->writeopen = 1;
801040f5:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
801040fc:	00 00 00 
  p->nwrite = 0;
801040ff:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80104106:	00 00 00 
  p->nread = 0;
80104109:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80104110:	00 00 00 
  initlock(&p->lock, "pipe");
80104113:	68 42 80 10 80       	push   $0x80108042
80104118:	50                   	push   %eax
80104119:	e8 22 0f 00 00       	call   80105040 <initlock>
  (*f0)->type = FD_PIPE;
8010411e:	8b 06                	mov    (%esi),%eax
  (*f0)->pipe = p;
  (*f1)->type = FD_PIPE;
  (*f1)->readable = 0;
  (*f1)->writable = 1;
  (*f1)->pipe = p;
  return 0;
80104120:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
80104123:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80104129:	8b 06                	mov    (%esi),%eax
8010412b:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
8010412f:	8b 06                	mov    (%esi),%eax
80104131:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80104135:	8b 06                	mov    (%esi),%eax
80104137:	89 58 0c             	mov    %ebx,0xc(%eax)
  (*f1)->type = FD_PIPE;
8010413a:	8b 07                	mov    (%edi),%eax
8010413c:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80104142:	8b 07                	mov    (%edi),%eax
80104144:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80104148:	8b 07                	mov    (%edi),%eax
8010414a:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
8010414e:	8b 07                	mov    (%edi),%eax
80104150:	89 58 0c             	mov    %ebx,0xc(%eax)
  return 0;
80104153:	31 c0                	xor    %eax,%eax
  if(*f0)
    fileclose(*f0);
  if(*f1)
    fileclose(*f1);
  return -1;
}
80104155:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104158:	5b                   	pop    %ebx
80104159:	5e                   	pop    %esi
8010415a:	5f                   	pop    %edi
8010415b:	5d                   	pop    %ebp
8010415c:	c3                   	ret
  if(*f0)
8010415d:	8b 06                	mov    (%esi),%eax
8010415f:	85 c0                	test   %eax,%eax
80104161:	74 1e                	je     80104181 <pipealloc+0xe1>
    fileclose(*f0);
80104163:	83 ec 0c             	sub    $0xc,%esp
80104166:	50                   	push   %eax
80104167:	e8 34 da ff ff       	call   80101ba0 <fileclose>
8010416c:	83 c4 10             	add    $0x10,%esp
  if(*f1)
8010416f:	8b 07                	mov    (%edi),%eax
80104171:	85 c0                	test   %eax,%eax
80104173:	74 0c                	je     80104181 <pipealloc+0xe1>
    fileclose(*f1);
80104175:	83 ec 0c             	sub    $0xc,%esp
80104178:	50                   	push   %eax
80104179:	e8 22 da ff ff       	call   80101ba0 <fileclose>
8010417e:	83 c4 10             	add    $0x10,%esp
  return -1;
80104181:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104186:	eb cd                	jmp    80104155 <pipealloc+0xb5>
  if(*f0)
80104188:	8b 06                	mov    (%esi),%eax
8010418a:	85 c0                	test   %eax,%eax
8010418c:	75 d5                	jne    80104163 <pipealloc+0xc3>
8010418e:	eb df                	jmp    8010416f <pipealloc+0xcf>

80104190 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80104190:	55                   	push   %ebp
80104191:	89 e5                	mov    %esp,%ebp
80104193:	56                   	push   %esi
80104194:	53                   	push   %ebx
80104195:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104198:	8b 75 0c             	mov    0xc(%ebp),%esi
  acquire(&p->lock);
8010419b:	83 ec 0c             	sub    $0xc,%esp
8010419e:	53                   	push   %ebx
8010419f:	e8 8c 10 00 00       	call   80105230 <acquire>
  if(writable){
801041a4:	83 c4 10             	add    $0x10,%esp
801041a7:	85 f6                	test   %esi,%esi
801041a9:	74 65                	je     80104210 <pipeclose+0x80>
    p->writeopen = 0;
    wakeup(&p->nread);
801041ab:	83 ec 0c             	sub    $0xc,%esp
801041ae:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
    p->writeopen = 0;
801041b4:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
801041bb:	00 00 00 
    wakeup(&p->nread);
801041be:	50                   	push   %eax
801041bf:	e8 ac 0b 00 00       	call   80104d70 <wakeup>
801041c4:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
801041c7:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
801041cd:	85 d2                	test   %edx,%edx
801041cf:	75 0a                	jne    801041db <pipeclose+0x4b>
801041d1:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
801041d7:	85 c0                	test   %eax,%eax
801041d9:	74 15                	je     801041f0 <pipeclose+0x60>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
801041db:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801041de:	8d 65 f8             	lea    -0x8(%ebp),%esp
801041e1:	5b                   	pop    %ebx
801041e2:	5e                   	pop    %esi
801041e3:	5d                   	pop    %ebp
    release(&p->lock);
801041e4:	e9 e7 0f 00 00       	jmp    801051d0 <release>
801041e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    release(&p->lock);
801041f0:	83 ec 0c             	sub    $0xc,%esp
801041f3:	53                   	push   %ebx
801041f4:	e8 d7 0f 00 00       	call   801051d0 <release>
    kfree((char*)p);
801041f9:	83 c4 10             	add    $0x10,%esp
801041fc:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801041ff:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104202:	5b                   	pop    %ebx
80104203:	5e                   	pop    %esi
80104204:	5d                   	pop    %ebp
    kfree((char*)p);
80104205:	e9 26 ef ff ff       	jmp    80103130 <kfree>
8010420a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    wakeup(&p->nwrite);
80104210:	83 ec 0c             	sub    $0xc,%esp
80104213:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
    p->readopen = 0;
80104219:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80104220:	00 00 00 
    wakeup(&p->nwrite);
80104223:	50                   	push   %eax
80104224:	e8 47 0b 00 00       	call   80104d70 <wakeup>
80104229:	83 c4 10             	add    $0x10,%esp
8010422c:	eb 99                	jmp    801041c7 <pipeclose+0x37>
8010422e:	66 90                	xchg   %ax,%ax

80104230 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80104230:	55                   	push   %ebp
80104231:	89 e5                	mov    %esp,%ebp
80104233:	57                   	push   %edi
80104234:	56                   	push   %esi
80104235:	53                   	push   %ebx
80104236:	83 ec 28             	sub    $0x28,%esp
80104239:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010423c:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  acquire(&p->lock);
8010423f:	53                   	push   %ebx
80104240:	e8 eb 0f 00 00       	call   80105230 <acquire>
  for(i = 0; i < n; i++){
80104245:	83 c4 10             	add    $0x10,%esp
80104248:	85 ff                	test   %edi,%edi
8010424a:	0f 8e ce 00 00 00    	jle    8010431e <pipewrite+0xee>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80104250:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
80104256:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80104259:	89 7d 10             	mov    %edi,0x10(%ebp)
8010425c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010425f:	8d 34 39             	lea    (%ecx,%edi,1),%esi
80104262:	89 75 e0             	mov    %esi,-0x20(%ebp)
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80104265:	8d b3 34 02 00 00    	lea    0x234(%ebx),%esi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010426b:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80104271:	8d bb 38 02 00 00    	lea    0x238(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80104277:	8d 90 00 02 00 00    	lea    0x200(%eax),%edx
8010427d:	39 55 e4             	cmp    %edx,-0x1c(%ebp)
80104280:	0f 85 b6 00 00 00    	jne    8010433c <pipewrite+0x10c>
80104286:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80104289:	eb 3b                	jmp    801042c6 <pipewrite+0x96>
8010428b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(p->readopen == 0 || myproc()->killed){
80104290:	e8 5b 03 00 00       	call   801045f0 <myproc>
80104295:	8b 48 24             	mov    0x24(%eax),%ecx
80104298:	85 c9                	test   %ecx,%ecx
8010429a:	75 34                	jne    801042d0 <pipewrite+0xa0>
      wakeup(&p->nread);
8010429c:	83 ec 0c             	sub    $0xc,%esp
8010429f:	56                   	push   %esi
801042a0:	e8 cb 0a 00 00       	call   80104d70 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
801042a5:	58                   	pop    %eax
801042a6:	5a                   	pop    %edx
801042a7:	53                   	push   %ebx
801042a8:	57                   	push   %edi
801042a9:	e8 02 0a 00 00       	call   80104cb0 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
801042ae:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
801042b4:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
801042ba:	83 c4 10             	add    $0x10,%esp
801042bd:	05 00 02 00 00       	add    $0x200,%eax
801042c2:	39 c2                	cmp    %eax,%edx
801042c4:	75 2a                	jne    801042f0 <pipewrite+0xc0>
      if(p->readopen == 0 || myproc()->killed){
801042c6:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
801042cc:	85 c0                	test   %eax,%eax
801042ce:	75 c0                	jne    80104290 <pipewrite+0x60>
        release(&p->lock);
801042d0:	83 ec 0c             	sub    $0xc,%esp
801042d3:	53                   	push   %ebx
801042d4:	e8 f7 0e 00 00       	call   801051d0 <release>
        return -1;
801042d9:	83 c4 10             	add    $0x10,%esp
801042dc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
801042e1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801042e4:	5b                   	pop    %ebx
801042e5:	5e                   	pop    %esi
801042e6:	5f                   	pop    %edi
801042e7:	5d                   	pop    %ebp
801042e8:	c3                   	ret
801042e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801042f0:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
801042f3:	8d 42 01             	lea    0x1(%edx),%eax
801042f6:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
  for(i = 0; i < n; i++){
801042fc:	83 c1 01             	add    $0x1,%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
801042ff:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
80104305:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80104308:	0f b6 41 ff          	movzbl -0x1(%ecx),%eax
8010430c:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
  for(i = 0; i < n; i++){
80104310:	8b 45 e0             	mov    -0x20(%ebp),%eax
80104313:	39 c1                	cmp    %eax,%ecx
80104315:	0f 85 50 ff ff ff    	jne    8010426b <pipewrite+0x3b>
8010431b:	8b 7d 10             	mov    0x10(%ebp),%edi
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
8010431e:	83 ec 0c             	sub    $0xc,%esp
80104321:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80104327:	50                   	push   %eax
80104328:	e8 43 0a 00 00       	call   80104d70 <wakeup>
  release(&p->lock);
8010432d:	89 1c 24             	mov    %ebx,(%esp)
80104330:	e8 9b 0e 00 00       	call   801051d0 <release>
  return n;
80104335:	83 c4 10             	add    $0x10,%esp
80104338:	89 f8                	mov    %edi,%eax
8010433a:	eb a5                	jmp    801042e1 <pipewrite+0xb1>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010433c:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010433f:	eb b2                	jmp    801042f3 <pipewrite+0xc3>
80104341:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104348:	00 
80104349:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80104350 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
80104350:	55                   	push   %ebp
80104351:	89 e5                	mov    %esp,%ebp
80104353:	57                   	push   %edi
80104354:	56                   	push   %esi
80104355:	53                   	push   %ebx
80104356:	83 ec 18             	sub    $0x18,%esp
80104359:	8b 75 08             	mov    0x8(%ebp),%esi
8010435c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  int i;

  acquire(&p->lock);
8010435f:	56                   	push   %esi
80104360:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
80104366:	e8 c5 0e 00 00       	call   80105230 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010436b:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80104371:	83 c4 10             	add    $0x10,%esp
80104374:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
8010437a:	74 2f                	je     801043ab <piperead+0x5b>
8010437c:	eb 37                	jmp    801043b5 <piperead+0x65>
8010437e:	66 90                	xchg   %ax,%ax
    if(myproc()->killed){
80104380:	e8 6b 02 00 00       	call   801045f0 <myproc>
80104385:	8b 40 24             	mov    0x24(%eax),%eax
80104388:	85 c0                	test   %eax,%eax
8010438a:	0f 85 80 00 00 00    	jne    80104410 <piperead+0xc0>
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80104390:	83 ec 08             	sub    $0x8,%esp
80104393:	56                   	push   %esi
80104394:	53                   	push   %ebx
80104395:	e8 16 09 00 00       	call   80104cb0 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010439a:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
801043a0:	83 c4 10             	add    $0x10,%esp
801043a3:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
801043a9:	75 0a                	jne    801043b5 <piperead+0x65>
801043ab:	8b 96 40 02 00 00    	mov    0x240(%esi),%edx
801043b1:	85 d2                	test   %edx,%edx
801043b3:	75 cb                	jne    80104380 <piperead+0x30>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801043b5:	8b 4d 10             	mov    0x10(%ebp),%ecx
801043b8:	31 db                	xor    %ebx,%ebx
801043ba:	85 c9                	test   %ecx,%ecx
801043bc:	7f 26                	jg     801043e4 <piperead+0x94>
801043be:	eb 2c                	jmp    801043ec <piperead+0x9c>
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
801043c0:	8d 48 01             	lea    0x1(%eax),%ecx
801043c3:	25 ff 01 00 00       	and    $0x1ff,%eax
801043c8:	89 8e 34 02 00 00    	mov    %ecx,0x234(%esi)
801043ce:	0f b6 44 06 34       	movzbl 0x34(%esi,%eax,1),%eax
801043d3:	88 04 1f             	mov    %al,(%edi,%ebx,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801043d6:	83 c3 01             	add    $0x1,%ebx
801043d9:	39 5d 10             	cmp    %ebx,0x10(%ebp)
801043dc:	74 0e                	je     801043ec <piperead+0x9c>
801043de:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
    if(p->nread == p->nwrite)
801043e4:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
801043ea:	75 d4                	jne    801043c0 <piperead+0x70>
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
801043ec:	83 ec 0c             	sub    $0xc,%esp
801043ef:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
801043f5:	50                   	push   %eax
801043f6:	e8 75 09 00 00       	call   80104d70 <wakeup>
  release(&p->lock);
801043fb:	89 34 24             	mov    %esi,(%esp)
801043fe:	e8 cd 0d 00 00       	call   801051d0 <release>
  return i;
80104403:	83 c4 10             	add    $0x10,%esp
}
80104406:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104409:	89 d8                	mov    %ebx,%eax
8010440b:	5b                   	pop    %ebx
8010440c:	5e                   	pop    %esi
8010440d:	5f                   	pop    %edi
8010440e:	5d                   	pop    %ebp
8010440f:	c3                   	ret
      release(&p->lock);
80104410:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104413:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
      release(&p->lock);
80104418:	56                   	push   %esi
80104419:	e8 b2 0d 00 00       	call   801051d0 <release>
      return -1;
8010441e:	83 c4 10             	add    $0x10,%esp
}
80104421:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104424:	89 d8                	mov    %ebx,%eax
80104426:	5b                   	pop    %ebx
80104427:	5e                   	pop    %esi
80104428:	5f                   	pop    %edi
80104429:	5d                   	pop    %ebp
8010442a:	c3                   	ret
8010442b:	66 90                	xchg   %ax,%ax
8010442d:	66 90                	xchg   %ax,%ax
8010442f:	90                   	nop

80104430 <allocproc>:
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
80104430:	55                   	push   %ebp
80104431:	89 e5                	mov    %esp,%ebp
80104433:	53                   	push   %ebx
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104434:	bb f4 2f 11 80       	mov    $0x80112ff4,%ebx
{
80104439:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
8010443c:	68 c0 2f 11 80       	push   $0x80112fc0
80104441:	e8 ea 0d 00 00       	call   80105230 <acquire>
80104446:	83 c4 10             	add    $0x10,%esp
80104449:	eb 10                	jmp    8010445b <allocproc+0x2b>
8010444b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104450:	83 c3 7c             	add    $0x7c,%ebx
80104453:	81 fb f4 4e 11 80    	cmp    $0x80114ef4,%ebx
80104459:	74 75                	je     801044d0 <allocproc+0xa0>
    if(p->state == UNUSED)
8010445b:	8b 43 0c             	mov    0xc(%ebx),%eax
8010445e:	85 c0                	test   %eax,%eax
80104460:	75 ee                	jne    80104450 <allocproc+0x20>
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
80104462:	a1 04 b0 10 80       	mov    0x8010b004,%eax

  release(&ptable.lock);
80104467:	83 ec 0c             	sub    $0xc,%esp
  p->state = EMBRYO;
8010446a:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
80104471:	89 43 10             	mov    %eax,0x10(%ebx)
80104474:	8d 50 01             	lea    0x1(%eax),%edx
  release(&ptable.lock);
80104477:	68 c0 2f 11 80       	push   $0x80112fc0
  p->pid = nextpid++;
8010447c:	89 15 04 b0 10 80    	mov    %edx,0x8010b004
  release(&ptable.lock);
80104482:	e8 49 0d 00 00       	call   801051d0 <release>

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
80104487:	e8 64 ee ff ff       	call   801032f0 <kalloc>
8010448c:	83 c4 10             	add    $0x10,%esp
8010448f:	89 43 08             	mov    %eax,0x8(%ebx)
80104492:	85 c0                	test   %eax,%eax
80104494:	74 53                	je     801044e9 <allocproc+0xb9>
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80104496:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
8010449c:	83 ec 04             	sub    $0x4,%esp
  sp -= sizeof *p->context;
8010449f:	05 9c 0f 00 00       	add    $0xf9c,%eax
  sp -= sizeof *p->tf;
801044a4:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
801044a7:	c7 40 14 e2 64 10 80 	movl   $0x801064e2,0x14(%eax)
  p->context = (struct context*)sp;
801044ae:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
801044b1:	6a 14                	push   $0x14
801044b3:	6a 00                	push   $0x0
801044b5:	50                   	push   %eax
801044b6:	e8 75 0e 00 00       	call   80105330 <memset>
  p->context->eip = (uint)forkret;
801044bb:	8b 43 1c             	mov    0x1c(%ebx),%eax

  return p;
801044be:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
801044c1:	c7 40 10 00 45 10 80 	movl   $0x80104500,0x10(%eax)
}
801044c8:	89 d8                	mov    %ebx,%eax
801044ca:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801044cd:	c9                   	leave
801044ce:	c3                   	ret
801044cf:	90                   	nop
  release(&ptable.lock);
801044d0:	83 ec 0c             	sub    $0xc,%esp
  return 0;
801044d3:	31 db                	xor    %ebx,%ebx
  release(&ptable.lock);
801044d5:	68 c0 2f 11 80       	push   $0x80112fc0
801044da:	e8 f1 0c 00 00       	call   801051d0 <release>
  return 0;
801044df:	83 c4 10             	add    $0x10,%esp
}
801044e2:	89 d8                	mov    %ebx,%eax
801044e4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801044e7:	c9                   	leave
801044e8:	c3                   	ret
    p->state = UNUSED;
801044e9:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  return 0;
801044f0:	31 db                	xor    %ebx,%ebx
801044f2:	eb ee                	jmp    801044e2 <allocproc+0xb2>
801044f4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801044fb:	00 
801044fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104500 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
80104500:	55                   	push   %ebp
80104501:	89 e5                	mov    %esp,%ebp
80104503:	83 ec 14             	sub    $0x14,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80104506:	68 c0 2f 11 80       	push   $0x80112fc0
8010450b:	e8 c0 0c 00 00       	call   801051d0 <release>

  if (first) {
80104510:	a1 00 b0 10 80       	mov    0x8010b000,%eax
80104515:	83 c4 10             	add    $0x10,%esp
80104518:	85 c0                	test   %eax,%eax
8010451a:	75 04                	jne    80104520 <forkret+0x20>
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}
8010451c:	c9                   	leave
8010451d:	c3                   	ret
8010451e:	66 90                	xchg   %ax,%ax
    first = 0;
80104520:	c7 05 00 b0 10 80 00 	movl   $0x0,0x8010b000
80104527:	00 00 00 
    iinit(ROOTDEV);
8010452a:	83 ec 0c             	sub    $0xc,%esp
8010452d:	6a 01                	push   $0x1
8010452f:	e8 dc dc ff ff       	call   80102210 <iinit>
    initlog(ROOTDEV);
80104534:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
8010453b:	e8 f0 f3 ff ff       	call   80103930 <initlog>
}
80104540:	83 c4 10             	add    $0x10,%esp
80104543:	c9                   	leave
80104544:	c3                   	ret
80104545:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010454c:	00 
8010454d:	8d 76 00             	lea    0x0(%esi),%esi

80104550 <pinit>:
{
80104550:	55                   	push   %ebp
80104551:	89 e5                	mov    %esp,%ebp
80104553:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
80104556:	68 47 80 10 80       	push   $0x80108047
8010455b:	68 c0 2f 11 80       	push   $0x80112fc0
80104560:	e8 db 0a 00 00       	call   80105040 <initlock>
}
80104565:	83 c4 10             	add    $0x10,%esp
80104568:	c9                   	leave
80104569:	c3                   	ret
8010456a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104570 <mycpu>:
{
80104570:	55                   	push   %ebp
80104571:	89 e5                	mov    %esp,%ebp
80104573:	56                   	push   %esi
80104574:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104575:	9c                   	pushf
80104576:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104577:	f6 c4 02             	test   $0x2,%ah
8010457a:	75 46                	jne    801045c2 <mycpu+0x52>
  apicid = lapicid();
8010457c:	e8 df ef ff ff       	call   80103560 <lapicid>
  for (i = 0; i < ncpu; ++i) {
80104581:	8b 35 24 2a 11 80    	mov    0x80112a24,%esi
80104587:	85 f6                	test   %esi,%esi
80104589:	7e 2a                	jle    801045b5 <mycpu+0x45>
8010458b:	31 d2                	xor    %edx,%edx
8010458d:	eb 08                	jmp    80104597 <mycpu+0x27>
8010458f:	90                   	nop
80104590:	83 c2 01             	add    $0x1,%edx
80104593:	39 f2                	cmp    %esi,%edx
80104595:	74 1e                	je     801045b5 <mycpu+0x45>
    if (cpus[i].apicid == apicid)
80104597:	69 ca b0 00 00 00    	imul   $0xb0,%edx,%ecx
8010459d:	0f b6 99 40 2a 11 80 	movzbl -0x7feed5c0(%ecx),%ebx
801045a4:	39 c3                	cmp    %eax,%ebx
801045a6:	75 e8                	jne    80104590 <mycpu+0x20>
}
801045a8:	8d 65 f8             	lea    -0x8(%ebp),%esp
      return &cpus[i];
801045ab:	8d 81 40 2a 11 80    	lea    -0x7feed5c0(%ecx),%eax
}
801045b1:	5b                   	pop    %ebx
801045b2:	5e                   	pop    %esi
801045b3:	5d                   	pop    %ebp
801045b4:	c3                   	ret
  panic("unknown apicid\n");
801045b5:	83 ec 0c             	sub    $0xc,%esp
801045b8:	68 4e 80 10 80       	push   $0x8010804e
801045bd:	e8 be bd ff ff       	call   80100380 <panic>
    panic("mycpu called with interrupts enabled\n");
801045c2:	83 ec 0c             	sub    $0xc,%esp
801045c5:	68 6c 84 10 80       	push   $0x8010846c
801045ca:	e8 b1 bd ff ff       	call   80100380 <panic>
801045cf:	90                   	nop

801045d0 <cpuid>:
cpuid() {
801045d0:	55                   	push   %ebp
801045d1:	89 e5                	mov    %esp,%ebp
801045d3:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
801045d6:	e8 95 ff ff ff       	call   80104570 <mycpu>
}
801045db:	c9                   	leave
  return mycpu()-cpus;
801045dc:	2d 40 2a 11 80       	sub    $0x80112a40,%eax
801045e1:	c1 f8 04             	sar    $0x4,%eax
801045e4:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
801045ea:	c3                   	ret
801045eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801045f0 <myproc>:
myproc(void) {
801045f0:	55                   	push   %ebp
801045f1:	89 e5                	mov    %esp,%ebp
801045f3:	53                   	push   %ebx
801045f4:	83 ec 04             	sub    $0x4,%esp
  pushcli();
801045f7:	e8 e4 0a 00 00       	call   801050e0 <pushcli>
  c = mycpu();
801045fc:	e8 6f ff ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104601:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104607:	e8 24 0b 00 00       	call   80105130 <popcli>
}
8010460c:	89 d8                	mov    %ebx,%eax
8010460e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104611:	c9                   	leave
80104612:	c3                   	ret
80104613:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010461a:	00 
8010461b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104620 <userinit>:
{
80104620:	55                   	push   %ebp
80104621:	89 e5                	mov    %esp,%ebp
80104623:	53                   	push   %ebx
80104624:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80104627:	e8 04 fe ff ff       	call   80104430 <allocproc>
8010462c:	89 c3                	mov    %eax,%ebx
  initproc = p;
8010462e:	a3 f4 4e 11 80       	mov    %eax,0x80114ef4
  if((p->pgdir = setupkvm()) == 0)
80104633:	e8 78 34 00 00       	call   80107ab0 <setupkvm>
80104638:	89 43 04             	mov    %eax,0x4(%ebx)
8010463b:	85 c0                	test   %eax,%eax
8010463d:	0f 84 bd 00 00 00    	je     80104700 <userinit+0xe0>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
80104643:	83 ec 04             	sub    $0x4,%esp
80104646:	68 2c 00 00 00       	push   $0x2c
8010464b:	68 60 b4 10 80       	push   $0x8010b460
80104650:	50                   	push   %eax
80104651:	e8 3a 31 00 00       	call   80107790 <inituvm>
  memset(p->tf, 0, sizeof(*p->tf));
80104656:	83 c4 0c             	add    $0xc,%esp
  p->sz = PGSIZE;
80104659:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
8010465f:	6a 4c                	push   $0x4c
80104661:	6a 00                	push   $0x0
80104663:	ff 73 18             	push   0x18(%ebx)
80104666:	e8 c5 0c 00 00       	call   80105330 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
8010466b:	8b 43 18             	mov    0x18(%ebx),%eax
8010466e:	ba 1b 00 00 00       	mov    $0x1b,%edx
  safestrcpy(p->name, "initcode", sizeof(p->name));
80104673:	83 c4 0c             	add    $0xc,%esp
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80104676:	b9 23 00 00 00       	mov    $0x23,%ecx
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
8010467b:	66 89 50 3c          	mov    %dx,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
8010467f:	8b 43 18             	mov    0x18(%ebx),%eax
80104682:	66 89 48 2c          	mov    %cx,0x2c(%eax)
  p->tf->es = p->tf->ds;
80104686:	8b 43 18             	mov    0x18(%ebx),%eax
80104689:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
8010468d:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80104691:	8b 43 18             	mov    0x18(%ebx),%eax
80104694:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80104698:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
8010469c:	8b 43 18             	mov    0x18(%ebx),%eax
8010469f:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
801046a6:	8b 43 18             	mov    0x18(%ebx),%eax
801046a9:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
801046b0:	8b 43 18             	mov    0x18(%ebx),%eax
801046b3:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
801046ba:	8d 43 6c             	lea    0x6c(%ebx),%eax
801046bd:	6a 10                	push   $0x10
801046bf:	68 77 80 10 80       	push   $0x80108077
801046c4:	50                   	push   %eax
801046c5:	e8 16 0e 00 00       	call   801054e0 <safestrcpy>
  p->cwd = namei("/");
801046ca:	c7 04 24 80 80 10 80 	movl   $0x80108080,(%esp)
801046d1:	e8 3a e6 ff ff       	call   80102d10 <namei>
801046d6:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
801046d9:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
801046e0:	e8 4b 0b 00 00       	call   80105230 <acquire>
  p->state = RUNNABLE;
801046e5:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
801046ec:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
801046f3:	e8 d8 0a 00 00       	call   801051d0 <release>
}
801046f8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801046fb:	83 c4 10             	add    $0x10,%esp
801046fe:	c9                   	leave
801046ff:	c3                   	ret
    panic("userinit: out of memory?");
80104700:	83 ec 0c             	sub    $0xc,%esp
80104703:	68 5e 80 10 80       	push   $0x8010805e
80104708:	e8 73 bc ff ff       	call   80100380 <panic>
8010470d:	8d 76 00             	lea    0x0(%esi),%esi

80104710 <growproc>:
{
80104710:	55                   	push   %ebp
80104711:	89 e5                	mov    %esp,%ebp
80104713:	56                   	push   %esi
80104714:	53                   	push   %ebx
80104715:	8b 75 08             	mov    0x8(%ebp),%esi
  pushcli();
80104718:	e8 c3 09 00 00       	call   801050e0 <pushcli>
  c = mycpu();
8010471d:	e8 4e fe ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104722:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104728:	e8 03 0a 00 00       	call   80105130 <popcli>
  sz = curproc->sz;
8010472d:	8b 03                	mov    (%ebx),%eax
  if(n > 0){
8010472f:	85 f6                	test   %esi,%esi
80104731:	7f 1d                	jg     80104750 <growproc+0x40>
  } else if(n < 0){
80104733:	75 3b                	jne    80104770 <growproc+0x60>
  switchuvm(curproc);
80104735:	83 ec 0c             	sub    $0xc,%esp
  curproc->sz = sz;
80104738:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
8010473a:	53                   	push   %ebx
8010473b:	e8 40 2f 00 00       	call   80107680 <switchuvm>
  return 0;
80104740:	83 c4 10             	add    $0x10,%esp
80104743:	31 c0                	xor    %eax,%eax
}
80104745:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104748:	5b                   	pop    %ebx
80104749:	5e                   	pop    %esi
8010474a:	5d                   	pop    %ebp
8010474b:	c3                   	ret
8010474c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80104750:	83 ec 04             	sub    $0x4,%esp
80104753:	01 c6                	add    %eax,%esi
80104755:	56                   	push   %esi
80104756:	50                   	push   %eax
80104757:	ff 73 04             	push   0x4(%ebx)
8010475a:	e8 81 31 00 00       	call   801078e0 <allocuvm>
8010475f:	83 c4 10             	add    $0x10,%esp
80104762:	85 c0                	test   %eax,%eax
80104764:	75 cf                	jne    80104735 <growproc+0x25>
      return -1;
80104766:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010476b:	eb d8                	jmp    80104745 <growproc+0x35>
8010476d:	8d 76 00             	lea    0x0(%esi),%esi
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80104770:	83 ec 04             	sub    $0x4,%esp
80104773:	01 c6                	add    %eax,%esi
80104775:	56                   	push   %esi
80104776:	50                   	push   %eax
80104777:	ff 73 04             	push   0x4(%ebx)
8010477a:	e8 81 32 00 00       	call   80107a00 <deallocuvm>
8010477f:	83 c4 10             	add    $0x10,%esp
80104782:	85 c0                	test   %eax,%eax
80104784:	75 af                	jne    80104735 <growproc+0x25>
80104786:	eb de                	jmp    80104766 <growproc+0x56>
80104788:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010478f:	00 

80104790 <fork>:
{
80104790:	55                   	push   %ebp
80104791:	89 e5                	mov    %esp,%ebp
80104793:	57                   	push   %edi
80104794:	56                   	push   %esi
80104795:	53                   	push   %ebx
80104796:	83 ec 1c             	sub    $0x1c,%esp
  pushcli();
80104799:	e8 42 09 00 00       	call   801050e0 <pushcli>
  c = mycpu();
8010479e:	e8 cd fd ff ff       	call   80104570 <mycpu>
  p = c->proc;
801047a3:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801047a9:	e8 82 09 00 00       	call   80105130 <popcli>
  if((np = allocproc()) == 0){
801047ae:	e8 7d fc ff ff       	call   80104430 <allocproc>
801047b3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801047b6:	85 c0                	test   %eax,%eax
801047b8:	0f 84 d6 00 00 00    	je     80104894 <fork+0x104>
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
801047be:	83 ec 08             	sub    $0x8,%esp
801047c1:	ff 33                	push   (%ebx)
801047c3:	89 c7                	mov    %eax,%edi
801047c5:	ff 73 04             	push   0x4(%ebx)
801047c8:	e8 d3 33 00 00       	call   80107ba0 <copyuvm>
801047cd:	83 c4 10             	add    $0x10,%esp
801047d0:	89 47 04             	mov    %eax,0x4(%edi)
801047d3:	85 c0                	test   %eax,%eax
801047d5:	0f 84 9a 00 00 00    	je     80104875 <fork+0xe5>
  np->sz = curproc->sz;
801047db:	8b 03                	mov    (%ebx),%eax
801047dd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801047e0:	89 01                	mov    %eax,(%ecx)
  *np->tf = *curproc->tf;
801047e2:	8b 79 18             	mov    0x18(%ecx),%edi
  np->parent = curproc;
801047e5:	89 c8                	mov    %ecx,%eax
801047e7:	89 59 14             	mov    %ebx,0x14(%ecx)
  *np->tf = *curproc->tf;
801047ea:	b9 13 00 00 00       	mov    $0x13,%ecx
801047ef:	8b 73 18             	mov    0x18(%ebx),%esi
801047f2:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  for(i = 0; i < NOFILE; i++)
801047f4:	31 f6                	xor    %esi,%esi
  np->tf->eax = 0;
801047f6:	8b 40 18             	mov    0x18(%eax),%eax
801047f9:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
    if(curproc->ofile[i])
80104800:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
80104804:	85 c0                	test   %eax,%eax
80104806:	74 13                	je     8010481b <fork+0x8b>
      np->ofile[i] = filedup(curproc->ofile[i]);
80104808:	83 ec 0c             	sub    $0xc,%esp
8010480b:	50                   	push   %eax
8010480c:	e8 3f d3 ff ff       	call   80101b50 <filedup>
80104811:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80104814:	83 c4 10             	add    $0x10,%esp
80104817:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
  for(i = 0; i < NOFILE; i++)
8010481b:	83 c6 01             	add    $0x1,%esi
8010481e:	83 fe 10             	cmp    $0x10,%esi
80104821:	75 dd                	jne    80104800 <fork+0x70>
  np->cwd = idup(curproc->cwd);
80104823:	83 ec 0c             	sub    $0xc,%esp
80104826:	ff 73 68             	push   0x68(%ebx)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80104829:	83 c3 6c             	add    $0x6c,%ebx
  np->cwd = idup(curproc->cwd);
8010482c:	e8 cf db ff ff       	call   80102400 <idup>
80104831:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80104834:	83 c4 0c             	add    $0xc,%esp
  np->cwd = idup(curproc->cwd);
80104837:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
8010483a:	8d 47 6c             	lea    0x6c(%edi),%eax
8010483d:	6a 10                	push   $0x10
8010483f:	53                   	push   %ebx
80104840:	50                   	push   %eax
80104841:	e8 9a 0c 00 00       	call   801054e0 <safestrcpy>
  pid = np->pid;
80104846:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
80104849:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104850:	e8 db 09 00 00       	call   80105230 <acquire>
  np->state = RUNNABLE;
80104855:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
8010485c:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104863:	e8 68 09 00 00       	call   801051d0 <release>
  return pid;
80104868:	83 c4 10             	add    $0x10,%esp
}
8010486b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010486e:	89 d8                	mov    %ebx,%eax
80104870:	5b                   	pop    %ebx
80104871:	5e                   	pop    %esi
80104872:	5f                   	pop    %edi
80104873:	5d                   	pop    %ebp
80104874:	c3                   	ret
    kfree(np->kstack);
80104875:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80104878:	83 ec 0c             	sub    $0xc,%esp
8010487b:	ff 73 08             	push   0x8(%ebx)
8010487e:	e8 ad e8 ff ff       	call   80103130 <kfree>
    np->kstack = 0;
80104883:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    return -1;
8010488a:	83 c4 10             	add    $0x10,%esp
    np->state = UNUSED;
8010488d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80104894:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104899:	eb d0                	jmp    8010486b <fork+0xdb>
8010489b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801048a0 <scheduler>:
{
801048a0:	55                   	push   %ebp
801048a1:	89 e5                	mov    %esp,%ebp
801048a3:	57                   	push   %edi
801048a4:	56                   	push   %esi
801048a5:	53                   	push   %ebx
801048a6:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
801048a9:	e8 c2 fc ff ff       	call   80104570 <mycpu>
  c->proc = 0;
801048ae:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
801048b5:	00 00 00 
  struct cpu *c = mycpu();
801048b8:	89 c6                	mov    %eax,%esi
  c->proc = 0;
801048ba:	8d 78 04             	lea    0x4(%eax),%edi
801048bd:	8d 76 00             	lea    0x0(%esi),%esi
  asm volatile("sti");
801048c0:	fb                   	sti
    acquire(&ptable.lock);
801048c1:	83 ec 0c             	sub    $0xc,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801048c4:	bb f4 2f 11 80       	mov    $0x80112ff4,%ebx
    acquire(&ptable.lock);
801048c9:	68 c0 2f 11 80       	push   $0x80112fc0
801048ce:	e8 5d 09 00 00       	call   80105230 <acquire>
801048d3:	83 c4 10             	add    $0x10,%esp
801048d6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048dd:	00 
801048de:	66 90                	xchg   %ax,%ax
      if(p->state != RUNNABLE)
801048e0:	83 7b 0c 03          	cmpl   $0x3,0xc(%ebx)
801048e4:	75 33                	jne    80104919 <scheduler+0x79>
      switchuvm(p);
801048e6:	83 ec 0c             	sub    $0xc,%esp
      c->proc = p;
801048e9:	89 9e ac 00 00 00    	mov    %ebx,0xac(%esi)
      switchuvm(p);
801048ef:	53                   	push   %ebx
801048f0:	e8 8b 2d 00 00       	call   80107680 <switchuvm>
      swtch(&(c->scheduler), p->context);
801048f5:	58                   	pop    %eax
801048f6:	5a                   	pop    %edx
801048f7:	ff 73 1c             	push   0x1c(%ebx)
801048fa:	57                   	push   %edi
      p->state = RUNNING;
801048fb:	c7 43 0c 04 00 00 00 	movl   $0x4,0xc(%ebx)
      swtch(&(c->scheduler), p->context);
80104902:	e8 34 0c 00 00       	call   8010553b <swtch>
      switchkvm();
80104907:	e8 64 2d 00 00       	call   80107670 <switchkvm>
      c->proc = 0;
8010490c:	83 c4 10             	add    $0x10,%esp
8010490f:	c7 86 ac 00 00 00 00 	movl   $0x0,0xac(%esi)
80104916:	00 00 00 
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104919:	83 c3 7c             	add    $0x7c,%ebx
8010491c:	81 fb f4 4e 11 80    	cmp    $0x80114ef4,%ebx
80104922:	75 bc                	jne    801048e0 <scheduler+0x40>
    release(&ptable.lock);
80104924:	83 ec 0c             	sub    $0xc,%esp
80104927:	68 c0 2f 11 80       	push   $0x80112fc0
8010492c:	e8 9f 08 00 00       	call   801051d0 <release>
    sti();
80104931:	83 c4 10             	add    $0x10,%esp
80104934:	eb 8a                	jmp    801048c0 <scheduler+0x20>
80104936:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010493d:	00 
8010493e:	66 90                	xchg   %ax,%ax

80104940 <sched>:
{
80104940:	55                   	push   %ebp
80104941:	89 e5                	mov    %esp,%ebp
80104943:	56                   	push   %esi
80104944:	53                   	push   %ebx
  pushcli();
80104945:	e8 96 07 00 00       	call   801050e0 <pushcli>
  c = mycpu();
8010494a:	e8 21 fc ff ff       	call   80104570 <mycpu>
  p = c->proc;
8010494f:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104955:	e8 d6 07 00 00       	call   80105130 <popcli>
  if(!holding(&ptable.lock))
8010495a:	83 ec 0c             	sub    $0xc,%esp
8010495d:	68 c0 2f 11 80       	push   $0x80112fc0
80104962:	e8 29 08 00 00       	call   80105190 <holding>
80104967:	83 c4 10             	add    $0x10,%esp
8010496a:	85 c0                	test   %eax,%eax
8010496c:	74 4f                	je     801049bd <sched+0x7d>
  if(mycpu()->ncli != 1)
8010496e:	e8 fd fb ff ff       	call   80104570 <mycpu>
80104973:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
8010497a:	75 68                	jne    801049e4 <sched+0xa4>
  if(p->state == RUNNING)
8010497c:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80104980:	74 55                	je     801049d7 <sched+0x97>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80104982:	9c                   	pushf
80104983:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80104984:	f6 c4 02             	test   $0x2,%ah
80104987:	75 41                	jne    801049ca <sched+0x8a>
  intena = mycpu()->intena;
80104989:	e8 e2 fb ff ff       	call   80104570 <mycpu>
  swtch(&p->context, mycpu()->scheduler);
8010498e:	83 c3 1c             	add    $0x1c,%ebx
  intena = mycpu()->intena;
80104991:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
80104997:	e8 d4 fb ff ff       	call   80104570 <mycpu>
8010499c:	83 ec 08             	sub    $0x8,%esp
8010499f:	ff 70 04             	push   0x4(%eax)
801049a2:	53                   	push   %ebx
801049a3:	e8 93 0b 00 00       	call   8010553b <swtch>
  mycpu()->intena = intena;
801049a8:	e8 c3 fb ff ff       	call   80104570 <mycpu>
}
801049ad:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
801049b0:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
801049b6:	8d 65 f8             	lea    -0x8(%ebp),%esp
801049b9:	5b                   	pop    %ebx
801049ba:	5e                   	pop    %esi
801049bb:	5d                   	pop    %ebp
801049bc:	c3                   	ret
    panic("sched ptable.lock");
801049bd:	83 ec 0c             	sub    $0xc,%esp
801049c0:	68 82 80 10 80       	push   $0x80108082
801049c5:	e8 b6 b9 ff ff       	call   80100380 <panic>
    panic("sched interruptible");
801049ca:	83 ec 0c             	sub    $0xc,%esp
801049cd:	68 ae 80 10 80       	push   $0x801080ae
801049d2:	e8 a9 b9 ff ff       	call   80100380 <panic>
    panic("sched running");
801049d7:	83 ec 0c             	sub    $0xc,%esp
801049da:	68 a0 80 10 80       	push   $0x801080a0
801049df:	e8 9c b9 ff ff       	call   80100380 <panic>
    panic("sched locks");
801049e4:	83 ec 0c             	sub    $0xc,%esp
801049e7:	68 94 80 10 80       	push   $0x80108094
801049ec:	e8 8f b9 ff ff       	call   80100380 <panic>
801049f1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801049f8:	00 
801049f9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80104a00 <exit>:
{
80104a00:	55                   	push   %ebp
80104a01:	89 e5                	mov    %esp,%ebp
80104a03:	57                   	push   %edi
80104a04:	56                   	push   %esi
80104a05:	53                   	push   %ebx
80104a06:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
80104a09:	e8 e2 fb ff ff       	call   801045f0 <myproc>
  if(curproc == initproc)
80104a0e:	39 05 f4 4e 11 80    	cmp    %eax,0x80114ef4
80104a14:	0f 84 fd 00 00 00    	je     80104b17 <exit+0x117>
80104a1a:	89 c3                	mov    %eax,%ebx
80104a1c:	8d 70 28             	lea    0x28(%eax),%esi
80104a1f:	8d 78 68             	lea    0x68(%eax),%edi
80104a22:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(curproc->ofile[fd]){
80104a28:	8b 06                	mov    (%esi),%eax
80104a2a:	85 c0                	test   %eax,%eax
80104a2c:	74 12                	je     80104a40 <exit+0x40>
      fileclose(curproc->ofile[fd]);
80104a2e:	83 ec 0c             	sub    $0xc,%esp
80104a31:	50                   	push   %eax
80104a32:	e8 69 d1 ff ff       	call   80101ba0 <fileclose>
      curproc->ofile[fd] = 0;
80104a37:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80104a3d:	83 c4 10             	add    $0x10,%esp
  for(fd = 0; fd < NOFILE; fd++){
80104a40:	83 c6 04             	add    $0x4,%esi
80104a43:	39 f7                	cmp    %esi,%edi
80104a45:	75 e1                	jne    80104a28 <exit+0x28>
  begin_op();
80104a47:	e8 84 ef ff ff       	call   801039d0 <begin_op>
  iput(curproc->cwd);
80104a4c:	83 ec 0c             	sub    $0xc,%esp
80104a4f:	ff 73 68             	push   0x68(%ebx)
80104a52:	e8 09 db ff ff       	call   80102560 <iput>
  end_op();
80104a57:	e8 e4 ef ff ff       	call   80103a40 <end_op>
  curproc->cwd = 0;
80104a5c:	c7 43 68 00 00 00 00 	movl   $0x0,0x68(%ebx)
  acquire(&ptable.lock);
80104a63:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104a6a:	e8 c1 07 00 00       	call   80105230 <acquire>
  wakeup1(curproc->parent);
80104a6f:	8b 53 14             	mov    0x14(%ebx),%edx
80104a72:	83 c4 10             	add    $0x10,%esp
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104a75:	b8 f4 2f 11 80       	mov    $0x80112ff4,%eax
80104a7a:	eb 0e                	jmp    80104a8a <exit+0x8a>
80104a7c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104a80:	83 c0 7c             	add    $0x7c,%eax
80104a83:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104a88:	74 1c                	je     80104aa6 <exit+0xa6>
    if(p->state == SLEEPING && p->chan == chan)
80104a8a:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80104a8e:	75 f0                	jne    80104a80 <exit+0x80>
80104a90:	3b 50 20             	cmp    0x20(%eax),%edx
80104a93:	75 eb                	jne    80104a80 <exit+0x80>
      p->state = RUNNABLE;
80104a95:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104a9c:	83 c0 7c             	add    $0x7c,%eax
80104a9f:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104aa4:	75 e4                	jne    80104a8a <exit+0x8a>
      p->parent = initproc;
80104aa6:	8b 0d f4 4e 11 80    	mov    0x80114ef4,%ecx
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104aac:	ba f4 2f 11 80       	mov    $0x80112ff4,%edx
80104ab1:	eb 10                	jmp    80104ac3 <exit+0xc3>
80104ab3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104ab8:	83 c2 7c             	add    $0x7c,%edx
80104abb:	81 fa f4 4e 11 80    	cmp    $0x80114ef4,%edx
80104ac1:	74 3b                	je     80104afe <exit+0xfe>
    if(p->parent == curproc){
80104ac3:	39 5a 14             	cmp    %ebx,0x14(%edx)
80104ac6:	75 f0                	jne    80104ab8 <exit+0xb8>
      if(p->state == ZOMBIE)
80104ac8:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
      p->parent = initproc;
80104acc:	89 4a 14             	mov    %ecx,0x14(%edx)
      if(p->state == ZOMBIE)
80104acf:	75 e7                	jne    80104ab8 <exit+0xb8>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104ad1:	b8 f4 2f 11 80       	mov    $0x80112ff4,%eax
80104ad6:	eb 12                	jmp    80104aea <exit+0xea>
80104ad8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104adf:	00 
80104ae0:	83 c0 7c             	add    $0x7c,%eax
80104ae3:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104ae8:	74 ce                	je     80104ab8 <exit+0xb8>
    if(p->state == SLEEPING && p->chan == chan)
80104aea:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80104aee:	75 f0                	jne    80104ae0 <exit+0xe0>
80104af0:	3b 48 20             	cmp    0x20(%eax),%ecx
80104af3:	75 eb                	jne    80104ae0 <exit+0xe0>
      p->state = RUNNABLE;
80104af5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80104afc:	eb e2                	jmp    80104ae0 <exit+0xe0>
  curproc->state = ZOMBIE;
80104afe:	c7 43 0c 05 00 00 00 	movl   $0x5,0xc(%ebx)
  sched();
80104b05:	e8 36 fe ff ff       	call   80104940 <sched>
  panic("zombie exit");
80104b0a:	83 ec 0c             	sub    $0xc,%esp
80104b0d:	68 cf 80 10 80       	push   $0x801080cf
80104b12:	e8 69 b8 ff ff       	call   80100380 <panic>
    panic("init exiting");
80104b17:	83 ec 0c             	sub    $0xc,%esp
80104b1a:	68 c2 80 10 80       	push   $0x801080c2
80104b1f:	e8 5c b8 ff ff       	call   80100380 <panic>
80104b24:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b2b:	00 
80104b2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104b30 <wait>:
{
80104b30:	55                   	push   %ebp
80104b31:	89 e5                	mov    %esp,%ebp
80104b33:	56                   	push   %esi
80104b34:	53                   	push   %ebx
  pushcli();
80104b35:	e8 a6 05 00 00       	call   801050e0 <pushcli>
  c = mycpu();
80104b3a:	e8 31 fa ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104b3f:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80104b45:	e8 e6 05 00 00       	call   80105130 <popcli>
  acquire(&ptable.lock);
80104b4a:	83 ec 0c             	sub    $0xc,%esp
80104b4d:	68 c0 2f 11 80       	push   $0x80112fc0
80104b52:	e8 d9 06 00 00       	call   80105230 <acquire>
80104b57:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
80104b5a:	31 c0                	xor    %eax,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104b5c:	bb f4 2f 11 80       	mov    $0x80112ff4,%ebx
80104b61:	eb 10                	jmp    80104b73 <wait+0x43>
80104b63:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b68:	83 c3 7c             	add    $0x7c,%ebx
80104b6b:	81 fb f4 4e 11 80    	cmp    $0x80114ef4,%ebx
80104b71:	74 1b                	je     80104b8e <wait+0x5e>
      if(p->parent != curproc)
80104b73:	39 73 14             	cmp    %esi,0x14(%ebx)
80104b76:	75 f0                	jne    80104b68 <wait+0x38>
      if(p->state == ZOMBIE){
80104b78:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80104b7c:	74 62                	je     80104be0 <wait+0xb0>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104b7e:	83 c3 7c             	add    $0x7c,%ebx
      havekids = 1;
80104b81:	b8 01 00 00 00       	mov    $0x1,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104b86:	81 fb f4 4e 11 80    	cmp    $0x80114ef4,%ebx
80104b8c:	75 e5                	jne    80104b73 <wait+0x43>
    if(!havekids || curproc->killed){
80104b8e:	85 c0                	test   %eax,%eax
80104b90:	0f 84 a0 00 00 00    	je     80104c36 <wait+0x106>
80104b96:	8b 46 24             	mov    0x24(%esi),%eax
80104b99:	85 c0                	test   %eax,%eax
80104b9b:	0f 85 95 00 00 00    	jne    80104c36 <wait+0x106>
  pushcli();
80104ba1:	e8 3a 05 00 00       	call   801050e0 <pushcli>
  c = mycpu();
80104ba6:	e8 c5 f9 ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104bab:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104bb1:	e8 7a 05 00 00       	call   80105130 <popcli>
  if(p == 0)
80104bb6:	85 db                	test   %ebx,%ebx
80104bb8:	0f 84 8f 00 00 00    	je     80104c4d <wait+0x11d>
  p->chan = chan;
80104bbe:	89 73 20             	mov    %esi,0x20(%ebx)
  p->state = SLEEPING;
80104bc1:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104bc8:	e8 73 fd ff ff       	call   80104940 <sched>
  p->chan = 0;
80104bcd:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
80104bd4:	eb 84                	jmp    80104b5a <wait+0x2a>
80104bd6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104bdd:	00 
80104bde:	66 90                	xchg   %ax,%ax
        kfree(p->kstack);
80104be0:	83 ec 0c             	sub    $0xc,%esp
        pid = p->pid;
80104be3:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
80104be6:	ff 73 08             	push   0x8(%ebx)
80104be9:	e8 42 e5 ff ff       	call   80103130 <kfree>
        p->kstack = 0;
80104bee:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
80104bf5:	5a                   	pop    %edx
80104bf6:	ff 73 04             	push   0x4(%ebx)
80104bf9:	e8 32 2e 00 00       	call   80107a30 <freevm>
        p->pid = 0;
80104bfe:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
80104c05:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
80104c0c:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80104c10:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
80104c17:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
80104c1e:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104c25:	e8 a6 05 00 00       	call   801051d0 <release>
        return pid;
80104c2a:	83 c4 10             	add    $0x10,%esp
}
80104c2d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104c30:	89 f0                	mov    %esi,%eax
80104c32:	5b                   	pop    %ebx
80104c33:	5e                   	pop    %esi
80104c34:	5d                   	pop    %ebp
80104c35:	c3                   	ret
      release(&ptable.lock);
80104c36:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104c39:	be ff ff ff ff       	mov    $0xffffffff,%esi
      release(&ptable.lock);
80104c3e:	68 c0 2f 11 80       	push   $0x80112fc0
80104c43:	e8 88 05 00 00       	call   801051d0 <release>
      return -1;
80104c48:	83 c4 10             	add    $0x10,%esp
80104c4b:	eb e0                	jmp    80104c2d <wait+0xfd>
    panic("sleep");
80104c4d:	83 ec 0c             	sub    $0xc,%esp
80104c50:	68 db 80 10 80       	push   $0x801080db
80104c55:	e8 26 b7 ff ff       	call   80100380 <panic>
80104c5a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104c60 <yield>:
{
80104c60:	55                   	push   %ebp
80104c61:	89 e5                	mov    %esp,%ebp
80104c63:	53                   	push   %ebx
80104c64:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
80104c67:	68 c0 2f 11 80       	push   $0x80112fc0
80104c6c:	e8 bf 05 00 00       	call   80105230 <acquire>
  pushcli();
80104c71:	e8 6a 04 00 00       	call   801050e0 <pushcli>
  c = mycpu();
80104c76:	e8 f5 f8 ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104c7b:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104c81:	e8 aa 04 00 00       	call   80105130 <popcli>
  myproc()->state = RUNNABLE;
80104c86:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  sched();
80104c8d:	e8 ae fc ff ff       	call   80104940 <sched>
  release(&ptable.lock);
80104c92:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104c99:	e8 32 05 00 00       	call   801051d0 <release>
}
80104c9e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ca1:	83 c4 10             	add    $0x10,%esp
80104ca4:	c9                   	leave
80104ca5:	c3                   	ret
80104ca6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104cad:	00 
80104cae:	66 90                	xchg   %ax,%ax

80104cb0 <sleep>:
{
80104cb0:	55                   	push   %ebp
80104cb1:	89 e5                	mov    %esp,%ebp
80104cb3:	57                   	push   %edi
80104cb4:	56                   	push   %esi
80104cb5:	53                   	push   %ebx
80104cb6:	83 ec 0c             	sub    $0xc,%esp
80104cb9:	8b 7d 08             	mov    0x8(%ebp),%edi
80104cbc:	8b 75 0c             	mov    0xc(%ebp),%esi
  pushcli();
80104cbf:	e8 1c 04 00 00       	call   801050e0 <pushcli>
  c = mycpu();
80104cc4:	e8 a7 f8 ff ff       	call   80104570 <mycpu>
  p = c->proc;
80104cc9:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80104ccf:	e8 5c 04 00 00       	call   80105130 <popcli>
  if(p == 0)
80104cd4:	85 db                	test   %ebx,%ebx
80104cd6:	0f 84 87 00 00 00    	je     80104d63 <sleep+0xb3>
  if(lk == 0)
80104cdc:	85 f6                	test   %esi,%esi
80104cde:	74 76                	je     80104d56 <sleep+0xa6>
  if(lk != &ptable.lock){  //DOC: sleeplock0
80104ce0:	81 fe c0 2f 11 80    	cmp    $0x80112fc0,%esi
80104ce6:	74 50                	je     80104d38 <sleep+0x88>
    acquire(&ptable.lock);  //DOC: sleeplock1
80104ce8:	83 ec 0c             	sub    $0xc,%esp
80104ceb:	68 c0 2f 11 80       	push   $0x80112fc0
80104cf0:	e8 3b 05 00 00       	call   80105230 <acquire>
    release(lk);
80104cf5:	89 34 24             	mov    %esi,(%esp)
80104cf8:	e8 d3 04 00 00       	call   801051d0 <release>
  p->chan = chan;
80104cfd:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104d00:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104d07:	e8 34 fc ff ff       	call   80104940 <sched>
  p->chan = 0;
80104d0c:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80104d13:	c7 04 24 c0 2f 11 80 	movl   $0x80112fc0,(%esp)
80104d1a:	e8 b1 04 00 00       	call   801051d0 <release>
    acquire(lk);
80104d1f:	83 c4 10             	add    $0x10,%esp
80104d22:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104d25:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104d28:	5b                   	pop    %ebx
80104d29:	5e                   	pop    %esi
80104d2a:	5f                   	pop    %edi
80104d2b:	5d                   	pop    %ebp
    acquire(lk);
80104d2c:	e9 ff 04 00 00       	jmp    80105230 <acquire>
80104d31:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  p->chan = chan;
80104d38:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104d3b:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104d42:	e8 f9 fb ff ff       	call   80104940 <sched>
  p->chan = 0;
80104d47:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
80104d4e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104d51:	5b                   	pop    %ebx
80104d52:	5e                   	pop    %esi
80104d53:	5f                   	pop    %edi
80104d54:	5d                   	pop    %ebp
80104d55:	c3                   	ret
    panic("sleep without lk");
80104d56:	83 ec 0c             	sub    $0xc,%esp
80104d59:	68 e1 80 10 80       	push   $0x801080e1
80104d5e:	e8 1d b6 ff ff       	call   80100380 <panic>
    panic("sleep");
80104d63:	83 ec 0c             	sub    $0xc,%esp
80104d66:	68 db 80 10 80       	push   $0x801080db
80104d6b:	e8 10 b6 ff ff       	call   80100380 <panic>

80104d70 <wakeup>:
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
80104d70:	55                   	push   %ebp
80104d71:	89 e5                	mov    %esp,%ebp
80104d73:	53                   	push   %ebx
80104d74:	83 ec 10             	sub    $0x10,%esp
80104d77:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ptable.lock);
80104d7a:	68 c0 2f 11 80       	push   $0x80112fc0
80104d7f:	e8 ac 04 00 00       	call   80105230 <acquire>
80104d84:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104d87:	b8 f4 2f 11 80       	mov    $0x80112ff4,%eax
80104d8c:	eb 0c                	jmp    80104d9a <wakeup+0x2a>
80104d8e:	66 90                	xchg   %ax,%ax
80104d90:	83 c0 7c             	add    $0x7c,%eax
80104d93:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104d98:	74 1c                	je     80104db6 <wakeup+0x46>
    if(p->state == SLEEPING && p->chan == chan)
80104d9a:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80104d9e:	75 f0                	jne    80104d90 <wakeup+0x20>
80104da0:	3b 58 20             	cmp    0x20(%eax),%ebx
80104da3:	75 eb                	jne    80104d90 <wakeup+0x20>
      p->state = RUNNABLE;
80104da5:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80104dac:	83 c0 7c             	add    $0x7c,%eax
80104daf:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104db4:	75 e4                	jne    80104d9a <wakeup+0x2a>
  wakeup1(chan);
  release(&ptable.lock);
80104db6:	c7 45 08 c0 2f 11 80 	movl   $0x80112fc0,0x8(%ebp)
}
80104dbd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104dc0:	c9                   	leave
  release(&ptable.lock);
80104dc1:	e9 0a 04 00 00       	jmp    801051d0 <release>
80104dc6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104dcd:	00 
80104dce:	66 90                	xchg   %ax,%ax

80104dd0 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
80104dd0:	55                   	push   %ebp
80104dd1:	89 e5                	mov    %esp,%ebp
80104dd3:	53                   	push   %ebx
80104dd4:	83 ec 10             	sub    $0x10,%esp
80104dd7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
80104dda:	68 c0 2f 11 80       	push   $0x80112fc0
80104ddf:	e8 4c 04 00 00       	call   80105230 <acquire>
80104de4:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104de7:	b8 f4 2f 11 80       	mov    $0x80112ff4,%eax
80104dec:	eb 0c                	jmp    80104dfa <kill+0x2a>
80104dee:	66 90                	xchg   %ax,%ax
80104df0:	83 c0 7c             	add    $0x7c,%eax
80104df3:	3d f4 4e 11 80       	cmp    $0x80114ef4,%eax
80104df8:	74 36                	je     80104e30 <kill+0x60>
    if(p->pid == pid){
80104dfa:	39 58 10             	cmp    %ebx,0x10(%eax)
80104dfd:	75 f1                	jne    80104df0 <kill+0x20>
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
80104dff:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
      p->killed = 1;
80104e03:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      if(p->state == SLEEPING)
80104e0a:	75 07                	jne    80104e13 <kill+0x43>
        p->state = RUNNABLE;
80104e0c:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104e13:	83 ec 0c             	sub    $0xc,%esp
80104e16:	68 c0 2f 11 80       	push   $0x80112fc0
80104e1b:	e8 b0 03 00 00       	call   801051d0 <release>
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}
80104e20:	8b 5d fc             	mov    -0x4(%ebp),%ebx
      return 0;
80104e23:	83 c4 10             	add    $0x10,%esp
80104e26:	31 c0                	xor    %eax,%eax
}
80104e28:	c9                   	leave
80104e29:	c3                   	ret
80104e2a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
80104e30:	83 ec 0c             	sub    $0xc,%esp
80104e33:	68 c0 2f 11 80       	push   $0x80112fc0
80104e38:	e8 93 03 00 00       	call   801051d0 <release>
}
80104e3d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
80104e40:	83 c4 10             	add    $0x10,%esp
80104e43:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104e48:	c9                   	leave
80104e49:	c3                   	ret
80104e4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104e50 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80104e50:	55                   	push   %ebp
80104e51:	89 e5                	mov    %esp,%ebp
80104e53:	57                   	push   %edi
80104e54:	56                   	push   %esi
80104e55:	8d 75 e8             	lea    -0x18(%ebp),%esi
80104e58:	53                   	push   %ebx
80104e59:	bb 60 30 11 80       	mov    $0x80113060,%ebx
80104e5e:	83 ec 3c             	sub    $0x3c,%esp
80104e61:	eb 24                	jmp    80104e87 <procdump+0x37>
80104e63:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
80104e68:	83 ec 0c             	sub    $0xc,%esp
80104e6b:	68 a0 82 10 80       	push   $0x801082a0
80104e70:	e8 6b be ff ff       	call   80100ce0 <cprintf>
80104e75:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104e78:	83 c3 7c             	add    $0x7c,%ebx
80104e7b:	81 fb 60 4f 11 80    	cmp    $0x80114f60,%ebx
80104e81:	0f 84 81 00 00 00    	je     80104f08 <procdump+0xb8>
    if(p->state == UNUSED)
80104e87:	8b 43 a0             	mov    -0x60(%ebx),%eax
80104e8a:	85 c0                	test   %eax,%eax
80104e8c:	74 ea                	je     80104e78 <procdump+0x28>
      state = "???";
80104e8e:	ba f2 80 10 80       	mov    $0x801080f2,%edx
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80104e93:	83 f8 05             	cmp    $0x5,%eax
80104e96:	77 11                	ja     80104ea9 <procdump+0x59>
80104e98:	8b 14 85 80 87 10 80 	mov    -0x7fef7880(,%eax,4),%edx
      state = "???";
80104e9f:	b8 f2 80 10 80       	mov    $0x801080f2,%eax
80104ea4:	85 d2                	test   %edx,%edx
80104ea6:	0f 44 d0             	cmove  %eax,%edx
    cprintf("%d %s %s", p->pid, state, p->name);
80104ea9:	53                   	push   %ebx
80104eaa:	52                   	push   %edx
80104eab:	ff 73 a4             	push   -0x5c(%ebx)
80104eae:	68 f6 80 10 80       	push   $0x801080f6
80104eb3:	e8 28 be ff ff       	call   80100ce0 <cprintf>
    if(p->state == SLEEPING){
80104eb8:	83 c4 10             	add    $0x10,%esp
80104ebb:	83 7b a0 02          	cmpl   $0x2,-0x60(%ebx)
80104ebf:	75 a7                	jne    80104e68 <procdump+0x18>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80104ec1:	83 ec 08             	sub    $0x8,%esp
80104ec4:	8d 45 c0             	lea    -0x40(%ebp),%eax
80104ec7:	8d 7d c0             	lea    -0x40(%ebp),%edi
80104eca:	50                   	push   %eax
80104ecb:	8b 43 b0             	mov    -0x50(%ebx),%eax
80104ece:	8b 40 0c             	mov    0xc(%eax),%eax
80104ed1:	83 c0 08             	add    $0x8,%eax
80104ed4:	50                   	push   %eax
80104ed5:	e8 86 01 00 00       	call   80105060 <getcallerpcs>
      for(i=0; i<10 && pc[i] != 0; i++)
80104eda:	83 c4 10             	add    $0x10,%esp
80104edd:	8d 76 00             	lea    0x0(%esi),%esi
80104ee0:	8b 17                	mov    (%edi),%edx
80104ee2:	85 d2                	test   %edx,%edx
80104ee4:	74 82                	je     80104e68 <procdump+0x18>
        cprintf(" %p", pc[i]);
80104ee6:	83 ec 08             	sub    $0x8,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80104ee9:	83 c7 04             	add    $0x4,%edi
        cprintf(" %p", pc[i]);
80104eec:	52                   	push   %edx
80104eed:	68 41 7e 10 80       	push   $0x80107e41
80104ef2:	e8 e9 bd ff ff       	call   80100ce0 <cprintf>
      for(i=0; i<10 && pc[i] != 0; i++)
80104ef7:	83 c4 10             	add    $0x10,%esp
80104efa:	39 f7                	cmp    %esi,%edi
80104efc:	75 e2                	jne    80104ee0 <procdump+0x90>
80104efe:	e9 65 ff ff ff       	jmp    80104e68 <procdump+0x18>
80104f03:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  }
}
80104f08:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104f0b:	5b                   	pop    %ebx
80104f0c:	5e                   	pop    %esi
80104f0d:	5f                   	pop    %edi
80104f0e:	5d                   	pop    %ebp
80104f0f:	c3                   	ret

80104f10 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80104f10:	55                   	push   %ebp
80104f11:	89 e5                	mov    %esp,%ebp
80104f13:	53                   	push   %ebx
80104f14:	83 ec 0c             	sub    $0xc,%esp
80104f17:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
80104f1a:	68 29 81 10 80       	push   $0x80108129
80104f1f:	8d 43 04             	lea    0x4(%ebx),%eax
80104f22:	50                   	push   %eax
80104f23:	e8 18 01 00 00       	call   80105040 <initlock>
  lk->name = name;
80104f28:	8b 45 0c             	mov    0xc(%ebp),%eax
  lk->locked = 0;
80104f2b:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
}
80104f31:	83 c4 10             	add    $0x10,%esp
  lk->pid = 0;
80104f34:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  lk->name = name;
80104f3b:	89 43 38             	mov    %eax,0x38(%ebx)
}
80104f3e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104f41:	c9                   	leave
80104f42:	c3                   	ret
80104f43:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104f4a:	00 
80104f4b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104f50 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104f50:	55                   	push   %ebp
80104f51:	89 e5                	mov    %esp,%ebp
80104f53:	56                   	push   %esi
80104f54:	53                   	push   %ebx
80104f55:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104f58:	8d 73 04             	lea    0x4(%ebx),%esi
80104f5b:	83 ec 0c             	sub    $0xc,%esp
80104f5e:	56                   	push   %esi
80104f5f:	e8 cc 02 00 00       	call   80105230 <acquire>
  while (lk->locked) {
80104f64:	8b 13                	mov    (%ebx),%edx
80104f66:	83 c4 10             	add    $0x10,%esp
80104f69:	85 d2                	test   %edx,%edx
80104f6b:	74 16                	je     80104f83 <acquiresleep+0x33>
80104f6d:	8d 76 00             	lea    0x0(%esi),%esi
    sleep(lk, &lk->lk);
80104f70:	83 ec 08             	sub    $0x8,%esp
80104f73:	56                   	push   %esi
80104f74:	53                   	push   %ebx
80104f75:	e8 36 fd ff ff       	call   80104cb0 <sleep>
  while (lk->locked) {
80104f7a:	8b 03                	mov    (%ebx),%eax
80104f7c:	83 c4 10             	add    $0x10,%esp
80104f7f:	85 c0                	test   %eax,%eax
80104f81:	75 ed                	jne    80104f70 <acquiresleep+0x20>
  }
  lk->locked = 1;
80104f83:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
80104f89:	e8 62 f6 ff ff       	call   801045f0 <myproc>
80104f8e:	8b 40 10             	mov    0x10(%eax),%eax
80104f91:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
80104f94:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104f97:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104f9a:	5b                   	pop    %ebx
80104f9b:	5e                   	pop    %esi
80104f9c:	5d                   	pop    %ebp
  release(&lk->lk);
80104f9d:	e9 2e 02 00 00       	jmp    801051d0 <release>
80104fa2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104fa9:	00 
80104faa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104fb0 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80104fb0:	55                   	push   %ebp
80104fb1:	89 e5                	mov    %esp,%ebp
80104fb3:	56                   	push   %esi
80104fb4:	53                   	push   %ebx
80104fb5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104fb8:	8d 73 04             	lea    0x4(%ebx),%esi
80104fbb:	83 ec 0c             	sub    $0xc,%esp
80104fbe:	56                   	push   %esi
80104fbf:	e8 6c 02 00 00       	call   80105230 <acquire>
  lk->locked = 0;
80104fc4:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80104fca:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
80104fd1:	89 1c 24             	mov    %ebx,(%esp)
80104fd4:	e8 97 fd ff ff       	call   80104d70 <wakeup>
  release(&lk->lk);
80104fd9:	83 c4 10             	add    $0x10,%esp
80104fdc:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104fdf:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104fe2:	5b                   	pop    %ebx
80104fe3:	5e                   	pop    %esi
80104fe4:	5d                   	pop    %ebp
  release(&lk->lk);
80104fe5:	e9 e6 01 00 00       	jmp    801051d0 <release>
80104fea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104ff0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80104ff0:	55                   	push   %ebp
80104ff1:	89 e5                	mov    %esp,%ebp
80104ff3:	57                   	push   %edi
80104ff4:	31 ff                	xor    %edi,%edi
80104ff6:	56                   	push   %esi
80104ff7:	53                   	push   %ebx
80104ff8:	83 ec 18             	sub    $0x18,%esp
80104ffb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
80104ffe:	8d 73 04             	lea    0x4(%ebx),%esi
80105001:	56                   	push   %esi
80105002:	e8 29 02 00 00       	call   80105230 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
80105007:	8b 03                	mov    (%ebx),%eax
80105009:	83 c4 10             	add    $0x10,%esp
8010500c:	85 c0                	test   %eax,%eax
8010500e:	75 18                	jne    80105028 <holdingsleep+0x38>
  release(&lk->lk);
80105010:	83 ec 0c             	sub    $0xc,%esp
80105013:	56                   	push   %esi
80105014:	e8 b7 01 00 00       	call   801051d0 <release>
  return r;
}
80105019:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010501c:	89 f8                	mov    %edi,%eax
8010501e:	5b                   	pop    %ebx
8010501f:	5e                   	pop    %esi
80105020:	5f                   	pop    %edi
80105021:	5d                   	pop    %ebp
80105022:	c3                   	ret
80105023:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lk->locked && (lk->pid == myproc()->pid);
80105028:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
8010502b:	e8 c0 f5 ff ff       	call   801045f0 <myproc>
80105030:	39 58 10             	cmp    %ebx,0x10(%eax)
80105033:	0f 94 c0             	sete   %al
80105036:	0f b6 c0             	movzbl %al,%eax
80105039:	89 c7                	mov    %eax,%edi
8010503b:	eb d3                	jmp    80105010 <holdingsleep+0x20>
8010503d:	66 90                	xchg   %ax,%ax
8010503f:	90                   	nop

80105040 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80105040:	55                   	push   %ebp
80105041:	89 e5                	mov    %esp,%ebp
80105043:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80105046:	8b 55 0c             	mov    0xc(%ebp),%edx
  lk->locked = 0;
80105049:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->name = name;
8010504f:	89 50 04             	mov    %edx,0x4(%eax)
  lk->cpu = 0;
80105052:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80105059:	5d                   	pop    %ebp
8010505a:	c3                   	ret
8010505b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105060 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80105060:	55                   	push   %ebp
80105061:	89 e5                	mov    %esp,%ebp
80105063:	53                   	push   %ebx
80105064:	8b 45 08             	mov    0x8(%ebp),%eax
80105067:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
8010506a:	8d 50 f8             	lea    -0x8(%eax),%edx
  for(i = 0; i < 10; i++){
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
8010506d:	05 f8 ff ff 7f       	add    $0x7ffffff8,%eax
80105072:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
  for(i = 0; i < 10; i++){
80105077:	b8 00 00 00 00       	mov    $0x0,%eax
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
8010507c:	76 10                	jbe    8010508e <getcallerpcs+0x2e>
8010507e:	eb 28                	jmp    801050a8 <getcallerpcs+0x48>
80105080:	8d 9a 00 00 00 80    	lea    -0x80000000(%edx),%ebx
80105086:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
8010508c:	77 1a                	ja     801050a8 <getcallerpcs+0x48>
      break;
    pcs[i] = ebp[1];     // saved %eip
8010508e:	8b 5a 04             	mov    0x4(%edx),%ebx
80105091:	89 1c 81             	mov    %ebx,(%ecx,%eax,4)
  for(i = 0; i < 10; i++){
80105094:	83 c0 01             	add    $0x1,%eax
    ebp = (uint*)ebp[0]; // saved %ebp
80105097:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
80105099:	83 f8 0a             	cmp    $0xa,%eax
8010509c:	75 e2                	jne    80105080 <getcallerpcs+0x20>
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}
8010509e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801050a1:	c9                   	leave
801050a2:	c3                   	ret
801050a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801050a8:	8d 04 81             	lea    (%ecx,%eax,4),%eax
801050ab:	83 c1 28             	add    $0x28,%ecx
801050ae:	89 ca                	mov    %ecx,%edx
801050b0:	29 c2                	sub    %eax,%edx
801050b2:	83 e2 04             	and    $0x4,%edx
801050b5:	74 11                	je     801050c8 <getcallerpcs+0x68>
    pcs[i] = 0;
801050b7:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801050bd:	83 c0 04             	add    $0x4,%eax
801050c0:	39 c1                	cmp    %eax,%ecx
801050c2:	74 da                	je     8010509e <getcallerpcs+0x3e>
801050c4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    pcs[i] = 0;
801050c8:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801050ce:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
801050d1:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
801050d8:	39 c1                	cmp    %eax,%ecx
801050da:	75 ec                	jne    801050c8 <getcallerpcs+0x68>
801050dc:	eb c0                	jmp    8010509e <getcallerpcs+0x3e>
801050de:	66 90                	xchg   %ax,%ax

801050e0 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
801050e0:	55                   	push   %ebp
801050e1:	89 e5                	mov    %esp,%ebp
801050e3:	53                   	push   %ebx
801050e4:	83 ec 04             	sub    $0x4,%esp
801050e7:	9c                   	pushf
801050e8:	5b                   	pop    %ebx
  asm volatile("cli");
801050e9:	fa                   	cli
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
801050ea:	e8 81 f4 ff ff       	call   80104570 <mycpu>
801050ef:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
801050f5:	85 c0                	test   %eax,%eax
801050f7:	74 17                	je     80105110 <pushcli+0x30>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
801050f9:	e8 72 f4 ff ff       	call   80104570 <mycpu>
801050fe:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80105105:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105108:	c9                   	leave
80105109:	c3                   	ret
8010510a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    mycpu()->intena = eflags & FL_IF;
80105110:	e8 5b f4 ff ff       	call   80104570 <mycpu>
80105115:	81 e3 00 02 00 00    	and    $0x200,%ebx
8010511b:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80105121:	eb d6                	jmp    801050f9 <pushcli+0x19>
80105123:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010512a:	00 
8010512b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105130 <popcli>:

void
popcli(void)
{
80105130:	55                   	push   %ebp
80105131:	89 e5                	mov    %esp,%ebp
80105133:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80105136:	9c                   	pushf
80105137:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80105138:	f6 c4 02             	test   $0x2,%ah
8010513b:	75 35                	jne    80105172 <popcli+0x42>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
8010513d:	e8 2e f4 ff ff       	call   80104570 <mycpu>
80105142:	83 a8 a4 00 00 00 01 	subl   $0x1,0xa4(%eax)
80105149:	78 34                	js     8010517f <popcli+0x4f>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
8010514b:	e8 20 f4 ff ff       	call   80104570 <mycpu>
80105150:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80105156:	85 d2                	test   %edx,%edx
80105158:	74 06                	je     80105160 <popcli+0x30>
    sti();
}
8010515a:	c9                   	leave
8010515b:	c3                   	ret
8010515c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(mycpu()->ncli == 0 && mycpu()->intena)
80105160:	e8 0b f4 ff ff       	call   80104570 <mycpu>
80105165:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
8010516b:	85 c0                	test   %eax,%eax
8010516d:	74 eb                	je     8010515a <popcli+0x2a>
  asm volatile("sti");
8010516f:	fb                   	sti
}
80105170:	c9                   	leave
80105171:	c3                   	ret
    panic("popcli - interruptible");
80105172:	83 ec 0c             	sub    $0xc,%esp
80105175:	68 34 81 10 80       	push   $0x80108134
8010517a:	e8 01 b2 ff ff       	call   80100380 <panic>
    panic("popcli");
8010517f:	83 ec 0c             	sub    $0xc,%esp
80105182:	68 4b 81 10 80       	push   $0x8010814b
80105187:	e8 f4 b1 ff ff       	call   80100380 <panic>
8010518c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105190 <holding>:
{
80105190:	55                   	push   %ebp
80105191:	89 e5                	mov    %esp,%ebp
80105193:	56                   	push   %esi
80105194:	53                   	push   %ebx
80105195:	8b 75 08             	mov    0x8(%ebp),%esi
80105198:	31 db                	xor    %ebx,%ebx
  pushcli();
8010519a:	e8 41 ff ff ff       	call   801050e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
8010519f:	8b 06                	mov    (%esi),%eax
801051a1:	85 c0                	test   %eax,%eax
801051a3:	75 0b                	jne    801051b0 <holding+0x20>
  popcli();
801051a5:	e8 86 ff ff ff       	call   80105130 <popcli>
}
801051aa:	89 d8                	mov    %ebx,%eax
801051ac:	5b                   	pop    %ebx
801051ad:	5e                   	pop    %esi
801051ae:	5d                   	pop    %ebp
801051af:	c3                   	ret
  r = lock->locked && lock->cpu == mycpu();
801051b0:	8b 5e 08             	mov    0x8(%esi),%ebx
801051b3:	e8 b8 f3 ff ff       	call   80104570 <mycpu>
801051b8:	39 c3                	cmp    %eax,%ebx
801051ba:	0f 94 c3             	sete   %bl
  popcli();
801051bd:	e8 6e ff ff ff       	call   80105130 <popcli>
  r = lock->locked && lock->cpu == mycpu();
801051c2:	0f b6 db             	movzbl %bl,%ebx
}
801051c5:	89 d8                	mov    %ebx,%eax
801051c7:	5b                   	pop    %ebx
801051c8:	5e                   	pop    %esi
801051c9:	5d                   	pop    %ebp
801051ca:	c3                   	ret
801051cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801051d0 <release>:
{
801051d0:	55                   	push   %ebp
801051d1:	89 e5                	mov    %esp,%ebp
801051d3:	56                   	push   %esi
801051d4:	53                   	push   %ebx
801051d5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
801051d8:	e8 03 ff ff ff       	call   801050e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
801051dd:	8b 03                	mov    (%ebx),%eax
801051df:	85 c0                	test   %eax,%eax
801051e1:	75 15                	jne    801051f8 <release+0x28>
  popcli();
801051e3:	e8 48 ff ff ff       	call   80105130 <popcli>
    panic("release");
801051e8:	83 ec 0c             	sub    $0xc,%esp
801051eb:	68 52 81 10 80       	push   $0x80108152
801051f0:	e8 8b b1 ff ff       	call   80100380 <panic>
801051f5:	8d 76 00             	lea    0x0(%esi),%esi
  r = lock->locked && lock->cpu == mycpu();
801051f8:	8b 73 08             	mov    0x8(%ebx),%esi
801051fb:	e8 70 f3 ff ff       	call   80104570 <mycpu>
80105200:	39 c6                	cmp    %eax,%esi
80105202:	75 df                	jne    801051e3 <release+0x13>
  popcli();
80105204:	e8 27 ff ff ff       	call   80105130 <popcli>
  lk->pcs[0] = 0;
80105209:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80105210:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80105217:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
8010521c:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
}
80105222:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105225:	5b                   	pop    %ebx
80105226:	5e                   	pop    %esi
80105227:	5d                   	pop    %ebp
  popcli();
80105228:	e9 03 ff ff ff       	jmp    80105130 <popcli>
8010522d:	8d 76 00             	lea    0x0(%esi),%esi

80105230 <acquire>:
{
80105230:	55                   	push   %ebp
80105231:	89 e5                	mov    %esp,%ebp
80105233:	53                   	push   %ebx
80105234:	83 ec 04             	sub    $0x4,%esp
  pushcli(); // disable interrupts to avoid deadlock.
80105237:	e8 a4 fe ff ff       	call   801050e0 <pushcli>
  if(holding(lk))
8010523c:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
8010523f:	e8 9c fe ff ff       	call   801050e0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80105244:	8b 03                	mov    (%ebx),%eax
80105246:	85 c0                	test   %eax,%eax
80105248:	0f 85 b2 00 00 00    	jne    80105300 <acquire+0xd0>
  popcli();
8010524e:	e8 dd fe ff ff       	call   80105130 <popcli>
  asm volatile("lock; xchgl %0, %1" :
80105253:	b9 01 00 00 00       	mov    $0x1,%ecx
80105258:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010525f:	00 
  while(xchg(&lk->locked, 1) != 0)
80105260:	8b 55 08             	mov    0x8(%ebp),%edx
80105263:	89 c8                	mov    %ecx,%eax
80105265:	f0 87 02             	lock xchg %eax,(%edx)
80105268:	85 c0                	test   %eax,%eax
8010526a:	75 f4                	jne    80105260 <acquire+0x30>
  __sync_synchronize();
8010526c:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80105271:	8b 5d 08             	mov    0x8(%ebp),%ebx
80105274:	e8 f7 f2 ff ff       	call   80104570 <mycpu>
  getcallerpcs(&lk, lk->pcs);
80105279:	8b 4d 08             	mov    0x8(%ebp),%ecx
  for(i = 0; i < 10; i++){
8010527c:	31 d2                	xor    %edx,%edx
  lk->cpu = mycpu();
8010527e:	89 43 08             	mov    %eax,0x8(%ebx)
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80105281:	8d 85 00 00 00 80    	lea    -0x80000000(%ebp),%eax
80105287:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
8010528c:	77 32                	ja     801052c0 <acquire+0x90>
  ebp = (uint*)v - 2;
8010528e:	89 e8                	mov    %ebp,%eax
80105290:	eb 14                	jmp    801052a6 <acquire+0x76>
80105292:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80105298:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
8010529e:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
801052a4:	77 1a                	ja     801052c0 <acquire+0x90>
    pcs[i] = ebp[1];     // saved %eip
801052a6:	8b 58 04             	mov    0x4(%eax),%ebx
801052a9:	89 5c 91 0c          	mov    %ebx,0xc(%ecx,%edx,4)
  for(i = 0; i < 10; i++){
801052ad:	83 c2 01             	add    $0x1,%edx
    ebp = (uint*)ebp[0]; // saved %ebp
801052b0:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
801052b2:	83 fa 0a             	cmp    $0xa,%edx
801052b5:	75 e1                	jne    80105298 <acquire+0x68>
}
801052b7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801052ba:	c9                   	leave
801052bb:	c3                   	ret
801052bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
801052c0:	8d 44 91 0c          	lea    0xc(%ecx,%edx,4),%eax
801052c4:	83 c1 34             	add    $0x34,%ecx
801052c7:	89 ca                	mov    %ecx,%edx
801052c9:	29 c2                	sub    %eax,%edx
801052cb:	83 e2 04             	and    $0x4,%edx
801052ce:	74 10                	je     801052e0 <acquire+0xb0>
    pcs[i] = 0;
801052d0:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801052d6:	83 c0 04             	add    $0x4,%eax
801052d9:	39 c1                	cmp    %eax,%ecx
801052db:	74 da                	je     801052b7 <acquire+0x87>
801052dd:	8d 76 00             	lea    0x0(%esi),%esi
    pcs[i] = 0;
801052e0:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801052e6:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
801052e9:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
801052f0:	39 c1                	cmp    %eax,%ecx
801052f2:	75 ec                	jne    801052e0 <acquire+0xb0>
801052f4:	eb c1                	jmp    801052b7 <acquire+0x87>
801052f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801052fd:	00 
801052fe:	66 90                	xchg   %ax,%ax
  r = lock->locked && lock->cpu == mycpu();
80105300:	8b 5b 08             	mov    0x8(%ebx),%ebx
80105303:	e8 68 f2 ff ff       	call   80104570 <mycpu>
80105308:	39 c3                	cmp    %eax,%ebx
8010530a:	0f 85 3e ff ff ff    	jne    8010524e <acquire+0x1e>
  popcli();
80105310:	e8 1b fe ff ff       	call   80105130 <popcli>
    panic("acquire");
80105315:	83 ec 0c             	sub    $0xc,%esp
80105318:	68 5a 81 10 80       	push   $0x8010815a
8010531d:	e8 5e b0 ff ff       	call   80100380 <panic>
80105322:	66 90                	xchg   %ax,%ax
80105324:	66 90                	xchg   %ax,%ax
80105326:	66 90                	xchg   %ax,%ax
80105328:	66 90                	xchg   %ax,%ax
8010532a:	66 90                	xchg   %ax,%ax
8010532c:	66 90                	xchg   %ax,%ax
8010532e:	66 90                	xchg   %ax,%ax

80105330 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
80105330:	55                   	push   %ebp
80105331:	89 e5                	mov    %esp,%ebp
80105333:	57                   	push   %edi
80105334:	8b 55 08             	mov    0x8(%ebp),%edx
80105337:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
8010533a:	89 d0                	mov    %edx,%eax
8010533c:	09 c8                	or     %ecx,%eax
8010533e:	a8 03                	test   $0x3,%al
80105340:	75 1e                	jne    80105360 <memset+0x30>
    c &= 0xFF;
80105342:	0f b6 45 0c          	movzbl 0xc(%ebp),%eax
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80105346:	c1 e9 02             	shr    $0x2,%ecx
  asm volatile("cld; rep stosl" :
80105349:	89 d7                	mov    %edx,%edi
8010534b:	69 c0 01 01 01 01    	imul   $0x1010101,%eax,%eax
80105351:	fc                   	cld
80105352:	f3 ab                	rep stos %eax,%es:(%edi)
  } else
    stosb(dst, c, n);
  return dst;
}
80105354:	8b 7d fc             	mov    -0x4(%ebp),%edi
80105357:	89 d0                	mov    %edx,%eax
80105359:	c9                   	leave
8010535a:	c3                   	ret
8010535b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  asm volatile("cld; rep stosb" :
80105360:	8b 45 0c             	mov    0xc(%ebp),%eax
80105363:	89 d7                	mov    %edx,%edi
80105365:	fc                   	cld
80105366:	f3 aa                	rep stos %al,%es:(%edi)
80105368:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010536b:	89 d0                	mov    %edx,%eax
8010536d:	c9                   	leave
8010536e:	c3                   	ret
8010536f:	90                   	nop

80105370 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80105370:	55                   	push   %ebp
80105371:	89 e5                	mov    %esp,%ebp
80105373:	56                   	push   %esi
80105374:	8b 75 10             	mov    0x10(%ebp),%esi
80105377:	8b 45 08             	mov    0x8(%ebp),%eax
8010537a:	53                   	push   %ebx
8010537b:	8b 55 0c             	mov    0xc(%ebp),%edx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
8010537e:	85 f6                	test   %esi,%esi
80105380:	74 2e                	je     801053b0 <memcmp+0x40>
80105382:	01 c6                	add    %eax,%esi
80105384:	eb 14                	jmp    8010539a <memcmp+0x2a>
80105386:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010538d:	00 
8010538e:	66 90                	xchg   %ax,%ax
    if(*s1 != *s2)
      return *s1 - *s2;
    s1++, s2++;
80105390:	83 c0 01             	add    $0x1,%eax
80105393:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0){
80105396:	39 f0                	cmp    %esi,%eax
80105398:	74 16                	je     801053b0 <memcmp+0x40>
    if(*s1 != *s2)
8010539a:	0f b6 08             	movzbl (%eax),%ecx
8010539d:	0f b6 1a             	movzbl (%edx),%ebx
801053a0:	38 d9                	cmp    %bl,%cl
801053a2:	74 ec                	je     80105390 <memcmp+0x20>
      return *s1 - *s2;
801053a4:	0f b6 c1             	movzbl %cl,%eax
801053a7:	29 d8                	sub    %ebx,%eax
  }

  return 0;
}
801053a9:	5b                   	pop    %ebx
801053aa:	5e                   	pop    %esi
801053ab:	5d                   	pop    %ebp
801053ac:	c3                   	ret
801053ad:	8d 76 00             	lea    0x0(%esi),%esi
801053b0:	5b                   	pop    %ebx
  return 0;
801053b1:	31 c0                	xor    %eax,%eax
}
801053b3:	5e                   	pop    %esi
801053b4:	5d                   	pop    %ebp
801053b5:	c3                   	ret
801053b6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801053bd:	00 
801053be:	66 90                	xchg   %ax,%ax

801053c0 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
801053c0:	55                   	push   %ebp
801053c1:	89 e5                	mov    %esp,%ebp
801053c3:	57                   	push   %edi
801053c4:	8b 55 08             	mov    0x8(%ebp),%edx
801053c7:	8b 45 10             	mov    0x10(%ebp),%eax
801053ca:	56                   	push   %esi
801053cb:	8b 75 0c             	mov    0xc(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
801053ce:	39 d6                	cmp    %edx,%esi
801053d0:	73 26                	jae    801053f8 <memmove+0x38>
801053d2:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
801053d5:	39 ca                	cmp    %ecx,%edx
801053d7:	73 1f                	jae    801053f8 <memmove+0x38>
    s += n;
    d += n;
    while(n-- > 0)
801053d9:	85 c0                	test   %eax,%eax
801053db:	74 0f                	je     801053ec <memmove+0x2c>
801053dd:	83 e8 01             	sub    $0x1,%eax
      *--d = *--s;
801053e0:	0f b6 0c 06          	movzbl (%esi,%eax,1),%ecx
801053e4:	88 0c 02             	mov    %cl,(%edx,%eax,1)
    while(n-- > 0)
801053e7:	83 e8 01             	sub    $0x1,%eax
801053ea:	73 f4                	jae    801053e0 <memmove+0x20>
  } else
    while(n-- > 0)
      *d++ = *s++;

  return dst;
}
801053ec:	5e                   	pop    %esi
801053ed:	89 d0                	mov    %edx,%eax
801053ef:	5f                   	pop    %edi
801053f0:	5d                   	pop    %ebp
801053f1:	c3                   	ret
801053f2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    while(n-- > 0)
801053f8:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
801053fb:	89 d7                	mov    %edx,%edi
801053fd:	85 c0                	test   %eax,%eax
801053ff:	74 eb                	je     801053ec <memmove+0x2c>
80105401:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      *d++ = *s++;
80105408:	a4                   	movsb  %ds:(%esi),%es:(%edi)
    while(n-- > 0)
80105409:	39 ce                	cmp    %ecx,%esi
8010540b:	75 fb                	jne    80105408 <memmove+0x48>
}
8010540d:	5e                   	pop    %esi
8010540e:	89 d0                	mov    %edx,%eax
80105410:	5f                   	pop    %edi
80105411:	5d                   	pop    %ebp
80105412:	c3                   	ret
80105413:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010541a:	00 
8010541b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105420 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
80105420:	eb 9e                	jmp    801053c0 <memmove>
80105422:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105429:	00 
8010542a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105430 <strncmp>:
}

int
strncmp(const char *p, const char *q, uint n)
{
80105430:	55                   	push   %ebp
80105431:	89 e5                	mov    %esp,%ebp
80105433:	53                   	push   %ebx
80105434:	8b 55 10             	mov    0x10(%ebp),%edx
80105437:	8b 45 08             	mov    0x8(%ebp),%eax
8010543a:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(n > 0 && *p && *p == *q)
8010543d:	85 d2                	test   %edx,%edx
8010543f:	75 16                	jne    80105457 <strncmp+0x27>
80105441:	eb 2d                	jmp    80105470 <strncmp+0x40>
80105443:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80105448:	3a 19                	cmp    (%ecx),%bl
8010544a:	75 12                	jne    8010545e <strncmp+0x2e>
    n--, p++, q++;
8010544c:	83 c0 01             	add    $0x1,%eax
8010544f:	83 c1 01             	add    $0x1,%ecx
  while(n > 0 && *p && *p == *q)
80105452:	83 ea 01             	sub    $0x1,%edx
80105455:	74 19                	je     80105470 <strncmp+0x40>
80105457:	0f b6 18             	movzbl (%eax),%ebx
8010545a:	84 db                	test   %bl,%bl
8010545c:	75 ea                	jne    80105448 <strncmp+0x18>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
8010545e:	0f b6 00             	movzbl (%eax),%eax
80105461:	0f b6 11             	movzbl (%ecx),%edx
}
80105464:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105467:	c9                   	leave
  return (uchar)*p - (uchar)*q;
80105468:	29 d0                	sub    %edx,%eax
}
8010546a:	c3                   	ret
8010546b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80105470:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80105473:	31 c0                	xor    %eax,%eax
}
80105475:	c9                   	leave
80105476:	c3                   	ret
80105477:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010547e:	00 
8010547f:	90                   	nop

80105480 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80105480:	55                   	push   %ebp
80105481:	89 e5                	mov    %esp,%ebp
80105483:	57                   	push   %edi
80105484:	56                   	push   %esi
80105485:	8b 75 08             	mov    0x8(%ebp),%esi
80105488:	53                   	push   %ebx
80105489:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
8010548c:	89 f0                	mov    %esi,%eax
8010548e:	eb 15                	jmp    801054a5 <strncpy+0x25>
80105490:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
80105494:	8b 7d 0c             	mov    0xc(%ebp),%edi
80105497:	83 c0 01             	add    $0x1,%eax
8010549a:	0f b6 4f ff          	movzbl -0x1(%edi),%ecx
8010549e:	88 48 ff             	mov    %cl,-0x1(%eax)
801054a1:	84 c9                	test   %cl,%cl
801054a3:	74 13                	je     801054b8 <strncpy+0x38>
801054a5:	89 d3                	mov    %edx,%ebx
801054a7:	83 ea 01             	sub    $0x1,%edx
801054aa:	85 db                	test   %ebx,%ebx
801054ac:	7f e2                	jg     80105490 <strncpy+0x10>
    ;
  while(n-- > 0)
    *s++ = 0;
  return os;
}
801054ae:	5b                   	pop    %ebx
801054af:	89 f0                	mov    %esi,%eax
801054b1:	5e                   	pop    %esi
801054b2:	5f                   	pop    %edi
801054b3:	5d                   	pop    %ebp
801054b4:	c3                   	ret
801054b5:	8d 76 00             	lea    0x0(%esi),%esi
  while(n-- > 0)
801054b8:	8d 0c 18             	lea    (%eax,%ebx,1),%ecx
801054bb:	83 e9 01             	sub    $0x1,%ecx
801054be:	85 d2                	test   %edx,%edx
801054c0:	74 ec                	je     801054ae <strncpy+0x2e>
801054c2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    *s++ = 0;
801054c8:	83 c0 01             	add    $0x1,%eax
801054cb:	89 ca                	mov    %ecx,%edx
801054cd:	c6 40 ff 00          	movb   $0x0,-0x1(%eax)
  while(n-- > 0)
801054d1:	29 c2                	sub    %eax,%edx
801054d3:	85 d2                	test   %edx,%edx
801054d5:	7f f1                	jg     801054c8 <strncpy+0x48>
}
801054d7:	5b                   	pop    %ebx
801054d8:	89 f0                	mov    %esi,%eax
801054da:	5e                   	pop    %esi
801054db:	5f                   	pop    %edi
801054dc:	5d                   	pop    %ebp
801054dd:	c3                   	ret
801054de:	66 90                	xchg   %ax,%ax

801054e0 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
801054e0:	55                   	push   %ebp
801054e1:	89 e5                	mov    %esp,%ebp
801054e3:	56                   	push   %esi
801054e4:	8b 55 10             	mov    0x10(%ebp),%edx
801054e7:	8b 75 08             	mov    0x8(%ebp),%esi
801054ea:	53                   	push   %ebx
801054eb:	8b 45 0c             	mov    0xc(%ebp),%eax
  char *os;

  os = s;
  if(n <= 0)
801054ee:	85 d2                	test   %edx,%edx
801054f0:	7e 25                	jle    80105517 <safestrcpy+0x37>
801054f2:	8d 5c 10 ff          	lea    -0x1(%eax,%edx,1),%ebx
801054f6:	89 f2                	mov    %esi,%edx
801054f8:	eb 16                	jmp    80105510 <safestrcpy+0x30>
801054fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
80105500:	0f b6 08             	movzbl (%eax),%ecx
80105503:	83 c0 01             	add    $0x1,%eax
80105506:	83 c2 01             	add    $0x1,%edx
80105509:	88 4a ff             	mov    %cl,-0x1(%edx)
8010550c:	84 c9                	test   %cl,%cl
8010550e:	74 04                	je     80105514 <safestrcpy+0x34>
80105510:	39 d8                	cmp    %ebx,%eax
80105512:	75 ec                	jne    80105500 <safestrcpy+0x20>
    ;
  *s = 0;
80105514:	c6 02 00             	movb   $0x0,(%edx)
  return os;
}
80105517:	89 f0                	mov    %esi,%eax
80105519:	5b                   	pop    %ebx
8010551a:	5e                   	pop    %esi
8010551b:	5d                   	pop    %ebp
8010551c:	c3                   	ret
8010551d:	8d 76 00             	lea    0x0(%esi),%esi

80105520 <strlen>:

int
strlen(const char *s)
{
80105520:	55                   	push   %ebp
  int n;

  for(n = 0; s[n]; n++)
80105521:	31 c0                	xor    %eax,%eax
{
80105523:	89 e5                	mov    %esp,%ebp
80105525:	8b 55 08             	mov    0x8(%ebp),%edx
  for(n = 0; s[n]; n++)
80105528:	80 3a 00             	cmpb   $0x0,(%edx)
8010552b:	74 0c                	je     80105539 <strlen+0x19>
8010552d:	8d 76 00             	lea    0x0(%esi),%esi
80105530:	83 c0 01             	add    $0x1,%eax
80105533:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
80105537:	75 f7                	jne    80105530 <strlen+0x10>
    ;
  return n;
}
80105539:	5d                   	pop    %ebp
8010553a:	c3                   	ret

8010553b <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
8010553b:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
8010553f:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80105543:	55                   	push   %ebp
  pushl %ebx
80105544:	53                   	push   %ebx
  pushl %esi
80105545:	56                   	push   %esi
  pushl %edi
80105546:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
80105547:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
80105549:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
8010554b:	5f                   	pop    %edi
  popl %esi
8010554c:	5e                   	pop    %esi
  popl %ebx
8010554d:	5b                   	pop    %ebx
  popl %ebp
8010554e:	5d                   	pop    %ebp
  ret
8010554f:	c3                   	ret

80105550 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80105550:	55                   	push   %ebp
80105551:	89 e5                	mov    %esp,%ebp
80105553:	53                   	push   %ebx
80105554:	83 ec 04             	sub    $0x4,%esp
80105557:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
8010555a:	e8 91 f0 ff ff       	call   801045f0 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
8010555f:	8b 00                	mov    (%eax),%eax
80105561:	39 c3                	cmp    %eax,%ebx
80105563:	73 1b                	jae    80105580 <fetchint+0x30>
80105565:	8d 53 04             	lea    0x4(%ebx),%edx
80105568:	39 d0                	cmp    %edx,%eax
8010556a:	72 14                	jb     80105580 <fetchint+0x30>
    return -1;
  *ip = *(int*)(addr);
8010556c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010556f:	8b 13                	mov    (%ebx),%edx
80105571:	89 10                	mov    %edx,(%eax)
  return 0;
80105573:	31 c0                	xor    %eax,%eax
}
80105575:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105578:	c9                   	leave
80105579:	c3                   	ret
8010557a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80105580:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105585:	eb ee                	jmp    80105575 <fetchint+0x25>
80105587:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010558e:	00 
8010558f:	90                   	nop

80105590 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80105590:	55                   	push   %ebp
80105591:	89 e5                	mov    %esp,%ebp
80105593:	53                   	push   %ebx
80105594:	83 ec 04             	sub    $0x4,%esp
80105597:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
8010559a:	e8 51 f0 ff ff       	call   801045f0 <myproc>

  if(addr >= curproc->sz)
8010559f:	3b 18                	cmp    (%eax),%ebx
801055a1:	73 2d                	jae    801055d0 <fetchstr+0x40>
    return -1;
  *pp = (char*)addr;
801055a3:	8b 55 0c             	mov    0xc(%ebp),%edx
801055a6:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
801055a8:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
801055aa:	39 d3                	cmp    %edx,%ebx
801055ac:	73 22                	jae    801055d0 <fetchstr+0x40>
801055ae:	89 d8                	mov    %ebx,%eax
801055b0:	eb 0d                	jmp    801055bf <fetchstr+0x2f>
801055b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801055b8:	83 c0 01             	add    $0x1,%eax
801055bb:	39 d0                	cmp    %edx,%eax
801055bd:	73 11                	jae    801055d0 <fetchstr+0x40>
    if(*s == 0)
801055bf:	80 38 00             	cmpb   $0x0,(%eax)
801055c2:	75 f4                	jne    801055b8 <fetchstr+0x28>
      return s - *pp;
801055c4:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
801055c6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801055c9:	c9                   	leave
801055ca:	c3                   	ret
801055cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
801055d0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
801055d3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801055d8:	c9                   	leave
801055d9:	c3                   	ret
801055da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801055e0 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
801055e0:	55                   	push   %ebp
801055e1:	89 e5                	mov    %esp,%ebp
801055e3:	56                   	push   %esi
801055e4:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
801055e5:	e8 06 f0 ff ff       	call   801045f0 <myproc>
801055ea:	8b 55 08             	mov    0x8(%ebp),%edx
801055ed:	8b 40 18             	mov    0x18(%eax),%eax
801055f0:	8b 40 44             	mov    0x44(%eax),%eax
801055f3:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
801055f6:	e8 f5 ef ff ff       	call   801045f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
801055fb:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
801055fe:	8b 00                	mov    (%eax),%eax
80105600:	39 c6                	cmp    %eax,%esi
80105602:	73 1c                	jae    80105620 <argint+0x40>
80105604:	8d 53 08             	lea    0x8(%ebx),%edx
80105607:	39 d0                	cmp    %edx,%eax
80105609:	72 15                	jb     80105620 <argint+0x40>
  *ip = *(int*)(addr);
8010560b:	8b 45 0c             	mov    0xc(%ebp),%eax
8010560e:	8b 53 04             	mov    0x4(%ebx),%edx
80105611:	89 10                	mov    %edx,(%eax)
  return 0;
80105613:	31 c0                	xor    %eax,%eax
}
80105615:	5b                   	pop    %ebx
80105616:	5e                   	pop    %esi
80105617:	5d                   	pop    %ebp
80105618:	c3                   	ret
80105619:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80105620:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80105625:	eb ee                	jmp    80105615 <argint+0x35>
80105627:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010562e:	00 
8010562f:	90                   	nop

80105630 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80105630:	55                   	push   %ebp
80105631:	89 e5                	mov    %esp,%ebp
80105633:	57                   	push   %edi
80105634:	56                   	push   %esi
80105635:	53                   	push   %ebx
80105636:	83 ec 0c             	sub    $0xc,%esp
  int i;
  struct proc *curproc = myproc();
80105639:	e8 b2 ef ff ff       	call   801045f0 <myproc>
8010563e:	89 c6                	mov    %eax,%esi
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80105640:	e8 ab ef ff ff       	call   801045f0 <myproc>
80105645:	8b 55 08             	mov    0x8(%ebp),%edx
80105648:	8b 40 18             	mov    0x18(%eax),%eax
8010564b:	8b 40 44             	mov    0x44(%eax),%eax
8010564e:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80105651:	e8 9a ef ff ff       	call   801045f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80105656:	8d 7b 04             	lea    0x4(%ebx),%edi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80105659:	8b 00                	mov    (%eax),%eax
8010565b:	39 c7                	cmp    %eax,%edi
8010565d:	73 31                	jae    80105690 <argptr+0x60>
8010565f:	8d 4b 08             	lea    0x8(%ebx),%ecx
80105662:	39 c8                	cmp    %ecx,%eax
80105664:	72 2a                	jb     80105690 <argptr+0x60>
 
  if(argint(n, &i) < 0)
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80105666:	8b 55 10             	mov    0x10(%ebp),%edx
  *ip = *(int*)(addr);
80105669:	8b 43 04             	mov    0x4(%ebx),%eax
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
8010566c:	85 d2                	test   %edx,%edx
8010566e:	78 20                	js     80105690 <argptr+0x60>
80105670:	8b 16                	mov    (%esi),%edx
80105672:	39 d0                	cmp    %edx,%eax
80105674:	73 1a                	jae    80105690 <argptr+0x60>
80105676:	8b 5d 10             	mov    0x10(%ebp),%ebx
80105679:	01 c3                	add    %eax,%ebx
8010567b:	39 da                	cmp    %ebx,%edx
8010567d:	72 11                	jb     80105690 <argptr+0x60>
    return -1;
  *pp = (char*)i;
8010567f:	8b 55 0c             	mov    0xc(%ebp),%edx
80105682:	89 02                	mov    %eax,(%edx)
  return 0;
80105684:	31 c0                	xor    %eax,%eax
}
80105686:	83 c4 0c             	add    $0xc,%esp
80105689:	5b                   	pop    %ebx
8010568a:	5e                   	pop    %esi
8010568b:	5f                   	pop    %edi
8010568c:	5d                   	pop    %ebp
8010568d:	c3                   	ret
8010568e:	66 90                	xchg   %ax,%ax
    return -1;
80105690:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105695:	eb ef                	jmp    80105686 <argptr+0x56>
80105697:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010569e:	00 
8010569f:	90                   	nop

801056a0 <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
801056a0:	55                   	push   %ebp
801056a1:	89 e5                	mov    %esp,%ebp
801056a3:	56                   	push   %esi
801056a4:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
801056a5:	e8 46 ef ff ff       	call   801045f0 <myproc>
801056aa:	8b 55 08             	mov    0x8(%ebp),%edx
801056ad:	8b 40 18             	mov    0x18(%eax),%eax
801056b0:	8b 40 44             	mov    0x44(%eax),%eax
801056b3:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
801056b6:	e8 35 ef ff ff       	call   801045f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
801056bb:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
801056be:	8b 00                	mov    (%eax),%eax
801056c0:	39 c6                	cmp    %eax,%esi
801056c2:	73 44                	jae    80105708 <argstr+0x68>
801056c4:	8d 53 08             	lea    0x8(%ebx),%edx
801056c7:	39 d0                	cmp    %edx,%eax
801056c9:	72 3d                	jb     80105708 <argstr+0x68>
  *ip = *(int*)(addr);
801056cb:	8b 5b 04             	mov    0x4(%ebx),%ebx
  struct proc *curproc = myproc();
801056ce:	e8 1d ef ff ff       	call   801045f0 <myproc>
  if(addr >= curproc->sz)
801056d3:	3b 18                	cmp    (%eax),%ebx
801056d5:	73 31                	jae    80105708 <argstr+0x68>
  *pp = (char*)addr;
801056d7:	8b 55 0c             	mov    0xc(%ebp),%edx
801056da:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
801056dc:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
801056de:	39 d3                	cmp    %edx,%ebx
801056e0:	73 26                	jae    80105708 <argstr+0x68>
801056e2:	89 d8                	mov    %ebx,%eax
801056e4:	eb 11                	jmp    801056f7 <argstr+0x57>
801056e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801056ed:	00 
801056ee:	66 90                	xchg   %ax,%ax
801056f0:	83 c0 01             	add    $0x1,%eax
801056f3:	39 d0                	cmp    %edx,%eax
801056f5:	73 11                	jae    80105708 <argstr+0x68>
    if(*s == 0)
801056f7:	80 38 00             	cmpb   $0x0,(%eax)
801056fa:	75 f4                	jne    801056f0 <argstr+0x50>
      return s - *pp;
801056fc:	29 d8                	sub    %ebx,%eax
  int addr;
  if(argint(n, &addr) < 0)
    return -1;
  return fetchstr(addr, pp);
}
801056fe:	5b                   	pop    %ebx
801056ff:	5e                   	pop    %esi
80105700:	5d                   	pop    %ebp
80105701:	c3                   	ret
80105702:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80105708:	5b                   	pop    %ebx
    return -1;
80105709:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010570e:	5e                   	pop    %esi
8010570f:	5d                   	pop    %ebp
80105710:	c3                   	ret
80105711:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105718:	00 
80105719:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80105720 <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
80105720:	55                   	push   %ebp
80105721:	89 e5                	mov    %esp,%ebp
80105723:	53                   	push   %ebx
80105724:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
80105727:	e8 c4 ee ff ff       	call   801045f0 <myproc>
8010572c:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
8010572e:	8b 40 18             	mov    0x18(%eax),%eax
80105731:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80105734:	8d 50 ff             	lea    -0x1(%eax),%edx
80105737:	83 fa 14             	cmp    $0x14,%edx
8010573a:	77 24                	ja     80105760 <syscall+0x40>
8010573c:	8b 14 85 a0 87 10 80 	mov    -0x7fef7860(,%eax,4),%edx
80105743:	85 d2                	test   %edx,%edx
80105745:	74 19                	je     80105760 <syscall+0x40>
    curproc->tf->eax = syscalls[num]();
80105747:	ff d2                	call   *%edx
80105749:	89 c2                	mov    %eax,%edx
8010574b:	8b 43 18             	mov    0x18(%ebx),%eax
8010574e:	89 50 1c             	mov    %edx,0x1c(%eax)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
80105751:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105754:	c9                   	leave
80105755:	c3                   	ret
80105756:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010575d:	00 
8010575e:	66 90                	xchg   %ax,%ax
    cprintf("%d %s: unknown sys call %d\n",
80105760:	50                   	push   %eax
            curproc->pid, curproc->name, num);
80105761:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
80105764:	50                   	push   %eax
80105765:	ff 73 10             	push   0x10(%ebx)
80105768:	68 62 81 10 80       	push   $0x80108162
8010576d:	e8 6e b5 ff ff       	call   80100ce0 <cprintf>
    curproc->tf->eax = -1;
80105772:	8b 43 18             	mov    0x18(%ebx),%eax
80105775:	83 c4 10             	add    $0x10,%esp
80105778:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
}
8010577f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105782:	c9                   	leave
80105783:	c3                   	ret
80105784:	66 90                	xchg   %ax,%ax
80105786:	66 90                	xchg   %ax,%ax
80105788:	66 90                	xchg   %ax,%ax
8010578a:	66 90                	xchg   %ax,%ax
8010578c:	66 90                	xchg   %ax,%ax
8010578e:	66 90                	xchg   %ax,%ax

80105790 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80105790:	55                   	push   %ebp
80105791:	89 e5                	mov    %esp,%ebp
80105793:	57                   	push   %edi
80105794:	56                   	push   %esi
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80105795:	8d 7d da             	lea    -0x26(%ebp),%edi
{
80105798:	53                   	push   %ebx
80105799:	83 ec 34             	sub    $0x34,%esp
8010579c:	89 4d d0             	mov    %ecx,-0x30(%ebp)
8010579f:	8b 4d 08             	mov    0x8(%ebp),%ecx
801057a2:	89 55 d4             	mov    %edx,-0x2c(%ebp)
801057a5:	89 4d cc             	mov    %ecx,-0x34(%ebp)
  if((dp = nameiparent(path, name)) == 0)
801057a8:	57                   	push   %edi
801057a9:	50                   	push   %eax
801057aa:	e8 81 d5 ff ff       	call   80102d30 <nameiparent>
801057af:	83 c4 10             	add    $0x10,%esp
801057b2:	85 c0                	test   %eax,%eax
801057b4:	74 5e                	je     80105814 <create+0x84>
    return 0;
  ilock(dp);
801057b6:	83 ec 0c             	sub    $0xc,%esp
801057b9:	89 c3                	mov    %eax,%ebx
801057bb:	50                   	push   %eax
801057bc:	e8 6f cc ff ff       	call   80102430 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
801057c1:	83 c4 0c             	add    $0xc,%esp
801057c4:	6a 00                	push   $0x0
801057c6:	57                   	push   %edi
801057c7:	53                   	push   %ebx
801057c8:	e8 b3 d1 ff ff       	call   80102980 <dirlookup>
801057cd:	83 c4 10             	add    $0x10,%esp
801057d0:	89 c6                	mov    %eax,%esi
801057d2:	85 c0                	test   %eax,%eax
801057d4:	74 4a                	je     80105820 <create+0x90>
    iunlockput(dp);
801057d6:	83 ec 0c             	sub    $0xc,%esp
801057d9:	53                   	push   %ebx
801057da:	e8 e1 ce ff ff       	call   801026c0 <iunlockput>
    ilock(ip);
801057df:	89 34 24             	mov    %esi,(%esp)
801057e2:	e8 49 cc ff ff       	call   80102430 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
801057e7:	83 c4 10             	add    $0x10,%esp
801057ea:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
801057ef:	75 17                	jne    80105808 <create+0x78>
801057f1:	66 83 7e 50 02       	cmpw   $0x2,0x50(%esi)
801057f6:	75 10                	jne    80105808 <create+0x78>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
801057f8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801057fb:	89 f0                	mov    %esi,%eax
801057fd:	5b                   	pop    %ebx
801057fe:	5e                   	pop    %esi
801057ff:	5f                   	pop    %edi
80105800:	5d                   	pop    %ebp
80105801:	c3                   	ret
80105802:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(ip);
80105808:	83 ec 0c             	sub    $0xc,%esp
8010580b:	56                   	push   %esi
8010580c:	e8 af ce ff ff       	call   801026c0 <iunlockput>
    return 0;
80105811:	83 c4 10             	add    $0x10,%esp
}
80105814:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return 0;
80105817:	31 f6                	xor    %esi,%esi
}
80105819:	5b                   	pop    %ebx
8010581a:	89 f0                	mov    %esi,%eax
8010581c:	5e                   	pop    %esi
8010581d:	5f                   	pop    %edi
8010581e:	5d                   	pop    %ebp
8010581f:	c3                   	ret
  if((ip = ialloc(dp->dev, type)) == 0)
80105820:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
80105824:	83 ec 08             	sub    $0x8,%esp
80105827:	50                   	push   %eax
80105828:	ff 33                	push   (%ebx)
8010582a:	e8 91 ca ff ff       	call   801022c0 <ialloc>
8010582f:	83 c4 10             	add    $0x10,%esp
80105832:	89 c6                	mov    %eax,%esi
80105834:	85 c0                	test   %eax,%eax
80105836:	0f 84 bc 00 00 00    	je     801058f8 <create+0x168>
  ilock(ip);
8010583c:	83 ec 0c             	sub    $0xc,%esp
8010583f:	50                   	push   %eax
80105840:	e8 eb cb ff ff       	call   80102430 <ilock>
  ip->major = major;
80105845:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
80105849:	66 89 46 52          	mov    %ax,0x52(%esi)
  ip->minor = minor;
8010584d:	0f b7 45 cc          	movzwl -0x34(%ebp),%eax
80105851:	66 89 46 54          	mov    %ax,0x54(%esi)
  ip->nlink = 1;
80105855:	b8 01 00 00 00       	mov    $0x1,%eax
8010585a:	66 89 46 56          	mov    %ax,0x56(%esi)
  iupdate(ip);
8010585e:	89 34 24             	mov    %esi,(%esp)
80105861:	e8 1a cb ff ff       	call   80102380 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80105866:	83 c4 10             	add    $0x10,%esp
80105869:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
8010586e:	74 30                	je     801058a0 <create+0x110>
  if(dirlink(dp, name, ip->inum) < 0)
80105870:	83 ec 04             	sub    $0x4,%esp
80105873:	ff 76 04             	push   0x4(%esi)
80105876:	57                   	push   %edi
80105877:	53                   	push   %ebx
80105878:	e8 d3 d3 ff ff       	call   80102c50 <dirlink>
8010587d:	83 c4 10             	add    $0x10,%esp
80105880:	85 c0                	test   %eax,%eax
80105882:	78 67                	js     801058eb <create+0x15b>
  iunlockput(dp);
80105884:	83 ec 0c             	sub    $0xc,%esp
80105887:	53                   	push   %ebx
80105888:	e8 33 ce ff ff       	call   801026c0 <iunlockput>
  return ip;
8010588d:	83 c4 10             	add    $0x10,%esp
}
80105890:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105893:	89 f0                	mov    %esi,%eax
80105895:	5b                   	pop    %ebx
80105896:	5e                   	pop    %esi
80105897:	5f                   	pop    %edi
80105898:	5d                   	pop    %ebp
80105899:	c3                   	ret
8010589a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iupdate(dp);
801058a0:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink++;  // for ".."
801058a3:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
    iupdate(dp);
801058a8:	53                   	push   %ebx
801058a9:	e8 d2 ca ff ff       	call   80102380 <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
801058ae:	83 c4 0c             	add    $0xc,%esp
801058b1:	ff 76 04             	push   0x4(%esi)
801058b4:	68 9a 81 10 80       	push   $0x8010819a
801058b9:	56                   	push   %esi
801058ba:	e8 91 d3 ff ff       	call   80102c50 <dirlink>
801058bf:	83 c4 10             	add    $0x10,%esp
801058c2:	85 c0                	test   %eax,%eax
801058c4:	78 18                	js     801058de <create+0x14e>
801058c6:	83 ec 04             	sub    $0x4,%esp
801058c9:	ff 73 04             	push   0x4(%ebx)
801058cc:	68 99 81 10 80       	push   $0x80108199
801058d1:	56                   	push   %esi
801058d2:	e8 79 d3 ff ff       	call   80102c50 <dirlink>
801058d7:	83 c4 10             	add    $0x10,%esp
801058da:	85 c0                	test   %eax,%eax
801058dc:	79 92                	jns    80105870 <create+0xe0>
      panic("create dots");
801058de:	83 ec 0c             	sub    $0xc,%esp
801058e1:	68 8d 81 10 80       	push   $0x8010818d
801058e6:	e8 95 aa ff ff       	call   80100380 <panic>
    panic("create: dirlink");
801058eb:	83 ec 0c             	sub    $0xc,%esp
801058ee:	68 9c 81 10 80       	push   $0x8010819c
801058f3:	e8 88 aa ff ff       	call   80100380 <panic>
    panic("create: ialloc");
801058f8:	83 ec 0c             	sub    $0xc,%esp
801058fb:	68 7e 81 10 80       	push   $0x8010817e
80105900:	e8 7b aa ff ff       	call   80100380 <panic>
80105905:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010590c:	00 
8010590d:	8d 76 00             	lea    0x0(%esi),%esi

80105910 <sys_dup>:
{
80105910:	55                   	push   %ebp
80105911:	89 e5                	mov    %esp,%ebp
80105913:	56                   	push   %esi
80105914:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105915:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105918:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010591b:	50                   	push   %eax
8010591c:	6a 00                	push   $0x0
8010591e:	e8 bd fc ff ff       	call   801055e0 <argint>
80105923:	83 c4 10             	add    $0x10,%esp
80105926:	85 c0                	test   %eax,%eax
80105928:	78 36                	js     80105960 <sys_dup+0x50>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010592a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
8010592e:	77 30                	ja     80105960 <sys_dup+0x50>
80105930:	e8 bb ec ff ff       	call   801045f0 <myproc>
80105935:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105938:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
8010593c:	85 f6                	test   %esi,%esi
8010593e:	74 20                	je     80105960 <sys_dup+0x50>
  struct proc *curproc = myproc();
80105940:	e8 ab ec ff ff       	call   801045f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
80105945:	31 db                	xor    %ebx,%ebx
80105947:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010594e:	00 
8010594f:	90                   	nop
    if(curproc->ofile[fd] == 0){
80105950:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105954:	85 d2                	test   %edx,%edx
80105956:	74 18                	je     80105970 <sys_dup+0x60>
  for(fd = 0; fd < NOFILE; fd++){
80105958:	83 c3 01             	add    $0x1,%ebx
8010595b:	83 fb 10             	cmp    $0x10,%ebx
8010595e:	75 f0                	jne    80105950 <sys_dup+0x40>
}
80105960:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return -1;
80105963:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
}
80105968:	89 d8                	mov    %ebx,%eax
8010596a:	5b                   	pop    %ebx
8010596b:	5e                   	pop    %esi
8010596c:	5d                   	pop    %ebp
8010596d:	c3                   	ret
8010596e:	66 90                	xchg   %ax,%ax
  filedup(f);
80105970:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80105973:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  filedup(f);
80105977:	56                   	push   %esi
80105978:	e8 d3 c1 ff ff       	call   80101b50 <filedup>
  return fd;
8010597d:	83 c4 10             	add    $0x10,%esp
}
80105980:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105983:	89 d8                	mov    %ebx,%eax
80105985:	5b                   	pop    %ebx
80105986:	5e                   	pop    %esi
80105987:	5d                   	pop    %ebp
80105988:	c3                   	ret
80105989:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80105990 <sys_read>:
{
80105990:	55                   	push   %ebp
80105991:	89 e5                	mov    %esp,%ebp
80105993:	56                   	push   %esi
80105994:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105995:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80105998:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
8010599b:	53                   	push   %ebx
8010599c:	6a 00                	push   $0x0
8010599e:	e8 3d fc ff ff       	call   801055e0 <argint>
801059a3:	83 c4 10             	add    $0x10,%esp
801059a6:	85 c0                	test   %eax,%eax
801059a8:	78 5e                	js     80105a08 <sys_read+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801059aa:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801059ae:	77 58                	ja     80105a08 <sys_read+0x78>
801059b0:	e8 3b ec ff ff       	call   801045f0 <myproc>
801059b5:	8b 55 f4             	mov    -0xc(%ebp),%edx
801059b8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
801059bc:	85 f6                	test   %esi,%esi
801059be:	74 48                	je     80105a08 <sys_read+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801059c0:	83 ec 08             	sub    $0x8,%esp
801059c3:	8d 45 f0             	lea    -0x10(%ebp),%eax
801059c6:	50                   	push   %eax
801059c7:	6a 02                	push   $0x2
801059c9:	e8 12 fc ff ff       	call   801055e0 <argint>
801059ce:	83 c4 10             	add    $0x10,%esp
801059d1:	85 c0                	test   %eax,%eax
801059d3:	78 33                	js     80105a08 <sys_read+0x78>
801059d5:	83 ec 04             	sub    $0x4,%esp
801059d8:	ff 75 f0             	push   -0x10(%ebp)
801059db:	53                   	push   %ebx
801059dc:	6a 01                	push   $0x1
801059de:	e8 4d fc ff ff       	call   80105630 <argptr>
801059e3:	83 c4 10             	add    $0x10,%esp
801059e6:	85 c0                	test   %eax,%eax
801059e8:	78 1e                	js     80105a08 <sys_read+0x78>
  return fileread(f, p, n);
801059ea:	83 ec 04             	sub    $0x4,%esp
801059ed:	ff 75 f0             	push   -0x10(%ebp)
801059f0:	ff 75 f4             	push   -0xc(%ebp)
801059f3:	56                   	push   %esi
801059f4:	e8 d7 c2 ff ff       	call   80101cd0 <fileread>
801059f9:	83 c4 10             	add    $0x10,%esp
}
801059fc:	8d 65 f8             	lea    -0x8(%ebp),%esp
801059ff:	5b                   	pop    %ebx
80105a00:	5e                   	pop    %esi
80105a01:	5d                   	pop    %ebp
80105a02:	c3                   	ret
80105a03:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105a08:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105a0d:	eb ed                	jmp    801059fc <sys_read+0x6c>
80105a0f:	90                   	nop

80105a10 <sys_write>:
{
80105a10:	55                   	push   %ebp
80105a11:	89 e5                	mov    %esp,%ebp
80105a13:	56                   	push   %esi
80105a14:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105a15:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80105a18:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80105a1b:	53                   	push   %ebx
80105a1c:	6a 00                	push   $0x0
80105a1e:	e8 bd fb ff ff       	call   801055e0 <argint>
80105a23:	83 c4 10             	add    $0x10,%esp
80105a26:	85 c0                	test   %eax,%eax
80105a28:	78 5e                	js     80105a88 <sys_write+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80105a2a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80105a2e:	77 58                	ja     80105a88 <sys_write+0x78>
80105a30:	e8 bb eb ff ff       	call   801045f0 <myproc>
80105a35:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105a38:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80105a3c:	85 f6                	test   %esi,%esi
80105a3e:	74 48                	je     80105a88 <sys_write+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80105a40:	83 ec 08             	sub    $0x8,%esp
80105a43:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105a46:	50                   	push   %eax
80105a47:	6a 02                	push   $0x2
80105a49:	e8 92 fb ff ff       	call   801055e0 <argint>
80105a4e:	83 c4 10             	add    $0x10,%esp
80105a51:	85 c0                	test   %eax,%eax
80105a53:	78 33                	js     80105a88 <sys_write+0x78>
80105a55:	83 ec 04             	sub    $0x4,%esp
80105a58:	ff 75 f0             	push   -0x10(%ebp)
80105a5b:	53                   	push   %ebx
80105a5c:	6a 01                	push   $0x1
80105a5e:	e8 cd fb ff ff       	call   80105630 <argptr>
80105a63:	83 c4 10             	add    $0x10,%esp
80105a66:	85 c0                	test   %eax,%eax
80105a68:	78 1e                	js     80105a88 <sys_write+0x78>
  return filewrite(f, p, n);
80105a6a:	83 ec 04             	sub    $0x4,%esp
80105a6d:	ff 75 f0             	push   -0x10(%ebp)
80105a70:	ff 75 f4             	push   -0xc(%ebp)
80105a73:	56                   	push   %esi
80105a74:	e8 e7 c2 ff ff       	call   80101d60 <filewrite>
80105a79:	83 c4 10             	add    $0x10,%esp
}
80105a7c:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105a7f:	5b                   	pop    %ebx
80105a80:	5e                   	pop    %esi
80105a81:	5d                   	pop    %ebp
80105a82:	c3                   	ret
80105a83:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80105a88:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105a8d:	eb ed                	jmp    80105a7c <sys_write+0x6c>
80105a8f:	90                   	nop

80105a90 <sys_close>:
{
80105a90:	55                   	push   %ebp
80105a91:	89 e5                	mov    %esp,%ebp
80105a93:	56                   	push   %esi
80105a94:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105a95:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105a98:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80105a9b:	50                   	push   %eax
80105a9c:	6a 00                	push   $0x0
80105a9e:	e8 3d fb ff ff       	call   801055e0 <argint>
80105aa3:	83 c4 10             	add    $0x10,%esp
80105aa6:	85 c0                	test   %eax,%eax
80105aa8:	78 3e                	js     80105ae8 <sys_close+0x58>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80105aaa:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80105aae:	77 38                	ja     80105ae8 <sys_close+0x58>
80105ab0:	e8 3b eb ff ff       	call   801045f0 <myproc>
80105ab5:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105ab8:	8d 5a 08             	lea    0x8(%edx),%ebx
80105abb:	8b 74 98 08          	mov    0x8(%eax,%ebx,4),%esi
80105abf:	85 f6                	test   %esi,%esi
80105ac1:	74 25                	je     80105ae8 <sys_close+0x58>
  myproc()->ofile[fd] = 0;
80105ac3:	e8 28 eb ff ff       	call   801045f0 <myproc>
  fileclose(f);
80105ac8:	83 ec 0c             	sub    $0xc,%esp
  myproc()->ofile[fd] = 0;
80105acb:	c7 44 98 08 00 00 00 	movl   $0x0,0x8(%eax,%ebx,4)
80105ad2:	00 
  fileclose(f);
80105ad3:	56                   	push   %esi
80105ad4:	e8 c7 c0 ff ff       	call   80101ba0 <fileclose>
  return 0;
80105ad9:	83 c4 10             	add    $0x10,%esp
80105adc:	31 c0                	xor    %eax,%eax
}
80105ade:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105ae1:	5b                   	pop    %ebx
80105ae2:	5e                   	pop    %esi
80105ae3:	5d                   	pop    %ebp
80105ae4:	c3                   	ret
80105ae5:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105ae8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105aed:	eb ef                	jmp    80105ade <sys_close+0x4e>
80105aef:	90                   	nop

80105af0 <sys_fstat>:
{
80105af0:	55                   	push   %ebp
80105af1:	89 e5                	mov    %esp,%ebp
80105af3:	56                   	push   %esi
80105af4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80105af5:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80105af8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80105afb:	53                   	push   %ebx
80105afc:	6a 00                	push   $0x0
80105afe:	e8 dd fa ff ff       	call   801055e0 <argint>
80105b03:	83 c4 10             	add    $0x10,%esp
80105b06:	85 c0                	test   %eax,%eax
80105b08:	78 46                	js     80105b50 <sys_fstat+0x60>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80105b0a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80105b0e:	77 40                	ja     80105b50 <sys_fstat+0x60>
80105b10:	e8 db ea ff ff       	call   801045f0 <myproc>
80105b15:	8b 55 f4             	mov    -0xc(%ebp),%edx
80105b18:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80105b1c:	85 f6                	test   %esi,%esi
80105b1e:	74 30                	je     80105b50 <sys_fstat+0x60>
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
80105b20:	83 ec 04             	sub    $0x4,%esp
80105b23:	6a 14                	push   $0x14
80105b25:	53                   	push   %ebx
80105b26:	6a 01                	push   $0x1
80105b28:	e8 03 fb ff ff       	call   80105630 <argptr>
80105b2d:	83 c4 10             	add    $0x10,%esp
80105b30:	85 c0                	test   %eax,%eax
80105b32:	78 1c                	js     80105b50 <sys_fstat+0x60>
  return filestat(f, st);
80105b34:	83 ec 08             	sub    $0x8,%esp
80105b37:	ff 75 f4             	push   -0xc(%ebp)
80105b3a:	56                   	push   %esi
80105b3b:	e8 40 c1 ff ff       	call   80101c80 <filestat>
80105b40:	83 c4 10             	add    $0x10,%esp
}
80105b43:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105b46:	5b                   	pop    %ebx
80105b47:	5e                   	pop    %esi
80105b48:	5d                   	pop    %ebp
80105b49:	c3                   	ret
80105b4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80105b50:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b55:	eb ec                	jmp    80105b43 <sys_fstat+0x53>
80105b57:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105b5e:	00 
80105b5f:	90                   	nop

80105b60 <sys_link>:
{
80105b60:	55                   	push   %ebp
80105b61:	89 e5                	mov    %esp,%ebp
80105b63:	57                   	push   %edi
80105b64:	56                   	push   %esi
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105b65:	8d 45 d4             	lea    -0x2c(%ebp),%eax
{
80105b68:	53                   	push   %ebx
80105b69:	83 ec 34             	sub    $0x34,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105b6c:	50                   	push   %eax
80105b6d:	6a 00                	push   $0x0
80105b6f:	e8 2c fb ff ff       	call   801056a0 <argstr>
80105b74:	83 c4 10             	add    $0x10,%esp
80105b77:	85 c0                	test   %eax,%eax
80105b79:	0f 88 fb 00 00 00    	js     80105c7a <sys_link+0x11a>
80105b7f:	83 ec 08             	sub    $0x8,%esp
80105b82:	8d 45 d0             	lea    -0x30(%ebp),%eax
80105b85:	50                   	push   %eax
80105b86:	6a 01                	push   $0x1
80105b88:	e8 13 fb ff ff       	call   801056a0 <argstr>
80105b8d:	83 c4 10             	add    $0x10,%esp
80105b90:	85 c0                	test   %eax,%eax
80105b92:	0f 88 e2 00 00 00    	js     80105c7a <sys_link+0x11a>
  begin_op();
80105b98:	e8 33 de ff ff       	call   801039d0 <begin_op>
  if((ip = namei(old)) == 0){
80105b9d:	83 ec 0c             	sub    $0xc,%esp
80105ba0:	ff 75 d4             	push   -0x2c(%ebp)
80105ba3:	e8 68 d1 ff ff       	call   80102d10 <namei>
80105ba8:	83 c4 10             	add    $0x10,%esp
80105bab:	89 c3                	mov    %eax,%ebx
80105bad:	85 c0                	test   %eax,%eax
80105baf:	0f 84 df 00 00 00    	je     80105c94 <sys_link+0x134>
  ilock(ip);
80105bb5:	83 ec 0c             	sub    $0xc,%esp
80105bb8:	50                   	push   %eax
80105bb9:	e8 72 c8 ff ff       	call   80102430 <ilock>
  if(ip->type == T_DIR){
80105bbe:	83 c4 10             	add    $0x10,%esp
80105bc1:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105bc6:	0f 84 b5 00 00 00    	je     80105c81 <sys_link+0x121>
  iupdate(ip);
80105bcc:	83 ec 0c             	sub    $0xc,%esp
  ip->nlink++;
80105bcf:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  if((dp = nameiparent(new, name)) == 0)
80105bd4:	8d 7d da             	lea    -0x26(%ebp),%edi
  iupdate(ip);
80105bd7:	53                   	push   %ebx
80105bd8:	e8 a3 c7 ff ff       	call   80102380 <iupdate>
  iunlock(ip);
80105bdd:	89 1c 24             	mov    %ebx,(%esp)
80105be0:	e8 2b c9 ff ff       	call   80102510 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
80105be5:	58                   	pop    %eax
80105be6:	5a                   	pop    %edx
80105be7:	57                   	push   %edi
80105be8:	ff 75 d0             	push   -0x30(%ebp)
80105beb:	e8 40 d1 ff ff       	call   80102d30 <nameiparent>
80105bf0:	83 c4 10             	add    $0x10,%esp
80105bf3:	89 c6                	mov    %eax,%esi
80105bf5:	85 c0                	test   %eax,%eax
80105bf7:	74 5b                	je     80105c54 <sys_link+0xf4>
  ilock(dp);
80105bf9:	83 ec 0c             	sub    $0xc,%esp
80105bfc:	50                   	push   %eax
80105bfd:	e8 2e c8 ff ff       	call   80102430 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
80105c02:	8b 03                	mov    (%ebx),%eax
80105c04:	83 c4 10             	add    $0x10,%esp
80105c07:	39 06                	cmp    %eax,(%esi)
80105c09:	75 3d                	jne    80105c48 <sys_link+0xe8>
80105c0b:	83 ec 04             	sub    $0x4,%esp
80105c0e:	ff 73 04             	push   0x4(%ebx)
80105c11:	57                   	push   %edi
80105c12:	56                   	push   %esi
80105c13:	e8 38 d0 ff ff       	call   80102c50 <dirlink>
80105c18:	83 c4 10             	add    $0x10,%esp
80105c1b:	85 c0                	test   %eax,%eax
80105c1d:	78 29                	js     80105c48 <sys_link+0xe8>
  iunlockput(dp);
80105c1f:	83 ec 0c             	sub    $0xc,%esp
80105c22:	56                   	push   %esi
80105c23:	e8 98 ca ff ff       	call   801026c0 <iunlockput>
  iput(ip);
80105c28:	89 1c 24             	mov    %ebx,(%esp)
80105c2b:	e8 30 c9 ff ff       	call   80102560 <iput>
  end_op();
80105c30:	e8 0b de ff ff       	call   80103a40 <end_op>
  return 0;
80105c35:	83 c4 10             	add    $0x10,%esp
80105c38:	31 c0                	xor    %eax,%eax
}
80105c3a:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105c3d:	5b                   	pop    %ebx
80105c3e:	5e                   	pop    %esi
80105c3f:	5f                   	pop    %edi
80105c40:	5d                   	pop    %ebp
80105c41:	c3                   	ret
80105c42:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(dp);
80105c48:	83 ec 0c             	sub    $0xc,%esp
80105c4b:	56                   	push   %esi
80105c4c:	e8 6f ca ff ff       	call   801026c0 <iunlockput>
    goto bad;
80105c51:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
80105c54:	83 ec 0c             	sub    $0xc,%esp
80105c57:	53                   	push   %ebx
80105c58:	e8 d3 c7 ff ff       	call   80102430 <ilock>
  ip->nlink--;
80105c5d:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
80105c62:	89 1c 24             	mov    %ebx,(%esp)
80105c65:	e8 16 c7 ff ff       	call   80102380 <iupdate>
  iunlockput(ip);
80105c6a:	89 1c 24             	mov    %ebx,(%esp)
80105c6d:	e8 4e ca ff ff       	call   801026c0 <iunlockput>
  end_op();
80105c72:	e8 c9 dd ff ff       	call   80103a40 <end_op>
  return -1;
80105c77:	83 c4 10             	add    $0x10,%esp
    return -1;
80105c7a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105c7f:	eb b9                	jmp    80105c3a <sys_link+0xda>
    iunlockput(ip);
80105c81:	83 ec 0c             	sub    $0xc,%esp
80105c84:	53                   	push   %ebx
80105c85:	e8 36 ca ff ff       	call   801026c0 <iunlockput>
    end_op();
80105c8a:	e8 b1 dd ff ff       	call   80103a40 <end_op>
    return -1;
80105c8f:	83 c4 10             	add    $0x10,%esp
80105c92:	eb e6                	jmp    80105c7a <sys_link+0x11a>
    end_op();
80105c94:	e8 a7 dd ff ff       	call   80103a40 <end_op>
    return -1;
80105c99:	eb df                	jmp    80105c7a <sys_link+0x11a>
80105c9b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105ca0 <sys_unlink>:
{
80105ca0:	55                   	push   %ebp
80105ca1:	89 e5                	mov    %esp,%ebp
80105ca3:	57                   	push   %edi
80105ca4:	56                   	push   %esi
  if(argstr(0, &path) < 0)
80105ca5:	8d 45 c0             	lea    -0x40(%ebp),%eax
{
80105ca8:	53                   	push   %ebx
80105ca9:	83 ec 54             	sub    $0x54,%esp
  if(argstr(0, &path) < 0)
80105cac:	50                   	push   %eax
80105cad:	6a 00                	push   $0x0
80105caf:	e8 ec f9 ff ff       	call   801056a0 <argstr>
80105cb4:	83 c4 10             	add    $0x10,%esp
80105cb7:	85 c0                	test   %eax,%eax
80105cb9:	0f 88 54 01 00 00    	js     80105e13 <sys_unlink+0x173>
  begin_op();
80105cbf:	e8 0c dd ff ff       	call   801039d0 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80105cc4:	8d 5d ca             	lea    -0x36(%ebp),%ebx
80105cc7:	83 ec 08             	sub    $0x8,%esp
80105cca:	53                   	push   %ebx
80105ccb:	ff 75 c0             	push   -0x40(%ebp)
80105cce:	e8 5d d0 ff ff       	call   80102d30 <nameiparent>
80105cd3:	83 c4 10             	add    $0x10,%esp
80105cd6:	89 45 b4             	mov    %eax,-0x4c(%ebp)
80105cd9:	85 c0                	test   %eax,%eax
80105cdb:	0f 84 58 01 00 00    	je     80105e39 <sys_unlink+0x199>
  ilock(dp);
80105ce1:	8b 7d b4             	mov    -0x4c(%ebp),%edi
80105ce4:	83 ec 0c             	sub    $0xc,%esp
80105ce7:	57                   	push   %edi
80105ce8:	e8 43 c7 ff ff       	call   80102430 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
80105ced:	58                   	pop    %eax
80105cee:	5a                   	pop    %edx
80105cef:	68 9a 81 10 80       	push   $0x8010819a
80105cf4:	53                   	push   %ebx
80105cf5:	e8 66 cc ff ff       	call   80102960 <namecmp>
80105cfa:	83 c4 10             	add    $0x10,%esp
80105cfd:	85 c0                	test   %eax,%eax
80105cff:	0f 84 fb 00 00 00    	je     80105e00 <sys_unlink+0x160>
80105d05:	83 ec 08             	sub    $0x8,%esp
80105d08:	68 99 81 10 80       	push   $0x80108199
80105d0d:	53                   	push   %ebx
80105d0e:	e8 4d cc ff ff       	call   80102960 <namecmp>
80105d13:	83 c4 10             	add    $0x10,%esp
80105d16:	85 c0                	test   %eax,%eax
80105d18:	0f 84 e2 00 00 00    	je     80105e00 <sys_unlink+0x160>
  if((ip = dirlookup(dp, name, &off)) == 0)
80105d1e:	83 ec 04             	sub    $0x4,%esp
80105d21:	8d 45 c4             	lea    -0x3c(%ebp),%eax
80105d24:	50                   	push   %eax
80105d25:	53                   	push   %ebx
80105d26:	57                   	push   %edi
80105d27:	e8 54 cc ff ff       	call   80102980 <dirlookup>
80105d2c:	83 c4 10             	add    $0x10,%esp
80105d2f:	89 c3                	mov    %eax,%ebx
80105d31:	85 c0                	test   %eax,%eax
80105d33:	0f 84 c7 00 00 00    	je     80105e00 <sys_unlink+0x160>
  ilock(ip);
80105d39:	83 ec 0c             	sub    $0xc,%esp
80105d3c:	50                   	push   %eax
80105d3d:	e8 ee c6 ff ff       	call   80102430 <ilock>
  if(ip->nlink < 1)
80105d42:	83 c4 10             	add    $0x10,%esp
80105d45:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80105d4a:	0f 8e 0a 01 00 00    	jle    80105e5a <sys_unlink+0x1ba>
  if(ip->type == T_DIR && !isdirempty(ip)){
80105d50:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105d55:	8d 7d d8             	lea    -0x28(%ebp),%edi
80105d58:	74 66                	je     80105dc0 <sys_unlink+0x120>
  memset(&de, 0, sizeof(de));
80105d5a:	83 ec 04             	sub    $0x4,%esp
80105d5d:	6a 10                	push   $0x10
80105d5f:	6a 00                	push   $0x0
80105d61:	57                   	push   %edi
80105d62:	e8 c9 f5 ff ff       	call   80105330 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105d67:	6a 10                	push   $0x10
80105d69:	ff 75 c4             	push   -0x3c(%ebp)
80105d6c:	57                   	push   %edi
80105d6d:	ff 75 b4             	push   -0x4c(%ebp)
80105d70:	e8 cb ca ff ff       	call   80102840 <writei>
80105d75:	83 c4 20             	add    $0x20,%esp
80105d78:	83 f8 10             	cmp    $0x10,%eax
80105d7b:	0f 85 cc 00 00 00    	jne    80105e4d <sys_unlink+0x1ad>
  if(ip->type == T_DIR){
80105d81:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105d86:	0f 84 94 00 00 00    	je     80105e20 <sys_unlink+0x180>
  iunlockput(dp);
80105d8c:	83 ec 0c             	sub    $0xc,%esp
80105d8f:	ff 75 b4             	push   -0x4c(%ebp)
80105d92:	e8 29 c9 ff ff       	call   801026c0 <iunlockput>
  ip->nlink--;
80105d97:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
80105d9c:	89 1c 24             	mov    %ebx,(%esp)
80105d9f:	e8 dc c5 ff ff       	call   80102380 <iupdate>
  iunlockput(ip);
80105da4:	89 1c 24             	mov    %ebx,(%esp)
80105da7:	e8 14 c9 ff ff       	call   801026c0 <iunlockput>
  end_op();
80105dac:	e8 8f dc ff ff       	call   80103a40 <end_op>
  return 0;
80105db1:	83 c4 10             	add    $0x10,%esp
80105db4:	31 c0                	xor    %eax,%eax
}
80105db6:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105db9:	5b                   	pop    %ebx
80105dba:	5e                   	pop    %esi
80105dbb:	5f                   	pop    %edi
80105dbc:	5d                   	pop    %ebp
80105dbd:	c3                   	ret
80105dbe:	66 90                	xchg   %ax,%ax
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105dc0:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
80105dc4:	76 94                	jbe    80105d5a <sys_unlink+0xba>
80105dc6:	be 20 00 00 00       	mov    $0x20,%esi
80105dcb:	eb 0b                	jmp    80105dd8 <sys_unlink+0x138>
80105dcd:	8d 76 00             	lea    0x0(%esi),%esi
80105dd0:	83 c6 10             	add    $0x10,%esi
80105dd3:	3b 73 58             	cmp    0x58(%ebx),%esi
80105dd6:	73 82                	jae    80105d5a <sys_unlink+0xba>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105dd8:	6a 10                	push   $0x10
80105dda:	56                   	push   %esi
80105ddb:	57                   	push   %edi
80105ddc:	53                   	push   %ebx
80105ddd:	e8 5e c9 ff ff       	call   80102740 <readi>
80105de2:	83 c4 10             	add    $0x10,%esp
80105de5:	83 f8 10             	cmp    $0x10,%eax
80105de8:	75 56                	jne    80105e40 <sys_unlink+0x1a0>
    if(de.inum != 0)
80105dea:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80105def:	74 df                	je     80105dd0 <sys_unlink+0x130>
    iunlockput(ip);
80105df1:	83 ec 0c             	sub    $0xc,%esp
80105df4:	53                   	push   %ebx
80105df5:	e8 c6 c8 ff ff       	call   801026c0 <iunlockput>
    goto bad;
80105dfa:	83 c4 10             	add    $0x10,%esp
80105dfd:	8d 76 00             	lea    0x0(%esi),%esi
  iunlockput(dp);
80105e00:	83 ec 0c             	sub    $0xc,%esp
80105e03:	ff 75 b4             	push   -0x4c(%ebp)
80105e06:	e8 b5 c8 ff ff       	call   801026c0 <iunlockput>
  end_op();
80105e0b:	e8 30 dc ff ff       	call   80103a40 <end_op>
  return -1;
80105e10:	83 c4 10             	add    $0x10,%esp
    return -1;
80105e13:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105e18:	eb 9c                	jmp    80105db6 <sys_unlink+0x116>
80105e1a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    dp->nlink--;
80105e20:	8b 45 b4             	mov    -0x4c(%ebp),%eax
    iupdate(dp);
80105e23:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink--;
80105e26:	66 83 68 56 01       	subw   $0x1,0x56(%eax)
    iupdate(dp);
80105e2b:	50                   	push   %eax
80105e2c:	e8 4f c5 ff ff       	call   80102380 <iupdate>
80105e31:	83 c4 10             	add    $0x10,%esp
80105e34:	e9 53 ff ff ff       	jmp    80105d8c <sys_unlink+0xec>
    end_op();
80105e39:	e8 02 dc ff ff       	call   80103a40 <end_op>
    return -1;
80105e3e:	eb d3                	jmp    80105e13 <sys_unlink+0x173>
      panic("isdirempty: readi");
80105e40:	83 ec 0c             	sub    $0xc,%esp
80105e43:	68 be 81 10 80       	push   $0x801081be
80105e48:	e8 33 a5 ff ff       	call   80100380 <panic>
    panic("unlink: writei");
80105e4d:	83 ec 0c             	sub    $0xc,%esp
80105e50:	68 d0 81 10 80       	push   $0x801081d0
80105e55:	e8 26 a5 ff ff       	call   80100380 <panic>
    panic("unlink: nlink < 1");
80105e5a:	83 ec 0c             	sub    $0xc,%esp
80105e5d:	68 ac 81 10 80       	push   $0x801081ac
80105e62:	e8 19 a5 ff ff       	call   80100380 <panic>
80105e67:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105e6e:	00 
80105e6f:	90                   	nop

80105e70 <sys_open>:

int
sys_open(void)
{
80105e70:	55                   	push   %ebp
80105e71:	89 e5                	mov    %esp,%ebp
80105e73:	57                   	push   %edi
80105e74:	56                   	push   %esi
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105e75:	8d 45 e0             	lea    -0x20(%ebp),%eax
{
80105e78:	53                   	push   %ebx
80105e79:	83 ec 24             	sub    $0x24,%esp
  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105e7c:	50                   	push   %eax
80105e7d:	6a 00                	push   $0x0
80105e7f:	e8 1c f8 ff ff       	call   801056a0 <argstr>
80105e84:	83 c4 10             	add    $0x10,%esp
80105e87:	85 c0                	test   %eax,%eax
80105e89:	0f 88 8e 00 00 00    	js     80105f1d <sys_open+0xad>
80105e8f:	83 ec 08             	sub    $0x8,%esp
80105e92:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105e95:	50                   	push   %eax
80105e96:	6a 01                	push   $0x1
80105e98:	e8 43 f7 ff ff       	call   801055e0 <argint>
80105e9d:	83 c4 10             	add    $0x10,%esp
80105ea0:	85 c0                	test   %eax,%eax
80105ea2:	78 79                	js     80105f1d <sys_open+0xad>
    return -1;

  begin_op();
80105ea4:	e8 27 db ff ff       	call   801039d0 <begin_op>

  if(omode & O_CREATE){
80105ea9:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
80105ead:	75 79                	jne    80105f28 <sys_open+0xb8>
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
80105eaf:	83 ec 0c             	sub    $0xc,%esp
80105eb2:	ff 75 e0             	push   -0x20(%ebp)
80105eb5:	e8 56 ce ff ff       	call   80102d10 <namei>
80105eba:	83 c4 10             	add    $0x10,%esp
80105ebd:	89 c6                	mov    %eax,%esi
80105ebf:	85 c0                	test   %eax,%eax
80105ec1:	0f 84 7e 00 00 00    	je     80105f45 <sys_open+0xd5>
      end_op();
      return -1;
    }
    ilock(ip);
80105ec7:	83 ec 0c             	sub    $0xc,%esp
80105eca:	50                   	push   %eax
80105ecb:	e8 60 c5 ff ff       	call   80102430 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
80105ed0:	83 c4 10             	add    $0x10,%esp
80105ed3:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80105ed8:	0f 84 ba 00 00 00    	je     80105f98 <sys_open+0x128>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
80105ede:	e8 fd bb ff ff       	call   80101ae0 <filealloc>
80105ee3:	89 c7                	mov    %eax,%edi
80105ee5:	85 c0                	test   %eax,%eax
80105ee7:	74 23                	je     80105f0c <sys_open+0x9c>
  struct proc *curproc = myproc();
80105ee9:	e8 02 e7 ff ff       	call   801045f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
80105eee:	31 db                	xor    %ebx,%ebx
    if(curproc->ofile[fd] == 0){
80105ef0:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80105ef4:	85 d2                	test   %edx,%edx
80105ef6:	74 58                	je     80105f50 <sys_open+0xe0>
  for(fd = 0; fd < NOFILE; fd++){
80105ef8:	83 c3 01             	add    $0x1,%ebx
80105efb:	83 fb 10             	cmp    $0x10,%ebx
80105efe:	75 f0                	jne    80105ef0 <sys_open+0x80>
    if(f)
      fileclose(f);
80105f00:	83 ec 0c             	sub    $0xc,%esp
80105f03:	57                   	push   %edi
80105f04:	e8 97 bc ff ff       	call   80101ba0 <fileclose>
80105f09:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80105f0c:	83 ec 0c             	sub    $0xc,%esp
80105f0f:	56                   	push   %esi
80105f10:	e8 ab c7 ff ff       	call   801026c0 <iunlockput>
    end_op();
80105f15:	e8 26 db ff ff       	call   80103a40 <end_op>
    return -1;
80105f1a:	83 c4 10             	add    $0x10,%esp
    return -1;
80105f1d:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80105f22:	eb 65                	jmp    80105f89 <sys_open+0x119>
80105f24:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    ip = create(path, T_FILE, 0, 0);
80105f28:	83 ec 0c             	sub    $0xc,%esp
80105f2b:	31 c9                	xor    %ecx,%ecx
80105f2d:	ba 02 00 00 00       	mov    $0x2,%edx
80105f32:	6a 00                	push   $0x0
80105f34:	8b 45 e0             	mov    -0x20(%ebp),%eax
80105f37:	e8 54 f8 ff ff       	call   80105790 <create>
    if(ip == 0){
80105f3c:	83 c4 10             	add    $0x10,%esp
    ip = create(path, T_FILE, 0, 0);
80105f3f:	89 c6                	mov    %eax,%esi
    if(ip == 0){
80105f41:	85 c0                	test   %eax,%eax
80105f43:	75 99                	jne    80105ede <sys_open+0x6e>
      end_op();
80105f45:	e8 f6 da ff ff       	call   80103a40 <end_op>
      return -1;
80105f4a:	eb d1                	jmp    80105f1d <sys_open+0xad>
80105f4c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  iunlock(ip);
80105f50:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80105f53:	89 7c 98 28          	mov    %edi,0x28(%eax,%ebx,4)
  iunlock(ip);
80105f57:	56                   	push   %esi
80105f58:	e8 b3 c5 ff ff       	call   80102510 <iunlock>
  end_op();
80105f5d:	e8 de da ff ff       	call   80103a40 <end_op>

  f->type = FD_INODE;
80105f62:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
80105f68:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105f6b:	83 c4 10             	add    $0x10,%esp
  f->ip = ip;
80105f6e:	89 77 10             	mov    %esi,0x10(%edi)
  f->readable = !(omode & O_WRONLY);
80105f71:	89 d0                	mov    %edx,%eax
  f->off = 0;
80105f73:	c7 47 14 00 00 00 00 	movl   $0x0,0x14(%edi)
  f->readable = !(omode & O_WRONLY);
80105f7a:	f7 d0                	not    %eax
80105f7c:	83 e0 01             	and    $0x1,%eax
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105f7f:	83 e2 03             	and    $0x3,%edx
  f->readable = !(omode & O_WRONLY);
80105f82:	88 47 08             	mov    %al,0x8(%edi)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105f85:	0f 95 47 09          	setne  0x9(%edi)
  return fd;
}
80105f89:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105f8c:	89 d8                	mov    %ebx,%eax
80105f8e:	5b                   	pop    %ebx
80105f8f:	5e                   	pop    %esi
80105f90:	5f                   	pop    %edi
80105f91:	5d                   	pop    %ebp
80105f92:	c3                   	ret
80105f93:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(ip->type == T_DIR && omode != O_RDONLY){
80105f98:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80105f9b:	85 c9                	test   %ecx,%ecx
80105f9d:	0f 84 3b ff ff ff    	je     80105ede <sys_open+0x6e>
80105fa3:	e9 64 ff ff ff       	jmp    80105f0c <sys_open+0x9c>
80105fa8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105faf:	00 

80105fb0 <sys_mkdir>:

int
sys_mkdir(void)
{
80105fb0:	55                   	push   %ebp
80105fb1:	89 e5                	mov    %esp,%ebp
80105fb3:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80105fb6:	e8 15 da ff ff       	call   801039d0 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
80105fbb:	83 ec 08             	sub    $0x8,%esp
80105fbe:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105fc1:	50                   	push   %eax
80105fc2:	6a 00                	push   $0x0
80105fc4:	e8 d7 f6 ff ff       	call   801056a0 <argstr>
80105fc9:	83 c4 10             	add    $0x10,%esp
80105fcc:	85 c0                	test   %eax,%eax
80105fce:	78 30                	js     80106000 <sys_mkdir+0x50>
80105fd0:	83 ec 0c             	sub    $0xc,%esp
80105fd3:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105fd6:	31 c9                	xor    %ecx,%ecx
80105fd8:	ba 01 00 00 00       	mov    $0x1,%edx
80105fdd:	6a 00                	push   $0x0
80105fdf:	e8 ac f7 ff ff       	call   80105790 <create>
80105fe4:	83 c4 10             	add    $0x10,%esp
80105fe7:	85 c0                	test   %eax,%eax
80105fe9:	74 15                	je     80106000 <sys_mkdir+0x50>
    end_op();
    return -1;
  }
  iunlockput(ip);
80105feb:	83 ec 0c             	sub    $0xc,%esp
80105fee:	50                   	push   %eax
80105fef:	e8 cc c6 ff ff       	call   801026c0 <iunlockput>
  end_op();
80105ff4:	e8 47 da ff ff       	call   80103a40 <end_op>
  return 0;
80105ff9:	83 c4 10             	add    $0x10,%esp
80105ffc:	31 c0                	xor    %eax,%eax
}
80105ffe:	c9                   	leave
80105fff:	c3                   	ret
    end_op();
80106000:	e8 3b da ff ff       	call   80103a40 <end_op>
    return -1;
80106005:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010600a:	c9                   	leave
8010600b:	c3                   	ret
8010600c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80106010 <sys_mknod>:

int
sys_mknod(void)
{
80106010:	55                   	push   %ebp
80106011:	89 e5                	mov    %esp,%ebp
80106013:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
80106016:	e8 b5 d9 ff ff       	call   801039d0 <begin_op>
  if((argstr(0, &path)) < 0 ||
8010601b:	83 ec 08             	sub    $0x8,%esp
8010601e:	8d 45 ec             	lea    -0x14(%ebp),%eax
80106021:	50                   	push   %eax
80106022:	6a 00                	push   $0x0
80106024:	e8 77 f6 ff ff       	call   801056a0 <argstr>
80106029:	83 c4 10             	add    $0x10,%esp
8010602c:	85 c0                	test   %eax,%eax
8010602e:	78 60                	js     80106090 <sys_mknod+0x80>
     argint(1, &major) < 0 ||
80106030:	83 ec 08             	sub    $0x8,%esp
80106033:	8d 45 f0             	lea    -0x10(%ebp),%eax
80106036:	50                   	push   %eax
80106037:	6a 01                	push   $0x1
80106039:	e8 a2 f5 ff ff       	call   801055e0 <argint>
  if((argstr(0, &path)) < 0 ||
8010603e:	83 c4 10             	add    $0x10,%esp
80106041:	85 c0                	test   %eax,%eax
80106043:	78 4b                	js     80106090 <sys_mknod+0x80>
     argint(2, &minor) < 0 ||
80106045:	83 ec 08             	sub    $0x8,%esp
80106048:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010604b:	50                   	push   %eax
8010604c:	6a 02                	push   $0x2
8010604e:	e8 8d f5 ff ff       	call   801055e0 <argint>
     argint(1, &major) < 0 ||
80106053:	83 c4 10             	add    $0x10,%esp
80106056:	85 c0                	test   %eax,%eax
80106058:	78 36                	js     80106090 <sys_mknod+0x80>
     (ip = create(path, T_DEV, major, minor)) == 0){
8010605a:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
8010605e:	83 ec 0c             	sub    $0xc,%esp
80106061:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
80106065:	ba 03 00 00 00       	mov    $0x3,%edx
8010606a:	50                   	push   %eax
8010606b:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010606e:	e8 1d f7 ff ff       	call   80105790 <create>
     argint(2, &minor) < 0 ||
80106073:	83 c4 10             	add    $0x10,%esp
80106076:	85 c0                	test   %eax,%eax
80106078:	74 16                	je     80106090 <sys_mknod+0x80>
    end_op();
    return -1;
  }
  iunlockput(ip);
8010607a:	83 ec 0c             	sub    $0xc,%esp
8010607d:	50                   	push   %eax
8010607e:	e8 3d c6 ff ff       	call   801026c0 <iunlockput>
  end_op();
80106083:	e8 b8 d9 ff ff       	call   80103a40 <end_op>
  return 0;
80106088:	83 c4 10             	add    $0x10,%esp
8010608b:	31 c0                	xor    %eax,%eax
}
8010608d:	c9                   	leave
8010608e:	c3                   	ret
8010608f:	90                   	nop
    end_op();
80106090:	e8 ab d9 ff ff       	call   80103a40 <end_op>
    return -1;
80106095:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010609a:	c9                   	leave
8010609b:	c3                   	ret
8010609c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801060a0 <sys_chdir>:

int
sys_chdir(void)
{
801060a0:	55                   	push   %ebp
801060a1:	89 e5                	mov    %esp,%ebp
801060a3:	56                   	push   %esi
801060a4:	53                   	push   %ebx
801060a5:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
801060a8:	e8 43 e5 ff ff       	call   801045f0 <myproc>
801060ad:	89 c6                	mov    %eax,%esi
  
  begin_op();
801060af:	e8 1c d9 ff ff       	call   801039d0 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
801060b4:	83 ec 08             	sub    $0x8,%esp
801060b7:	8d 45 f4             	lea    -0xc(%ebp),%eax
801060ba:	50                   	push   %eax
801060bb:	6a 00                	push   $0x0
801060bd:	e8 de f5 ff ff       	call   801056a0 <argstr>
801060c2:	83 c4 10             	add    $0x10,%esp
801060c5:	85 c0                	test   %eax,%eax
801060c7:	78 77                	js     80106140 <sys_chdir+0xa0>
801060c9:	83 ec 0c             	sub    $0xc,%esp
801060cc:	ff 75 f4             	push   -0xc(%ebp)
801060cf:	e8 3c cc ff ff       	call   80102d10 <namei>
801060d4:	83 c4 10             	add    $0x10,%esp
801060d7:	89 c3                	mov    %eax,%ebx
801060d9:	85 c0                	test   %eax,%eax
801060db:	74 63                	je     80106140 <sys_chdir+0xa0>
    end_op();
    return -1;
  }
  ilock(ip);
801060dd:	83 ec 0c             	sub    $0xc,%esp
801060e0:	50                   	push   %eax
801060e1:	e8 4a c3 ff ff       	call   80102430 <ilock>
  if(ip->type != T_DIR){
801060e6:	83 c4 10             	add    $0x10,%esp
801060e9:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
801060ee:	75 30                	jne    80106120 <sys_chdir+0x80>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
801060f0:	83 ec 0c             	sub    $0xc,%esp
801060f3:	53                   	push   %ebx
801060f4:	e8 17 c4 ff ff       	call   80102510 <iunlock>
  iput(curproc->cwd);
801060f9:	58                   	pop    %eax
801060fa:	ff 76 68             	push   0x68(%esi)
801060fd:	e8 5e c4 ff ff       	call   80102560 <iput>
  end_op();
80106102:	e8 39 d9 ff ff       	call   80103a40 <end_op>
  curproc->cwd = ip;
80106107:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
8010610a:	83 c4 10             	add    $0x10,%esp
8010610d:	31 c0                	xor    %eax,%eax
}
8010610f:	8d 65 f8             	lea    -0x8(%ebp),%esp
80106112:	5b                   	pop    %ebx
80106113:	5e                   	pop    %esi
80106114:	5d                   	pop    %ebp
80106115:	c3                   	ret
80106116:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010611d:	00 
8010611e:	66 90                	xchg   %ax,%ax
    iunlockput(ip);
80106120:	83 ec 0c             	sub    $0xc,%esp
80106123:	53                   	push   %ebx
80106124:	e8 97 c5 ff ff       	call   801026c0 <iunlockput>
    end_op();
80106129:	e8 12 d9 ff ff       	call   80103a40 <end_op>
    return -1;
8010612e:	83 c4 10             	add    $0x10,%esp
    return -1;
80106131:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80106136:	eb d7                	jmp    8010610f <sys_chdir+0x6f>
80106138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010613f:	00 
    end_op();
80106140:	e8 fb d8 ff ff       	call   80103a40 <end_op>
    return -1;
80106145:	eb ea                	jmp    80106131 <sys_chdir+0x91>
80106147:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010614e:	00 
8010614f:	90                   	nop

80106150 <sys_exec>:

int
sys_exec(void)
{
80106150:	55                   	push   %ebp
80106151:	89 e5                	mov    %esp,%ebp
80106153:	57                   	push   %edi
80106154:	56                   	push   %esi
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80106155:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
{
8010615b:	53                   	push   %ebx
8010615c:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80106162:	50                   	push   %eax
80106163:	6a 00                	push   $0x0
80106165:	e8 36 f5 ff ff       	call   801056a0 <argstr>
8010616a:	83 c4 10             	add    $0x10,%esp
8010616d:	85 c0                	test   %eax,%eax
8010616f:	0f 88 87 00 00 00    	js     801061fc <sys_exec+0xac>
80106175:	83 ec 08             	sub    $0x8,%esp
80106178:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
8010617e:	50                   	push   %eax
8010617f:	6a 01                	push   $0x1
80106181:	e8 5a f4 ff ff       	call   801055e0 <argint>
80106186:	83 c4 10             	add    $0x10,%esp
80106189:	85 c0                	test   %eax,%eax
8010618b:	78 6f                	js     801061fc <sys_exec+0xac>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
8010618d:	83 ec 04             	sub    $0x4,%esp
80106190:	8d b5 68 ff ff ff    	lea    -0x98(%ebp),%esi
  for(i=0;; i++){
80106196:	31 db                	xor    %ebx,%ebx
  memset(argv, 0, sizeof(argv));
80106198:	68 80 00 00 00       	push   $0x80
8010619d:	6a 00                	push   $0x0
8010619f:	56                   	push   %esi
801061a0:	e8 8b f1 ff ff       	call   80105330 <memset>
801061a5:	83 c4 10             	add    $0x10,%esp
801061a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801061af:	00 
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
801061b0:	83 ec 08             	sub    $0x8,%esp
801061b3:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
801061b9:	8d 3c 9d 00 00 00 00 	lea    0x0(,%ebx,4),%edi
801061c0:	50                   	push   %eax
801061c1:	8b 85 60 ff ff ff    	mov    -0xa0(%ebp),%eax
801061c7:	01 f8                	add    %edi,%eax
801061c9:	50                   	push   %eax
801061ca:	e8 81 f3 ff ff       	call   80105550 <fetchint>
801061cf:	83 c4 10             	add    $0x10,%esp
801061d2:	85 c0                	test   %eax,%eax
801061d4:	78 26                	js     801061fc <sys_exec+0xac>
      return -1;
    if(uarg == 0){
801061d6:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
801061dc:	85 c0                	test   %eax,%eax
801061de:	74 30                	je     80106210 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
801061e0:	83 ec 08             	sub    $0x8,%esp
801061e3:	8d 14 3e             	lea    (%esi,%edi,1),%edx
801061e6:	52                   	push   %edx
801061e7:	50                   	push   %eax
801061e8:	e8 a3 f3 ff ff       	call   80105590 <fetchstr>
801061ed:	83 c4 10             	add    $0x10,%esp
801061f0:	85 c0                	test   %eax,%eax
801061f2:	78 08                	js     801061fc <sys_exec+0xac>
  for(i=0;; i++){
801061f4:	83 c3 01             	add    $0x1,%ebx
    if(i >= NELEM(argv))
801061f7:	83 fb 20             	cmp    $0x20,%ebx
801061fa:	75 b4                	jne    801061b0 <sys_exec+0x60>
      return -1;
  }
  return exec(path, argv);
}
801061fc:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return -1;
801061ff:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106204:	5b                   	pop    %ebx
80106205:	5e                   	pop    %esi
80106206:	5f                   	pop    %edi
80106207:	5d                   	pop    %ebp
80106208:	c3                   	ret
80106209:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      argv[i] = 0;
80106210:	c7 84 9d 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%ebx,4)
80106217:	00 00 00 00 
  return exec(path, argv);
8010621b:	83 ec 08             	sub    $0x8,%esp
8010621e:	56                   	push   %esi
8010621f:	ff b5 5c ff ff ff    	push   -0xa4(%ebp)
80106225:	e8 16 b5 ff ff       	call   80101740 <exec>
8010622a:	83 c4 10             	add    $0x10,%esp
}
8010622d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106230:	5b                   	pop    %ebx
80106231:	5e                   	pop    %esi
80106232:	5f                   	pop    %edi
80106233:	5d                   	pop    %ebp
80106234:	c3                   	ret
80106235:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010623c:	00 
8010623d:	8d 76 00             	lea    0x0(%esi),%esi

80106240 <sys_pipe>:

int
sys_pipe(void)
{
80106240:	55                   	push   %ebp
80106241:	89 e5                	mov    %esp,%ebp
80106243:	57                   	push   %edi
80106244:	56                   	push   %esi
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80106245:	8d 45 dc             	lea    -0x24(%ebp),%eax
{
80106248:	53                   	push   %ebx
80106249:	83 ec 20             	sub    $0x20,%esp
  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
8010624c:	6a 08                	push   $0x8
8010624e:	50                   	push   %eax
8010624f:	6a 00                	push   $0x0
80106251:	e8 da f3 ff ff       	call   80105630 <argptr>
80106256:	83 c4 10             	add    $0x10,%esp
80106259:	85 c0                	test   %eax,%eax
8010625b:	0f 88 8b 00 00 00    	js     801062ec <sys_pipe+0xac>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80106261:	83 ec 08             	sub    $0x8,%esp
80106264:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80106267:	50                   	push   %eax
80106268:	8d 45 e0             	lea    -0x20(%ebp),%eax
8010626b:	50                   	push   %eax
8010626c:	e8 2f de ff ff       	call   801040a0 <pipealloc>
80106271:	83 c4 10             	add    $0x10,%esp
80106274:	85 c0                	test   %eax,%eax
80106276:	78 74                	js     801062ec <sys_pipe+0xac>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80106278:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(fd = 0; fd < NOFILE; fd++){
8010627b:	31 db                	xor    %ebx,%ebx
  struct proc *curproc = myproc();
8010627d:	e8 6e e3 ff ff       	call   801045f0 <myproc>
    if(curproc->ofile[fd] == 0){
80106282:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
80106286:	85 f6                	test   %esi,%esi
80106288:	74 16                	je     801062a0 <sys_pipe+0x60>
8010628a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(fd = 0; fd < NOFILE; fd++){
80106290:	83 c3 01             	add    $0x1,%ebx
80106293:	83 fb 10             	cmp    $0x10,%ebx
80106296:	74 3d                	je     801062d5 <sys_pipe+0x95>
    if(curproc->ofile[fd] == 0){
80106298:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
8010629c:	85 f6                	test   %esi,%esi
8010629e:	75 f0                	jne    80106290 <sys_pipe+0x50>
      curproc->ofile[fd] = f;
801062a0:	8d 73 08             	lea    0x8(%ebx),%esi
801062a3:	89 7c b0 08          	mov    %edi,0x8(%eax,%esi,4)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
801062a7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  struct proc *curproc = myproc();
801062aa:	e8 41 e3 ff ff       	call   801045f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
801062af:	31 d2                	xor    %edx,%edx
801062b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(curproc->ofile[fd] == 0){
801062b8:	8b 4c 90 28          	mov    0x28(%eax,%edx,4),%ecx
801062bc:	85 c9                	test   %ecx,%ecx
801062be:	74 38                	je     801062f8 <sys_pipe+0xb8>
  for(fd = 0; fd < NOFILE; fd++){
801062c0:	83 c2 01             	add    $0x1,%edx
801062c3:	83 fa 10             	cmp    $0x10,%edx
801062c6:	75 f0                	jne    801062b8 <sys_pipe+0x78>
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
801062c8:	e8 23 e3 ff ff       	call   801045f0 <myproc>
801062cd:	c7 44 b0 08 00 00 00 	movl   $0x0,0x8(%eax,%esi,4)
801062d4:	00 
    fileclose(rf);
801062d5:	83 ec 0c             	sub    $0xc,%esp
801062d8:	ff 75 e0             	push   -0x20(%ebp)
801062db:	e8 c0 b8 ff ff       	call   80101ba0 <fileclose>
    fileclose(wf);
801062e0:	58                   	pop    %eax
801062e1:	ff 75 e4             	push   -0x1c(%ebp)
801062e4:	e8 b7 b8 ff ff       	call   80101ba0 <fileclose>
    return -1;
801062e9:	83 c4 10             	add    $0x10,%esp
    return -1;
801062ec:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801062f1:	eb 16                	jmp    80106309 <sys_pipe+0xc9>
801062f3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      curproc->ofile[fd] = f;
801062f8:	89 7c 90 28          	mov    %edi,0x28(%eax,%edx,4)
  }
  fd[0] = fd0;
801062fc:	8b 45 dc             	mov    -0x24(%ebp),%eax
801062ff:	89 18                	mov    %ebx,(%eax)
  fd[1] = fd1;
80106301:	8b 45 dc             	mov    -0x24(%ebp),%eax
80106304:	89 50 04             	mov    %edx,0x4(%eax)
  return 0;
80106307:	31 c0                	xor    %eax,%eax
}
80106309:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010630c:	5b                   	pop    %ebx
8010630d:	5e                   	pop    %esi
8010630e:	5f                   	pop    %edi
8010630f:	5d                   	pop    %ebp
80106310:	c3                   	ret
80106311:	66 90                	xchg   %ax,%ax
80106313:	66 90                	xchg   %ax,%ax
80106315:	66 90                	xchg   %ax,%ax
80106317:	66 90                	xchg   %ax,%ax
80106319:	66 90                	xchg   %ax,%ax
8010631b:	66 90                	xchg   %ax,%ax
8010631d:	66 90                	xchg   %ax,%ax
8010631f:	90                   	nop

80106320 <sys_fork>:
#include "proc.h"

int
sys_fork(void)
{
  return fork();
80106320:	e9 6b e4 ff ff       	jmp    80104790 <fork>
80106325:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010632c:	00 
8010632d:	8d 76 00             	lea    0x0(%esi),%esi

80106330 <sys_exit>:
}

int
sys_exit(void)
{
80106330:	55                   	push   %ebp
80106331:	89 e5                	mov    %esp,%ebp
80106333:	83 ec 08             	sub    $0x8,%esp
  exit();
80106336:	e8 c5 e6 ff ff       	call   80104a00 <exit>
  return 0;  // not reached
}
8010633b:	31 c0                	xor    %eax,%eax
8010633d:	c9                   	leave
8010633e:	c3                   	ret
8010633f:	90                   	nop

80106340 <sys_wait>:

int
sys_wait(void)
{
  return wait();
80106340:	e9 eb e7 ff ff       	jmp    80104b30 <wait>
80106345:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010634c:	00 
8010634d:	8d 76 00             	lea    0x0(%esi),%esi

80106350 <sys_kill>:
}

int
sys_kill(void)
{
80106350:	55                   	push   %ebp
80106351:	89 e5                	mov    %esp,%ebp
80106353:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
80106356:	8d 45 f4             	lea    -0xc(%ebp),%eax
80106359:	50                   	push   %eax
8010635a:	6a 00                	push   $0x0
8010635c:	e8 7f f2 ff ff       	call   801055e0 <argint>
80106361:	83 c4 10             	add    $0x10,%esp
80106364:	85 c0                	test   %eax,%eax
80106366:	78 18                	js     80106380 <sys_kill+0x30>
    return -1;
  return kill(pid);
80106368:	83 ec 0c             	sub    $0xc,%esp
8010636b:	ff 75 f4             	push   -0xc(%ebp)
8010636e:	e8 5d ea ff ff       	call   80104dd0 <kill>
80106373:	83 c4 10             	add    $0x10,%esp
}
80106376:	c9                   	leave
80106377:	c3                   	ret
80106378:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010637f:	00 
80106380:	c9                   	leave
    return -1;
80106381:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106386:	c3                   	ret
80106387:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010638e:	00 
8010638f:	90                   	nop

80106390 <sys_getpid>:

int
sys_getpid(void)
{
80106390:	55                   	push   %ebp
80106391:	89 e5                	mov    %esp,%ebp
80106393:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80106396:	e8 55 e2 ff ff       	call   801045f0 <myproc>
8010639b:	8b 40 10             	mov    0x10(%eax),%eax
}
8010639e:	c9                   	leave
8010639f:	c3                   	ret

801063a0 <sys_sbrk>:

int
sys_sbrk(void)
{
801063a0:	55                   	push   %ebp
801063a1:	89 e5                	mov    %esp,%ebp
801063a3:	53                   	push   %ebx
  int addr;
  int n;

  if(argint(0, &n) < 0)
801063a4:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
801063a7:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
801063aa:	50                   	push   %eax
801063ab:	6a 00                	push   $0x0
801063ad:	e8 2e f2 ff ff       	call   801055e0 <argint>
801063b2:	83 c4 10             	add    $0x10,%esp
801063b5:	85 c0                	test   %eax,%eax
801063b7:	78 27                	js     801063e0 <sys_sbrk+0x40>
    return -1;
  addr = myproc()->sz;
801063b9:	e8 32 e2 ff ff       	call   801045f0 <myproc>
  if(growproc(n) < 0)
801063be:	83 ec 0c             	sub    $0xc,%esp
  addr = myproc()->sz;
801063c1:	8b 18                	mov    (%eax),%ebx
  if(growproc(n) < 0)
801063c3:	ff 75 f4             	push   -0xc(%ebp)
801063c6:	e8 45 e3 ff ff       	call   80104710 <growproc>
801063cb:	83 c4 10             	add    $0x10,%esp
801063ce:	85 c0                	test   %eax,%eax
801063d0:	78 0e                	js     801063e0 <sys_sbrk+0x40>
    return -1;
  return addr;
}
801063d2:	89 d8                	mov    %ebx,%eax
801063d4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801063d7:	c9                   	leave
801063d8:	c3                   	ret
801063d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
801063e0:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801063e5:	eb eb                	jmp    801063d2 <sys_sbrk+0x32>
801063e7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801063ee:	00 
801063ef:	90                   	nop

801063f0 <sys_sleep>:

int
sys_sleep(void)
{
801063f0:	55                   	push   %ebp
801063f1:	89 e5                	mov    %esp,%ebp
801063f3:	53                   	push   %ebx
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
801063f4:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
801063f7:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
801063fa:	50                   	push   %eax
801063fb:	6a 00                	push   $0x0
801063fd:	e8 de f1 ff ff       	call   801055e0 <argint>
80106402:	83 c4 10             	add    $0x10,%esp
80106405:	85 c0                	test   %eax,%eax
80106407:	78 64                	js     8010646d <sys_sleep+0x7d>
    return -1;
  acquire(&tickslock);
80106409:	83 ec 0c             	sub    $0xc,%esp
8010640c:	68 20 4f 11 80       	push   $0x80114f20
80106411:	e8 1a ee ff ff       	call   80105230 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
80106416:	8b 55 f4             	mov    -0xc(%ebp),%edx
  ticks0 = ticks;
80106419:	8b 1d 00 4f 11 80    	mov    0x80114f00,%ebx
  while(ticks - ticks0 < n){
8010641f:	83 c4 10             	add    $0x10,%esp
80106422:	85 d2                	test   %edx,%edx
80106424:	75 2b                	jne    80106451 <sys_sleep+0x61>
80106426:	eb 58                	jmp    80106480 <sys_sleep+0x90>
80106428:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010642f:	00 
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80106430:	83 ec 08             	sub    $0x8,%esp
80106433:	68 20 4f 11 80       	push   $0x80114f20
80106438:	68 00 4f 11 80       	push   $0x80114f00
8010643d:	e8 6e e8 ff ff       	call   80104cb0 <sleep>
  while(ticks - ticks0 < n){
80106442:	a1 00 4f 11 80       	mov    0x80114f00,%eax
80106447:	83 c4 10             	add    $0x10,%esp
8010644a:	29 d8                	sub    %ebx,%eax
8010644c:	3b 45 f4             	cmp    -0xc(%ebp),%eax
8010644f:	73 2f                	jae    80106480 <sys_sleep+0x90>
    if(myproc()->killed){
80106451:	e8 9a e1 ff ff       	call   801045f0 <myproc>
80106456:	8b 40 24             	mov    0x24(%eax),%eax
80106459:	85 c0                	test   %eax,%eax
8010645b:	74 d3                	je     80106430 <sys_sleep+0x40>
      release(&tickslock);
8010645d:	83 ec 0c             	sub    $0xc,%esp
80106460:	68 20 4f 11 80       	push   $0x80114f20
80106465:	e8 66 ed ff ff       	call   801051d0 <release>
      return -1;
8010646a:	83 c4 10             	add    $0x10,%esp
  }
  release(&tickslock);
  return 0;
}
8010646d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
80106470:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106475:	c9                   	leave
80106476:	c3                   	ret
80106477:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010647e:	00 
8010647f:	90                   	nop
  release(&tickslock);
80106480:	83 ec 0c             	sub    $0xc,%esp
80106483:	68 20 4f 11 80       	push   $0x80114f20
80106488:	e8 43 ed ff ff       	call   801051d0 <release>
}
8010648d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return 0;
80106490:	83 c4 10             	add    $0x10,%esp
80106493:	31 c0                	xor    %eax,%eax
}
80106495:	c9                   	leave
80106496:	c3                   	ret
80106497:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010649e:	00 
8010649f:	90                   	nop

801064a0 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
801064a0:	55                   	push   %ebp
801064a1:	89 e5                	mov    %esp,%ebp
801064a3:	53                   	push   %ebx
801064a4:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
801064a7:	68 20 4f 11 80       	push   $0x80114f20
801064ac:	e8 7f ed ff ff       	call   80105230 <acquire>
  xticks = ticks;
801064b1:	8b 1d 00 4f 11 80    	mov    0x80114f00,%ebx
  release(&tickslock);
801064b7:	c7 04 24 20 4f 11 80 	movl   $0x80114f20,(%esp)
801064be:	e8 0d ed ff ff       	call   801051d0 <release>
  return xticks;
}
801064c3:	89 d8                	mov    %ebx,%eax
801064c5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801064c8:	c9                   	leave
801064c9:	c3                   	ret

801064ca <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
801064ca:	1e                   	push   %ds
  pushl %es
801064cb:	06                   	push   %es
  pushl %fs
801064cc:	0f a0                	push   %fs
  pushl %gs
801064ce:	0f a8                	push   %gs
  pushal
801064d0:	60                   	pusha
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
801064d1:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
801064d5:	8e d8                	mov    %eax,%ds
  movw %ax, %es
801064d7:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
801064d9:	54                   	push   %esp
  call trap
801064da:	e8 c1 00 00 00       	call   801065a0 <trap>
  addl $4, %esp
801064df:	83 c4 04             	add    $0x4,%esp

801064e2 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
801064e2:	61                   	popa
  popl %gs
801064e3:	0f a9                	pop    %gs
  popl %fs
801064e5:	0f a1                	pop    %fs
  popl %es
801064e7:	07                   	pop    %es
  popl %ds
801064e8:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
801064e9:	83 c4 08             	add    $0x8,%esp
  iret
801064ec:	cf                   	iret
801064ed:	66 90                	xchg   %ax,%ax
801064ef:	90                   	nop

801064f0 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
801064f0:	55                   	push   %ebp
  int i;

  for(i = 0; i < 256; i++)
801064f1:	31 c0                	xor    %eax,%eax
{
801064f3:	89 e5                	mov    %esp,%ebp
801064f5:	83 ec 08             	sub    $0x8,%esp
801064f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801064ff:	00 
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80106500:	8b 14 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%edx
80106507:	c7 04 c5 62 4f 11 80 	movl   $0x8e000008,-0x7feeb09e(,%eax,8)
8010650e:	08 00 00 8e 
80106512:	66 89 14 c5 60 4f 11 	mov    %dx,-0x7feeb0a0(,%eax,8)
80106519:	80 
8010651a:	c1 ea 10             	shr    $0x10,%edx
8010651d:	66 89 14 c5 66 4f 11 	mov    %dx,-0x7feeb09a(,%eax,8)
80106524:	80 
  for(i = 0; i < 256; i++)
80106525:	83 c0 01             	add    $0x1,%eax
80106528:	3d 00 01 00 00       	cmp    $0x100,%eax
8010652d:	75 d1                	jne    80106500 <tvinit+0x10>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
8010652f:	83 ec 08             	sub    $0x8,%esp
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80106532:	a1 08 b1 10 80       	mov    0x8010b108,%eax
80106537:	c7 05 62 51 11 80 08 	movl   $0xef000008,0x80115162
8010653e:	00 00 ef 
  initlock(&tickslock, "time");
80106541:	68 df 81 10 80       	push   $0x801081df
80106546:	68 20 4f 11 80       	push   $0x80114f20
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
8010654b:	66 a3 60 51 11 80    	mov    %ax,0x80115160
80106551:	c1 e8 10             	shr    $0x10,%eax
80106554:	66 a3 66 51 11 80    	mov    %ax,0x80115166
  initlock(&tickslock, "time");
8010655a:	e8 e1 ea ff ff       	call   80105040 <initlock>
}
8010655f:	83 c4 10             	add    $0x10,%esp
80106562:	c9                   	leave
80106563:	c3                   	ret
80106564:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010656b:	00 
8010656c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80106570 <idtinit>:

void
idtinit(void)
{
80106570:	55                   	push   %ebp
  pd[0] = size-1;
80106571:	b8 ff 07 00 00       	mov    $0x7ff,%eax
80106576:	89 e5                	mov    %esp,%ebp
80106578:	83 ec 10             	sub    $0x10,%esp
8010657b:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
8010657f:	b8 60 4f 11 80       	mov    $0x80114f60,%eax
80106584:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80106588:	c1 e8 10             	shr    $0x10,%eax
8010658b:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
8010658f:	8d 45 fa             	lea    -0x6(%ebp),%eax
80106592:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80106595:	c9                   	leave
80106596:	c3                   	ret
80106597:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010659e:	00 
8010659f:	90                   	nop

801065a0 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
801065a0:	55                   	push   %ebp
801065a1:	89 e5                	mov    %esp,%ebp
801065a3:	57                   	push   %edi
801065a4:	56                   	push   %esi
801065a5:	53                   	push   %ebx
801065a6:	83 ec 1c             	sub    $0x1c,%esp
801065a9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(tf->trapno == T_SYSCALL){
801065ac:	8b 43 30             	mov    0x30(%ebx),%eax
801065af:	83 f8 40             	cmp    $0x40,%eax
801065b2:	0f 84 58 01 00 00    	je     80106710 <trap+0x170>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
801065b8:	83 e8 20             	sub    $0x20,%eax
801065bb:	83 f8 1f             	cmp    $0x1f,%eax
801065be:	0f 87 7c 00 00 00    	ja     80106640 <trap+0xa0>
801065c4:	ff 24 85 f8 87 10 80 	jmp    *-0x7fef7808(,%eax,4)
801065cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
801065d0:	e8 eb c8 ff ff       	call   80102ec0 <ideintr>
    lapiceoi();
801065d5:	e8 a6 cf ff ff       	call   80103580 <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801065da:	e8 11 e0 ff ff       	call   801045f0 <myproc>
801065df:	85 c0                	test   %eax,%eax
801065e1:	74 1a                	je     801065fd <trap+0x5d>
801065e3:	e8 08 e0 ff ff       	call   801045f0 <myproc>
801065e8:	8b 50 24             	mov    0x24(%eax),%edx
801065eb:	85 d2                	test   %edx,%edx
801065ed:	74 0e                	je     801065fd <trap+0x5d>
801065ef:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
801065f3:	f7 d0                	not    %eax
801065f5:	a8 03                	test   $0x3,%al
801065f7:	0f 84 db 01 00 00    	je     801067d8 <trap+0x238>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
801065fd:	e8 ee df ff ff       	call   801045f0 <myproc>
80106602:	85 c0                	test   %eax,%eax
80106604:	74 0f                	je     80106615 <trap+0x75>
80106606:	e8 e5 df ff ff       	call   801045f0 <myproc>
8010660b:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
8010660f:	0f 84 ab 00 00 00    	je     801066c0 <trap+0x120>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80106615:	e8 d6 df ff ff       	call   801045f0 <myproc>
8010661a:	85 c0                	test   %eax,%eax
8010661c:	74 1a                	je     80106638 <trap+0x98>
8010661e:	e8 cd df ff ff       	call   801045f0 <myproc>
80106623:	8b 40 24             	mov    0x24(%eax),%eax
80106626:	85 c0                	test   %eax,%eax
80106628:	74 0e                	je     80106638 <trap+0x98>
8010662a:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
8010662e:	f7 d0                	not    %eax
80106630:	a8 03                	test   $0x3,%al
80106632:	0f 84 05 01 00 00    	je     8010673d <trap+0x19d>
    exit();
}
80106638:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010663b:	5b                   	pop    %ebx
8010663c:	5e                   	pop    %esi
8010663d:	5f                   	pop    %edi
8010663e:	5d                   	pop    %ebp
8010663f:	c3                   	ret
    if(myproc() == 0 || (tf->cs&3) == 0){
80106640:	e8 ab df ff ff       	call   801045f0 <myproc>
80106645:	8b 7b 38             	mov    0x38(%ebx),%edi
80106648:	85 c0                	test   %eax,%eax
8010664a:	0f 84 a2 01 00 00    	je     801067f2 <trap+0x252>
80106650:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
80106654:	0f 84 98 01 00 00    	je     801067f2 <trap+0x252>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
8010665a:	0f 20 d1             	mov    %cr2,%ecx
8010665d:	89 4d d8             	mov    %ecx,-0x28(%ebp)
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106660:	e8 6b df ff ff       	call   801045d0 <cpuid>
80106665:	8b 73 30             	mov    0x30(%ebx),%esi
80106668:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010666b:	8b 43 34             	mov    0x34(%ebx),%eax
8010666e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80106671:	e8 7a df ff ff       	call   801045f0 <myproc>
80106676:	89 45 e0             	mov    %eax,-0x20(%ebp)
80106679:	e8 72 df ff ff       	call   801045f0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010667e:	8b 4d d8             	mov    -0x28(%ebp),%ecx
80106681:	51                   	push   %ecx
80106682:	57                   	push   %edi
80106683:	8b 55 dc             	mov    -0x24(%ebp),%edx
80106686:	52                   	push   %edx
80106687:	ff 75 e4             	push   -0x1c(%ebp)
8010668a:	56                   	push   %esi
            myproc()->pid, myproc()->name, tf->trapno,
8010668b:	8b 75 e0             	mov    -0x20(%ebp),%esi
8010668e:	83 c6 6c             	add    $0x6c,%esi
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80106691:	56                   	push   %esi
80106692:	ff 70 10             	push   0x10(%eax)
80106695:	68 ec 84 10 80       	push   $0x801084ec
8010669a:	e8 41 a6 ff ff       	call   80100ce0 <cprintf>
    myproc()->killed = 1;
8010669f:	83 c4 20             	add    $0x20,%esp
801066a2:	e8 49 df ff ff       	call   801045f0 <myproc>
801066a7:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801066ae:	e8 3d df ff ff       	call   801045f0 <myproc>
801066b3:	85 c0                	test   %eax,%eax
801066b5:	0f 85 28 ff ff ff    	jne    801065e3 <trap+0x43>
801066bb:	e9 3d ff ff ff       	jmp    801065fd <trap+0x5d>
  if(myproc() && myproc()->state == RUNNING &&
801066c0:	83 7b 30 20          	cmpl   $0x20,0x30(%ebx)
801066c4:	0f 85 4b ff ff ff    	jne    80106615 <trap+0x75>
    yield();
801066ca:	e8 91 e5 ff ff       	call   80104c60 <yield>
801066cf:	e9 41 ff ff ff       	jmp    80106615 <trap+0x75>
801066d4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
801066d8:	8b 7b 38             	mov    0x38(%ebx),%edi
801066db:	0f b7 73 3c          	movzwl 0x3c(%ebx),%esi
801066df:	e8 ec de ff ff       	call   801045d0 <cpuid>
801066e4:	57                   	push   %edi
801066e5:	56                   	push   %esi
801066e6:	50                   	push   %eax
801066e7:	68 94 84 10 80       	push   $0x80108494
801066ec:	e8 ef a5 ff ff       	call   80100ce0 <cprintf>
    lapiceoi();
801066f1:	e8 8a ce ff ff       	call   80103580 <lapiceoi>
    break;
801066f6:	83 c4 10             	add    $0x10,%esp
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
801066f9:	e8 f2 de ff ff       	call   801045f0 <myproc>
801066fe:	85 c0                	test   %eax,%eax
80106700:	0f 85 dd fe ff ff    	jne    801065e3 <trap+0x43>
80106706:	e9 f2 fe ff ff       	jmp    801065fd <trap+0x5d>
8010670b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(myproc()->killed)
80106710:	e8 db de ff ff       	call   801045f0 <myproc>
80106715:	8b 70 24             	mov    0x24(%eax),%esi
80106718:	85 f6                	test   %esi,%esi
8010671a:	0f 85 c8 00 00 00    	jne    801067e8 <trap+0x248>
    myproc()->tf = tf;
80106720:	e8 cb de ff ff       	call   801045f0 <myproc>
80106725:	89 58 18             	mov    %ebx,0x18(%eax)
    syscall();
80106728:	e8 f3 ef ff ff       	call   80105720 <syscall>
    if(myproc()->killed)
8010672d:	e8 be de ff ff       	call   801045f0 <myproc>
80106732:	8b 48 24             	mov    0x24(%eax),%ecx
80106735:	85 c9                	test   %ecx,%ecx
80106737:	0f 84 fb fe ff ff    	je     80106638 <trap+0x98>
}
8010673d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106740:	5b                   	pop    %ebx
80106741:	5e                   	pop    %esi
80106742:	5f                   	pop    %edi
80106743:	5d                   	pop    %ebp
      exit();
80106744:	e9 b7 e2 ff ff       	jmp    80104a00 <exit>
80106749:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    uartintr();
80106750:	e8 4b 02 00 00       	call   801069a0 <uartintr>
    lapiceoi();
80106755:	e8 26 ce ff ff       	call   80103580 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010675a:	e8 91 de ff ff       	call   801045f0 <myproc>
8010675f:	85 c0                	test   %eax,%eax
80106761:	0f 85 7c fe ff ff    	jne    801065e3 <trap+0x43>
80106767:	e9 91 fe ff ff       	jmp    801065fd <trap+0x5d>
8010676c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    kbdintr();
80106770:	e8 db cc ff ff       	call   80103450 <kbdintr>
    lapiceoi();
80106775:	e8 06 ce ff ff       	call   80103580 <lapiceoi>
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010677a:	e8 71 de ff ff       	call   801045f0 <myproc>
8010677f:	85 c0                	test   %eax,%eax
80106781:	0f 85 5c fe ff ff    	jne    801065e3 <trap+0x43>
80106787:	e9 71 fe ff ff       	jmp    801065fd <trap+0x5d>
8010678c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(cpuid() == 0){
80106790:	e8 3b de ff ff       	call   801045d0 <cpuid>
80106795:	85 c0                	test   %eax,%eax
80106797:	0f 85 38 fe ff ff    	jne    801065d5 <trap+0x35>
      acquire(&tickslock);
8010679d:	83 ec 0c             	sub    $0xc,%esp
801067a0:	68 20 4f 11 80       	push   $0x80114f20
801067a5:	e8 86 ea ff ff       	call   80105230 <acquire>
      ticks++;
801067aa:	83 05 00 4f 11 80 01 	addl   $0x1,0x80114f00
      wakeup(&ticks);
801067b1:	c7 04 24 00 4f 11 80 	movl   $0x80114f00,(%esp)
801067b8:	e8 b3 e5 ff ff       	call   80104d70 <wakeup>
      release(&tickslock);
801067bd:	c7 04 24 20 4f 11 80 	movl   $0x80114f20,(%esp)
801067c4:	e8 07 ea ff ff       	call   801051d0 <release>
801067c9:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
801067cc:	e9 04 fe ff ff       	jmp    801065d5 <trap+0x35>
801067d1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    exit();
801067d8:	e8 23 e2 ff ff       	call   80104a00 <exit>
801067dd:	e9 1b fe ff ff       	jmp    801065fd <trap+0x5d>
801067e2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      exit();
801067e8:	e8 13 e2 ff ff       	call   80104a00 <exit>
801067ed:	e9 2e ff ff ff       	jmp    80106720 <trap+0x180>
801067f2:	0f 20 d6             	mov    %cr2,%esi
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
801067f5:	e8 d6 dd ff ff       	call   801045d0 <cpuid>
801067fa:	83 ec 0c             	sub    $0xc,%esp
801067fd:	56                   	push   %esi
801067fe:	57                   	push   %edi
801067ff:	50                   	push   %eax
80106800:	ff 73 30             	push   0x30(%ebx)
80106803:	68 b8 84 10 80       	push   $0x801084b8
80106808:	e8 d3 a4 ff ff       	call   80100ce0 <cprintf>
      panic("trap");
8010680d:	83 c4 14             	add    $0x14,%esp
80106810:	68 e4 81 10 80       	push   $0x801081e4
80106815:	e8 66 9b ff ff       	call   80100380 <panic>
8010681a:	66 90                	xchg   %ax,%ax
8010681c:	66 90                	xchg   %ax,%ax
8010681e:	66 90                	xchg   %ax,%ax

80106820 <uartgetc>:
}

static int
uartgetc(void)
{
  if(!uart)
80106820:	a1 60 57 11 80       	mov    0x80115760,%eax
80106825:	85 c0                	test   %eax,%eax
80106827:	74 17                	je     80106840 <uartgetc+0x20>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80106829:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010682e:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
8010682f:	a8 01                	test   $0x1,%al
80106831:	74 0d                	je     80106840 <uartgetc+0x20>
80106833:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106838:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
80106839:	0f b6 c0             	movzbl %al,%eax
8010683c:	c3                   	ret
8010683d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80106840:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106845:	c3                   	ret
80106846:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010684d:	00 
8010684e:	66 90                	xchg   %ax,%ax

80106850 <uartinit>:
{
80106850:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106851:	31 c9                	xor    %ecx,%ecx
80106853:	89 c8                	mov    %ecx,%eax
80106855:	89 e5                	mov    %esp,%ebp
80106857:	57                   	push   %edi
80106858:	bf fa 03 00 00       	mov    $0x3fa,%edi
8010685d:	56                   	push   %esi
8010685e:	89 fa                	mov    %edi,%edx
80106860:	53                   	push   %ebx
80106861:	83 ec 1c             	sub    $0x1c,%esp
80106864:	ee                   	out    %al,(%dx)
80106865:	be fb 03 00 00       	mov    $0x3fb,%esi
8010686a:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
8010686f:	89 f2                	mov    %esi,%edx
80106871:	ee                   	out    %al,(%dx)
80106872:	b8 0c 00 00 00       	mov    $0xc,%eax
80106877:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010687c:	ee                   	out    %al,(%dx)
8010687d:	bb f9 03 00 00       	mov    $0x3f9,%ebx
80106882:	89 c8                	mov    %ecx,%eax
80106884:	89 da                	mov    %ebx,%edx
80106886:	ee                   	out    %al,(%dx)
80106887:	b8 03 00 00 00       	mov    $0x3,%eax
8010688c:	89 f2                	mov    %esi,%edx
8010688e:	ee                   	out    %al,(%dx)
8010688f:	ba fc 03 00 00       	mov    $0x3fc,%edx
80106894:	89 c8                	mov    %ecx,%eax
80106896:	ee                   	out    %al,(%dx)
80106897:	b8 01 00 00 00       	mov    $0x1,%eax
8010689c:	89 da                	mov    %ebx,%edx
8010689e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010689f:	ba fd 03 00 00       	mov    $0x3fd,%edx
801068a4:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
801068a5:	3c ff                	cmp    $0xff,%al
801068a7:	0f 84 7c 00 00 00    	je     80106929 <uartinit+0xd9>
  uart = 1;
801068ad:	c7 05 60 57 11 80 01 	movl   $0x1,0x80115760
801068b4:	00 00 00 
801068b7:	89 fa                	mov    %edi,%edx
801068b9:	ec                   	in     (%dx),%al
801068ba:	ba f8 03 00 00       	mov    $0x3f8,%edx
801068bf:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
801068c0:	83 ec 08             	sub    $0x8,%esp
  for(p="xv6...\n"; *p; p++)
801068c3:	bf e9 81 10 80       	mov    $0x801081e9,%edi
801068c8:	be fd 03 00 00       	mov    $0x3fd,%esi
  ioapicenable(IRQ_COM1, 0);
801068cd:	6a 00                	push   $0x0
801068cf:	6a 04                	push   $0x4
801068d1:	e8 1a c8 ff ff       	call   801030f0 <ioapicenable>
801068d6:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
801068d9:	c6 45 e7 78          	movb   $0x78,-0x19(%ebp)
801068dd:	8d 76 00             	lea    0x0(%esi),%esi
  if(!uart)
801068e0:	a1 60 57 11 80       	mov    0x80115760,%eax
801068e5:	85 c0                	test   %eax,%eax
801068e7:	74 32                	je     8010691b <uartinit+0xcb>
801068e9:	89 f2                	mov    %esi,%edx
801068eb:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
801068ec:	a8 20                	test   $0x20,%al
801068ee:	75 21                	jne    80106911 <uartinit+0xc1>
801068f0:	bb 80 00 00 00       	mov    $0x80,%ebx
801068f5:	8d 76 00             	lea    0x0(%esi),%esi
    microdelay(10);
801068f8:	83 ec 0c             	sub    $0xc,%esp
801068fb:	6a 0a                	push   $0xa
801068fd:	e8 9e cc ff ff       	call   801035a0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106902:	83 c4 10             	add    $0x10,%esp
80106905:	83 eb 01             	sub    $0x1,%ebx
80106908:	74 07                	je     80106911 <uartinit+0xc1>
8010690a:	89 f2                	mov    %esi,%edx
8010690c:	ec                   	in     (%dx),%al
8010690d:	a8 20                	test   $0x20,%al
8010690f:	74 e7                	je     801068f8 <uartinit+0xa8>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106911:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106916:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
8010691a:	ee                   	out    %al,(%dx)
  for(p="xv6...\n"; *p; p++)
8010691b:	0f b6 47 01          	movzbl 0x1(%edi),%eax
8010691f:	83 c7 01             	add    $0x1,%edi
80106922:	88 45 e7             	mov    %al,-0x19(%ebp)
80106925:	84 c0                	test   %al,%al
80106927:	75 b7                	jne    801068e0 <uartinit+0x90>
}
80106929:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010692c:	5b                   	pop    %ebx
8010692d:	5e                   	pop    %esi
8010692e:	5f                   	pop    %edi
8010692f:	5d                   	pop    %ebp
80106930:	c3                   	ret
80106931:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106938:	00 
80106939:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80106940 <uartputc>:
  if(!uart)
80106940:	a1 60 57 11 80       	mov    0x80115760,%eax
80106945:	85 c0                	test   %eax,%eax
80106947:	74 4f                	je     80106998 <uartputc+0x58>
{
80106949:	55                   	push   %ebp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010694a:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010694f:	89 e5                	mov    %esp,%ebp
80106951:	56                   	push   %esi
80106952:	53                   	push   %ebx
80106953:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106954:	a8 20                	test   $0x20,%al
80106956:	75 29                	jne    80106981 <uartputc+0x41>
80106958:	bb 80 00 00 00       	mov    $0x80,%ebx
8010695d:	be fd 03 00 00       	mov    $0x3fd,%esi
80106962:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    microdelay(10);
80106968:	83 ec 0c             	sub    $0xc,%esp
8010696b:	6a 0a                	push   $0xa
8010696d:	e8 2e cc ff ff       	call   801035a0 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106972:	83 c4 10             	add    $0x10,%esp
80106975:	83 eb 01             	sub    $0x1,%ebx
80106978:	74 07                	je     80106981 <uartputc+0x41>
8010697a:	89 f2                	mov    %esi,%edx
8010697c:	ec                   	in     (%dx),%al
8010697d:	a8 20                	test   $0x20,%al
8010697f:	74 e7                	je     80106968 <uartputc+0x28>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106981:	8b 45 08             	mov    0x8(%ebp),%eax
80106984:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106989:	ee                   	out    %al,(%dx)
}
8010698a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010698d:	5b                   	pop    %ebx
8010698e:	5e                   	pop    %esi
8010698f:	5d                   	pop    %ebp
80106990:	c3                   	ret
80106991:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106998:	c3                   	ret
80106999:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801069a0 <uartintr>:

void
uartintr(void)
{
801069a0:	55                   	push   %ebp
801069a1:	89 e5                	mov    %esp,%ebp
801069a3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
801069a6:	68 20 68 10 80       	push   $0x80106820
801069ab:	e8 20 a5 ff ff       	call   80100ed0 <consoleintr>
}
801069b0:	83 c4 10             	add    $0x10,%esp
801069b3:	c9                   	leave
801069b4:	c3                   	ret

801069b5 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
801069b5:	6a 00                	push   $0x0
  pushl $0
801069b7:	6a 00                	push   $0x0
  jmp alltraps
801069b9:	e9 0c fb ff ff       	jmp    801064ca <alltraps>

801069be <vector1>:
.globl vector1
vector1:
  pushl $0
801069be:	6a 00                	push   $0x0
  pushl $1
801069c0:	6a 01                	push   $0x1
  jmp alltraps
801069c2:	e9 03 fb ff ff       	jmp    801064ca <alltraps>

801069c7 <vector2>:
.globl vector2
vector2:
  pushl $0
801069c7:	6a 00                	push   $0x0
  pushl $2
801069c9:	6a 02                	push   $0x2
  jmp alltraps
801069cb:	e9 fa fa ff ff       	jmp    801064ca <alltraps>

801069d0 <vector3>:
.globl vector3
vector3:
  pushl $0
801069d0:	6a 00                	push   $0x0
  pushl $3
801069d2:	6a 03                	push   $0x3
  jmp alltraps
801069d4:	e9 f1 fa ff ff       	jmp    801064ca <alltraps>

801069d9 <vector4>:
.globl vector4
vector4:
  pushl $0
801069d9:	6a 00                	push   $0x0
  pushl $4
801069db:	6a 04                	push   $0x4
  jmp alltraps
801069dd:	e9 e8 fa ff ff       	jmp    801064ca <alltraps>

801069e2 <vector5>:
.globl vector5
vector5:
  pushl $0
801069e2:	6a 00                	push   $0x0
  pushl $5
801069e4:	6a 05                	push   $0x5
  jmp alltraps
801069e6:	e9 df fa ff ff       	jmp    801064ca <alltraps>

801069eb <vector6>:
.globl vector6
vector6:
  pushl $0
801069eb:	6a 00                	push   $0x0
  pushl $6
801069ed:	6a 06                	push   $0x6
  jmp alltraps
801069ef:	e9 d6 fa ff ff       	jmp    801064ca <alltraps>

801069f4 <vector7>:
.globl vector7
vector7:
  pushl $0
801069f4:	6a 00                	push   $0x0
  pushl $7
801069f6:	6a 07                	push   $0x7
  jmp alltraps
801069f8:	e9 cd fa ff ff       	jmp    801064ca <alltraps>

801069fd <vector8>:
.globl vector8
vector8:
  pushl $8
801069fd:	6a 08                	push   $0x8
  jmp alltraps
801069ff:	e9 c6 fa ff ff       	jmp    801064ca <alltraps>

80106a04 <vector9>:
.globl vector9
vector9:
  pushl $0
80106a04:	6a 00                	push   $0x0
  pushl $9
80106a06:	6a 09                	push   $0x9
  jmp alltraps
80106a08:	e9 bd fa ff ff       	jmp    801064ca <alltraps>

80106a0d <vector10>:
.globl vector10
vector10:
  pushl $10
80106a0d:	6a 0a                	push   $0xa
  jmp alltraps
80106a0f:	e9 b6 fa ff ff       	jmp    801064ca <alltraps>

80106a14 <vector11>:
.globl vector11
vector11:
  pushl $11
80106a14:	6a 0b                	push   $0xb
  jmp alltraps
80106a16:	e9 af fa ff ff       	jmp    801064ca <alltraps>

80106a1b <vector12>:
.globl vector12
vector12:
  pushl $12
80106a1b:	6a 0c                	push   $0xc
  jmp alltraps
80106a1d:	e9 a8 fa ff ff       	jmp    801064ca <alltraps>

80106a22 <vector13>:
.globl vector13
vector13:
  pushl $13
80106a22:	6a 0d                	push   $0xd
  jmp alltraps
80106a24:	e9 a1 fa ff ff       	jmp    801064ca <alltraps>

80106a29 <vector14>:
.globl vector14
vector14:
  pushl $14
80106a29:	6a 0e                	push   $0xe
  jmp alltraps
80106a2b:	e9 9a fa ff ff       	jmp    801064ca <alltraps>

80106a30 <vector15>:
.globl vector15
vector15:
  pushl $0
80106a30:	6a 00                	push   $0x0
  pushl $15
80106a32:	6a 0f                	push   $0xf
  jmp alltraps
80106a34:	e9 91 fa ff ff       	jmp    801064ca <alltraps>

80106a39 <vector16>:
.globl vector16
vector16:
  pushl $0
80106a39:	6a 00                	push   $0x0
  pushl $16
80106a3b:	6a 10                	push   $0x10
  jmp alltraps
80106a3d:	e9 88 fa ff ff       	jmp    801064ca <alltraps>

80106a42 <vector17>:
.globl vector17
vector17:
  pushl $17
80106a42:	6a 11                	push   $0x11
  jmp alltraps
80106a44:	e9 81 fa ff ff       	jmp    801064ca <alltraps>

80106a49 <vector18>:
.globl vector18
vector18:
  pushl $0
80106a49:	6a 00                	push   $0x0
  pushl $18
80106a4b:	6a 12                	push   $0x12
  jmp alltraps
80106a4d:	e9 78 fa ff ff       	jmp    801064ca <alltraps>

80106a52 <vector19>:
.globl vector19
vector19:
  pushl $0
80106a52:	6a 00                	push   $0x0
  pushl $19
80106a54:	6a 13                	push   $0x13
  jmp alltraps
80106a56:	e9 6f fa ff ff       	jmp    801064ca <alltraps>

80106a5b <vector20>:
.globl vector20
vector20:
  pushl $0
80106a5b:	6a 00                	push   $0x0
  pushl $20
80106a5d:	6a 14                	push   $0x14
  jmp alltraps
80106a5f:	e9 66 fa ff ff       	jmp    801064ca <alltraps>

80106a64 <vector21>:
.globl vector21
vector21:
  pushl $0
80106a64:	6a 00                	push   $0x0
  pushl $21
80106a66:	6a 15                	push   $0x15
  jmp alltraps
80106a68:	e9 5d fa ff ff       	jmp    801064ca <alltraps>

80106a6d <vector22>:
.globl vector22
vector22:
  pushl $0
80106a6d:	6a 00                	push   $0x0
  pushl $22
80106a6f:	6a 16                	push   $0x16
  jmp alltraps
80106a71:	e9 54 fa ff ff       	jmp    801064ca <alltraps>

80106a76 <vector23>:
.globl vector23
vector23:
  pushl $0
80106a76:	6a 00                	push   $0x0
  pushl $23
80106a78:	6a 17                	push   $0x17
  jmp alltraps
80106a7a:	e9 4b fa ff ff       	jmp    801064ca <alltraps>

80106a7f <vector24>:
.globl vector24
vector24:
  pushl $0
80106a7f:	6a 00                	push   $0x0
  pushl $24
80106a81:	6a 18                	push   $0x18
  jmp alltraps
80106a83:	e9 42 fa ff ff       	jmp    801064ca <alltraps>

80106a88 <vector25>:
.globl vector25
vector25:
  pushl $0
80106a88:	6a 00                	push   $0x0
  pushl $25
80106a8a:	6a 19                	push   $0x19
  jmp alltraps
80106a8c:	e9 39 fa ff ff       	jmp    801064ca <alltraps>

80106a91 <vector26>:
.globl vector26
vector26:
  pushl $0
80106a91:	6a 00                	push   $0x0
  pushl $26
80106a93:	6a 1a                	push   $0x1a
  jmp alltraps
80106a95:	e9 30 fa ff ff       	jmp    801064ca <alltraps>

80106a9a <vector27>:
.globl vector27
vector27:
  pushl $0
80106a9a:	6a 00                	push   $0x0
  pushl $27
80106a9c:	6a 1b                	push   $0x1b
  jmp alltraps
80106a9e:	e9 27 fa ff ff       	jmp    801064ca <alltraps>

80106aa3 <vector28>:
.globl vector28
vector28:
  pushl $0
80106aa3:	6a 00                	push   $0x0
  pushl $28
80106aa5:	6a 1c                	push   $0x1c
  jmp alltraps
80106aa7:	e9 1e fa ff ff       	jmp    801064ca <alltraps>

80106aac <vector29>:
.globl vector29
vector29:
  pushl $0
80106aac:	6a 00                	push   $0x0
  pushl $29
80106aae:	6a 1d                	push   $0x1d
  jmp alltraps
80106ab0:	e9 15 fa ff ff       	jmp    801064ca <alltraps>

80106ab5 <vector30>:
.globl vector30
vector30:
  pushl $0
80106ab5:	6a 00                	push   $0x0
  pushl $30
80106ab7:	6a 1e                	push   $0x1e
  jmp alltraps
80106ab9:	e9 0c fa ff ff       	jmp    801064ca <alltraps>

80106abe <vector31>:
.globl vector31
vector31:
  pushl $0
80106abe:	6a 00                	push   $0x0
  pushl $31
80106ac0:	6a 1f                	push   $0x1f
  jmp alltraps
80106ac2:	e9 03 fa ff ff       	jmp    801064ca <alltraps>

80106ac7 <vector32>:
.globl vector32
vector32:
  pushl $0
80106ac7:	6a 00                	push   $0x0
  pushl $32
80106ac9:	6a 20                	push   $0x20
  jmp alltraps
80106acb:	e9 fa f9 ff ff       	jmp    801064ca <alltraps>

80106ad0 <vector33>:
.globl vector33
vector33:
  pushl $0
80106ad0:	6a 00                	push   $0x0
  pushl $33
80106ad2:	6a 21                	push   $0x21
  jmp alltraps
80106ad4:	e9 f1 f9 ff ff       	jmp    801064ca <alltraps>

80106ad9 <vector34>:
.globl vector34
vector34:
  pushl $0
80106ad9:	6a 00                	push   $0x0
  pushl $34
80106adb:	6a 22                	push   $0x22
  jmp alltraps
80106add:	e9 e8 f9 ff ff       	jmp    801064ca <alltraps>

80106ae2 <vector35>:
.globl vector35
vector35:
  pushl $0
80106ae2:	6a 00                	push   $0x0
  pushl $35
80106ae4:	6a 23                	push   $0x23
  jmp alltraps
80106ae6:	e9 df f9 ff ff       	jmp    801064ca <alltraps>

80106aeb <vector36>:
.globl vector36
vector36:
  pushl $0
80106aeb:	6a 00                	push   $0x0
  pushl $36
80106aed:	6a 24                	push   $0x24
  jmp alltraps
80106aef:	e9 d6 f9 ff ff       	jmp    801064ca <alltraps>

80106af4 <vector37>:
.globl vector37
vector37:
  pushl $0
80106af4:	6a 00                	push   $0x0
  pushl $37
80106af6:	6a 25                	push   $0x25
  jmp alltraps
80106af8:	e9 cd f9 ff ff       	jmp    801064ca <alltraps>

80106afd <vector38>:
.globl vector38
vector38:
  pushl $0
80106afd:	6a 00                	push   $0x0
  pushl $38
80106aff:	6a 26                	push   $0x26
  jmp alltraps
80106b01:	e9 c4 f9 ff ff       	jmp    801064ca <alltraps>

80106b06 <vector39>:
.globl vector39
vector39:
  pushl $0
80106b06:	6a 00                	push   $0x0
  pushl $39
80106b08:	6a 27                	push   $0x27
  jmp alltraps
80106b0a:	e9 bb f9 ff ff       	jmp    801064ca <alltraps>

80106b0f <vector40>:
.globl vector40
vector40:
  pushl $0
80106b0f:	6a 00                	push   $0x0
  pushl $40
80106b11:	6a 28                	push   $0x28
  jmp alltraps
80106b13:	e9 b2 f9 ff ff       	jmp    801064ca <alltraps>

80106b18 <vector41>:
.globl vector41
vector41:
  pushl $0
80106b18:	6a 00                	push   $0x0
  pushl $41
80106b1a:	6a 29                	push   $0x29
  jmp alltraps
80106b1c:	e9 a9 f9 ff ff       	jmp    801064ca <alltraps>

80106b21 <vector42>:
.globl vector42
vector42:
  pushl $0
80106b21:	6a 00                	push   $0x0
  pushl $42
80106b23:	6a 2a                	push   $0x2a
  jmp alltraps
80106b25:	e9 a0 f9 ff ff       	jmp    801064ca <alltraps>

80106b2a <vector43>:
.globl vector43
vector43:
  pushl $0
80106b2a:	6a 00                	push   $0x0
  pushl $43
80106b2c:	6a 2b                	push   $0x2b
  jmp alltraps
80106b2e:	e9 97 f9 ff ff       	jmp    801064ca <alltraps>

80106b33 <vector44>:
.globl vector44
vector44:
  pushl $0
80106b33:	6a 00                	push   $0x0
  pushl $44
80106b35:	6a 2c                	push   $0x2c
  jmp alltraps
80106b37:	e9 8e f9 ff ff       	jmp    801064ca <alltraps>

80106b3c <vector45>:
.globl vector45
vector45:
  pushl $0
80106b3c:	6a 00                	push   $0x0
  pushl $45
80106b3e:	6a 2d                	push   $0x2d
  jmp alltraps
80106b40:	e9 85 f9 ff ff       	jmp    801064ca <alltraps>

80106b45 <vector46>:
.globl vector46
vector46:
  pushl $0
80106b45:	6a 00                	push   $0x0
  pushl $46
80106b47:	6a 2e                	push   $0x2e
  jmp alltraps
80106b49:	e9 7c f9 ff ff       	jmp    801064ca <alltraps>

80106b4e <vector47>:
.globl vector47
vector47:
  pushl $0
80106b4e:	6a 00                	push   $0x0
  pushl $47
80106b50:	6a 2f                	push   $0x2f
  jmp alltraps
80106b52:	e9 73 f9 ff ff       	jmp    801064ca <alltraps>

80106b57 <vector48>:
.globl vector48
vector48:
  pushl $0
80106b57:	6a 00                	push   $0x0
  pushl $48
80106b59:	6a 30                	push   $0x30
  jmp alltraps
80106b5b:	e9 6a f9 ff ff       	jmp    801064ca <alltraps>

80106b60 <vector49>:
.globl vector49
vector49:
  pushl $0
80106b60:	6a 00                	push   $0x0
  pushl $49
80106b62:	6a 31                	push   $0x31
  jmp alltraps
80106b64:	e9 61 f9 ff ff       	jmp    801064ca <alltraps>

80106b69 <vector50>:
.globl vector50
vector50:
  pushl $0
80106b69:	6a 00                	push   $0x0
  pushl $50
80106b6b:	6a 32                	push   $0x32
  jmp alltraps
80106b6d:	e9 58 f9 ff ff       	jmp    801064ca <alltraps>

80106b72 <vector51>:
.globl vector51
vector51:
  pushl $0
80106b72:	6a 00                	push   $0x0
  pushl $51
80106b74:	6a 33                	push   $0x33
  jmp alltraps
80106b76:	e9 4f f9 ff ff       	jmp    801064ca <alltraps>

80106b7b <vector52>:
.globl vector52
vector52:
  pushl $0
80106b7b:	6a 00                	push   $0x0
  pushl $52
80106b7d:	6a 34                	push   $0x34
  jmp alltraps
80106b7f:	e9 46 f9 ff ff       	jmp    801064ca <alltraps>

80106b84 <vector53>:
.globl vector53
vector53:
  pushl $0
80106b84:	6a 00                	push   $0x0
  pushl $53
80106b86:	6a 35                	push   $0x35
  jmp alltraps
80106b88:	e9 3d f9 ff ff       	jmp    801064ca <alltraps>

80106b8d <vector54>:
.globl vector54
vector54:
  pushl $0
80106b8d:	6a 00                	push   $0x0
  pushl $54
80106b8f:	6a 36                	push   $0x36
  jmp alltraps
80106b91:	e9 34 f9 ff ff       	jmp    801064ca <alltraps>

80106b96 <vector55>:
.globl vector55
vector55:
  pushl $0
80106b96:	6a 00                	push   $0x0
  pushl $55
80106b98:	6a 37                	push   $0x37
  jmp alltraps
80106b9a:	e9 2b f9 ff ff       	jmp    801064ca <alltraps>

80106b9f <vector56>:
.globl vector56
vector56:
  pushl $0
80106b9f:	6a 00                	push   $0x0
  pushl $56
80106ba1:	6a 38                	push   $0x38
  jmp alltraps
80106ba3:	e9 22 f9 ff ff       	jmp    801064ca <alltraps>

80106ba8 <vector57>:
.globl vector57
vector57:
  pushl $0
80106ba8:	6a 00                	push   $0x0
  pushl $57
80106baa:	6a 39                	push   $0x39
  jmp alltraps
80106bac:	e9 19 f9 ff ff       	jmp    801064ca <alltraps>

80106bb1 <vector58>:
.globl vector58
vector58:
  pushl $0
80106bb1:	6a 00                	push   $0x0
  pushl $58
80106bb3:	6a 3a                	push   $0x3a
  jmp alltraps
80106bb5:	e9 10 f9 ff ff       	jmp    801064ca <alltraps>

80106bba <vector59>:
.globl vector59
vector59:
  pushl $0
80106bba:	6a 00                	push   $0x0
  pushl $59
80106bbc:	6a 3b                	push   $0x3b
  jmp alltraps
80106bbe:	e9 07 f9 ff ff       	jmp    801064ca <alltraps>

80106bc3 <vector60>:
.globl vector60
vector60:
  pushl $0
80106bc3:	6a 00                	push   $0x0
  pushl $60
80106bc5:	6a 3c                	push   $0x3c
  jmp alltraps
80106bc7:	e9 fe f8 ff ff       	jmp    801064ca <alltraps>

80106bcc <vector61>:
.globl vector61
vector61:
  pushl $0
80106bcc:	6a 00                	push   $0x0
  pushl $61
80106bce:	6a 3d                	push   $0x3d
  jmp alltraps
80106bd0:	e9 f5 f8 ff ff       	jmp    801064ca <alltraps>

80106bd5 <vector62>:
.globl vector62
vector62:
  pushl $0
80106bd5:	6a 00                	push   $0x0
  pushl $62
80106bd7:	6a 3e                	push   $0x3e
  jmp alltraps
80106bd9:	e9 ec f8 ff ff       	jmp    801064ca <alltraps>

80106bde <vector63>:
.globl vector63
vector63:
  pushl $0
80106bde:	6a 00                	push   $0x0
  pushl $63
80106be0:	6a 3f                	push   $0x3f
  jmp alltraps
80106be2:	e9 e3 f8 ff ff       	jmp    801064ca <alltraps>

80106be7 <vector64>:
.globl vector64
vector64:
  pushl $0
80106be7:	6a 00                	push   $0x0
  pushl $64
80106be9:	6a 40                	push   $0x40
  jmp alltraps
80106beb:	e9 da f8 ff ff       	jmp    801064ca <alltraps>

80106bf0 <vector65>:
.globl vector65
vector65:
  pushl $0
80106bf0:	6a 00                	push   $0x0
  pushl $65
80106bf2:	6a 41                	push   $0x41
  jmp alltraps
80106bf4:	e9 d1 f8 ff ff       	jmp    801064ca <alltraps>

80106bf9 <vector66>:
.globl vector66
vector66:
  pushl $0
80106bf9:	6a 00                	push   $0x0
  pushl $66
80106bfb:	6a 42                	push   $0x42
  jmp alltraps
80106bfd:	e9 c8 f8 ff ff       	jmp    801064ca <alltraps>

80106c02 <vector67>:
.globl vector67
vector67:
  pushl $0
80106c02:	6a 00                	push   $0x0
  pushl $67
80106c04:	6a 43                	push   $0x43
  jmp alltraps
80106c06:	e9 bf f8 ff ff       	jmp    801064ca <alltraps>

80106c0b <vector68>:
.globl vector68
vector68:
  pushl $0
80106c0b:	6a 00                	push   $0x0
  pushl $68
80106c0d:	6a 44                	push   $0x44
  jmp alltraps
80106c0f:	e9 b6 f8 ff ff       	jmp    801064ca <alltraps>

80106c14 <vector69>:
.globl vector69
vector69:
  pushl $0
80106c14:	6a 00                	push   $0x0
  pushl $69
80106c16:	6a 45                	push   $0x45
  jmp alltraps
80106c18:	e9 ad f8 ff ff       	jmp    801064ca <alltraps>

80106c1d <vector70>:
.globl vector70
vector70:
  pushl $0
80106c1d:	6a 00                	push   $0x0
  pushl $70
80106c1f:	6a 46                	push   $0x46
  jmp alltraps
80106c21:	e9 a4 f8 ff ff       	jmp    801064ca <alltraps>

80106c26 <vector71>:
.globl vector71
vector71:
  pushl $0
80106c26:	6a 00                	push   $0x0
  pushl $71
80106c28:	6a 47                	push   $0x47
  jmp alltraps
80106c2a:	e9 9b f8 ff ff       	jmp    801064ca <alltraps>

80106c2f <vector72>:
.globl vector72
vector72:
  pushl $0
80106c2f:	6a 00                	push   $0x0
  pushl $72
80106c31:	6a 48                	push   $0x48
  jmp alltraps
80106c33:	e9 92 f8 ff ff       	jmp    801064ca <alltraps>

80106c38 <vector73>:
.globl vector73
vector73:
  pushl $0
80106c38:	6a 00                	push   $0x0
  pushl $73
80106c3a:	6a 49                	push   $0x49
  jmp alltraps
80106c3c:	e9 89 f8 ff ff       	jmp    801064ca <alltraps>

80106c41 <vector74>:
.globl vector74
vector74:
  pushl $0
80106c41:	6a 00                	push   $0x0
  pushl $74
80106c43:	6a 4a                	push   $0x4a
  jmp alltraps
80106c45:	e9 80 f8 ff ff       	jmp    801064ca <alltraps>

80106c4a <vector75>:
.globl vector75
vector75:
  pushl $0
80106c4a:	6a 00                	push   $0x0
  pushl $75
80106c4c:	6a 4b                	push   $0x4b
  jmp alltraps
80106c4e:	e9 77 f8 ff ff       	jmp    801064ca <alltraps>

80106c53 <vector76>:
.globl vector76
vector76:
  pushl $0
80106c53:	6a 00                	push   $0x0
  pushl $76
80106c55:	6a 4c                	push   $0x4c
  jmp alltraps
80106c57:	e9 6e f8 ff ff       	jmp    801064ca <alltraps>

80106c5c <vector77>:
.globl vector77
vector77:
  pushl $0
80106c5c:	6a 00                	push   $0x0
  pushl $77
80106c5e:	6a 4d                	push   $0x4d
  jmp alltraps
80106c60:	e9 65 f8 ff ff       	jmp    801064ca <alltraps>

80106c65 <vector78>:
.globl vector78
vector78:
  pushl $0
80106c65:	6a 00                	push   $0x0
  pushl $78
80106c67:	6a 4e                	push   $0x4e
  jmp alltraps
80106c69:	e9 5c f8 ff ff       	jmp    801064ca <alltraps>

80106c6e <vector79>:
.globl vector79
vector79:
  pushl $0
80106c6e:	6a 00                	push   $0x0
  pushl $79
80106c70:	6a 4f                	push   $0x4f
  jmp alltraps
80106c72:	e9 53 f8 ff ff       	jmp    801064ca <alltraps>

80106c77 <vector80>:
.globl vector80
vector80:
  pushl $0
80106c77:	6a 00                	push   $0x0
  pushl $80
80106c79:	6a 50                	push   $0x50
  jmp alltraps
80106c7b:	e9 4a f8 ff ff       	jmp    801064ca <alltraps>

80106c80 <vector81>:
.globl vector81
vector81:
  pushl $0
80106c80:	6a 00                	push   $0x0
  pushl $81
80106c82:	6a 51                	push   $0x51
  jmp alltraps
80106c84:	e9 41 f8 ff ff       	jmp    801064ca <alltraps>

80106c89 <vector82>:
.globl vector82
vector82:
  pushl $0
80106c89:	6a 00                	push   $0x0
  pushl $82
80106c8b:	6a 52                	push   $0x52
  jmp alltraps
80106c8d:	e9 38 f8 ff ff       	jmp    801064ca <alltraps>

80106c92 <vector83>:
.globl vector83
vector83:
  pushl $0
80106c92:	6a 00                	push   $0x0
  pushl $83
80106c94:	6a 53                	push   $0x53
  jmp alltraps
80106c96:	e9 2f f8 ff ff       	jmp    801064ca <alltraps>

80106c9b <vector84>:
.globl vector84
vector84:
  pushl $0
80106c9b:	6a 00                	push   $0x0
  pushl $84
80106c9d:	6a 54                	push   $0x54
  jmp alltraps
80106c9f:	e9 26 f8 ff ff       	jmp    801064ca <alltraps>

80106ca4 <vector85>:
.globl vector85
vector85:
  pushl $0
80106ca4:	6a 00                	push   $0x0
  pushl $85
80106ca6:	6a 55                	push   $0x55
  jmp alltraps
80106ca8:	e9 1d f8 ff ff       	jmp    801064ca <alltraps>

80106cad <vector86>:
.globl vector86
vector86:
  pushl $0
80106cad:	6a 00                	push   $0x0
  pushl $86
80106caf:	6a 56                	push   $0x56
  jmp alltraps
80106cb1:	e9 14 f8 ff ff       	jmp    801064ca <alltraps>

80106cb6 <vector87>:
.globl vector87
vector87:
  pushl $0
80106cb6:	6a 00                	push   $0x0
  pushl $87
80106cb8:	6a 57                	push   $0x57
  jmp alltraps
80106cba:	e9 0b f8 ff ff       	jmp    801064ca <alltraps>

80106cbf <vector88>:
.globl vector88
vector88:
  pushl $0
80106cbf:	6a 00                	push   $0x0
  pushl $88
80106cc1:	6a 58                	push   $0x58
  jmp alltraps
80106cc3:	e9 02 f8 ff ff       	jmp    801064ca <alltraps>

80106cc8 <vector89>:
.globl vector89
vector89:
  pushl $0
80106cc8:	6a 00                	push   $0x0
  pushl $89
80106cca:	6a 59                	push   $0x59
  jmp alltraps
80106ccc:	e9 f9 f7 ff ff       	jmp    801064ca <alltraps>

80106cd1 <vector90>:
.globl vector90
vector90:
  pushl $0
80106cd1:	6a 00                	push   $0x0
  pushl $90
80106cd3:	6a 5a                	push   $0x5a
  jmp alltraps
80106cd5:	e9 f0 f7 ff ff       	jmp    801064ca <alltraps>

80106cda <vector91>:
.globl vector91
vector91:
  pushl $0
80106cda:	6a 00                	push   $0x0
  pushl $91
80106cdc:	6a 5b                	push   $0x5b
  jmp alltraps
80106cde:	e9 e7 f7 ff ff       	jmp    801064ca <alltraps>

80106ce3 <vector92>:
.globl vector92
vector92:
  pushl $0
80106ce3:	6a 00                	push   $0x0
  pushl $92
80106ce5:	6a 5c                	push   $0x5c
  jmp alltraps
80106ce7:	e9 de f7 ff ff       	jmp    801064ca <alltraps>

80106cec <vector93>:
.globl vector93
vector93:
  pushl $0
80106cec:	6a 00                	push   $0x0
  pushl $93
80106cee:	6a 5d                	push   $0x5d
  jmp alltraps
80106cf0:	e9 d5 f7 ff ff       	jmp    801064ca <alltraps>

80106cf5 <vector94>:
.globl vector94
vector94:
  pushl $0
80106cf5:	6a 00                	push   $0x0
  pushl $94
80106cf7:	6a 5e                	push   $0x5e
  jmp alltraps
80106cf9:	e9 cc f7 ff ff       	jmp    801064ca <alltraps>

80106cfe <vector95>:
.globl vector95
vector95:
  pushl $0
80106cfe:	6a 00                	push   $0x0
  pushl $95
80106d00:	6a 5f                	push   $0x5f
  jmp alltraps
80106d02:	e9 c3 f7 ff ff       	jmp    801064ca <alltraps>

80106d07 <vector96>:
.globl vector96
vector96:
  pushl $0
80106d07:	6a 00                	push   $0x0
  pushl $96
80106d09:	6a 60                	push   $0x60
  jmp alltraps
80106d0b:	e9 ba f7 ff ff       	jmp    801064ca <alltraps>

80106d10 <vector97>:
.globl vector97
vector97:
  pushl $0
80106d10:	6a 00                	push   $0x0
  pushl $97
80106d12:	6a 61                	push   $0x61
  jmp alltraps
80106d14:	e9 b1 f7 ff ff       	jmp    801064ca <alltraps>

80106d19 <vector98>:
.globl vector98
vector98:
  pushl $0
80106d19:	6a 00                	push   $0x0
  pushl $98
80106d1b:	6a 62                	push   $0x62
  jmp alltraps
80106d1d:	e9 a8 f7 ff ff       	jmp    801064ca <alltraps>

80106d22 <vector99>:
.globl vector99
vector99:
  pushl $0
80106d22:	6a 00                	push   $0x0
  pushl $99
80106d24:	6a 63                	push   $0x63
  jmp alltraps
80106d26:	e9 9f f7 ff ff       	jmp    801064ca <alltraps>

80106d2b <vector100>:
.globl vector100
vector100:
  pushl $0
80106d2b:	6a 00                	push   $0x0
  pushl $100
80106d2d:	6a 64                	push   $0x64
  jmp alltraps
80106d2f:	e9 96 f7 ff ff       	jmp    801064ca <alltraps>

80106d34 <vector101>:
.globl vector101
vector101:
  pushl $0
80106d34:	6a 00                	push   $0x0
  pushl $101
80106d36:	6a 65                	push   $0x65
  jmp alltraps
80106d38:	e9 8d f7 ff ff       	jmp    801064ca <alltraps>

80106d3d <vector102>:
.globl vector102
vector102:
  pushl $0
80106d3d:	6a 00                	push   $0x0
  pushl $102
80106d3f:	6a 66                	push   $0x66
  jmp alltraps
80106d41:	e9 84 f7 ff ff       	jmp    801064ca <alltraps>

80106d46 <vector103>:
.globl vector103
vector103:
  pushl $0
80106d46:	6a 00                	push   $0x0
  pushl $103
80106d48:	6a 67                	push   $0x67
  jmp alltraps
80106d4a:	e9 7b f7 ff ff       	jmp    801064ca <alltraps>

80106d4f <vector104>:
.globl vector104
vector104:
  pushl $0
80106d4f:	6a 00                	push   $0x0
  pushl $104
80106d51:	6a 68                	push   $0x68
  jmp alltraps
80106d53:	e9 72 f7 ff ff       	jmp    801064ca <alltraps>

80106d58 <vector105>:
.globl vector105
vector105:
  pushl $0
80106d58:	6a 00                	push   $0x0
  pushl $105
80106d5a:	6a 69                	push   $0x69
  jmp alltraps
80106d5c:	e9 69 f7 ff ff       	jmp    801064ca <alltraps>

80106d61 <vector106>:
.globl vector106
vector106:
  pushl $0
80106d61:	6a 00                	push   $0x0
  pushl $106
80106d63:	6a 6a                	push   $0x6a
  jmp alltraps
80106d65:	e9 60 f7 ff ff       	jmp    801064ca <alltraps>

80106d6a <vector107>:
.globl vector107
vector107:
  pushl $0
80106d6a:	6a 00                	push   $0x0
  pushl $107
80106d6c:	6a 6b                	push   $0x6b
  jmp alltraps
80106d6e:	e9 57 f7 ff ff       	jmp    801064ca <alltraps>

80106d73 <vector108>:
.globl vector108
vector108:
  pushl $0
80106d73:	6a 00                	push   $0x0
  pushl $108
80106d75:	6a 6c                	push   $0x6c
  jmp alltraps
80106d77:	e9 4e f7 ff ff       	jmp    801064ca <alltraps>

80106d7c <vector109>:
.globl vector109
vector109:
  pushl $0
80106d7c:	6a 00                	push   $0x0
  pushl $109
80106d7e:	6a 6d                	push   $0x6d
  jmp alltraps
80106d80:	e9 45 f7 ff ff       	jmp    801064ca <alltraps>

80106d85 <vector110>:
.globl vector110
vector110:
  pushl $0
80106d85:	6a 00                	push   $0x0
  pushl $110
80106d87:	6a 6e                	push   $0x6e
  jmp alltraps
80106d89:	e9 3c f7 ff ff       	jmp    801064ca <alltraps>

80106d8e <vector111>:
.globl vector111
vector111:
  pushl $0
80106d8e:	6a 00                	push   $0x0
  pushl $111
80106d90:	6a 6f                	push   $0x6f
  jmp alltraps
80106d92:	e9 33 f7 ff ff       	jmp    801064ca <alltraps>

80106d97 <vector112>:
.globl vector112
vector112:
  pushl $0
80106d97:	6a 00                	push   $0x0
  pushl $112
80106d99:	6a 70                	push   $0x70
  jmp alltraps
80106d9b:	e9 2a f7 ff ff       	jmp    801064ca <alltraps>

80106da0 <vector113>:
.globl vector113
vector113:
  pushl $0
80106da0:	6a 00                	push   $0x0
  pushl $113
80106da2:	6a 71                	push   $0x71
  jmp alltraps
80106da4:	e9 21 f7 ff ff       	jmp    801064ca <alltraps>

80106da9 <vector114>:
.globl vector114
vector114:
  pushl $0
80106da9:	6a 00                	push   $0x0
  pushl $114
80106dab:	6a 72                	push   $0x72
  jmp alltraps
80106dad:	e9 18 f7 ff ff       	jmp    801064ca <alltraps>

80106db2 <vector115>:
.globl vector115
vector115:
  pushl $0
80106db2:	6a 00                	push   $0x0
  pushl $115
80106db4:	6a 73                	push   $0x73
  jmp alltraps
80106db6:	e9 0f f7 ff ff       	jmp    801064ca <alltraps>

80106dbb <vector116>:
.globl vector116
vector116:
  pushl $0
80106dbb:	6a 00                	push   $0x0
  pushl $116
80106dbd:	6a 74                	push   $0x74
  jmp alltraps
80106dbf:	e9 06 f7 ff ff       	jmp    801064ca <alltraps>

80106dc4 <vector117>:
.globl vector117
vector117:
  pushl $0
80106dc4:	6a 00                	push   $0x0
  pushl $117
80106dc6:	6a 75                	push   $0x75
  jmp alltraps
80106dc8:	e9 fd f6 ff ff       	jmp    801064ca <alltraps>

80106dcd <vector118>:
.globl vector118
vector118:
  pushl $0
80106dcd:	6a 00                	push   $0x0
  pushl $118
80106dcf:	6a 76                	push   $0x76
  jmp alltraps
80106dd1:	e9 f4 f6 ff ff       	jmp    801064ca <alltraps>

80106dd6 <vector119>:
.globl vector119
vector119:
  pushl $0
80106dd6:	6a 00                	push   $0x0
  pushl $119
80106dd8:	6a 77                	push   $0x77
  jmp alltraps
80106dda:	e9 eb f6 ff ff       	jmp    801064ca <alltraps>

80106ddf <vector120>:
.globl vector120
vector120:
  pushl $0
80106ddf:	6a 00                	push   $0x0
  pushl $120
80106de1:	6a 78                	push   $0x78
  jmp alltraps
80106de3:	e9 e2 f6 ff ff       	jmp    801064ca <alltraps>

80106de8 <vector121>:
.globl vector121
vector121:
  pushl $0
80106de8:	6a 00                	push   $0x0
  pushl $121
80106dea:	6a 79                	push   $0x79
  jmp alltraps
80106dec:	e9 d9 f6 ff ff       	jmp    801064ca <alltraps>

80106df1 <vector122>:
.globl vector122
vector122:
  pushl $0
80106df1:	6a 00                	push   $0x0
  pushl $122
80106df3:	6a 7a                	push   $0x7a
  jmp alltraps
80106df5:	e9 d0 f6 ff ff       	jmp    801064ca <alltraps>

80106dfa <vector123>:
.globl vector123
vector123:
  pushl $0
80106dfa:	6a 00                	push   $0x0
  pushl $123
80106dfc:	6a 7b                	push   $0x7b
  jmp alltraps
80106dfe:	e9 c7 f6 ff ff       	jmp    801064ca <alltraps>

80106e03 <vector124>:
.globl vector124
vector124:
  pushl $0
80106e03:	6a 00                	push   $0x0
  pushl $124
80106e05:	6a 7c                	push   $0x7c
  jmp alltraps
80106e07:	e9 be f6 ff ff       	jmp    801064ca <alltraps>

80106e0c <vector125>:
.globl vector125
vector125:
  pushl $0
80106e0c:	6a 00                	push   $0x0
  pushl $125
80106e0e:	6a 7d                	push   $0x7d
  jmp alltraps
80106e10:	e9 b5 f6 ff ff       	jmp    801064ca <alltraps>

80106e15 <vector126>:
.globl vector126
vector126:
  pushl $0
80106e15:	6a 00                	push   $0x0
  pushl $126
80106e17:	6a 7e                	push   $0x7e
  jmp alltraps
80106e19:	e9 ac f6 ff ff       	jmp    801064ca <alltraps>

80106e1e <vector127>:
.globl vector127
vector127:
  pushl $0
80106e1e:	6a 00                	push   $0x0
  pushl $127
80106e20:	6a 7f                	push   $0x7f
  jmp alltraps
80106e22:	e9 a3 f6 ff ff       	jmp    801064ca <alltraps>

80106e27 <vector128>:
.globl vector128
vector128:
  pushl $0
80106e27:	6a 00                	push   $0x0
  pushl $128
80106e29:	68 80 00 00 00       	push   $0x80
  jmp alltraps
80106e2e:	e9 97 f6 ff ff       	jmp    801064ca <alltraps>

80106e33 <vector129>:
.globl vector129
vector129:
  pushl $0
80106e33:	6a 00                	push   $0x0
  pushl $129
80106e35:	68 81 00 00 00       	push   $0x81
  jmp alltraps
80106e3a:	e9 8b f6 ff ff       	jmp    801064ca <alltraps>

80106e3f <vector130>:
.globl vector130
vector130:
  pushl $0
80106e3f:	6a 00                	push   $0x0
  pushl $130
80106e41:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80106e46:	e9 7f f6 ff ff       	jmp    801064ca <alltraps>

80106e4b <vector131>:
.globl vector131
vector131:
  pushl $0
80106e4b:	6a 00                	push   $0x0
  pushl $131
80106e4d:	68 83 00 00 00       	push   $0x83
  jmp alltraps
80106e52:	e9 73 f6 ff ff       	jmp    801064ca <alltraps>

80106e57 <vector132>:
.globl vector132
vector132:
  pushl $0
80106e57:	6a 00                	push   $0x0
  pushl $132
80106e59:	68 84 00 00 00       	push   $0x84
  jmp alltraps
80106e5e:	e9 67 f6 ff ff       	jmp    801064ca <alltraps>

80106e63 <vector133>:
.globl vector133
vector133:
  pushl $0
80106e63:	6a 00                	push   $0x0
  pushl $133
80106e65:	68 85 00 00 00       	push   $0x85
  jmp alltraps
80106e6a:	e9 5b f6 ff ff       	jmp    801064ca <alltraps>

80106e6f <vector134>:
.globl vector134
vector134:
  pushl $0
80106e6f:	6a 00                	push   $0x0
  pushl $134
80106e71:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80106e76:	e9 4f f6 ff ff       	jmp    801064ca <alltraps>

80106e7b <vector135>:
.globl vector135
vector135:
  pushl $0
80106e7b:	6a 00                	push   $0x0
  pushl $135
80106e7d:	68 87 00 00 00       	push   $0x87
  jmp alltraps
80106e82:	e9 43 f6 ff ff       	jmp    801064ca <alltraps>

80106e87 <vector136>:
.globl vector136
vector136:
  pushl $0
80106e87:	6a 00                	push   $0x0
  pushl $136
80106e89:	68 88 00 00 00       	push   $0x88
  jmp alltraps
80106e8e:	e9 37 f6 ff ff       	jmp    801064ca <alltraps>

80106e93 <vector137>:
.globl vector137
vector137:
  pushl $0
80106e93:	6a 00                	push   $0x0
  pushl $137
80106e95:	68 89 00 00 00       	push   $0x89
  jmp alltraps
80106e9a:	e9 2b f6 ff ff       	jmp    801064ca <alltraps>

80106e9f <vector138>:
.globl vector138
vector138:
  pushl $0
80106e9f:	6a 00                	push   $0x0
  pushl $138
80106ea1:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
80106ea6:	e9 1f f6 ff ff       	jmp    801064ca <alltraps>

80106eab <vector139>:
.globl vector139
vector139:
  pushl $0
80106eab:	6a 00                	push   $0x0
  pushl $139
80106ead:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
80106eb2:	e9 13 f6 ff ff       	jmp    801064ca <alltraps>

80106eb7 <vector140>:
.globl vector140
vector140:
  pushl $0
80106eb7:	6a 00                	push   $0x0
  pushl $140
80106eb9:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
80106ebe:	e9 07 f6 ff ff       	jmp    801064ca <alltraps>

80106ec3 <vector141>:
.globl vector141
vector141:
  pushl $0
80106ec3:	6a 00                	push   $0x0
  pushl $141
80106ec5:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
80106eca:	e9 fb f5 ff ff       	jmp    801064ca <alltraps>

80106ecf <vector142>:
.globl vector142
vector142:
  pushl $0
80106ecf:	6a 00                	push   $0x0
  pushl $142
80106ed1:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
80106ed6:	e9 ef f5 ff ff       	jmp    801064ca <alltraps>

80106edb <vector143>:
.globl vector143
vector143:
  pushl $0
80106edb:	6a 00                	push   $0x0
  pushl $143
80106edd:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80106ee2:	e9 e3 f5 ff ff       	jmp    801064ca <alltraps>

80106ee7 <vector144>:
.globl vector144
vector144:
  pushl $0
80106ee7:	6a 00                	push   $0x0
  pushl $144
80106ee9:	68 90 00 00 00       	push   $0x90
  jmp alltraps
80106eee:	e9 d7 f5 ff ff       	jmp    801064ca <alltraps>

80106ef3 <vector145>:
.globl vector145
vector145:
  pushl $0
80106ef3:	6a 00                	push   $0x0
  pushl $145
80106ef5:	68 91 00 00 00       	push   $0x91
  jmp alltraps
80106efa:	e9 cb f5 ff ff       	jmp    801064ca <alltraps>

80106eff <vector146>:
.globl vector146
vector146:
  pushl $0
80106eff:	6a 00                	push   $0x0
  pushl $146
80106f01:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80106f06:	e9 bf f5 ff ff       	jmp    801064ca <alltraps>

80106f0b <vector147>:
.globl vector147
vector147:
  pushl $0
80106f0b:	6a 00                	push   $0x0
  pushl $147
80106f0d:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80106f12:	e9 b3 f5 ff ff       	jmp    801064ca <alltraps>

80106f17 <vector148>:
.globl vector148
vector148:
  pushl $0
80106f17:	6a 00                	push   $0x0
  pushl $148
80106f19:	68 94 00 00 00       	push   $0x94
  jmp alltraps
80106f1e:	e9 a7 f5 ff ff       	jmp    801064ca <alltraps>

80106f23 <vector149>:
.globl vector149
vector149:
  pushl $0
80106f23:	6a 00                	push   $0x0
  pushl $149
80106f25:	68 95 00 00 00       	push   $0x95
  jmp alltraps
80106f2a:	e9 9b f5 ff ff       	jmp    801064ca <alltraps>

80106f2f <vector150>:
.globl vector150
vector150:
  pushl $0
80106f2f:	6a 00                	push   $0x0
  pushl $150
80106f31:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80106f36:	e9 8f f5 ff ff       	jmp    801064ca <alltraps>

80106f3b <vector151>:
.globl vector151
vector151:
  pushl $0
80106f3b:	6a 00                	push   $0x0
  pushl $151
80106f3d:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80106f42:	e9 83 f5 ff ff       	jmp    801064ca <alltraps>

80106f47 <vector152>:
.globl vector152
vector152:
  pushl $0
80106f47:	6a 00                	push   $0x0
  pushl $152
80106f49:	68 98 00 00 00       	push   $0x98
  jmp alltraps
80106f4e:	e9 77 f5 ff ff       	jmp    801064ca <alltraps>

80106f53 <vector153>:
.globl vector153
vector153:
  pushl $0
80106f53:	6a 00                	push   $0x0
  pushl $153
80106f55:	68 99 00 00 00       	push   $0x99
  jmp alltraps
80106f5a:	e9 6b f5 ff ff       	jmp    801064ca <alltraps>

80106f5f <vector154>:
.globl vector154
vector154:
  pushl $0
80106f5f:	6a 00                	push   $0x0
  pushl $154
80106f61:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80106f66:	e9 5f f5 ff ff       	jmp    801064ca <alltraps>

80106f6b <vector155>:
.globl vector155
vector155:
  pushl $0
80106f6b:	6a 00                	push   $0x0
  pushl $155
80106f6d:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80106f72:	e9 53 f5 ff ff       	jmp    801064ca <alltraps>

80106f77 <vector156>:
.globl vector156
vector156:
  pushl $0
80106f77:	6a 00                	push   $0x0
  pushl $156
80106f79:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
80106f7e:	e9 47 f5 ff ff       	jmp    801064ca <alltraps>

80106f83 <vector157>:
.globl vector157
vector157:
  pushl $0
80106f83:	6a 00                	push   $0x0
  pushl $157
80106f85:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
80106f8a:	e9 3b f5 ff ff       	jmp    801064ca <alltraps>

80106f8f <vector158>:
.globl vector158
vector158:
  pushl $0
80106f8f:	6a 00                	push   $0x0
  pushl $158
80106f91:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
80106f96:	e9 2f f5 ff ff       	jmp    801064ca <alltraps>

80106f9b <vector159>:
.globl vector159
vector159:
  pushl $0
80106f9b:	6a 00                	push   $0x0
  pushl $159
80106f9d:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
80106fa2:	e9 23 f5 ff ff       	jmp    801064ca <alltraps>

80106fa7 <vector160>:
.globl vector160
vector160:
  pushl $0
80106fa7:	6a 00                	push   $0x0
  pushl $160
80106fa9:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
80106fae:	e9 17 f5 ff ff       	jmp    801064ca <alltraps>

80106fb3 <vector161>:
.globl vector161
vector161:
  pushl $0
80106fb3:	6a 00                	push   $0x0
  pushl $161
80106fb5:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
80106fba:	e9 0b f5 ff ff       	jmp    801064ca <alltraps>

80106fbf <vector162>:
.globl vector162
vector162:
  pushl $0
80106fbf:	6a 00                	push   $0x0
  pushl $162
80106fc1:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
80106fc6:	e9 ff f4 ff ff       	jmp    801064ca <alltraps>

80106fcb <vector163>:
.globl vector163
vector163:
  pushl $0
80106fcb:	6a 00                	push   $0x0
  pushl $163
80106fcd:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
80106fd2:	e9 f3 f4 ff ff       	jmp    801064ca <alltraps>

80106fd7 <vector164>:
.globl vector164
vector164:
  pushl $0
80106fd7:	6a 00                	push   $0x0
  pushl $164
80106fd9:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
80106fde:	e9 e7 f4 ff ff       	jmp    801064ca <alltraps>

80106fe3 <vector165>:
.globl vector165
vector165:
  pushl $0
80106fe3:	6a 00                	push   $0x0
  pushl $165
80106fe5:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
80106fea:	e9 db f4 ff ff       	jmp    801064ca <alltraps>

80106fef <vector166>:
.globl vector166
vector166:
  pushl $0
80106fef:	6a 00                	push   $0x0
  pushl $166
80106ff1:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80106ff6:	e9 cf f4 ff ff       	jmp    801064ca <alltraps>

80106ffb <vector167>:
.globl vector167
vector167:
  pushl $0
80106ffb:	6a 00                	push   $0x0
  pushl $167
80106ffd:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80107002:	e9 c3 f4 ff ff       	jmp    801064ca <alltraps>

80107007 <vector168>:
.globl vector168
vector168:
  pushl $0
80107007:	6a 00                	push   $0x0
  pushl $168
80107009:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
8010700e:	e9 b7 f4 ff ff       	jmp    801064ca <alltraps>

80107013 <vector169>:
.globl vector169
vector169:
  pushl $0
80107013:	6a 00                	push   $0x0
  pushl $169
80107015:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
8010701a:	e9 ab f4 ff ff       	jmp    801064ca <alltraps>

8010701f <vector170>:
.globl vector170
vector170:
  pushl $0
8010701f:	6a 00                	push   $0x0
  pushl $170
80107021:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80107026:	e9 9f f4 ff ff       	jmp    801064ca <alltraps>

8010702b <vector171>:
.globl vector171
vector171:
  pushl $0
8010702b:	6a 00                	push   $0x0
  pushl $171
8010702d:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80107032:	e9 93 f4 ff ff       	jmp    801064ca <alltraps>

80107037 <vector172>:
.globl vector172
vector172:
  pushl $0
80107037:	6a 00                	push   $0x0
  pushl $172
80107039:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
8010703e:	e9 87 f4 ff ff       	jmp    801064ca <alltraps>

80107043 <vector173>:
.globl vector173
vector173:
  pushl $0
80107043:	6a 00                	push   $0x0
  pushl $173
80107045:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
8010704a:	e9 7b f4 ff ff       	jmp    801064ca <alltraps>

8010704f <vector174>:
.globl vector174
vector174:
  pushl $0
8010704f:	6a 00                	push   $0x0
  pushl $174
80107051:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80107056:	e9 6f f4 ff ff       	jmp    801064ca <alltraps>

8010705b <vector175>:
.globl vector175
vector175:
  pushl $0
8010705b:	6a 00                	push   $0x0
  pushl $175
8010705d:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80107062:	e9 63 f4 ff ff       	jmp    801064ca <alltraps>

80107067 <vector176>:
.globl vector176
vector176:
  pushl $0
80107067:	6a 00                	push   $0x0
  pushl $176
80107069:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
8010706e:	e9 57 f4 ff ff       	jmp    801064ca <alltraps>

80107073 <vector177>:
.globl vector177
vector177:
  pushl $0
80107073:	6a 00                	push   $0x0
  pushl $177
80107075:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
8010707a:	e9 4b f4 ff ff       	jmp    801064ca <alltraps>

8010707f <vector178>:
.globl vector178
vector178:
  pushl $0
8010707f:	6a 00                	push   $0x0
  pushl $178
80107081:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80107086:	e9 3f f4 ff ff       	jmp    801064ca <alltraps>

8010708b <vector179>:
.globl vector179
vector179:
  pushl $0
8010708b:	6a 00                	push   $0x0
  pushl $179
8010708d:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80107092:	e9 33 f4 ff ff       	jmp    801064ca <alltraps>

80107097 <vector180>:
.globl vector180
vector180:
  pushl $0
80107097:	6a 00                	push   $0x0
  pushl $180
80107099:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
8010709e:	e9 27 f4 ff ff       	jmp    801064ca <alltraps>

801070a3 <vector181>:
.globl vector181
vector181:
  pushl $0
801070a3:	6a 00                	push   $0x0
  pushl $181
801070a5:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
801070aa:	e9 1b f4 ff ff       	jmp    801064ca <alltraps>

801070af <vector182>:
.globl vector182
vector182:
  pushl $0
801070af:	6a 00                	push   $0x0
  pushl $182
801070b1:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
801070b6:	e9 0f f4 ff ff       	jmp    801064ca <alltraps>

801070bb <vector183>:
.globl vector183
vector183:
  pushl $0
801070bb:	6a 00                	push   $0x0
  pushl $183
801070bd:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
801070c2:	e9 03 f4 ff ff       	jmp    801064ca <alltraps>

801070c7 <vector184>:
.globl vector184
vector184:
  pushl $0
801070c7:	6a 00                	push   $0x0
  pushl $184
801070c9:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
801070ce:	e9 f7 f3 ff ff       	jmp    801064ca <alltraps>

801070d3 <vector185>:
.globl vector185
vector185:
  pushl $0
801070d3:	6a 00                	push   $0x0
  pushl $185
801070d5:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
801070da:	e9 eb f3 ff ff       	jmp    801064ca <alltraps>

801070df <vector186>:
.globl vector186
vector186:
  pushl $0
801070df:	6a 00                	push   $0x0
  pushl $186
801070e1:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
801070e6:	e9 df f3 ff ff       	jmp    801064ca <alltraps>

801070eb <vector187>:
.globl vector187
vector187:
  pushl $0
801070eb:	6a 00                	push   $0x0
  pushl $187
801070ed:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
801070f2:	e9 d3 f3 ff ff       	jmp    801064ca <alltraps>

801070f7 <vector188>:
.globl vector188
vector188:
  pushl $0
801070f7:	6a 00                	push   $0x0
  pushl $188
801070f9:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
801070fe:	e9 c7 f3 ff ff       	jmp    801064ca <alltraps>

80107103 <vector189>:
.globl vector189
vector189:
  pushl $0
80107103:	6a 00                	push   $0x0
  pushl $189
80107105:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
8010710a:	e9 bb f3 ff ff       	jmp    801064ca <alltraps>

8010710f <vector190>:
.globl vector190
vector190:
  pushl $0
8010710f:	6a 00                	push   $0x0
  pushl $190
80107111:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80107116:	e9 af f3 ff ff       	jmp    801064ca <alltraps>

8010711b <vector191>:
.globl vector191
vector191:
  pushl $0
8010711b:	6a 00                	push   $0x0
  pushl $191
8010711d:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80107122:	e9 a3 f3 ff ff       	jmp    801064ca <alltraps>

80107127 <vector192>:
.globl vector192
vector192:
  pushl $0
80107127:	6a 00                	push   $0x0
  pushl $192
80107129:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
8010712e:	e9 97 f3 ff ff       	jmp    801064ca <alltraps>

80107133 <vector193>:
.globl vector193
vector193:
  pushl $0
80107133:	6a 00                	push   $0x0
  pushl $193
80107135:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
8010713a:	e9 8b f3 ff ff       	jmp    801064ca <alltraps>

8010713f <vector194>:
.globl vector194
vector194:
  pushl $0
8010713f:	6a 00                	push   $0x0
  pushl $194
80107141:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80107146:	e9 7f f3 ff ff       	jmp    801064ca <alltraps>

8010714b <vector195>:
.globl vector195
vector195:
  pushl $0
8010714b:	6a 00                	push   $0x0
  pushl $195
8010714d:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80107152:	e9 73 f3 ff ff       	jmp    801064ca <alltraps>

80107157 <vector196>:
.globl vector196
vector196:
  pushl $0
80107157:	6a 00                	push   $0x0
  pushl $196
80107159:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
8010715e:	e9 67 f3 ff ff       	jmp    801064ca <alltraps>

80107163 <vector197>:
.globl vector197
vector197:
  pushl $0
80107163:	6a 00                	push   $0x0
  pushl $197
80107165:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
8010716a:	e9 5b f3 ff ff       	jmp    801064ca <alltraps>

8010716f <vector198>:
.globl vector198
vector198:
  pushl $0
8010716f:	6a 00                	push   $0x0
  pushl $198
80107171:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80107176:	e9 4f f3 ff ff       	jmp    801064ca <alltraps>

8010717b <vector199>:
.globl vector199
vector199:
  pushl $0
8010717b:	6a 00                	push   $0x0
  pushl $199
8010717d:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80107182:	e9 43 f3 ff ff       	jmp    801064ca <alltraps>

80107187 <vector200>:
.globl vector200
vector200:
  pushl $0
80107187:	6a 00                	push   $0x0
  pushl $200
80107189:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
8010718e:	e9 37 f3 ff ff       	jmp    801064ca <alltraps>

80107193 <vector201>:
.globl vector201
vector201:
  pushl $0
80107193:	6a 00                	push   $0x0
  pushl $201
80107195:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
8010719a:	e9 2b f3 ff ff       	jmp    801064ca <alltraps>

8010719f <vector202>:
.globl vector202
vector202:
  pushl $0
8010719f:	6a 00                	push   $0x0
  pushl $202
801071a1:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
801071a6:	e9 1f f3 ff ff       	jmp    801064ca <alltraps>

801071ab <vector203>:
.globl vector203
vector203:
  pushl $0
801071ab:	6a 00                	push   $0x0
  pushl $203
801071ad:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
801071b2:	e9 13 f3 ff ff       	jmp    801064ca <alltraps>

801071b7 <vector204>:
.globl vector204
vector204:
  pushl $0
801071b7:	6a 00                	push   $0x0
  pushl $204
801071b9:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
801071be:	e9 07 f3 ff ff       	jmp    801064ca <alltraps>

801071c3 <vector205>:
.globl vector205
vector205:
  pushl $0
801071c3:	6a 00                	push   $0x0
  pushl $205
801071c5:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
801071ca:	e9 fb f2 ff ff       	jmp    801064ca <alltraps>

801071cf <vector206>:
.globl vector206
vector206:
  pushl $0
801071cf:	6a 00                	push   $0x0
  pushl $206
801071d1:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
801071d6:	e9 ef f2 ff ff       	jmp    801064ca <alltraps>

801071db <vector207>:
.globl vector207
vector207:
  pushl $0
801071db:	6a 00                	push   $0x0
  pushl $207
801071dd:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
801071e2:	e9 e3 f2 ff ff       	jmp    801064ca <alltraps>

801071e7 <vector208>:
.globl vector208
vector208:
  pushl $0
801071e7:	6a 00                	push   $0x0
  pushl $208
801071e9:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
801071ee:	e9 d7 f2 ff ff       	jmp    801064ca <alltraps>

801071f3 <vector209>:
.globl vector209
vector209:
  pushl $0
801071f3:	6a 00                	push   $0x0
  pushl $209
801071f5:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
801071fa:	e9 cb f2 ff ff       	jmp    801064ca <alltraps>

801071ff <vector210>:
.globl vector210
vector210:
  pushl $0
801071ff:	6a 00                	push   $0x0
  pushl $210
80107201:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80107206:	e9 bf f2 ff ff       	jmp    801064ca <alltraps>

8010720b <vector211>:
.globl vector211
vector211:
  pushl $0
8010720b:	6a 00                	push   $0x0
  pushl $211
8010720d:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80107212:	e9 b3 f2 ff ff       	jmp    801064ca <alltraps>

80107217 <vector212>:
.globl vector212
vector212:
  pushl $0
80107217:	6a 00                	push   $0x0
  pushl $212
80107219:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
8010721e:	e9 a7 f2 ff ff       	jmp    801064ca <alltraps>

80107223 <vector213>:
.globl vector213
vector213:
  pushl $0
80107223:	6a 00                	push   $0x0
  pushl $213
80107225:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
8010722a:	e9 9b f2 ff ff       	jmp    801064ca <alltraps>

8010722f <vector214>:
.globl vector214
vector214:
  pushl $0
8010722f:	6a 00                	push   $0x0
  pushl $214
80107231:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80107236:	e9 8f f2 ff ff       	jmp    801064ca <alltraps>

8010723b <vector215>:
.globl vector215
vector215:
  pushl $0
8010723b:	6a 00                	push   $0x0
  pushl $215
8010723d:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80107242:	e9 83 f2 ff ff       	jmp    801064ca <alltraps>

80107247 <vector216>:
.globl vector216
vector216:
  pushl $0
80107247:	6a 00                	push   $0x0
  pushl $216
80107249:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
8010724e:	e9 77 f2 ff ff       	jmp    801064ca <alltraps>

80107253 <vector217>:
.globl vector217
vector217:
  pushl $0
80107253:	6a 00                	push   $0x0
  pushl $217
80107255:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
8010725a:	e9 6b f2 ff ff       	jmp    801064ca <alltraps>

8010725f <vector218>:
.globl vector218
vector218:
  pushl $0
8010725f:	6a 00                	push   $0x0
  pushl $218
80107261:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80107266:	e9 5f f2 ff ff       	jmp    801064ca <alltraps>

8010726b <vector219>:
.globl vector219
vector219:
  pushl $0
8010726b:	6a 00                	push   $0x0
  pushl $219
8010726d:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80107272:	e9 53 f2 ff ff       	jmp    801064ca <alltraps>

80107277 <vector220>:
.globl vector220
vector220:
  pushl $0
80107277:	6a 00                	push   $0x0
  pushl $220
80107279:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
8010727e:	e9 47 f2 ff ff       	jmp    801064ca <alltraps>

80107283 <vector221>:
.globl vector221
vector221:
  pushl $0
80107283:	6a 00                	push   $0x0
  pushl $221
80107285:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
8010728a:	e9 3b f2 ff ff       	jmp    801064ca <alltraps>

8010728f <vector222>:
.globl vector222
vector222:
  pushl $0
8010728f:	6a 00                	push   $0x0
  pushl $222
80107291:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80107296:	e9 2f f2 ff ff       	jmp    801064ca <alltraps>

8010729b <vector223>:
.globl vector223
vector223:
  pushl $0
8010729b:	6a 00                	push   $0x0
  pushl $223
8010729d:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
801072a2:	e9 23 f2 ff ff       	jmp    801064ca <alltraps>

801072a7 <vector224>:
.globl vector224
vector224:
  pushl $0
801072a7:	6a 00                	push   $0x0
  pushl $224
801072a9:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
801072ae:	e9 17 f2 ff ff       	jmp    801064ca <alltraps>

801072b3 <vector225>:
.globl vector225
vector225:
  pushl $0
801072b3:	6a 00                	push   $0x0
  pushl $225
801072b5:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
801072ba:	e9 0b f2 ff ff       	jmp    801064ca <alltraps>

801072bf <vector226>:
.globl vector226
vector226:
  pushl $0
801072bf:	6a 00                	push   $0x0
  pushl $226
801072c1:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
801072c6:	e9 ff f1 ff ff       	jmp    801064ca <alltraps>

801072cb <vector227>:
.globl vector227
vector227:
  pushl $0
801072cb:	6a 00                	push   $0x0
  pushl $227
801072cd:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
801072d2:	e9 f3 f1 ff ff       	jmp    801064ca <alltraps>

801072d7 <vector228>:
.globl vector228
vector228:
  pushl $0
801072d7:	6a 00                	push   $0x0
  pushl $228
801072d9:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
801072de:	e9 e7 f1 ff ff       	jmp    801064ca <alltraps>

801072e3 <vector229>:
.globl vector229
vector229:
  pushl $0
801072e3:	6a 00                	push   $0x0
  pushl $229
801072e5:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
801072ea:	e9 db f1 ff ff       	jmp    801064ca <alltraps>

801072ef <vector230>:
.globl vector230
vector230:
  pushl $0
801072ef:	6a 00                	push   $0x0
  pushl $230
801072f1:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
801072f6:	e9 cf f1 ff ff       	jmp    801064ca <alltraps>

801072fb <vector231>:
.globl vector231
vector231:
  pushl $0
801072fb:	6a 00                	push   $0x0
  pushl $231
801072fd:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80107302:	e9 c3 f1 ff ff       	jmp    801064ca <alltraps>

80107307 <vector232>:
.globl vector232
vector232:
  pushl $0
80107307:	6a 00                	push   $0x0
  pushl $232
80107309:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
8010730e:	e9 b7 f1 ff ff       	jmp    801064ca <alltraps>

80107313 <vector233>:
.globl vector233
vector233:
  pushl $0
80107313:	6a 00                	push   $0x0
  pushl $233
80107315:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
8010731a:	e9 ab f1 ff ff       	jmp    801064ca <alltraps>

8010731f <vector234>:
.globl vector234
vector234:
  pushl $0
8010731f:	6a 00                	push   $0x0
  pushl $234
80107321:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80107326:	e9 9f f1 ff ff       	jmp    801064ca <alltraps>

8010732b <vector235>:
.globl vector235
vector235:
  pushl $0
8010732b:	6a 00                	push   $0x0
  pushl $235
8010732d:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80107332:	e9 93 f1 ff ff       	jmp    801064ca <alltraps>

80107337 <vector236>:
.globl vector236
vector236:
  pushl $0
80107337:	6a 00                	push   $0x0
  pushl $236
80107339:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
8010733e:	e9 87 f1 ff ff       	jmp    801064ca <alltraps>

80107343 <vector237>:
.globl vector237
vector237:
  pushl $0
80107343:	6a 00                	push   $0x0
  pushl $237
80107345:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
8010734a:	e9 7b f1 ff ff       	jmp    801064ca <alltraps>

8010734f <vector238>:
.globl vector238
vector238:
  pushl $0
8010734f:	6a 00                	push   $0x0
  pushl $238
80107351:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80107356:	e9 6f f1 ff ff       	jmp    801064ca <alltraps>

8010735b <vector239>:
.globl vector239
vector239:
  pushl $0
8010735b:	6a 00                	push   $0x0
  pushl $239
8010735d:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80107362:	e9 63 f1 ff ff       	jmp    801064ca <alltraps>

80107367 <vector240>:
.globl vector240
vector240:
  pushl $0
80107367:	6a 00                	push   $0x0
  pushl $240
80107369:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
8010736e:	e9 57 f1 ff ff       	jmp    801064ca <alltraps>

80107373 <vector241>:
.globl vector241
vector241:
  pushl $0
80107373:	6a 00                	push   $0x0
  pushl $241
80107375:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
8010737a:	e9 4b f1 ff ff       	jmp    801064ca <alltraps>

8010737f <vector242>:
.globl vector242
vector242:
  pushl $0
8010737f:	6a 00                	push   $0x0
  pushl $242
80107381:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80107386:	e9 3f f1 ff ff       	jmp    801064ca <alltraps>

8010738b <vector243>:
.globl vector243
vector243:
  pushl $0
8010738b:	6a 00                	push   $0x0
  pushl $243
8010738d:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80107392:	e9 33 f1 ff ff       	jmp    801064ca <alltraps>

80107397 <vector244>:
.globl vector244
vector244:
  pushl $0
80107397:	6a 00                	push   $0x0
  pushl $244
80107399:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
8010739e:	e9 27 f1 ff ff       	jmp    801064ca <alltraps>

801073a3 <vector245>:
.globl vector245
vector245:
  pushl $0
801073a3:	6a 00                	push   $0x0
  pushl $245
801073a5:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
801073aa:	e9 1b f1 ff ff       	jmp    801064ca <alltraps>

801073af <vector246>:
.globl vector246
vector246:
  pushl $0
801073af:	6a 00                	push   $0x0
  pushl $246
801073b1:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
801073b6:	e9 0f f1 ff ff       	jmp    801064ca <alltraps>

801073bb <vector247>:
.globl vector247
vector247:
  pushl $0
801073bb:	6a 00                	push   $0x0
  pushl $247
801073bd:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
801073c2:	e9 03 f1 ff ff       	jmp    801064ca <alltraps>

801073c7 <vector248>:
.globl vector248
vector248:
  pushl $0
801073c7:	6a 00                	push   $0x0
  pushl $248
801073c9:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
801073ce:	e9 f7 f0 ff ff       	jmp    801064ca <alltraps>

801073d3 <vector249>:
.globl vector249
vector249:
  pushl $0
801073d3:	6a 00                	push   $0x0
  pushl $249
801073d5:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
801073da:	e9 eb f0 ff ff       	jmp    801064ca <alltraps>

801073df <vector250>:
.globl vector250
vector250:
  pushl $0
801073df:	6a 00                	push   $0x0
  pushl $250
801073e1:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
801073e6:	e9 df f0 ff ff       	jmp    801064ca <alltraps>

801073eb <vector251>:
.globl vector251
vector251:
  pushl $0
801073eb:	6a 00                	push   $0x0
  pushl $251
801073ed:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
801073f2:	e9 d3 f0 ff ff       	jmp    801064ca <alltraps>

801073f7 <vector252>:
.globl vector252
vector252:
  pushl $0
801073f7:	6a 00                	push   $0x0
  pushl $252
801073f9:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
801073fe:	e9 c7 f0 ff ff       	jmp    801064ca <alltraps>

80107403 <vector253>:
.globl vector253
vector253:
  pushl $0
80107403:	6a 00                	push   $0x0
  pushl $253
80107405:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
8010740a:	e9 bb f0 ff ff       	jmp    801064ca <alltraps>

8010740f <vector254>:
.globl vector254
vector254:
  pushl $0
8010740f:	6a 00                	push   $0x0
  pushl $254
80107411:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80107416:	e9 af f0 ff ff       	jmp    801064ca <alltraps>

8010741b <vector255>:
.globl vector255
vector255:
  pushl $0
8010741b:	6a 00                	push   $0x0
  pushl $255
8010741d:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80107422:	e9 a3 f0 ff ff       	jmp    801064ca <alltraps>
80107427:	66 90                	xchg   %ax,%ax
80107429:	66 90                	xchg   %ax,%ax
8010742b:	66 90                	xchg   %ax,%ax
8010742d:	66 90                	xchg   %ax,%ax
8010742f:	90                   	nop

80107430 <deallocuvm.part.0>:
// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80107430:	55                   	push   %ebp
80107431:	89 e5                	mov    %esp,%ebp
80107433:	57                   	push   %edi
80107434:	56                   	push   %esi
80107435:	53                   	push   %ebx
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
80107436:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
8010743c:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80107442:	83 ec 1c             	sub    $0x1c,%esp
  for(; a  < oldsz; a += PGSIZE){
80107445:	39 d3                	cmp    %edx,%ebx
80107447:	73 56                	jae    8010749f <deallocuvm.part.0+0x6f>
80107449:	89 4d e0             	mov    %ecx,-0x20(%ebp)
8010744c:	89 c6                	mov    %eax,%esi
8010744e:	89 d7                	mov    %edx,%edi
80107450:	eb 12                	jmp    80107464 <deallocuvm.part.0+0x34>
80107452:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    pte = walkpgdir(pgdir, (char*)a, 0);
    if(!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
80107458:	83 c2 01             	add    $0x1,%edx
8010745b:	89 d3                	mov    %edx,%ebx
8010745d:	c1 e3 16             	shl    $0x16,%ebx
  for(; a  < oldsz; a += PGSIZE){
80107460:	39 fb                	cmp    %edi,%ebx
80107462:	73 38                	jae    8010749c <deallocuvm.part.0+0x6c>
  pde = &pgdir[PDX(va)];
80107464:	89 da                	mov    %ebx,%edx
80107466:	c1 ea 16             	shr    $0x16,%edx
  if(*pde & PTE_P){
80107469:	8b 04 96             	mov    (%esi,%edx,4),%eax
8010746c:	a8 01                	test   $0x1,%al
8010746e:	74 e8                	je     80107458 <deallocuvm.part.0+0x28>
  return &pgtab[PTX(va)];
80107470:	89 d9                	mov    %ebx,%ecx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107472:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107477:	c1 e9 0a             	shr    $0xa,%ecx
8010747a:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
80107480:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
    if(!pte)
80107487:	85 c0                	test   %eax,%eax
80107489:	74 cd                	je     80107458 <deallocuvm.part.0+0x28>
    else if((*pte & PTE_P) != 0){
8010748b:	8b 10                	mov    (%eax),%edx
8010748d:	f6 c2 01             	test   $0x1,%dl
80107490:	75 1e                	jne    801074b0 <deallocuvm.part.0+0x80>
  for(; a  < oldsz; a += PGSIZE){
80107492:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80107498:	39 fb                	cmp    %edi,%ebx
8010749a:	72 c8                	jb     80107464 <deallocuvm.part.0+0x34>
8010749c:	8b 4d e0             	mov    -0x20(%ebp),%ecx
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
}
8010749f:	8d 65 f4             	lea    -0xc(%ebp),%esp
801074a2:	89 c8                	mov    %ecx,%eax
801074a4:	5b                   	pop    %ebx
801074a5:	5e                   	pop    %esi
801074a6:	5f                   	pop    %edi
801074a7:	5d                   	pop    %ebp
801074a8:	c3                   	ret
801074a9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      if(pa == 0)
801074b0:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
801074b6:	74 26                	je     801074de <deallocuvm.part.0+0xae>
      kfree(v);
801074b8:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
801074bb:	81 c2 00 00 00 80    	add    $0x80000000,%edx
801074c1:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(; a  < oldsz; a += PGSIZE){
801074c4:	81 c3 00 10 00 00    	add    $0x1000,%ebx
      kfree(v);
801074ca:	52                   	push   %edx
801074cb:	e8 60 bc ff ff       	call   80103130 <kfree>
      *pte = 0;
801074d0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  for(; a  < oldsz; a += PGSIZE){
801074d3:	83 c4 10             	add    $0x10,%esp
      *pte = 0;
801074d6:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
801074dc:	eb 82                	jmp    80107460 <deallocuvm.part.0+0x30>
        panic("kfree");
801074de:	83 ec 0c             	sub    $0xc,%esp
801074e1:	68 bd 7f 10 80       	push   $0x80107fbd
801074e6:	e8 95 8e ff ff       	call   80100380 <panic>
801074eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801074f0 <mappages>:
{
801074f0:	55                   	push   %ebp
801074f1:	89 e5                	mov    %esp,%ebp
801074f3:	57                   	push   %edi
801074f4:	56                   	push   %esi
801074f5:	53                   	push   %ebx
  a = (char*)PGROUNDDOWN((uint)va);
801074f6:	89 d3                	mov    %edx,%ebx
801074f8:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
{
801074fe:	83 ec 1c             	sub    $0x1c,%esp
80107501:	89 45 e0             	mov    %eax,-0x20(%ebp)
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80107504:	8d 44 0a ff          	lea    -0x1(%edx,%ecx,1),%eax
80107508:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010750d:	89 45 dc             	mov    %eax,-0x24(%ebp)
80107510:	8b 45 08             	mov    0x8(%ebp),%eax
80107513:	29 d8                	sub    %ebx,%eax
80107515:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80107518:	eb 3f                	jmp    80107559 <mappages+0x69>
8010751a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80107520:	89 da                	mov    %ebx,%edx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107522:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107527:	c1 ea 0a             	shr    $0xa,%edx
8010752a:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80107530:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80107537:	85 c0                	test   %eax,%eax
80107539:	74 75                	je     801075b0 <mappages+0xc0>
    if(*pte & PTE_P)
8010753b:	f6 00 01             	testb  $0x1,(%eax)
8010753e:	0f 85 86 00 00 00    	jne    801075ca <mappages+0xda>
    *pte = pa | perm | PTE_P;
80107544:	0b 75 0c             	or     0xc(%ebp),%esi
80107547:	83 ce 01             	or     $0x1,%esi
8010754a:	89 30                	mov    %esi,(%eax)
    if(a == last)
8010754c:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010754f:	39 c3                	cmp    %eax,%ebx
80107551:	74 6d                	je     801075c0 <mappages+0xd0>
    a += PGSIZE;
80107553:	81 c3 00 10 00 00    	add    $0x1000,%ebx
  for(;;){
80107559:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  pde = &pgdir[PDX(va)];
8010755c:	8b 4d e0             	mov    -0x20(%ebp),%ecx
8010755f:	8d 34 03             	lea    (%ebx,%eax,1),%esi
80107562:	89 d8                	mov    %ebx,%eax
80107564:	c1 e8 16             	shr    $0x16,%eax
80107567:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
  if(*pde & PTE_P){
8010756a:	8b 07                	mov    (%edi),%eax
8010756c:	a8 01                	test   $0x1,%al
8010756e:	75 b0                	jne    80107520 <mappages+0x30>
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80107570:	e8 7b bd ff ff       	call   801032f0 <kalloc>
80107575:	85 c0                	test   %eax,%eax
80107577:	74 37                	je     801075b0 <mappages+0xc0>
    memset(pgtab, 0, PGSIZE);
80107579:	83 ec 04             	sub    $0x4,%esp
8010757c:	68 00 10 00 00       	push   $0x1000
80107581:	6a 00                	push   $0x0
80107583:	50                   	push   %eax
80107584:	89 45 d8             	mov    %eax,-0x28(%ebp)
80107587:	e8 a4 dd ff ff       	call   80105330 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
8010758c:	8b 55 d8             	mov    -0x28(%ebp),%edx
  return &pgtab[PTX(va)];
8010758f:	83 c4 10             	add    $0x10,%esp
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80107592:	8d 82 00 00 00 80    	lea    -0x80000000(%edx),%eax
80107598:	83 c8 07             	or     $0x7,%eax
8010759b:	89 07                	mov    %eax,(%edi)
  return &pgtab[PTX(va)];
8010759d:	89 d8                	mov    %ebx,%eax
8010759f:	c1 e8 0a             	shr    $0xa,%eax
801075a2:	25 fc 0f 00 00       	and    $0xffc,%eax
801075a7:	01 d0                	add    %edx,%eax
801075a9:	eb 90                	jmp    8010753b <mappages+0x4b>
801075ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
}
801075b0:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
801075b3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801075b8:	5b                   	pop    %ebx
801075b9:	5e                   	pop    %esi
801075ba:	5f                   	pop    %edi
801075bb:	5d                   	pop    %ebp
801075bc:	c3                   	ret
801075bd:	8d 76 00             	lea    0x0(%esi),%esi
801075c0:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801075c3:	31 c0                	xor    %eax,%eax
}
801075c5:	5b                   	pop    %ebx
801075c6:	5e                   	pop    %esi
801075c7:	5f                   	pop    %edi
801075c8:	5d                   	pop    %ebp
801075c9:	c3                   	ret
      panic("remap");
801075ca:	83 ec 0c             	sub    $0xc,%esp
801075cd:	68 f1 81 10 80       	push   $0x801081f1
801075d2:	e8 a9 8d ff ff       	call   80100380 <panic>
801075d7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801075de:	00 
801075df:	90                   	nop

801075e0 <seginit>:
{
801075e0:	55                   	push   %ebp
801075e1:	89 e5                	mov    %esp,%ebp
801075e3:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
801075e6:	e8 e5 cf ff ff       	call   801045d0 <cpuid>
  pd[0] = size-1;
801075eb:	ba 2f 00 00 00       	mov    $0x2f,%edx
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
801075f0:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
801075f6:	66 89 55 f2          	mov    %dx,-0xe(%ebp)
801075fa:	c7 80 b8 2a 11 80 ff 	movl   $0xffff,-0x7feed548(%eax)
80107601:	ff 00 00 
80107604:	c7 80 bc 2a 11 80 00 	movl   $0xcf9a00,-0x7feed544(%eax)
8010760b:	9a cf 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
8010760e:	c7 80 c0 2a 11 80 ff 	movl   $0xffff,-0x7feed540(%eax)
80107615:	ff 00 00 
80107618:	c7 80 c4 2a 11 80 00 	movl   $0xcf9200,-0x7feed53c(%eax)
8010761f:	92 cf 00 
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80107622:	c7 80 c8 2a 11 80 ff 	movl   $0xffff,-0x7feed538(%eax)
80107629:	ff 00 00 
8010762c:	c7 80 cc 2a 11 80 00 	movl   $0xcffa00,-0x7feed534(%eax)
80107633:	fa cf 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80107636:	c7 80 d0 2a 11 80 ff 	movl   $0xffff,-0x7feed530(%eax)
8010763d:	ff 00 00 
80107640:	c7 80 d4 2a 11 80 00 	movl   $0xcff200,-0x7feed52c(%eax)
80107647:	f2 cf 00 
  lgdt(c->gdt, sizeof(c->gdt));
8010764a:	05 b0 2a 11 80       	add    $0x80112ab0,%eax
  pd[1] = (uint)p;
8010764f:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80107653:	c1 e8 10             	shr    $0x10,%eax
80107656:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
8010765a:	8d 45 f2             	lea    -0xe(%ebp),%eax
8010765d:	0f 01 10             	lgdtl  (%eax)
}
80107660:	c9                   	leave
80107661:	c3                   	ret
80107662:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107669:	00 
8010766a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107670 <switchkvm>:
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107670:	a1 64 57 11 80       	mov    0x80115764,%eax
80107675:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010767a:	0f 22 d8             	mov    %eax,%cr3
}
8010767d:	c3                   	ret
8010767e:	66 90                	xchg   %ax,%ax

80107680 <switchuvm>:
{
80107680:	55                   	push   %ebp
80107681:	89 e5                	mov    %esp,%ebp
80107683:	57                   	push   %edi
80107684:	56                   	push   %esi
80107685:	53                   	push   %ebx
80107686:	83 ec 1c             	sub    $0x1c,%esp
80107689:	8b 75 08             	mov    0x8(%ebp),%esi
  if(p == 0)
8010768c:	85 f6                	test   %esi,%esi
8010768e:	0f 84 cb 00 00 00    	je     8010775f <switchuvm+0xdf>
  if(p->kstack == 0)
80107694:	8b 46 08             	mov    0x8(%esi),%eax
80107697:	85 c0                	test   %eax,%eax
80107699:	0f 84 da 00 00 00    	je     80107779 <switchuvm+0xf9>
  if(p->pgdir == 0)
8010769f:	8b 46 04             	mov    0x4(%esi),%eax
801076a2:	85 c0                	test   %eax,%eax
801076a4:	0f 84 c2 00 00 00    	je     8010776c <switchuvm+0xec>
  pushcli();
801076aa:	e8 31 da ff ff       	call   801050e0 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801076af:	e8 bc ce ff ff       	call   80104570 <mycpu>
801076b4:	89 c3                	mov    %eax,%ebx
801076b6:	e8 b5 ce ff ff       	call   80104570 <mycpu>
801076bb:	89 c7                	mov    %eax,%edi
801076bd:	e8 ae ce ff ff       	call   80104570 <mycpu>
801076c2:	83 c7 08             	add    $0x8,%edi
801076c5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801076c8:	e8 a3 ce ff ff       	call   80104570 <mycpu>
801076cd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801076d0:	ba 67 00 00 00       	mov    $0x67,%edx
801076d5:	66 89 bb 9a 00 00 00 	mov    %di,0x9a(%ebx)
801076dc:	83 c0 08             	add    $0x8,%eax
801076df:	66 89 93 98 00 00 00 	mov    %dx,0x98(%ebx)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
801076e6:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801076eb:	83 c1 08             	add    $0x8,%ecx
801076ee:	c1 e8 18             	shr    $0x18,%eax
801076f1:	c1 e9 10             	shr    $0x10,%ecx
801076f4:	88 83 9f 00 00 00    	mov    %al,0x9f(%ebx)
801076fa:	88 8b 9c 00 00 00    	mov    %cl,0x9c(%ebx)
80107700:	b9 99 40 00 00       	mov    $0x4099,%ecx
80107705:	66 89 8b 9d 00 00 00 	mov    %cx,0x9d(%ebx)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010770c:	bb 10 00 00 00       	mov    $0x10,%ebx
  mycpu()->gdt[SEG_TSS].s = 0;
80107711:	e8 5a ce ff ff       	call   80104570 <mycpu>
80107716:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010771d:	e8 4e ce ff ff       	call   80104570 <mycpu>
80107722:	66 89 58 10          	mov    %bx,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80107726:	8b 5e 08             	mov    0x8(%esi),%ebx
80107729:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010772f:	e8 3c ce ff ff       	call   80104570 <mycpu>
80107734:	89 58 0c             	mov    %ebx,0xc(%eax)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80107737:	e8 34 ce ff ff       	call   80104570 <mycpu>
8010773c:	66 89 78 6e          	mov    %di,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
80107740:	b8 28 00 00 00       	mov    $0x28,%eax
80107745:	0f 00 d8             	ltr    %eax
  lcr3(V2P(p->pgdir));  // switch to process's address space
80107748:	8b 46 04             	mov    0x4(%esi),%eax
8010774b:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
80107750:	0f 22 d8             	mov    %eax,%cr3
}
80107753:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107756:	5b                   	pop    %ebx
80107757:	5e                   	pop    %esi
80107758:	5f                   	pop    %edi
80107759:	5d                   	pop    %ebp
  popcli();
8010775a:	e9 d1 d9 ff ff       	jmp    80105130 <popcli>
    panic("switchuvm: no process");
8010775f:	83 ec 0c             	sub    $0xc,%esp
80107762:	68 f7 81 10 80       	push   $0x801081f7
80107767:	e8 14 8c ff ff       	call   80100380 <panic>
    panic("switchuvm: no pgdir");
8010776c:	83 ec 0c             	sub    $0xc,%esp
8010776f:	68 22 82 10 80       	push   $0x80108222
80107774:	e8 07 8c ff ff       	call   80100380 <panic>
    panic("switchuvm: no kstack");
80107779:	83 ec 0c             	sub    $0xc,%esp
8010777c:	68 0d 82 10 80       	push   $0x8010820d
80107781:	e8 fa 8b ff ff       	call   80100380 <panic>
80107786:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010778d:	00 
8010778e:	66 90                	xchg   %ax,%ax

80107790 <inituvm>:
{
80107790:	55                   	push   %ebp
80107791:	89 e5                	mov    %esp,%ebp
80107793:	57                   	push   %edi
80107794:	56                   	push   %esi
80107795:	53                   	push   %ebx
80107796:	83 ec 1c             	sub    $0x1c,%esp
80107799:	8b 45 08             	mov    0x8(%ebp),%eax
8010779c:	8b 75 10             	mov    0x10(%ebp),%esi
8010779f:	8b 7d 0c             	mov    0xc(%ebp),%edi
801077a2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(sz >= PGSIZE)
801077a5:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
801077ab:	77 49                	ja     801077f6 <inituvm+0x66>
  mem = kalloc();
801077ad:	e8 3e bb ff ff       	call   801032f0 <kalloc>
  memset(mem, 0, PGSIZE);
801077b2:	83 ec 04             	sub    $0x4,%esp
801077b5:	68 00 10 00 00       	push   $0x1000
  mem = kalloc();
801077ba:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
801077bc:	6a 00                	push   $0x0
801077be:	50                   	push   %eax
801077bf:	e8 6c db ff ff       	call   80105330 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
801077c4:	58                   	pop    %eax
801077c5:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801077cb:	5a                   	pop    %edx
801077cc:	6a 06                	push   $0x6
801077ce:	b9 00 10 00 00       	mov    $0x1000,%ecx
801077d3:	31 d2                	xor    %edx,%edx
801077d5:	50                   	push   %eax
801077d6:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801077d9:	e8 12 fd ff ff       	call   801074f0 <mappages>
  memmove(mem, init, sz);
801077de:	83 c4 10             	add    $0x10,%esp
801077e1:	89 75 10             	mov    %esi,0x10(%ebp)
801077e4:	89 7d 0c             	mov    %edi,0xc(%ebp)
801077e7:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801077ea:	8d 65 f4             	lea    -0xc(%ebp),%esp
801077ed:	5b                   	pop    %ebx
801077ee:	5e                   	pop    %esi
801077ef:	5f                   	pop    %edi
801077f0:	5d                   	pop    %ebp
  memmove(mem, init, sz);
801077f1:	e9 ca db ff ff       	jmp    801053c0 <memmove>
    panic("inituvm: more than a page");
801077f6:	83 ec 0c             	sub    $0xc,%esp
801077f9:	68 36 82 10 80       	push   $0x80108236
801077fe:	e8 7d 8b ff ff       	call   80100380 <panic>
80107803:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010780a:	00 
8010780b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80107810 <loaduvm>:
{
80107810:	55                   	push   %ebp
80107811:	89 e5                	mov    %esp,%ebp
80107813:	57                   	push   %edi
80107814:	56                   	push   %esi
80107815:	53                   	push   %ebx
80107816:	83 ec 0c             	sub    $0xc,%esp
  if((uint) addr % PGSIZE != 0)
80107819:	8b 75 0c             	mov    0xc(%ebp),%esi
{
8010781c:	8b 7d 18             	mov    0x18(%ebp),%edi
  if((uint) addr % PGSIZE != 0)
8010781f:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80107825:	0f 85 a2 00 00 00    	jne    801078cd <loaduvm+0xbd>
  for(i = 0; i < sz; i += PGSIZE){
8010782b:	85 ff                	test   %edi,%edi
8010782d:	74 7d                	je     801078ac <loaduvm+0x9c>
8010782f:	90                   	nop
  pde = &pgdir[PDX(va)];
80107830:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107833:	8b 55 08             	mov    0x8(%ebp),%edx
80107836:	01 f0                	add    %esi,%eax
  pde = &pgdir[PDX(va)];
80107838:	89 c1                	mov    %eax,%ecx
8010783a:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
8010783d:	8b 0c 8a             	mov    (%edx,%ecx,4),%ecx
80107840:	f6 c1 01             	test   $0x1,%cl
80107843:	75 13                	jne    80107858 <loaduvm+0x48>
      panic("loaduvm: address should exist");
80107845:	83 ec 0c             	sub    $0xc,%esp
80107848:	68 50 82 10 80       	push   $0x80108250
8010784d:	e8 2e 8b ff ff       	call   80100380 <panic>
80107852:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80107858:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
8010785b:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
80107861:	25 fc 0f 00 00       	and    $0xffc,%eax
80107866:	8d 8c 01 00 00 00 80 	lea    -0x80000000(%ecx,%eax,1),%ecx
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
8010786d:	85 c9                	test   %ecx,%ecx
8010786f:	74 d4                	je     80107845 <loaduvm+0x35>
    if(sz - i < PGSIZE)
80107871:	89 fb                	mov    %edi,%ebx
80107873:	b8 00 10 00 00       	mov    $0x1000,%eax
80107878:	29 f3                	sub    %esi,%ebx
8010787a:	39 c3                	cmp    %eax,%ebx
8010787c:	0f 47 d8             	cmova  %eax,%ebx
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010787f:	53                   	push   %ebx
80107880:	8b 45 14             	mov    0x14(%ebp),%eax
80107883:	01 f0                	add    %esi,%eax
80107885:	50                   	push   %eax
    pa = PTE_ADDR(*pte);
80107886:	8b 01                	mov    (%ecx),%eax
80107888:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010788d:	05 00 00 00 80       	add    $0x80000000,%eax
80107892:	50                   	push   %eax
80107893:	ff 75 10             	push   0x10(%ebp)
80107896:	e8 a5 ae ff ff       	call   80102740 <readi>
8010789b:	83 c4 10             	add    $0x10,%esp
8010789e:	39 d8                	cmp    %ebx,%eax
801078a0:	75 1e                	jne    801078c0 <loaduvm+0xb0>
  for(i = 0; i < sz; i += PGSIZE){
801078a2:	81 c6 00 10 00 00    	add    $0x1000,%esi
801078a8:	39 fe                	cmp    %edi,%esi
801078aa:	72 84                	jb     80107830 <loaduvm+0x20>
}
801078ac:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
801078af:	31 c0                	xor    %eax,%eax
}
801078b1:	5b                   	pop    %ebx
801078b2:	5e                   	pop    %esi
801078b3:	5f                   	pop    %edi
801078b4:	5d                   	pop    %ebp
801078b5:	c3                   	ret
801078b6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801078bd:	00 
801078be:	66 90                	xchg   %ax,%ax
801078c0:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
801078c3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801078c8:	5b                   	pop    %ebx
801078c9:	5e                   	pop    %esi
801078ca:	5f                   	pop    %edi
801078cb:	5d                   	pop    %ebp
801078cc:	c3                   	ret
    panic("loaduvm: addr must be page aligned");
801078cd:	83 ec 0c             	sub    $0xc,%esp
801078d0:	68 30 85 10 80       	push   $0x80108530
801078d5:	e8 a6 8a ff ff       	call   80100380 <panic>
801078da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801078e0 <allocuvm>:
{
801078e0:	55                   	push   %ebp
801078e1:	89 e5                	mov    %esp,%ebp
801078e3:	57                   	push   %edi
801078e4:	56                   	push   %esi
801078e5:	53                   	push   %ebx
801078e6:	83 ec 1c             	sub    $0x1c,%esp
801078e9:	8b 75 10             	mov    0x10(%ebp),%esi
  if(newsz >= KERNBASE)
801078ec:	85 f6                	test   %esi,%esi
801078ee:	0f 88 98 00 00 00    	js     8010798c <allocuvm+0xac>
801078f4:	89 f2                	mov    %esi,%edx
  if(newsz < oldsz)
801078f6:	3b 75 0c             	cmp    0xc(%ebp),%esi
801078f9:	0f 82 a1 00 00 00    	jb     801079a0 <allocuvm+0xc0>
  a = PGROUNDUP(oldsz);
801078ff:	8b 45 0c             	mov    0xc(%ebp),%eax
80107902:	05 ff 0f 00 00       	add    $0xfff,%eax
80107907:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010790c:	89 c7                	mov    %eax,%edi
  for(; a < newsz; a += PGSIZE){
8010790e:	39 f0                	cmp    %esi,%eax
80107910:	0f 83 8d 00 00 00    	jae    801079a3 <allocuvm+0xc3>
80107916:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80107919:	eb 44                	jmp    8010795f <allocuvm+0x7f>
8010791b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    memset(mem, 0, PGSIZE);
80107920:	83 ec 04             	sub    $0x4,%esp
80107923:	68 00 10 00 00       	push   $0x1000
80107928:	6a 00                	push   $0x0
8010792a:	50                   	push   %eax
8010792b:	e8 00 da ff ff       	call   80105330 <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
80107930:	58                   	pop    %eax
80107931:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80107937:	5a                   	pop    %edx
80107938:	6a 06                	push   $0x6
8010793a:	b9 00 10 00 00       	mov    $0x1000,%ecx
8010793f:	89 fa                	mov    %edi,%edx
80107941:	50                   	push   %eax
80107942:	8b 45 08             	mov    0x8(%ebp),%eax
80107945:	e8 a6 fb ff ff       	call   801074f0 <mappages>
8010794a:	83 c4 10             	add    $0x10,%esp
8010794d:	85 c0                	test   %eax,%eax
8010794f:	78 5f                	js     801079b0 <allocuvm+0xd0>
  for(; a < newsz; a += PGSIZE){
80107951:	81 c7 00 10 00 00    	add    $0x1000,%edi
80107957:	39 f7                	cmp    %esi,%edi
80107959:	0f 83 89 00 00 00    	jae    801079e8 <allocuvm+0x108>
    mem = kalloc();
8010795f:	e8 8c b9 ff ff       	call   801032f0 <kalloc>
80107964:	89 c3                	mov    %eax,%ebx
    if(mem == 0){
80107966:	85 c0                	test   %eax,%eax
80107968:	75 b6                	jne    80107920 <allocuvm+0x40>
      cprintf("allocuvm out of memory\n");
8010796a:	83 ec 0c             	sub    $0xc,%esp
8010796d:	68 6e 82 10 80       	push   $0x8010826e
80107972:	e8 69 93 ff ff       	call   80100ce0 <cprintf>
  if(newsz >= oldsz)
80107977:	83 c4 10             	add    $0x10,%esp
8010797a:	3b 75 0c             	cmp    0xc(%ebp),%esi
8010797d:	74 0d                	je     8010798c <allocuvm+0xac>
8010797f:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107982:	8b 45 08             	mov    0x8(%ebp),%eax
80107985:	89 f2                	mov    %esi,%edx
80107987:	e8 a4 fa ff ff       	call   80107430 <deallocuvm.part.0>
    return 0;
8010798c:	31 d2                	xor    %edx,%edx
}
8010798e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107991:	89 d0                	mov    %edx,%eax
80107993:	5b                   	pop    %ebx
80107994:	5e                   	pop    %esi
80107995:	5f                   	pop    %edi
80107996:	5d                   	pop    %ebp
80107997:	c3                   	ret
80107998:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010799f:	00 
    return oldsz;
801079a0:	8b 55 0c             	mov    0xc(%ebp),%edx
}
801079a3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801079a6:	89 d0                	mov    %edx,%eax
801079a8:	5b                   	pop    %ebx
801079a9:	5e                   	pop    %esi
801079aa:	5f                   	pop    %edi
801079ab:	5d                   	pop    %ebp
801079ac:	c3                   	ret
801079ad:	8d 76 00             	lea    0x0(%esi),%esi
      cprintf("allocuvm out of memory (2)\n");
801079b0:	83 ec 0c             	sub    $0xc,%esp
801079b3:	68 86 82 10 80       	push   $0x80108286
801079b8:	e8 23 93 ff ff       	call   80100ce0 <cprintf>
  if(newsz >= oldsz)
801079bd:	83 c4 10             	add    $0x10,%esp
801079c0:	3b 75 0c             	cmp    0xc(%ebp),%esi
801079c3:	74 0d                	je     801079d2 <allocuvm+0xf2>
801079c5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801079c8:	8b 45 08             	mov    0x8(%ebp),%eax
801079cb:	89 f2                	mov    %esi,%edx
801079cd:	e8 5e fa ff ff       	call   80107430 <deallocuvm.part.0>
      kfree(mem);
801079d2:	83 ec 0c             	sub    $0xc,%esp
801079d5:	53                   	push   %ebx
801079d6:	e8 55 b7 ff ff       	call   80103130 <kfree>
      return 0;
801079db:	83 c4 10             	add    $0x10,%esp
    return 0;
801079de:	31 d2                	xor    %edx,%edx
801079e0:	eb ac                	jmp    8010798e <allocuvm+0xae>
801079e2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801079e8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
}
801079eb:	8d 65 f4             	lea    -0xc(%ebp),%esp
801079ee:	5b                   	pop    %ebx
801079ef:	5e                   	pop    %esi
801079f0:	89 d0                	mov    %edx,%eax
801079f2:	5f                   	pop    %edi
801079f3:	5d                   	pop    %ebp
801079f4:	c3                   	ret
801079f5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801079fc:	00 
801079fd:	8d 76 00             	lea    0x0(%esi),%esi

80107a00 <deallocuvm>:
{
80107a00:	55                   	push   %ebp
80107a01:	89 e5                	mov    %esp,%ebp
80107a03:	8b 55 0c             	mov    0xc(%ebp),%edx
80107a06:	8b 4d 10             	mov    0x10(%ebp),%ecx
80107a09:	8b 45 08             	mov    0x8(%ebp),%eax
  if(newsz >= oldsz)
80107a0c:	39 d1                	cmp    %edx,%ecx
80107a0e:	73 10                	jae    80107a20 <deallocuvm+0x20>
}
80107a10:	5d                   	pop    %ebp
80107a11:	e9 1a fa ff ff       	jmp    80107430 <deallocuvm.part.0>
80107a16:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107a1d:	00 
80107a1e:	66 90                	xchg   %ax,%ax
80107a20:	89 d0                	mov    %edx,%eax
80107a22:	5d                   	pop    %ebp
80107a23:	c3                   	ret
80107a24:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107a2b:	00 
80107a2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80107a30 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
80107a30:	55                   	push   %ebp
80107a31:	89 e5                	mov    %esp,%ebp
80107a33:	57                   	push   %edi
80107a34:	56                   	push   %esi
80107a35:	53                   	push   %ebx
80107a36:	83 ec 0c             	sub    $0xc,%esp
80107a39:	8b 75 08             	mov    0x8(%ebp),%esi
  uint i;

  if(pgdir == 0)
80107a3c:	85 f6                	test   %esi,%esi
80107a3e:	74 59                	je     80107a99 <freevm+0x69>
  if(newsz >= oldsz)
80107a40:	31 c9                	xor    %ecx,%ecx
80107a42:	ba 00 00 00 80       	mov    $0x80000000,%edx
80107a47:	89 f0                	mov    %esi,%eax
80107a49:	89 f3                	mov    %esi,%ebx
80107a4b:	e8 e0 f9 ff ff       	call   80107430 <deallocuvm.part.0>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for(i = 0; i < NPDENTRIES; i++){
80107a50:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
80107a56:	eb 0f                	jmp    80107a67 <freevm+0x37>
80107a58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107a5f:	00 
80107a60:	83 c3 04             	add    $0x4,%ebx
80107a63:	39 fb                	cmp    %edi,%ebx
80107a65:	74 23                	je     80107a8a <freevm+0x5a>
    if(pgdir[i] & PTE_P){
80107a67:	8b 03                	mov    (%ebx),%eax
80107a69:	a8 01                	test   $0x1,%al
80107a6b:	74 f3                	je     80107a60 <freevm+0x30>
      char * v = P2V(PTE_ADDR(pgdir[i]));
80107a6d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      kfree(v);
80107a72:	83 ec 0c             	sub    $0xc,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107a75:	83 c3 04             	add    $0x4,%ebx
      char * v = P2V(PTE_ADDR(pgdir[i]));
80107a78:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
80107a7d:	50                   	push   %eax
80107a7e:	e8 ad b6 ff ff       	call   80103130 <kfree>
80107a83:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107a86:	39 fb                	cmp    %edi,%ebx
80107a88:	75 dd                	jne    80107a67 <freevm+0x37>
    }
  }
  kfree((char*)pgdir);
80107a8a:	89 75 08             	mov    %esi,0x8(%ebp)
}
80107a8d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107a90:	5b                   	pop    %ebx
80107a91:	5e                   	pop    %esi
80107a92:	5f                   	pop    %edi
80107a93:	5d                   	pop    %ebp
  kfree((char*)pgdir);
80107a94:	e9 97 b6 ff ff       	jmp    80103130 <kfree>
    panic("freevm: no pgdir");
80107a99:	83 ec 0c             	sub    $0xc,%esp
80107a9c:	68 a2 82 10 80       	push   $0x801082a2
80107aa1:	e8 da 88 ff ff       	call   80100380 <panic>
80107aa6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107aad:	00 
80107aae:	66 90                	xchg   %ax,%ax

80107ab0 <setupkvm>:
{
80107ab0:	55                   	push   %ebp
80107ab1:	89 e5                	mov    %esp,%ebp
80107ab3:	56                   	push   %esi
80107ab4:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
80107ab5:	e8 36 b8 ff ff       	call   801032f0 <kalloc>
80107aba:	85 c0                	test   %eax,%eax
80107abc:	74 5e                	je     80107b1c <setupkvm+0x6c>
  memset(pgdir, 0, PGSIZE);
80107abe:	83 ec 04             	sub    $0x4,%esp
80107ac1:	89 c6                	mov    %eax,%esi
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107ac3:	bb 20 b4 10 80       	mov    $0x8010b420,%ebx
  memset(pgdir, 0, PGSIZE);
80107ac8:	68 00 10 00 00       	push   $0x1000
80107acd:	6a 00                	push   $0x0
80107acf:	50                   	push   %eax
80107ad0:	e8 5b d8 ff ff       	call   80105330 <memset>
80107ad5:	83 c4 10             	add    $0x10,%esp
                (uint)k->phys_start, k->perm) < 0) {
80107ad8:	8b 43 04             	mov    0x4(%ebx),%eax
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
80107adb:	83 ec 08             	sub    $0x8,%esp
80107ade:	8b 4b 08             	mov    0x8(%ebx),%ecx
80107ae1:	8b 13                	mov    (%ebx),%edx
80107ae3:	ff 73 0c             	push   0xc(%ebx)
80107ae6:	50                   	push   %eax
80107ae7:	29 c1                	sub    %eax,%ecx
80107ae9:	89 f0                	mov    %esi,%eax
80107aeb:	e8 00 fa ff ff       	call   801074f0 <mappages>
80107af0:	83 c4 10             	add    $0x10,%esp
80107af3:	85 c0                	test   %eax,%eax
80107af5:	78 19                	js     80107b10 <setupkvm+0x60>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
80107af7:	83 c3 10             	add    $0x10,%ebx
80107afa:	81 fb 60 b4 10 80    	cmp    $0x8010b460,%ebx
80107b00:	75 d6                	jne    80107ad8 <setupkvm+0x28>
}
80107b02:	8d 65 f8             	lea    -0x8(%ebp),%esp
80107b05:	89 f0                	mov    %esi,%eax
80107b07:	5b                   	pop    %ebx
80107b08:	5e                   	pop    %esi
80107b09:	5d                   	pop    %ebp
80107b0a:	c3                   	ret
80107b0b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      freevm(pgdir);
80107b10:	83 ec 0c             	sub    $0xc,%esp
80107b13:	56                   	push   %esi
80107b14:	e8 17 ff ff ff       	call   80107a30 <freevm>
      return 0;
80107b19:	83 c4 10             	add    $0x10,%esp
}
80107b1c:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return 0;
80107b1f:	31 f6                	xor    %esi,%esi
}
80107b21:	89 f0                	mov    %esi,%eax
80107b23:	5b                   	pop    %ebx
80107b24:	5e                   	pop    %esi
80107b25:	5d                   	pop    %ebp
80107b26:	c3                   	ret
80107b27:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107b2e:	00 
80107b2f:	90                   	nop

80107b30 <kvmalloc>:
{
80107b30:	55                   	push   %ebp
80107b31:	89 e5                	mov    %esp,%ebp
80107b33:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80107b36:	e8 75 ff ff ff       	call   80107ab0 <setupkvm>
80107b3b:	a3 64 57 11 80       	mov    %eax,0x80115764
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107b40:	05 00 00 00 80       	add    $0x80000000,%eax
80107b45:	0f 22 d8             	mov    %eax,%cr3
}
80107b48:	c9                   	leave
80107b49:	c3                   	ret
80107b4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107b50 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80107b50:	55                   	push   %ebp
80107b51:	89 e5                	mov    %esp,%ebp
80107b53:	83 ec 08             	sub    $0x8,%esp
80107b56:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107b59:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80107b5c:	89 c1                	mov    %eax,%ecx
80107b5e:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80107b61:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107b64:	f6 c2 01             	test   $0x1,%dl
80107b67:	75 17                	jne    80107b80 <clearpteu+0x30>
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if(pte == 0)
    panic("clearpteu");
80107b69:	83 ec 0c             	sub    $0xc,%esp
80107b6c:	68 b3 82 10 80       	push   $0x801082b3
80107b71:	e8 0a 88 ff ff       	call   80100380 <panic>
80107b76:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107b7d:	00 
80107b7e:	66 90                	xchg   %ax,%ax
  return &pgtab[PTX(va)];
80107b80:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107b83:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
80107b89:	25 fc 0f 00 00       	and    $0xffc,%eax
80107b8e:	8d 84 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%eax
  if(pte == 0)
80107b95:	85 c0                	test   %eax,%eax
80107b97:	74 d0                	je     80107b69 <clearpteu+0x19>
  *pte &= ~PTE_U;
80107b99:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
80107b9c:	c9                   	leave
80107b9d:	c3                   	ret
80107b9e:	66 90                	xchg   %ax,%ax

80107ba0 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
80107ba0:	55                   	push   %ebp
80107ba1:	89 e5                	mov    %esp,%ebp
80107ba3:	57                   	push   %edi
80107ba4:	56                   	push   %esi
80107ba5:	53                   	push   %ebx
80107ba6:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
80107ba9:	e8 02 ff ff ff       	call   80107ab0 <setupkvm>
80107bae:	89 45 e0             	mov    %eax,-0x20(%ebp)
80107bb1:	85 c0                	test   %eax,%eax
80107bb3:	0f 84 e9 00 00 00    	je     80107ca2 <copyuvm+0x102>
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
80107bb9:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107bbc:	85 c9                	test   %ecx,%ecx
80107bbe:	0f 84 b2 00 00 00    	je     80107c76 <copyuvm+0xd6>
80107bc4:	31 f6                	xor    %esi,%esi
80107bc6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107bcd:	00 
80107bce:	66 90                	xchg   %ax,%ax
  if(*pde & PTE_P){
80107bd0:	8b 4d 08             	mov    0x8(%ebp),%ecx
  pde = &pgdir[PDX(va)];
80107bd3:	89 f0                	mov    %esi,%eax
80107bd5:	c1 e8 16             	shr    $0x16,%eax
  if(*pde & PTE_P){
80107bd8:	8b 04 81             	mov    (%ecx,%eax,4),%eax
80107bdb:	a8 01                	test   $0x1,%al
80107bdd:	75 11                	jne    80107bf0 <copyuvm+0x50>
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
      panic("copyuvm: pte should exist");
80107bdf:	83 ec 0c             	sub    $0xc,%esp
80107be2:	68 bd 82 10 80       	push   $0x801082bd
80107be7:	e8 94 87 ff ff       	call   80100380 <panic>
80107bec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return &pgtab[PTX(va)];
80107bf0:	89 f2                	mov    %esi,%edx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107bf2:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107bf7:	c1 ea 0a             	shr    $0xa,%edx
80107bfa:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80107c00:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
80107c07:	85 c0                	test   %eax,%eax
80107c09:	74 d4                	je     80107bdf <copyuvm+0x3f>
    if(!(*pte & PTE_P))
80107c0b:	8b 00                	mov    (%eax),%eax
80107c0d:	a8 01                	test   $0x1,%al
80107c0f:	0f 84 9f 00 00 00    	je     80107cb4 <copyuvm+0x114>
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
80107c15:	89 c7                	mov    %eax,%edi
    flags = PTE_FLAGS(*pte);
80107c17:	25 ff 0f 00 00       	and    $0xfff,%eax
80107c1c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    pa = PTE_ADDR(*pte);
80107c1f:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
    if((mem = kalloc()) == 0)
80107c25:	e8 c6 b6 ff ff       	call   801032f0 <kalloc>
80107c2a:	89 c3                	mov    %eax,%ebx
80107c2c:	85 c0                	test   %eax,%eax
80107c2e:	74 64                	je     80107c94 <copyuvm+0xf4>
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
80107c30:	83 ec 04             	sub    $0x4,%esp
80107c33:	81 c7 00 00 00 80    	add    $0x80000000,%edi
80107c39:	68 00 10 00 00       	push   $0x1000
80107c3e:	57                   	push   %edi
80107c3f:	50                   	push   %eax
80107c40:	e8 7b d7 ff ff       	call   801053c0 <memmove>
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
80107c45:	58                   	pop    %eax
80107c46:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80107c4c:	5a                   	pop    %edx
80107c4d:	ff 75 e4             	push   -0x1c(%ebp)
80107c50:	b9 00 10 00 00       	mov    $0x1000,%ecx
80107c55:	89 f2                	mov    %esi,%edx
80107c57:	50                   	push   %eax
80107c58:	8b 45 e0             	mov    -0x20(%ebp),%eax
80107c5b:	e8 90 f8 ff ff       	call   801074f0 <mappages>
80107c60:	83 c4 10             	add    $0x10,%esp
80107c63:	85 c0                	test   %eax,%eax
80107c65:	78 21                	js     80107c88 <copyuvm+0xe8>
  for(i = 0; i < sz; i += PGSIZE){
80107c67:	81 c6 00 10 00 00    	add    $0x1000,%esi
80107c6d:	3b 75 0c             	cmp    0xc(%ebp),%esi
80107c70:	0f 82 5a ff ff ff    	jb     80107bd0 <copyuvm+0x30>
  return d;

bad:
  freevm(d);
  return 0;
}
80107c76:	8b 45 e0             	mov    -0x20(%ebp),%eax
80107c79:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107c7c:	5b                   	pop    %ebx
80107c7d:	5e                   	pop    %esi
80107c7e:	5f                   	pop    %edi
80107c7f:	5d                   	pop    %ebp
80107c80:	c3                   	ret
80107c81:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      kfree(mem);
80107c88:	83 ec 0c             	sub    $0xc,%esp
80107c8b:	53                   	push   %ebx
80107c8c:	e8 9f b4 ff ff       	call   80103130 <kfree>
      goto bad;
80107c91:	83 c4 10             	add    $0x10,%esp
  freevm(d);
80107c94:	83 ec 0c             	sub    $0xc,%esp
80107c97:	ff 75 e0             	push   -0x20(%ebp)
80107c9a:	e8 91 fd ff ff       	call   80107a30 <freevm>
  return 0;
80107c9f:	83 c4 10             	add    $0x10,%esp
    return 0;
80107ca2:	c7 45 e0 00 00 00 00 	movl   $0x0,-0x20(%ebp)
}
80107ca9:	8b 45 e0             	mov    -0x20(%ebp),%eax
80107cac:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107caf:	5b                   	pop    %ebx
80107cb0:	5e                   	pop    %esi
80107cb1:	5f                   	pop    %edi
80107cb2:	5d                   	pop    %ebp
80107cb3:	c3                   	ret
      panic("copyuvm: page not present");
80107cb4:	83 ec 0c             	sub    $0xc,%esp
80107cb7:	68 d7 82 10 80       	push   $0x801082d7
80107cbc:	e8 bf 86 ff ff       	call   80100380 <panic>
80107cc1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80107cc8:	00 
80107cc9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80107cd0 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
80107cd0:	55                   	push   %ebp
80107cd1:	89 e5                	mov    %esp,%ebp
80107cd3:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107cd6:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80107cd9:	89 c1                	mov    %eax,%ecx
80107cdb:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80107cde:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107ce1:	f6 c2 01             	test   $0x1,%dl
80107ce4:	0f 84 f8 00 00 00    	je     80107de2 <uva2ka.cold>
  return &pgtab[PTX(va)];
80107cea:	c1 e8 0c             	shr    $0xc,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107ced:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  if((*pte & PTE_P) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
}
80107cf3:	5d                   	pop    %ebp
  return &pgtab[PTX(va)];
80107cf4:	25 ff 03 00 00       	and    $0x3ff,%eax
  if((*pte & PTE_P) == 0)
80107cf9:	8b 94 82 00 00 00 80 	mov    -0x80000000(%edx,%eax,4),%edx
  return (char*)P2V(PTE_ADDR(*pte));
80107d00:	89 d0                	mov    %edx,%eax
80107d02:	f7 d2                	not    %edx
80107d04:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80107d09:	05 00 00 00 80       	add    $0x80000000,%eax
80107d0e:	83 e2 05             	and    $0x5,%edx
80107d11:	ba 00 00 00 00       	mov    $0x0,%edx
80107d16:	0f 45 c2             	cmovne %edx,%eax
}
80107d19:	c3                   	ret
80107d1a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107d20 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
80107d20:	55                   	push   %ebp
80107d21:	89 e5                	mov    %esp,%ebp
80107d23:	57                   	push   %edi
80107d24:	56                   	push   %esi
80107d25:	53                   	push   %ebx
80107d26:	83 ec 0c             	sub    $0xc,%esp
80107d29:	8b 75 14             	mov    0x14(%ebp),%esi
80107d2c:	8b 45 0c             	mov    0xc(%ebp),%eax
80107d2f:	8b 55 10             	mov    0x10(%ebp),%edx
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
80107d32:	85 f6                	test   %esi,%esi
80107d34:	75 51                	jne    80107d87 <copyout+0x67>
80107d36:	e9 9d 00 00 00       	jmp    80107dd8 <copyout+0xb8>
80107d3b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  return (char*)P2V(PTE_ADDR(*pte));
80107d40:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80107d46:	8d 8b 00 00 00 80    	lea    -0x80000000(%ebx),%ecx
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char*)va0);
    if(pa0 == 0)
80107d4c:	81 fb 00 00 00 80    	cmp    $0x80000000,%ebx
80107d52:	74 74                	je     80107dc8 <copyout+0xa8>
      return -1;
    n = PGSIZE - (va - va0);
80107d54:	89 fb                	mov    %edi,%ebx
80107d56:	29 c3                	sub    %eax,%ebx
80107d58:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if(n > len)
80107d5e:	39 f3                	cmp    %esi,%ebx
80107d60:	0f 47 de             	cmova  %esi,%ebx
      n = len;
    memmove(pa0 + (va - va0), buf, n);
80107d63:	29 f8                	sub    %edi,%eax
80107d65:	83 ec 04             	sub    $0x4,%esp
80107d68:	01 c1                	add    %eax,%ecx
80107d6a:	53                   	push   %ebx
80107d6b:	52                   	push   %edx
80107d6c:	89 55 10             	mov    %edx,0x10(%ebp)
80107d6f:	51                   	push   %ecx
80107d70:	e8 4b d6 ff ff       	call   801053c0 <memmove>
    len -= n;
    buf += n;
80107d75:	8b 55 10             	mov    0x10(%ebp),%edx
    va = va0 + PGSIZE;
80107d78:	8d 87 00 10 00 00    	lea    0x1000(%edi),%eax
  while(len > 0){
80107d7e:	83 c4 10             	add    $0x10,%esp
    buf += n;
80107d81:	01 da                	add    %ebx,%edx
  while(len > 0){
80107d83:	29 de                	sub    %ebx,%esi
80107d85:	74 51                	je     80107dd8 <copyout+0xb8>
  if(*pde & PTE_P){
80107d87:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pde = &pgdir[PDX(va)];
80107d8a:	89 c1                	mov    %eax,%ecx
    va0 = (uint)PGROUNDDOWN(va);
80107d8c:	89 c7                	mov    %eax,%edi
  pde = &pgdir[PDX(va)];
80107d8e:	c1 e9 16             	shr    $0x16,%ecx
    va0 = (uint)PGROUNDDOWN(va);
80107d91:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
  if(*pde & PTE_P){
80107d97:	8b 0c 8b             	mov    (%ebx,%ecx,4),%ecx
80107d9a:	f6 c1 01             	test   $0x1,%cl
80107d9d:	0f 84 46 00 00 00    	je     80107de9 <copyout.cold>
  return &pgtab[PTX(va)];
80107da3:	89 fb                	mov    %edi,%ebx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107da5:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
80107dab:	c1 eb 0c             	shr    $0xc,%ebx
80107dae:	81 e3 ff 03 00 00    	and    $0x3ff,%ebx
  if((*pte & PTE_P) == 0)
80107db4:	8b 9c 99 00 00 00 80 	mov    -0x80000000(%ecx,%ebx,4),%ebx
  if((*pte & PTE_U) == 0)
80107dbb:	89 d9                	mov    %ebx,%ecx
80107dbd:	f7 d1                	not    %ecx
80107dbf:	83 e1 05             	and    $0x5,%ecx
80107dc2:	0f 84 78 ff ff ff    	je     80107d40 <copyout+0x20>
  }
  return 0;
}
80107dc8:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80107dcb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80107dd0:	5b                   	pop    %ebx
80107dd1:	5e                   	pop    %esi
80107dd2:	5f                   	pop    %edi
80107dd3:	5d                   	pop    %ebp
80107dd4:	c3                   	ret
80107dd5:	8d 76 00             	lea    0x0(%esi),%esi
80107dd8:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80107ddb:	31 c0                	xor    %eax,%eax
}
80107ddd:	5b                   	pop    %ebx
80107dde:	5e                   	pop    %esi
80107ddf:	5f                   	pop    %edi
80107de0:	5d                   	pop    %ebp
80107de1:	c3                   	ret

80107de2 <uva2ka.cold>:
  if((*pte & PTE_P) == 0)
80107de2:	a1 00 00 00 00       	mov    0x0,%eax
80107de7:	0f 0b                	ud2

80107de9 <copyout.cold>:
80107de9:	a1 00 00 00 00       	mov    0x0,%eax
80107dee:	0f 0b                	ud2
