#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"

static int lltoa(long long x, char *dst){
  char t[32]; int i=0, p=0;
  if(x==0){ dst[0]='0'; dst[1]='\n'; return 2; }
  if(x<0){ dst[p++]='-'; x=-x; }
  while(x>0){ t[i++] = '0' + (x%10); x/=10; }
  while(i--) dst[p++] = t[i];
  dst[p++] = '\n';
  return p;
}

int
main(int argc, char *argv[])
{
  char buf[1024]; int n=0;

  if(argc > 1){
    int pos=0;
    for(int i=1;i<argc;i++){
      for(char *s=argv[i]; *s; s++) buf[pos++]=*s;
      if(i+1<argc) buf[pos++]=' ';
    }
    n = pos;
  } else {
    n = read(0, buf, sizeof(buf)-1);
    if(n < 0) n = 0;
  }
  buf[n]=0;

  long long sum=0, cur=0; int innum=0;
  for(int i=0;i<n;i++){
    char c = buf[i];
    if(c>='0' && c<='9'){ innum=1; cur = cur*10 + (c-'0'); }
    else { if(innum){ sum+=cur; cur=0; innum=0; } }
  }
  if(innum) sum+=cur;

  int fd = open("result.txt", O_CREATE|O_WRONLY);
  if(fd < 0){ printf(1,"find_sum: open failed\n"); exit(); }

  char out[64];
  int len = lltoa(sum, out);
  write(fd, out, len);
  close(fd);
  exit();
}