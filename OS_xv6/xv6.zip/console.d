console.o: console.c /usr/include/stdc-predef.h types.h x86.h defs.h \
 param.h traps.h spinlock.h sleeplock.h fs.h file.h memlayout.h mmu.h \
 proc.h
