find_sum.o: find_sum.c /usr/include/stdc-predef.h types.h stat.h fcntl.h \
 user.h
